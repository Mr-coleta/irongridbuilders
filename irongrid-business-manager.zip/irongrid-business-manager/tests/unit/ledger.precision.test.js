// UNIT TESTS — precision, boundaries and exact outputs. Written after mutation testing showed that the first suite
// would not notice certain wrong results (period end dates, report names, ordering, reversal accounts, rounding splits).
// Every expected value here is worked out independently by hand, never copied from the engine's output.
'use strict';
const { describe, it } = require('node:test');
const assert = require('node:assert/strict');
const L = require(process.env.LEDGER_PATH || '../../engine/ledger.js');
const UGX = 0, USD = 2;
const sum = (lines, a) => lines.filter(l => l.a === a).reduce((t, l) => t + l.d - l.c, 0);
const J = (pid, date, at, lines) => ({ pid, date, at, lines });

describe('Exact boundaries', () => {
  it('report periods include BOTH the first and the last day', () => {
    const js = [J('a/1', '2026-10-01', 't1', [{ a: '1000', d: 100, c: 0 }, { a: '4000', d: 0, c: 100 }]), J('a/2', '2026-10-31', 't2', [{ a: '1000', d: 7, c: 0 }, { a: '4000', d: 0, c: 7 }]), J('a/3', '2026-11-01', 't3', [{ a: '1000', d: 1000, c: 0 }, { a: '4000', d: 0, c: 1000 }])];
    assert.equal(L.profitLoss(js, '2026-10-01', '2026-10-31').ti, 107); assert.equal(L.vatReturn(js, '2026-10-01', '2026-10-31').sales, 107);
    assert.equal(L.balances(js, '2026-10-31', '2026-10-31')['1000'].d, 7); assert.equal(L.trialBalance(js, '2026-10-31').dr, 107);
    assert.equal(L.generalLedger(js, '1000', '2026-10-31', '2026-10-31').length, 1); assert.equal(L.generalLedger(js, '1000', '2026-10-31', '2026-10-31')[0].bal, 107, 'opening balance carried in');
    const pb = [J('i/1', '2026-10-31', 't', [{ a: '1100', d: 50, c: 0, p: 'c' }, { a: '4000', d: 0, c: 50 }])]; assert.equal(L.partyBalances(pb, '1100', '2026-10-31').get('c'), 50, 'party balance as at its posting date includes it');
    assert.equal(L.partyBalances(pb, '1100', '2026-10-30').get('c'), undefined);
  });
  it('dates: January and December are valid months; day 31 only where it exists; leap years', () => {
    for (const d of ['2026-01-01', '2026-01-31', '2026-12-01', '2026-12-31', '2028-02-29', '2026-04-30']) assert.equal(L.validDate(d), true, d);
    for (const d of ['2026-02-29', '2026-04-31', '2026-12-32', '2026-00-01', '2026-13-01', '2026-01-00', '2026-1-1', 20261101, '']) assert.equal(L.validDate(d), false, String(d));
  });
  it('VAT rate: 0% and 100% allowed, 18.5% allowed, 100.5% and −0.5% refused', () => {
    for (const v of [0, 100, 18.5, '18', '']) assert.equal(L.calcDoc({ items: [{ qty: 1, price: 1000 }], vatRate: v }, UGX).err, '', 'VAT ' + v);
    for (const v of [100.5, -0.5, 101]) assert.ok(L.calcDoc({ items: [{ qty: 1, price: 1000 }], vatRate: v }, UGX).err, 'VAT ' + v);
    assert.equal(L.calcDoc({ items: [{ qty: 1, price: 1000 }], vatRate: 100 }, UGX).total, 2000);
  });
  it('exactly 6 decimals in a quantity or price is accepted; 7 is refused; the smallest stock quantity posts', () => {
    assert.equal(L.calcDoc({ items: [{ qty: '0.000001', price: '1.000001' }] }, UGX).err, ''); assert.ok(L.calcDoc({ items: [{ qty: 1, price: '0.0000001' }] }, UGX).err);
    const p = L.post('purchases', { date: '2026-11-01', supplierId: 's', vatRate: 0, items: [{ qty: 0.000001, price: 1000000, itemId: 'k' }] }, { dp: UGX }); assert.equal(p.err, undefined); assert.deepEqual(p.stockAfter.k, { q: 1, v: 1 });
    const g = L.post('receipts', { date: '2026-11-01', clientId: 'c', method: L.IN_KIND, amount: 5, goods: [{ itemId: 'k', qty: 0.000001, value: 5 }] }, { dp: UGX }); assert.equal(g.err, undefined);
  });
  it('zero is shown as 0, never −0', () => { assert.ok(Object.is(L.toMajor(0, USD), 0)); assert.ok(Object.is(L.toMajor(0, UGX), 0)); assert.equal(L.toMajor(-1, USD), -0.01); });
});

describe('Rounding splits between lines (largest remainder) — exact allocation', () => {
  const split = (items, dp = UGX) => L.calcDoc({ items, vatRate: 0 }, dp).lines;
  it('three lines of 0.4 make 1: the first line (tie, lowest position) gets it', () => assert.deepEqual(split([{ qty: 1, price: 0.4 }, { qty: 1, price: 0.4 }, { qty: 1, price: 0.4 }]), [1, 0, 0]));
  it('0.3 + 0.6 = 0.9 → 1: the larger remainder (0.6) gets it', () => assert.deepEqual(split([{ qty: 1, price: 0.3 }, { qty: 1, price: 0.6 }]), [0, 1]));
  it('2.6 + 2.6 + 2.6 = 7.8 → 8: whole parts 2,2,2 plus 2 extra to the first two', () => assert.deepEqual(split([{ qty: 1, price: 2.6 }, { qty: 1, price: 2.6 }, { qty: 1, price: 2.6 }]), [3, 3, 2]));
  it('1.2 + 3.7 + 0.45 = 5.35 → 5: whole parts 1,3,0 plus 1 to the largest remainder (0.7)', () => assert.deepEqual(split([{ qty: 1, price: 1.2 }, { qty: 1, price: 3.7 }, { qty: 1, price: 0.45 }]), [1, 4, 0]));
  it('USD cents: 0.333 × 3 lines = 0.999 → 1.00: 33,33,34? no — remainders equal, first gets it: 34,33,33', () => assert.deepEqual(split([{ qty: 1, price: 0.333 }, { qty: 1, price: 0.333 }, { qty: 1, price: 0.333 }], USD), [34, 33, 33]));
  it('whole amounts are not touched', () => assert.deepEqual(split([{ qty: 3, price: 1000 }, { qty: 2, price: 250 }]), [3000, 500]));
  it('USD whole cents: lines exactly as written', () => assert.deepEqual(split([{ qty: 1, price: 4.35 }, { qty: 2, price: 0.5 }], USD), [435, 100]));
});

describe('Chart of accounts and payment methods — independent tables', () => {
  it('each payment method posts to the cash account the business uses', () => {
    assert.deepEqual(L.CASH, { 'Cash': '1000', 'MTN Mobile Money': '1010', 'Airtel Money': '1020', 'Bank transfer': '1030', 'Cheque': '1030', 'Card': '1030', 'Other': '1050' });
    assert.deepEqual(L.CASH_ACCTS, ['1000', '1010', '1020', '1030', '1050']);
  });
  it('report rows carry the account NAMES', () => {
    const js = [J('a/1', '2026-11-01', 't', [{ a: '1000', d: 100, c: 0 }, { a: '4000', d: 0, c: 60 }, { a: '2100', d: 0, c: 40 }])];
    assert.deepEqual(L.trialBalance(js).rows.map(r => [r.a, r.name, r.type, r.dr, r.cr]), [['1000', 'Cash on hand', 'asset', 100, 0], ['2100', 'Output VAT (owed to URA)', 'liability', 0, 40], ['4000', 'Sales', 'income', 0, 60]]);
    assert.deepEqual(L.profitLoss(js).inc, [{ a: '4000', name: 'Sales', amt: 60 }]);
    const bs = L.balanceSheet(js); assert.deepEqual(bs.asset, [{ a: '1000', name: 'Cash on hand', amt: 100 }]); assert.deepEqual(bs.liability, [{ a: '2100', name: 'Output VAT (owed to URA)', amt: 40 }]);
  });
  it('an account whose debits equal its credits shows 0 / 0 on the trial balance', () => {
    const js = [J('a/1', '2026-11-01', 't', [{ a: '1000', d: 50, c: 0 }, { a: '4000', d: 0, c: 50 }]), J('a/2', '2026-11-02', 't2', [{ a: '1000', d: 0, c: 50 }, { a: '6900', d: 50, c: 0 }])];
    const row = L.trialBalance(js).rows.find(r => r.a === '1000'); assert.deepEqual([row.dr, row.cr], [0, 0]);
  });
});

describe('Balance sheet, P&L and VAT — exact figures', () => {
  // capital 1,000,000 (posted by hand here), drawings 200,000, sales 500,000 + VAT 90,000 received, expense 100,000, VAT paid 30,000
  const js = [
    J('x/1', '2026-11-01', 't1', [{ a: '1030', d: 1000000, c: 0 }, { a: '3000', d: 0, c: 1000000 }]),
    J('x/2', '2026-11-02', 't2', [{ a: '1100', d: 590000, c: 0, p: 'c' }, { a: '4000', d: 0, c: 500000 }, { a: '2100', d: 0, c: 90000 }]),
    J('receipts/3', '2026-11-03', 't3', [{ a: '1030', d: 590000, c: 0 }, { a: '1100', d: 0, c: 590000, p: 'c' }]),
    J('payments/4', '2026-11-04', 't4', [{ a: '3200', d: 200000, c: 0 }, { a: '1030', d: 0, c: 200000 }]),
    J('payments/5', '2026-11-05', 't5', [{ a: '6050', d: 100000, c: 0 }, { a: '1030', d: 0, c: 100000 }]),
    J('payments/6', '2026-11-06', 't6', [{ a: '2100', d: 30000, c: 0 }, { a: '1030', d: 0, c: 30000 }]),
    J('purchases/7', '2026-11-07', 't7', [{ a: '6000', d: 50000, c: 0 }, { a: '1300', d: 9000, c: 0 }, { a: '2000', d: 0, c: 59000, p: 's' }]),
  ];
  it('balance sheet: equity = capital − drawings + profit; assets = liabilities + equity', () => {
    const bs = L.balanceSheet(js);
    assert.deepEqual(bs.equityLines, [{ a: '3000', name: "Owner's capital", amt: 1000000 }, { a: '3200', name: "Owner's drawings", amt: -200000 }]);
    assert.equal(bs.earnings, 500000 - 100000 - 50000); assert.equal(bs.equity, 1000000 - 200000 + 350000);
    assert.equal(bs.assets, 1000000 + 590000 - 200000 - 100000 - 30000 + 9000); assert.equal(bs.liabilities, 90000 - 30000 + 59000); assert.ok(bs.ok);
  });
  it('P&L: income and expenses as positive amounts; gross and net', () => {
    const p = L.profitLoss(js); assert.deepEqual(p.exp, [{ a: '6000', name: 'Materials & supplies', amt: 50000 }, { a: '6050', name: 'Rent', amt: 100000 }]);
    assert.deepEqual([p.ti, p.te, p.gross, p.net], [500000, 150000, 500000, 350000]);
  });
  it('VAT return: output, input, net payable, sales, purchases, paid to URA — and a refundable position', () => {
    assert.deepEqual(L.vatReturn(js), { outputVat: 90000, inputVat: 9000, netVat: 81000, sales: 500000, purchases: 50000, paidToURA: 30000 });
    const r = L.vatReturn([js[6]]); assert.equal(r.netVat, -9000, 'more input than output = refundable');
    const back = J('payments/6:R', '2026-11-08', 't8', [{ a: '1030', d: 30000, c: 0 }, { a: '2100', d: 0, c: 30000 }]); assert.equal(L.vatReturn([...js, back]).paidToURA, 0, 'a voided VAT payment cancels out');
    const sd = J('sdebits/9', '2026-11-09', 't9', [{ a: '2000', d: 11800, c: 0, p: 's' }, { a: '1300', d: 0, c: 1800 }, { a: '6000', d: 0, c: 10000 }]); const v = L.vatReturn([...js, sd]); assert.equal(v.inputVat, 7200); assert.equal(v.purchases, 40000);
  });
});

describe('General ledger ordering and running balance', () => {
  it('same-day postings are listed in the order they were made, with the balance after each', () => {
    const js = [J('a/2', '2026-11-05', '2026-11-05T09:00:02Z', [{ a: '1000', d: 0, c: 30, }, { a: '6900', d: 30, c: 0 }]), J('a/1', '2026-11-05', '2026-11-05T09:00:01Z', [{ a: '1000', d: 100, c: 0 }, { a: '4000', d: 0, c: 100 }]), J('a/0', '2026-11-04', '2026-11-06T00:00:00Z', [{ a: '1000', d: 5, c: 0 }, { a: '4000', d: 0, c: 5 }])];
    assert.deepEqual(L.generalLedger(js, '1000').map(r => [r.pid, r.bal]), [['a/0', 5], ['a/1', 105], ['a/2', 75]]);
    assert.deepEqual(L.generalLedger(js, '4000').map(r => r.bal), [5, 105], 'credit-normal account shows a positive running balance');
    const rows = L.generalLedger([J('i/1', '2026-11-01', 't', [{ a: '1100', d: 9, c: 0, p: 'c' }, { a: '1200', d: 0, c: 9, i: 'k', q: -1 }])], '1200'); assert.deepEqual([rows[0].i, rows[0].p], ['k', '']);
  });
});

describe('Reversals — exact accounts and amounts', () => {
  it('void of a stock purchase when average cost has risen: stock out at the higher average, difference DEBITED to cost of sales (5000)', () => {
    const je = { lines: [{ a: '1200', d: 1000, c: 0, i: 'k', q: 10e6 }, { a: '2000', d: 0, c: 1000, p: 's' }] };   // bought 10 for 1,000
    const r = L.reverse(je, { k: { q: 20e6, v: 2400 } });                                                            // average now 120
    assert.equal(r.err, undefined); assert.deepEqual(r.lines.map(l => [l.a, l.d, l.c]), [['1200', 0, 1200], ['5000', 200, 0], ['2000', 1000, 0]]); assert.deepEqual(r.stockAfter.k, { q: 10e6, v: 1200 });
  });
  it('… and when average cost has fallen: difference CREDITED to cost of sales', () => {
    const r = L.reverse({ lines: [{ a: '1200', d: 1000, c: 0, i: 'k', q: 10e6 }, { a: '2000', d: 0, c: 1000, p: 's' }] }, { k: { q: 20e6, v: 1600 } });
    assert.deepEqual(r.lines.map(l => [l.a, l.d, l.c]), [['1200', 0, 800], ['5000', 0, 200], ['2000', 1000, 0]]);
  });
  it('void of a stock loss: the stock comes back with its quantity and the exact value it left with; loss account reversed', () => {
    const r = L.reverse({ lines: [{ a: '5100', d: 70, c: 0, i: 'k' }, { a: '1200', d: 0, c: 70, i: 'k', q: -2e6, k: 'avg' }] }, { k: { q: 1e6, v: 30 } });
    assert.deepEqual(r.lines, [{ a: '5100', d: 0, c: 70, i: 'k' }, { a: '1200', d: 70, c: 0, i: 'k', q: 2e6 }]); assert.deepEqual(r.stockAfter.k, { q: 3e6, v: 100 });
  });
  it('plain lines are mirrored with their client/supplier kept', () => { const r = L.reverse({ lines: [{ a: '1000', d: 5, c: 0 }, { a: '1100', d: 0, c: 5, p: 'c9' }] }, {}); assert.deepEqual(r.lines, [{ a: '1000', d: 0, c: 5 }, { a: '1100', d: 5, c: 0, p: 'c9' }]); });
});

describe('Messages users see', () => {
  it('error texts are specific', () => {
    assert.equal(L.balanced([{ a: '1000', d: 6, c: 0 }, { a: '4000', d: 0, c: 5 }]), "Debits (6) don't equal credits (5).");
    assert.equal(L.post('invoices', { date: '2026-11-04', clientId: 'c', vatRate: 0, items: [{ desc: 'Cement 50kg', qty: 2, price: 1, itemId: 'k' }] }, { dp: UGX, stock: { k: { q: 1e6, v: 1 } } }).err, 'Not enough Cement 50kg in stock for this. (Cement 50kg)');
    assert.equal(L.post('invoices', { date: '2026-11-04', clientId: 'c', vatRate: 0, items: [{ qty: 2, price: 1, itemId: 'k' }] }, { dp: UGX, stock: {} }).err, 'Not enough stock in stock for this. (item)');
    assert.equal(L.post('receipts', { date: '2026-11-04', clientId: 'c', amount: 0, method: 'Cash' }, { dp: UGX }).err, 'Amount must be above zero in whole shillings.');
    assert.equal(L.post('payments', { date: '2026-11-04', amount: '1.005', method: 'Cash' }, { dp: USD }).err, 'Amount must be above zero with at most 2 decimals.');
    assert.equal(L.post('refunds', { date: '2026-11-04', clientId: 'c', amount: -1, method: 'Cash' }, { dp: UGX }).err, 'Amount must be above zero in whole shillings.');
    assert.equal(L.post('receipts', { date: '2026-11-04', clientId: 'c', method: L.IN_KIND, amount: 0, goods: [{ itemId: 'k', qty: 1, value: 0 }] }, { dp: UGX }).err, 'Each line of goods needs a value above zero in whole shillings.');
  });
  it('stock replay explains a costing error with both figures', () => {
    const r = L.replayStock([J('x/1', 'd', 't1', [{ a: '1200', d: 100, c: 0, i: 'k', q: 2e6, n: 0 }]), J('x/2', 'd', 't2', [{ a: '1200', d: 0, c: 70, i: 'k', q: -1e6, k: 'avg', n: 1 }])]);
    assert.equal(r.issues[0].msg, 'Cost 70 differs from the moving-average cost 50.');
  });
  it('a damaged reversal and a tampered reversal are described as such', () => {
    const d = { date: '2026-11-01', clientId: 'c', amount: 5, method: 'Cash' }; const p = L.post('receipts', d, { dp: UGX }); const je = L.makeJE('receipts', 'r', d, p.lines, { cur: 'UGX', dp: 0, at: 't' });
    const rv = L.reverse(je, {}); const jr = L.makeRev('receipts', 'r', d, rv.lines, { cur: 'UGX', dp: 0, at: 't2', date: '2026-11-02' });
    const msgs = x => L.check([{ coll: 'receipts', id: 'r', doc: x }], { dp: UGX }).issues.map(i => i.msg);
    assert.deepEqual(msgs({ ...d, je, void: true, voidedAt: '2026-11-02', jr: { ...jr, lines: 5 } }), ['The reversal journal is damaged.']);
    assert.ok(msgs({ ...d, je, void: true, voidedAt: '2026-11-02', jr: { ...jr, reason: 'x', lines: jr.lines.map(l => ({ ...l, d: l.d * 2, c: l.c * 2 })) } }).includes('The reversal entry was changed after posting (fingerprint mismatch).'));
  });
});

describe('Journal identity and fingerprints', () => {
  it('FNV-1a matches the published test vectors', () => { assert.equal(L.fnv(''), '811c9dc5'); assert.equal(L.fnv('a'), 'e40c292c'); assert.equal(L.fnv('foobar'), 'bf9cf968'); });
  it('canonical JSON is exact and key-order independent', () => { assert.equal(L.canon({ b: 1, a: [2, 'x', null] }), '{"a":[2,"x",null],"b":1}'); assert.equal(L.canon([]), '[]'); assert.equal(L.canon(undefined), 'null'); });
  it('journal records carry version 1, empty who/reason when unknown', () => {
    const d = { date: '2026-11-01', clientId: 'c', amount: 5, method: 'Cash' }; const p = L.post('receipts', d, { dp: UGX });
    const je = L.makeJE('receipts', 'r', d, p.lines, { cur: 'UGX', dp: 0, at: 't' }); assert.deepEqual([je.v, je.by, je.pid, je.date, je.cur, je.dp], [1, '', 'receipts/r', '2026-11-01', 'UGX', 0]);
    const jr = L.makeRev('receipts', 'r', d, p.lines, { cur: 'UGX', dp: 0, at: 't', date: '2026-11-02' }); assert.deepEqual([jr.v, jr.by, jr.reason, jr.pid, jr.date], [1, '', '', 'receipts/r:R', '2026-11-02']);
  });
  it('the fingerprint source records exactly the fields a posting depends on', () => {
    assert.deepEqual(L.source('receipts', { date: '2026-11-01', clientId: 'c', amount: 5, method: 'Cash' }), { date: '2026-11-01', clientId: 'c', supplierId: null, amount: '5', method: 'Cash', category: null, goods: [] });
    assert.deepEqual(L.source('invoices', { date: '2026-11-01', clientId: 'c', vatRate: 18, items: [{ qty: 2, price: 3, itemId: 'k', restock: true }] }),
      { date: '2026-11-01', clientId: 'c', supplierId: null, items: [['2', '3', 'k', true]], vatRate: '18', invoiceId: null, purchaseId: null, account: null });
    assert.deepEqual(L.source('adjustments', { date: 'd', itemId: 'k', qty: -1 }), { date: 'd', clientId: null, supplierId: null, itemId: 'k', qty: '-1', value: '0' });
    assert.deepEqual(L.source('payments', { date: 'd', amount: 1, method: 'Cash', supplierId: 's', goods: [{ itemId: 'k', qty: 1, value: 2 }] }).goods, [['k', '1', '2']]);
  });
  it('unitCosts() ignores lines that are not sales out of stock', () => assert.deepEqual(L.unitCosts({ lines: [{ a: '1200', d: 50, c: 0, i: 'k', q: 1e6 }, { a: '1200', d: 0, c: 9, i: 'j', q: -1e6 }] }), {}));
  it('stock movements carry quantity, signed value, cost basis and sequence', () => assert.deepEqual(L.stockMovements({ pid: 'p', at: 't', lines: [{ a: '1200', d: 0, c: 9, i: 'j', q: -1e6, k: 'avg', n: 4 }, { a: '1000', d: 1, c: 0 }] }), [{ item: 'j', q: -1e6, v: -9, k: 'avg', at: 't', pid: 'p', n: 4 }]));
});

describe('Check memoisation', () => {
  it('an unchanged document is not re-verified; a currency change forces re-verification', () => {
    const d = { date: '2026-11-01', clientId: 'c', amount: 5, method: 'Cash' }; const p = L.post('receipts', d, { dp: UGX }); const doc = { ...d, je: L.makeJE('receipts', 'r', d, p.lines, { cur: 'UGX', dp: 0, at: 't' }) };
    const memo = new WeakMap(); const e = [{ coll: 'receipts', id: 'r', doc }]; L.check(e, { dp: UGX, memo }); const first = memo.get(doc);
    L.check(e, { dp: UGX, memo }); assert.equal(memo.get(doc), first, 'reused'); L.warm(e, { dp: UGX, memo }, 0, 1); assert.equal(memo.get(doc), first, 'warm() reuses too');
    L.check(e, { dp: USD, memo }); assert.notEqual(memo.get(doc), first, 'recomputed for another currency'); const second = memo.get(doc);
    L.warm([{ coll: 'receipts', id: 'other', doc }], { dp: USD, memo }, 0, 1); assert.notEqual(memo.get(doc), second, 'recomputed for another id');
  });
});

describe('Gaps found in mutation round 2', () => {
  it('P&L nets accounts that have both debits and credits (sales reduced by a credit note; expense reduced by a supplier credit)', () => {
    const js = [J('i/1', '2026-11-01', 't1', [{ a: '1100', d: 1000, c: 0, p: 'c' }, { a: '4000', d: 0, c: 1000 }]), J('c/1', '2026-11-02', 't2', [{ a: '4000', d: 300, c: 0 }, { a: '1100', d: 0, c: 300, p: 'c' }]),
      J('p/1', '2026-11-01', 't3', [{ a: '6000', d: 500, c: 0 }, { a: '2000', d: 0, c: 500, p: 's' }]), J('d/1', '2026-11-03', 't4', [{ a: '2000', d: 100, c: 0, p: 's' }, { a: '6000', d: 0, c: 100 }])];
    const p = L.profitLoss(js); assert.deepEqual([p.inc[0].amt, p.exp[0].amt, p.ti, p.te, p.net], [700, 400, 700, 400, 300]);
    assert.equal(L.vatReturn(js).sales, 700, 'VAT return sales net of credit notes');
  });
  it('gross profit with no sales at all is minus the cost of sales', () => { const p = L.profitLoss([J('a/1', 'd', 't', [{ a: '5000', d: 80, c: 0 }, { a: '1200', d: 0, c: 80 }])]); assert.equal(p.gross, -80); });
  it('a customer balance never includes supplier lines (and vice versa)', () => {
    const js = [J('x/1', '2026-11-01', 't', [{ a: '1100', d: 50, c: 0, p: 'c' }, { a: '2000', d: 0, c: 50, p: 's' }])];
    assert.deepEqual([...L.partyBalances(js, '1100')], [['c', 50]]); assert.deepEqual([...L.partyBalances(js, '2000')], [['s', 50]]);
    assert.deepEqual([...L.partyBalances([J('y/1', 'd', 't', [{ a: '1100', d: 9, c: 0 }, { a: '4000', d: 0, c: 9 }])], '1100')], [], 'a line without a party belongs to no one');
  });
  it('a total that exceeds the exact range is refused even when the subtotal fits', () => { const t = L.calcDoc({ items: [{ qty: 1, price: 9007199254740000 }], vatRate: 18 }, UGX); assert.match(t.err, /too large/); });
  it('the smallest amount (1 shilling / 1 cent) is accepted; zero is refused for every cash document', () => {
    for (const c of ['receipts', 'payments', 'refunds']) { const base = { date: '2026-11-04', clientId: 'c', method: 'Cash' };
      assert.equal(L.post(c, { ...base, amount: 1 }, { dp: UGX }).err, undefined, c + ' 1'); assert.equal(L.post(c, { ...base, amount: 0.01 }, { dp: USD }).err, undefined, c + ' 0.01');
      assert.match(L.post(c, { ...base, amount: 0 }, { dp: UGX }).err, /above zero/, c + ' 0'); }
    assert.equal(L.post('receipts', { date: '2026-11-04', clientId: 'c', method: 'Cash', amount: '1.005' }, { dp: USD }).err, 'Amount must be above zero with at most 2 decimals.');
    assert.equal(L.post('refunds', { date: '2026-11-04', clientId: 'c', method: 'Cash', amount: '1.005' }, { dp: USD }).err, 'Amount must be above zero with at most 2 decimals.');
    assert.equal(L.post('receipts', { date: '2026-11-04', clientId: 'c', method: L.IN_KIND, amount: 1, goods: [{ itemId: 'k', qty: 1, value: 1 }] }, { dp: UGX }).err, undefined, 'goods worth 1 shilling');
  });
  it('rounding split ties are broken by line order at every position, not just the first', () => {
    assert.deepEqual(L.calcDoc({ items: [{ qty: 1, price: 0.2 }, { qty: 1, price: 0.5 }, { qty: 1, price: 0.5 }] }, UGX).lines, [0, 1, 0]);
    assert.deepEqual(L.calcDoc({ items: [{ qty: 1, price: 0.1 }, { qty: 1, price: 0.6 }, { qty: 1, price: 0.6 }, { qty: 1, price: 0.6 }] }, UGX).lines, [0, 1, 1, 0]);   // 1.9 → 2: two units, ties broken by position
  });
  it('supplier debit note with too little stock names the line (or "item")', () => {
    assert.equal(L.post('sdebits', { date: '2026-11-04', supplierId: 's', vatRate: 0, items: [{ qty: 2, price: 1, itemId: 'k' }] }, { dp: UGX, stock: {} }).err, 'Not enough stock in stock for this. (item)');
  });
  it('the fingerprint source for a zero-VAT document records VAT as 0', () => { assert.equal(L.source('invoices', { date: 'd', clientId: 'c', vatRate: 0, items: [] }).vatRate, '0'); });
  it('stock value going below zero while quantity stays positive is reported', () => {
    const r = L.replayStock([J('x/1', 'd', 't1', [{ a: '1200', d: 10, c: 0, i: 'k', q: 2e6, n: 0 }]), J('x/2', 'd', 't2', [{ a: '1200', d: 0, c: 20, i: 'k', q: -1e6, n: 1 }])]);
    assert.ok(r.issues.some(i => /below zero/.test(i.msg)), JSON.stringify(r.issues));
  });
  it('recomputation explains a stock line that no longer matches its document', () => {
    const d = { date: '2026-11-04', clientId: 'c', vatRate: 0, items: [{ qty: 1, price: 5, itemId: 'k' }] }; const p = L.post('invoices', d, { dp: UGX, stock: { k: { q: 1e6, v: 3 } } }); L.numberStock(p.lines, {});
    const je = L.makeJE('invoices', 'i', d, p.lines, { cur: 'UGX', dp: 0, at: 't' }); const changed = { ...d, items: [{ qty: 1, price: 5, itemId: 'other' }] }; je.h = L.seal(je, 'invoices', changed);
    const msgs = L.check([{ coll: 'invoices', id: 'i', doc: { ...changed, je } }], { dp: UGX }).issues.map(i => i.msg); assert.ok(msgs.some(m => m.startsWith("Can't recompute this posting: Stock lines don't match")), JSON.stringify(msgs));
  });
  it('a cached check result is not reused for the same document filed under another id', () => {
    const d = { date: '2026-11-01', clientId: 'c', amount: 5, method: 'Cash' }; const p = L.post('receipts', d, { dp: UGX }); const doc = { ...d, je: L.makeJE('receipts', 'r', d, p.lines, { cur: 'UGX', dp: 0, at: 't' }) };
    const memo = new WeakMap(); assert.deepEqual(L.check([{ coll: 'receipts', id: 'r', doc }], { dp: UGX, memo }).issues, []);
    assert.ok(L.check([{ coll: 'receipts', id: 'other', doc }], { dp: UGX, memo }).issues.some(i => /Posting id/.test(i.msg)), 'stale cached result reused');
  });
  it('general ledger orders three same-day postings by when they were made, whatever order they arrive in', () => {
    const mk = (pid, at, d) => J(pid, '2026-11-05', at, [{ a: '1000', d, c: 0 }, { a: '4000', d: 0, c: d }]);
    assert.deepEqual(L.generalLedger([mk('c', 't3', 3), mk('b', 't2', 2), mk('a', 't1', 1), J('z', '2026-11-04', 't9', [{ a: '1000', d: 10, c: 0 }, { a: '4000', d: 0, c: 10 }])], '1000').map(r => r.pid), ['z', 'a', 'b', 'c']);
  });
});

describe('General ledger ordering under any arrival order', () => {
  it('eight postings over three days, shuffled: listed by date, then by when made', () => {
    const mk = (pid, date, at, d) => J(pid, date, at, [{ a: '1000', d, c: 0 }, { a: '4000', d: 0, c: d }]);
    const items = [mk('e', '2026-11-05', 't5', 5), mk('b', '2026-11-05', 't2', 2), mk('x', '2026-11-06', 't0', 9), mk('d', '2026-11-05', 't4', 4), mk('a', '2026-11-05', 't1', 1), mk('w', '2026-11-04', 't9', 8), mk('c', '2026-11-05', 't3', 3), mk('f', '2026-11-05', 't6', 6)];
    assert.equal(L.generalLedger(items, '1000').map(r => r.pid).join(''), 'wabcdefx');
  });
});
