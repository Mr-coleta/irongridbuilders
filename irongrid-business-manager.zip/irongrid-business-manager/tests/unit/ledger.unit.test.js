// UNIT TESTS — accounting engine (engine/ledger.js). Runner: node --test (built-in), with coverage.
// Each test states the CORRECT accounting behaviour. Tests are never edited to make wrong code pass.
'use strict';
const { describe, it } = require('node:test');
const assert = require('node:assert/strict');
const L = require(process.env.LEDGER_PATH || '../../engine/ledger.js');
const UGX = 0, USD = 2;
const AT = n => '2026-11-04T10:' + String(Math.floor(n / 60) % 60).padStart(2, '0') + ':' + String(n % 60).padStart(2, '0') + '.000Z';
const sum = (je, a) => je.lines.filter(l => l.a === a).reduce((t, l) => t + l.d - l.c, 0);
const inv = (items, vat = 18, extra = {}) => ({ number: 'INV-1', date: '2026-11-04', clientId: 'c1', vatRate: vat, items, ...extra });
const ok = r => { assert.equal(r.err, undefined, 'unexpected error: ' + r.err); assert.equal(L.balanced(r.lines), '', 'journal must balance'); return r; };
const refused = (r, re) => { assert.ok(r.err, 'should have been refused'); if (re) assert.match(r.err, re); assert.deepEqual(r.lines, []); };

// a small book that posts through the engine exactly like the app does (stock sequence numbers included)
function book(dp = UGX) {
  const docs = [], stock = {}, counts = {}; let n = 0;
  const apply = (lines, after) => { L.numberStock(lines, counts); for (const l of lines) if (l.a === '1200' && l.i) counts[l.i] = l.n + 1; Object.assign(stock, after); };
  return {
    docs, stock, dp,
    post(coll, id, d, extra = {}) { const r = L.post(coll, d, { dp, stock, ...extra }); if (r.err) return r; apply(r.lines, r.stockAfter); const je = L.makeJE(coll, id, d, r.lines, { cur: dp ? 'USD' : 'UGX', dp, at: AT(n++), by: 'tester' }); const doc = { ...d, je }; docs.push({ coll, id, doc }); return { doc, je }; },
    void(coll, id, date) { const e = docs.find(x => x.coll === coll && x.id === id); const r = L.reverse(e.doc.je, stock); if (r.err) return r; apply(r.lines, r.stockAfter); e.doc = { ...e.doc, void: true, voidedAt: date, jr: L.makeRev(coll, id, e.doc, r.lines, { cur: 'UGX', dp, at: AT(n++), by: 'tester', date, reason: 'test' }) }; return e; },
    journals() { return docs.flatMap(e => [e.doc.je, e.doc.jr].filter(Boolean)); },
  };
}

describe('Exact decimal arithmetic', () => {
  it('parses plain decimals exactly, rejects non-numbers', () => {
    assert.deepEqual(L.dec('12.50'), { n: 125n, s: 1 }); assert.deepEqual(L.dec('-0.5'), { n: -5n, s: 1 }); assert.deepEqual(L.dec('.5'), { n: 5n, s: 1 });
    assert.deepEqual(L.dec('5.'), { n: 5n, s: 0 }); assert.deepEqual(L.dec(' 7 '), { n: 7n, s: 0 }); assert.deepEqual(L.dec(10n), { n: 10n, s: 0 });
    assert.deepEqual(L.dec(1e-7), { n: 1n, s: 7 }); assert.equal(L.dec('abc'), null); assert.equal(L.dec(''), null); assert.equal(L.dec('.'), null);
    assert.equal(L.dec(NaN), null); assert.equal(L.dec(Infinity), null); assert.equal(L.dec('1,000'), null); assert.equal(L.dec(null), null);
  });
  it('rounds half away from zero at the currency precision', () => {
    assert.equal(L.rnd(25n, 1, 0), 3n); assert.equal(L.rnd(24n, 1, 0), 2n); assert.equal(L.rnd(-25n, 1, 0), -3n); assert.equal(L.rnd(5n, 0, 2), 500n);
    assert.equal(L.roundMinor('2.175', USD), 218); assert.equal(L.roundMinor('1500.5', UGX), 1501); assert.equal(L.roundMinor('x', UGX), null);
  });
  it('a typed amount with more decimals than the currency allows is refused, never rounded', () => {
    assert.equal(L.exactMinor('2.175', USD), null); assert.equal(L.exactMinor('1500.5', UGX), null); assert.equal(L.exactMinor(0.1 + 0.2, USD), null);
    assert.equal(L.exactMinor('2.17', USD), 217); assert.equal(L.exactMinor('1500', UGX), 1500); assert.equal(L.exactMinor('9007199254740993', UGX), null);
  });
  it('minor units convert back to amounts exactly', () => {
    assert.equal(L.toMajor(218, USD), 2.18); assert.equal(L.toMajor(-5, USD), -0.05); assert.equal(L.toMajor(1500, UGX), 1500); assert.equal(L.toMajor(7, USD), 0.07);
  });
  it('quantities to millionths; more than 6 decimals refused', () => {
    assert.equal(L.qtyMicro('2.5'), 2500000); assert.equal(L.qtyMicro('0.000001'), 1); assert.equal(L.qtyMicro('0.0000001'), null); assert.equal(L.qtyMicro('x'), null); assert.equal(L.microQty(2500000), 2.5);
  });
  it('a×b÷c rounds half up exactly, both signs; average cost of a part, all, too much, or from nothing', () => {
    assert.equal(L.mulDiv(10, 1, 3), 3); assert.equal(L.mulDiv(5, 1, 2), 3); assert.equal(L.mulDiv(-5, 1, 2), -3); assert.equal(L.mulDiv(4900000, 30, 150), 980000);
    assert.equal(L.avgCost({ q: 3, v: 10 }, 3), 10); assert.equal(L.avgCost({ q: 3, v: 10 }, 1), 3); assert.equal(L.avgCost({ q: 3, v: 10 }, 4), null); assert.equal(L.avgCost({ q: 0, v: 0 }, 1), null); assert.equal(L.avgCost(null, 1), null);
  });
});

describe('Document totals (calcDoc)', () => {
  it('known floating-point failures are exact: 0.5 × 4.35 = 2.18; mixed UGX lines = 13,007', () => {
    assert.equal(L.calcDoc({ items: [{ qty: 0.5, price: 4.35 }], vatRate: 16 }, USD).sub, 218);
    const u = L.calcDoc({ items: [{ qty: 0.35, price: 32000 }, { qty: 7, price: 0.7 }, { qty: 0.35, price: 15.5 }, { qty: 0.5, price: 4.35 }], vatRate: 16 }, UGX);
    assert.deepEqual([u.sub, u.vat, u.total], [11213, 1794, 13007]);
  });
  it('VAT rounds once on the subtotal (1,003 × 18% = 180.54 → 181)', () => { const t = L.calcDoc({ items: [{ qty: 1, price: 1003 }], vatRate: 18 }, UGX); assert.deepEqual([t.sub, t.vat, t.total], [1003, 181, 1184]); });
  it('fractional VAT rates are exact (12.5% of 1,001 = 125.125 → 125)', () => { assert.equal(L.calcDoc({ items: [{ qty: 1, price: 1001 }], vatRate: 12.5 }, UGX).vat, 125); });
  it('line amounts always add up to the subtotal (largest remainder), whatever the rounding', () => {
    const t = L.calcDoc({ items: [{ qty: 1, price: 0.4 }, { qty: 1, price: 0.4 }, { qty: 1, price: 0.4 }], vatRate: 0 }, UGX); assert.equal(t.sub, 1); assert.equal(t.lines.reduce((a, b) => a + b), 1);
    const u = L.calcDoc({ items: [{ qty: 3, price: 33333.335 }, { qty: 1, price: 0.5 }], vatRate: 18 }, UGX); assert.equal(u.lines.reduce((a, b) => a + b), u.sub);
  });
  it('empty or missing items give zero; no crash on garbage', () => { assert.equal(L.calcDoc({}, UGX).total, 0); assert.equal(L.calcDoc(null, UGX).total, 0); assert.equal(L.calcDoc({ items: 'x' }, UGX).total, 0); });
  it('EDGE: a non-numeric quantity or price is an error', () => { assert.match(L.calcDoc({ items: [{ qty: 'two', price: 5 }] }, UGX).err, /valid number/); });
  it('EDGE: more than 6 decimals in quantity or price is an error', () => { assert.match(L.calcDoc({ items: [{ qty: '0.0000001', price: 5 }] }, UGX).err, /6 decimal/); });
  it('EDGE: negative VAT is an error', () => { assert.match(L.calcDoc({ items: [{ qty: 1, price: 5 }], vatRate: -18 }, UGX).err, /negative/); });
  it('EDGE: an unreadable VAT rate is an error, not silently 0%', () => { assert.ok(L.calcDoc({ items: [{ qty: 1, price: 1000 }], vatRate: 'eighteen' }, UGX).err); });
  it('EDGE: a VAT rate above 100% is an error', () => { assert.ok(L.calcDoc({ items: [{ qty: 1, price: 1000 }], vatRate: 180 }, UGX).err); });
  it('EDGE: a negative quantity is an error (would hide sales and VAT)', () => { assert.ok(L.calcDoc({ items: [{ qty: 10, price: 1000 }, { qty: -2, price: 1000 }] }, UGX).err); });
  it('EDGE: a negative price is an error', () => { assert.ok(L.calcDoc({ items: [{ qty: 1, price: -1000 }] }, UGX).err); });
  it('EDGE: amounts beyond exact range are refused', () => { assert.match(L.calcDoc({ items: [{ qty: 1e6, price: 1e13 }] }, UGX).err, /too large/); });
});

describe('Posting rules — every journal balances and hits the right accounts', () => {
  it('sales invoice: Dr AR total / Cr Sales / Cr Output VAT; zero-VAT invoice has no VAT line', () => {
    const r = ok(L.post('invoices', inv([{ desc: 'Labour', qty: 2, price: 50000 }]), { dp: UGX }));
    assert.deepEqual([sum(r, '1100'), sum(r, '4000'), sum(r, '2100')], [118000, -100000, -18000]); assert.equal(r.lines.find(l => l.a === '1100').p, 'c1');
    const z = ok(L.post('invoices', inv([{ desc: 'x', qty: 1, price: 100 }], 0), { dp: UGX })); assert.ok(!z.lines.some(l => l.a === '2100'));
  });
  it('invoice refusals: no client, zero total, stock without quantity, insufficient stock', () => {
    refused(L.post('invoices', { ...inv([{ qty: 1, price: 10 }]), clientId: null }, { dp: UGX }), /client/);
    refused(L.post('invoices', inv([{ qty: 0, price: 10 }]), { dp: UGX }), /more than zero/);
    refused(L.post('invoices', inv([{ desc: 'C', qty: 0, price: 0, itemId: 'k' }, { qty: 1, price: 10 }]), { dp: UGX, stock: { k: { q: 5e6, v: 50 } } }), /quantity above zero/);
    refused(L.post('invoices', inv([{ desc: 'C', qty: 6, price: 10, itemId: 'k' }]), { dp: UGX, stock: { k: { q: 5e6, v: 50 } } }), /Not enough/);
  });
  it('INSUFFICIENT STOCK: selling the exact quantity on hand takes all the value; one unit more is refused', () => {
    const r = ok(L.post('invoices', inv([{ desc: 'C', qty: 5, price: 10, itemId: 'k' }]), { dp: UGX, stock: { k: { q: 5e6, v: 51 } } })); assert.equal(sum(r, '5000'), 51); assert.deepEqual(r.stockAfter.k, { q: 0, v: 0 });
    refused(L.post('invoices', inv([{ desc: 'C', qty: 5.000001, price: 10, itemId: 'k' }]), { dp: UGX, stock: { k: { q: 5e6, v: 51 } } }), /Not enough/);
  });
  it('the stock state passed in is never mutated (the poster works on a copy)', () => { const st = { k: { q: 5e6, v: 50 } }; L.post('invoices', inv([{ desc: 'C', qty: 2, price: 10, itemId: 'k' }]), { dp: UGX, stock: st }); assert.deepEqual(st, { k: { q: 5e6, v: 50 } }); });
  it('client debit note: Dr AR / Cr Sales / Cr VAT; needs a client', () => {
    const r = ok(L.post('debits', inv([{ desc: 'Transport', qty: 1, price: 100000 }]), { dp: UGX })); assert.deepEqual([sum(r, '1100'), sum(r, '4000'), sum(r, '2100')], [118000, -100000, -18000]);
    refused(L.post('debits', { ...inv([{ qty: 1, price: 1 }]), clientId: '' }, { dp: UGX }), /client/);
  });
  it('credit note: reverses sales and VAT; restocked goods come back at the invoice cost; refusals', () => {
    const r = ok(L.post('credits', inv([{ desc: 'C', qty: 2, price: 15000, itemId: 'k', restock: true }, { desc: 'disc', qty: 1, price: 1000 }]), { dp: UGX, unitCost: { k: { q: 3e6, v: 30001 } } }));
    assert.deepEqual([sum(r, '1100'), sum(r, '4000'), sum(r, '2100'), sum(r, '1200'), sum(r, '5000')], [-36580, 31000, 5580, 20001, -20001]);
    const n = ok(L.post('credits', inv([{ desc: 'C', qty: 2, price: 15000, itemId: 'k' }], 0), { dp: UGX })); assert.ok(!n.lines.some(l => l.a === '1200'), 'not restocked unless asked');
    refused(L.post('credits', inv([{ desc: 'C', qty: 1, price: 1, itemId: 'k', restock: true }]), { dp: UGX, unitCost: {} }), /wasn't sold/);
    refused(L.post('credits', inv([{ desc: 'C', qty: 0, price: 1, itemId: 'k', restock: true }, { qty: 1, price: 5 }]), { dp: UGX, unitCost: { k: { q: 1, v: 1 } } }), /above zero/);
    refused(L.post('credits', { ...inv([{ qty: 1, price: 1 }]), clientId: null }, { dp: UGX }), /client/);
  });
  it('purchase: stock lines to Inventory, other lines to the chosen expense, VAT to Input VAT, total to AP', () => {
    const r = ok(L.post('purchases', { date: '2026-11-01', supplierId: 's1', vatRate: 18, account: 'Transport & fuel', items: [{ desc: 'Bars', qty: 3, price: 40000, itemId: 'y12' }, { desc: 'Delivery', qty: 1, price: 50000 }] }, { dp: UGX }));
    assert.deepEqual([sum(r, '1200'), sum(r, '6040'), sum(r, '1300'), sum(r, '2000')], [120000, 50000, 30600, -200600]); assert.deepEqual(r.stockAfter.y12, { q: 3e6, v: 120000 });
    const d = ok(L.post('purchases', { date: '2026-11-01', supplierId: 's1', vatRate: 0, items: [{ desc: 'x', qty: 1, price: 10 }] }, { dp: UGX })); assert.equal(sum(d, '6000'), 10, 'default account Materials & supplies');
    refused(L.post('purchases', { date: '2026-11-01', supplierId: null, vatRate: 0, items: [{ qty: 1, price: 1 }] }, { dp: UGX }), /supplier/);
    refused(L.post('purchases', { date: '2026-11-01', supplierId: 's1', vatRate: 0, items: [{ qty: 0, price: 1, itemId: 'k' }, { qty: 1, price: 1 }] }, { dp: UGX }), /above zero/);
  });
  it('supplier debit note: returns at average cost, price difference to cost of sales (both directions), non-stock lines credit the expense', () => {
    const st = { k: { q: 20e6, v: 640000 } }; // average 32,000
    const hi = ok(L.post('sdebits', { date: '2026-11-04', supplierId: 's1', vatRate: 18, items: [{ desc: 'C', qty: 2, price: 34000, itemId: 'k' }] }, { dp: UGX, stock: st }));
    assert.deepEqual([sum(hi, '2000'), sum(hi, '1300'), sum(hi, '1200'), sum(hi, '5000')], [80240, -12240, -64000, -4000]);
    const lo = ok(L.post('sdebits', { date: '2026-11-04', supplierId: 's1', vatRate: 0, items: [{ desc: 'C', qty: 2, price: 30000, itemId: 'k' }] }, { dp: UGX, stock: st })); assert.equal(sum(lo, '5000'), 4000);
    const ex = ok(L.post('sdebits', { date: '2026-11-04', supplierId: 's1', vatRate: 0, account: 'Rent', items: [{ desc: 'over-charge', qty: 1, price: 5000 }] }, { dp: UGX })); assert.equal(sum(ex, '6050'), -5000);
    refused(L.post('sdebits', { date: '2026-11-04', supplierId: 's1', vatRate: 0, items: [{ desc: 'C', qty: 30, price: 1, itemId: 'k' }] }, { dp: UGX, stock: st }), /Not enough/);
    refused(L.post('sdebits', { date: '2026-11-04', supplierId: 's1', vatRate: 0, items: [{ desc: 'C', qty: 0, price: 0, itemId: 'k' }, { qty: 1, price: 1 }] }, { dp: UGX, stock: st }), /above zero/);
    refused(L.post('sdebits', { date: '2026-11-04', supplierId: null, vatRate: 0, items: [{ qty: 1, price: 1 }] }, { dp: UGX }), /supplier/);
  });
  it('receipt: Dr the cash account for each method / Cr AR', () => {
    for (const [m, a] of Object.entries(L.CASH)) { const r = ok(L.post('receipts', { date: '2026-11-04', clientId: 'c1', amount: 1000, method: m }, { dp: UGX })); assert.equal(sum(r, a), 1000, m); assert.equal(sum(r, '1100'), -1000); }
  });
  it('receipt refusals: zero, negative, fractional shillings, unknown method, no client', () => {
    for (const amount of [0, -500, '1500.5', 'abc']) refused(L.post('receipts', { date: '2026-11-04', clientId: 'c1', amount, method: 'Cash' }, { dp: UGX }), /Amount/);
    refused(L.post('receipts', { date: '2026-11-04', clientId: 'c1', amount: 10, method: 'Bitcoin' }, { dp: UGX }), /how the money/);
    refused(L.post('receipts', { date: '2026-11-04', clientId: null, amount: 10, method: 'Cash' }, { dp: UGX }), /client/);
  });
  it('settlement in goods (cement, no VAT): Dr Inventory at agreed value / Cr AR; refusals for bad lines and mismatched totals', () => {
    const g = { date: '2026-11-04', clientId: 'c1', method: L.IN_KIND, amount: 900000, goods: [{ itemId: 'cem50', qty: 30, value: 900000 }] };
    const r = ok(L.post('receipts', g, { dp: UGX })); assert.deepEqual([sum(r, '1200'), sum(r, '1100')], [900000, -900000]); assert.ok(r.lines.every(l => ['1200', '1100'].includes(l.a)));
    refused(L.post('receipts', { ...g, amount: 900001 }, { dp: UGX }), /must equal/);
    refused(L.post('receipts', { ...g, goods: [] }, { dp: UGX }), /List the goods/);
    refused(L.post('receipts', { ...g, goods: [{ itemId: null, qty: 1, value: 1 }] }, { dp: UGX }), /stock item/);
    refused(L.post('receipts', { ...g, goods: [{ itemId: 'x', qty: 0, value: 1 }] }, { dp: UGX }), /quantity/);
    refused(L.post('receipts', { ...g, goods: [{ itemId: 'x', qty: 1, value: 0 }] }, { dp: UGX }), /value/);
  });
  it('supplier payment: Dr AP / Cr cash; expense payment by category; owner drawings, loans and VAT to URA go to balance-sheet accounts', () => {
    const r = ok(L.post('payments', { date: '2026-11-04', supplierId: 's1', amount: 5000, method: 'Bank transfer' }, { dp: UGX })); assert.deepEqual([sum(r, '2000'), sum(r, '1030')], [5000, -5000]);
    for (const [cat, acc] of [['Rent', '6050'], ['Owner withdrawal', '3200'], ['Loan repayment', '2300'], ['VAT paid to URA', '2100'], ['Unknown thing', '6900']]) { const e = ok(L.post('payments', { date: '2026-11-04', amount: 100, method: 'Cash', category: cat }, { dp: UGX })); assert.equal(sum(e, acc), 100, cat); }
    refused(L.post('payments', { date: '2026-11-04', amount: -1, method: 'Cash' }, { dp: UGX }), /Amount/);
    refused(L.post('payments', { date: '2026-11-04', amount: 1, method: '' }, { dp: UGX }), /how the money/);
  });
  it('refunds: to a client Dr AR / Cr cash; from a supplier Dr cash / Cr AP; refusals', () => {
    const c = ok(L.post('refunds', { date: '2026-11-04', clientId: 'c1', amount: 200, method: 'Cash' }, { dp: UGX })); assert.deepEqual([sum(c, '1100'), sum(c, '1000')], [200, -200]);
    const s = ok(L.post('refunds', { date: '2026-11-04', supplierId: 's1', amount: 300, method: 'Cheque' }, { dp: UGX })); assert.deepEqual([sum(s, '1030'), sum(s, '2000')], [300, -300]);
    refused(L.post('refunds', { date: '2026-11-04', amount: 300, method: 'Cash' }, { dp: UGX }), /client or supplier/);
    refused(L.post('refunds', { date: '2026-11-04', clientId: 'c1', amount: 0, method: 'Cash' }, { dp: UGX }), /Amount/);
    refused(L.post('refunds', { date: '2026-11-04', clientId: 'c1', amount: 5, method: 'Barter' }, { dp: UGX }), /method/);
  });
  it('stock adjustments: gain at stated value (zero allowed), loss at average cost; refusals', () => {
    const st = { b: { q: 3e6, v: 300 } };
    const loss = ok(L.post('adjustments', { date: '2026-11-04', itemId: 'b', qty: -1 }, { dp: UGX, stock: st })); assert.deepEqual([sum(loss, '5100'), sum(loss, '1200')], [100, -100]);
    const gain = ok(L.post('adjustments', { date: '2026-11-04', itemId: 'b', qty: 2, value: 250 }, { dp: UGX, stock: st })); assert.deepEqual([sum(gain, '1200'), sum(gain, '4900')], [250, -250]);
    const free = L.post('adjustments', { date: '2026-11-04', itemId: 'b', qty: 2, value: 0 }, { dp: UGX, stock: st }); assert.equal(free.err, undefined); assert.equal(free.stockAfter.b.q, 5e6);
    refused(L.post('adjustments', { date: '2026-11-04', itemId: null, qty: 1 }, { dp: UGX }), /item/);
    refused(L.post('adjustments', { date: '2026-11-04', itemId: 'b', qty: 0 }, { dp: UGX }), /quantity/);
    refused(L.post('adjustments', { date: '2026-11-04', itemId: 'b', qty: -4 }, { dp: UGX, stock: st }), /Not enough/);
    refused(L.post('adjustments', { date: '2026-11-04', itemId: 'b', qty: 1, value: '1.5' }, { dp: UGX, stock: st }), /value/);
  });
  it('unknown document types are not posted', () => { refused(L.post('proformas', inv([{ qty: 1, price: 1 }]), { dp: UGX }), /isn't posted/); });
  it('EDGE: invalid calendar dates are refused on every document type', () => {
    for (const date of ['2026-02-30', '2026-13-01', '2026-00-10', '26-11-04', '', null]) {
      refused(L.post('invoices', { ...inv([{ qty: 1, price: 10 }]), date }, { dp: UGX }), /date/);
      refused(L.post('receipts', { date, clientId: 'c1', amount: 10, method: 'Cash' }, { dp: UGX }), /date/);
    }
    ok(L.post('invoices', { ...inv([{ qty: 1, price: 10 }]), date: '2028-02-29' }, { dp: UGX }));   // leap day is valid
  });
  it('EDGE: negative quantities and prices are refused when posting', () => {
    refused(L.post('invoices', inv([{ qty: 10, price: 1000 }, { qty: -2, price: 1000 }]), { dp: UGX }));
    refused(L.post('purchases', { date: '2026-11-01', supplierId: 's1', vatRate: 0, items: [{ qty: 1, price: -5 }, { qty: 1, price: 10 }] }, { dp: UGX }));
  });
  it('a journal posted in USD keeps cents exactly', () => { const r = ok(L.post('invoices', inv([{ qty: 0.5, price: 4.35 }], 16), { dp: USD })); assert.deepEqual([sum(r, '4000'), sum(r, '2100'), sum(r, '1100')], [-218, -35, 253]); });
});

describe('balanced() — the double-entry guard', () => {
  it('accepts equal debits and credits; rejects every malformed journal', () => {
    assert.equal(L.balanced([{ a: '1000', d: 5, c: 0 }, { a: '4000', d: 0, c: 5 }]), '');
    assert.match(L.balanced([]), /no lines/);
    assert.match(L.balanced([{ a: '9999', d: 5, c: 0 }, { a: '4000', d: 0, c: 5 }]), /Unknown account/);
    assert.match(L.balanced([{ a: '1000', d: 5.5, c: 0 }, { a: '4000', d: 0, c: 5.5 }]), /whole number/);
    assert.match(L.balanced([{ a: '1000', d: -5, c: 0 }, { a: '4000', d: 0, c: -5 }]), /whole number/);
    assert.match(L.balanced([{ a: '1000', d: 5, c: 5 }]), /either a debit or a credit/);
    assert.match(L.balanced([{ a: '1000', d: 0, c: 0 }]), /either a debit or a credit/);
    assert.match(L.balanced([{ a: '1000', d: 6, c: 0 }, { a: '4000', d: 0, c: 5 }]), /don't equal/);
    assert.match(L.balanced([{ a: '1000', d: Number.MAX_SAFE_INTEGER, c: 0 }, { a: '1010', d: Number.MAX_SAFE_INTEGER, c: 0 }, { a: '4000', d: 0, c: 1 }]), /too large/);
    assert.equal(L.balanced([{ a: '1200', d: 0, c: 0, i: 'k', q: 1 }]), '', 'zero-value stock count line is allowed');
  });
});

describe('Weighted average stock', () => {
  it('100 @32,000 + 50 @34,000, sell 30 then 120: cost 980,000 + 3,920,000, stock ends 0/0', () => {
    const b = book(); b.post('purchases', 'p1', { date: '2026-11-01', supplierId: 's', vatRate: 18, items: [{ desc: 'C', qty: 100, price: 32000, itemId: 'c' }] });
    b.post('purchases', 'p2', { date: '2026-11-02', supplierId: 's', vatRate: 18, items: [{ desc: 'C', qty: 50, price: 34000, itemId: 'c' }] });
    assert.equal(sum(b.post('invoices', 'i1', inv([{ desc: 'C', qty: 30, price: 40000, itemId: 'c' }])).je, '5000'), 980000);
    assert.equal(sum(b.post('invoices', 'i2', inv([{ desc: 'C', qty: 120, price: 40000, itemId: 'c' }])).je, '5000'), 3920000);
    assert.deepEqual(b.stock.c, { q: 0, v: 0 }); assert.deepEqual(L.replayStock(b.journals()).issues, []);
  });
  it('unitCosts() reports what each item cost on an invoice', () => {
    const b = book(); b.post('purchases', 'p', { date: '2026-11-01', supplierId: 's', vatRate: 0, items: [{ qty: 4, price: 10, itemId: 'k' }] });
    const je = b.post('invoices', 'i', inv([{ qty: 3, price: 20, itemId: 'k' }])).je; assert.deepEqual(L.unitCosts(je), { k: { q: 3e6, v: 30 } }); assert.deepEqual(L.unitCosts(null), {});
  });
  it('replay flags: stock going below zero, cost not at average, sequence break, missing sequence, value left with no stock', () => {
    const mk = (lines, pid = 'x/1', at = AT(1)) => ({ pid, at, date: '2026-11-04', lines });
    let r = L.replayStock([mk([{ a: '1200', d: 0, c: 10, i: 'k', q: -1e6, k: 'avg', n: 0 }])]); assert.ok(r.issues.some(i => /below zero/.test(i.msg)));
    r = L.replayStock([mk([{ a: '1200', d: 100, c: 0, i: 'k', q: 2e6, n: 0 }]), mk([{ a: '1200', d: 0, c: 70, i: 'k', q: -1e6, k: 'avg', n: 1 }], 'x/2', AT(2))]); assert.ok(r.issues.some(i => /moving-average/.test(i.msg)));
    r = L.replayStock([mk([{ a: '1200', d: 100, c: 0, i: 'k', q: 2e6, n: 0 }]), mk([{ a: '1200', d: 5, c: 0, i: 'k', q: 1e6, n: 0 }], 'x/2')]); assert.ok(r.issues.some(i => /sequence/.test(i.msg)));
    r = L.replayStock([mk([{ a: '1200', d: 100, c: 0, i: 'k', q: 2e6 }])]); assert.ok(r.issues.some(i => /no sequence number/.test(i.msg)));
    r = L.replayStock([mk([{ a: '1200', d: 100, c: 0, i: 'k', q: 2e6, n: 0 }]), mk([{ a: '1200', d: 0, c: 60, i: 'k', q: -2e6, n: 1 }], 'x/2')]); assert.ok(r.issues.some(i => /value of/.test(i.msg)));
    assert.deepEqual(L.stockMovements(null), []);
  });
});

describe('Voids — reversal entries', () => {
  it('a voided receipt gets a mirror entry on the void date; balances before the void date are unchanged', () => {
    const b = book(); b.post('receipts', 'r', { date: '2026-11-01', clientId: 'c1', amount: 500, method: 'Cash' }); const e = b.void('receipts', 'r', '2026-11-04');
    assert.equal(e.doc.jr.pid, 'receipts/r:R'); assert.equal(sum(e.doc.jr, '1000'), -500); assert.equal(L.balances(b.journals(), null, '2026-11-03')['1000'].d, 500);
    assert.equal(L.partyBalances(b.journals(), '1100').get('c1'), 0); assert.deepEqual(L.check(b.docs, { dp: UGX }).issues, []);
  });
  it('voiding a stock purchase: refused if the stock is gone; otherwise out at average with the difference to cost of sales', () => {
    const b = book(); b.post('purchases', 'p1', { date: '2026-11-01', supplierId: 's', vatRate: 0, items: [{ qty: 10, price: 100, itemId: 'k' }] });
    b.post('invoices', 'i', inv([{ qty: 5, price: 150, itemId: 'k' }])); assert.match(b.void('purchases', 'p1', '2026-11-04').err, /more stock/);
    b.post('purchases', 'p2', { date: '2026-11-02', supplierId: 's', vatRate: 0, items: [{ qty: 10, price: 130, itemId: 'k' }] });
    const e = b.void('purchases', 'p1', '2026-11-04'); assert.ok(!e.err); assert.deepEqual(L.check(b.docs, { dp: UGX }).issues, []);
  });
  it('voiding a stock loss puts the stock back at the value it left with', () => {
    const b = book(); b.post('purchases', 'p', { date: '2026-11-01', supplierId: 's', vatRate: 0, items: [{ qty: 3, price: 100, itemId: 'k' }] });
    b.post('adjustments', 'a', { date: '2026-11-02', itemId: 'k', qty: -1 }); const e = b.void('adjustments', 'a', '2026-11-04'); assert.ok(!e.err); assert.deepEqual(b.stock.k, { q: 3e6, v: 300 });
  });
  it('a reversal that would not balance is refused', () => { const r = L.reverse({ lines: [{ a: '9999', d: 1, c: 0 }, { a: '4000', d: 0, c: 1 }] }, {}); assert.match(r.err, /Unknown account/); });
});

describe('Integrity checks — detect, never correct', () => {
  const setup = () => { const b = book(); b.post('receipts', 'r1', { date: '2026-11-01', clientId: 'c1', amount: 500000, method: 'Cash' }); b.post('invoices', 'i1', inv([{ desc: 'W', qty: 1, price: 1000 }])); return b; };
  const issues = docs => L.check(docs, { dp: UGX }).issues.map(i => i.msg).join(' | ');
  const clone = b => JSON.parse(JSON.stringify(b.docs));
  it('a clean book has no issues, and check() does not change the documents', () => { const b = setup(); const before = JSON.stringify(b.docs); assert.equal(issues(b.docs), ''); assert.equal(JSON.stringify(b.docs), before); });
  it('detects: amount changed after posting', () => { const t = clone(setup()); t[0].doc.amount = 50000; assert.match(issues(t), /fingerprint|doesn't match/); });
  it('detects: unbalanced journal', () => { const t = clone(setup()); t[1].doc.je.lines[0].d += 1; assert.match(issues(t), /don't equal/); });
  it('detects: duplicate posting', () => { const t = clone(setup()); t.push({ ...t[0] }); assert.match(issues(t), /Duplicate posting/); });
  it('detects: unposted document; damaged journal', () => { const t = clone(setup()); delete t[1].doc.je; assert.match(issues(t), /Not posted/); const u = clone(setup()); u[1].doc.je = { lines: 'x' }; assert.match(issues(u), /Not posted/); });
  it('detects: void without reversal, and reversal without void', () => { const t = clone(setup()); t[0].doc.void = true; assert.match(issues(t), /no reversal/); const b = setup(); b.void('receipts', 'r1', '2026-11-04'); const u = clone(b); u[0].doc.void = false; assert.match(issues(u), /not marked void/); });
  it('detects: wrong posting id, another currency, invalid or mismatched dates', () => {
    let t = clone(setup()); t[0].doc.je.pid = 'receipts/other'; assert.match(issues(t), /Posting id/);
    t = clone(setup()); assert.match(L.check(t, { dp: USD }).issues.map(i => i.msg).join(), /another currency/);
    t = clone(setup()); t[0].doc.je.date = '2026-1-1'; assert.match(issues(t), /date is invalid/);
    t = clone(setup()); t[0].doc.date = '2026-11-02'; assert.match(issues(t), /differs from the document date|fingerprint/);
    const b = setup(); b.void('receipts', 'r1', '2026-11-04'); t = clone(b); t[0].doc.voidedAt = '2026-11-05'; assert.match(issues(t), /void date/);
  });
  it('detects: re-sealed journal posted to the wrong account', () => { const t = clone(setup()); const j = t[1].doc.je; j.lines.find(l => l.a === '4000').a = '4900'; j.h = L.seal(j, 'invoices', t[1].doc); assert.match(issues(t), /doesn't match/); });
  it('detects: reversal that does not mirror the original; damaged reversal', () => {
    const b = book(); b.post('receipts', 'r', { date: '2026-11-01', clientId: 'c1', amount: 500, method: 'Cash' }); b.void('receipts', 'r', '2026-11-04');
    const t = clone(b); t[0].doc.jr.lines[0].a = '1010'; t[0].doc.jr.h = L.seal(t[0].doc.jr, 'receipts', null); assert.match(issues(t), /mirror/);
    const u = clone(b); u[0].doc.jr = { pid: 'x' }; assert.match(issues(u), /damaged/);
  });
  it('detects: a posting that can no longer be recomputed (source broken)', () => { const t = clone(setup()); t[0].doc.method = 'Teleport'; t[0].doc.je.h = L.seal(t[0].doc.je, 'receipts', t[0].doc); assert.match(issues(t), /recompute/); });
  it('detects: two sales costed from the same stock figures (lost lock)', () => {
    const b = book(); b.post('purchases', 'p1', { date: '2026-11-01', supplierId: 's', vatRate: 0, items: [{ desc: 'C', qty: 10, price: 100, itemId: 'cem' }] });
    const before = JSON.parse(JSON.stringify(b.stock)); b.post('invoices', 'i1', inv([{ desc: 'C', qty: 4, price: 150, itemId: 'cem' }]));
    const d = inv([{ desc: 'C', qty: 4, price: 150, itemId: 'cem' }]); const r = L.post('invoices', d, { dp: UGX, stock: before }); L.numberStock(r.lines, { cem: 1 });
    b.docs.push({ coll: 'invoices', id: 'i2', doc: { ...d, je: L.makeJE('invoices', 'i2', d, r.lines, { cur: 'UGX', dp: 0, at: AT(9) }) } }); assert.match(issues(b.docs), /out of sequence/);
  });
  it('per-document results are memoised and reused only while the document object is unchanged', () => {
    const b = setup(); const memo = new WeakMap(); const o = { dp: UGX, memo }; L.check(b.docs, o); assert.ok(memo.has(b.docs[0].doc));
    b.docs[0].doc = { ...b.docs[0].doc, amount: 1 }; assert.match(L.check(b.docs, o).issues.map(i => i.msg).join(), /fingerprint|doesn't match/, 'a changed object must be re-checked');
    const w = setup(); const m2 = new WeakMap(); L.warm(w.docs.map(x => ({ ...x })), { dp: UGX, memo: m2 }, 0, 10); L.warm([], { dp: UGX }, 0, 1);
  });
});

describe('Reports', () => {
  const build = () => {
    const b = book(); b.post('purchases', 'p1', { date: '2026-10-28', supplierId: 's', vatRate: 18, items: [{ desc: 'Cement', qty: 100, price: 32000, itemId: 'cem' }] });
    b.post('invoices', 'i1', inv([{ desc: 'Cement', qty: 40, price: 40000, itemId: 'cem' }, { desc: 'Labour', qty: 1, price: 200000 }]));
    b.post('receipts', 'r1', { date: '2026-11-04', clientId: 'c1', amount: 1000000, method: 'Bank transfer', invoiceId: 'i1' });
    b.post('payments', 'y1', { date: '2026-11-04', supplierId: 's', amount: 2000000, method: 'Bank transfer' });
    b.post('payments', 'y2', { date: '2026-11-04', amount: 50000, method: 'Cash', category: 'Transport & fuel' });
    b.post('payments', 'y3', { date: '2026-11-04', amount: 100000, method: 'Bank transfer', category: 'VAT paid to URA' });
    b.post('sdebits', 'd1', { date: '2026-11-05', supplierId: 's', vatRate: 18, items: [{ desc: 'Cement', qty: 1, price: 32000, itemId: 'cem' }] });
    return b;
  };
  it('trial balance and balance sheet balance; P&L and VAT return agree with the postings', () => {
    const J = build().journals(); const tb = L.trialBalance(J); assert.ok(tb.ok); assert.equal(tb.dr, tb.cr);
    const bs = L.balanceSheet(J); assert.ok(bs.ok, JSON.stringify([bs.assets, bs.liabilities, bs.equity])); assert.ok(Array.isArray(bs.equityLines));
    const pl = L.profitLoss(J); assert.deepEqual([pl.ti, pl.te, pl.net, pl.gross], [1800000, 1330000, 470000, 1800000 - 1280000]);
    const v = L.vatReturn(J); assert.deepEqual([v.outputVat, v.inputVat, v.sales, v.purchases, v.paidToURA], [324000, 576000 - 5760, 1800000, 3200000 - 32000, 100000]);
  });
  it('period reports: October and November add up to the whole; a document dated 31 Oct is in October only (month-end cut-off)', () => {
    const J = build().journals(); const oct = L.vatReturn(J, '2026-10-01', '2026-10-31'), nov = L.vatReturn(J, '2026-11-01', '2026-11-30'), all = L.vatReturn(J);
    assert.equal(oct.inputVat, 576000); assert.equal(nov.inputVat, -5760); assert.equal(oct.inputVat + nov.inputVat, all.inputVat); assert.equal(oct.outputVat, 0);
    const pO = L.profitLoss(J, '2026-10-01', '2026-10-31'), pN = L.profitLoss(J, '2026-11-01', '2026-11-30'), pA = L.profitLoss(J); assert.equal(pO.net + pN.net, pA.net);
  });
  it('general ledger: running balance, opening balance carried from before the period, period filter', () => {
    const J = build().journals(); const all = L.generalLedger(J, '1030'); assert.equal(all.at(-1).bal, 1000000 - 2000000 - 100000);
    const nov5 = L.generalLedger(J, '2000', '2026-11-05'); assert.equal(nov5.length, 1); assert.equal(nov5[0].bal, 3776000 - 2000000 - 37760);
    assert.equal(L.generalLedger(J, '4000', null, '2026-10-31').length, 0); assert.equal(L.generalLedger(J, '4000').at(-1).bal, 1800000, 'income shows as a positive balance');
  });
  it('customer and supplier ledgers by party; as at a date', () => {
    const J = build().journals(); assert.equal(L.partyBalances(J, '1100').get('c1'), 2124000 - 1000000);   // invoice 1,800,000 + VAT 324,000, less receipt
    assert.equal(L.partyBalances(J, '2000').get('s'), 3776000 - 2000000 - 37760); assert.equal(L.partyBalances(J, '2000', '2026-10-31').get('s'), 3776000);
  });
  it('trial balance as at a date excludes later postings', () => { const J = build().journals(); assert.equal(L.trialBalance(J, '2026-10-31').dr, 3776000); });
});

describe('Fingerprint and identity', () => {
  it('canonical form ignores key order; fnv is stable', () => { assert.equal(L.canon({ b: 1, a: [2, { d: 3, c: undefined }] }), L.canon({ a: [2, { c: null, d: 3 }], b: 1 })); assert.equal(L.fnv('abc'), L.fnv('abc')); assert.notEqual(L.fnv('abc'), L.fnv('abd')); });
  it('the fingerprint covers amounts and source fields but not who/when', () => {
    const d = { date: '2026-11-04', clientId: 'c1', amount: 10, method: 'Cash' }; const r = L.post('receipts', d, { dp: UGX });
    const a = L.makeJE('receipts', 'x', d, r.lines, { cur: 'UGX', dp: 0, at: AT(1), by: 'u1' }), b = L.makeJE('receipts', 'x', d, r.lines, { cur: 'UGX', dp: 0, at: AT(2), by: 'u2' });
    assert.equal(a.h, b.h); assert.notEqual(a.h, L.makeJE('receipts', 'x', { ...d, amount: 11 }, r.lines, { cur: 'UGX', dp: 0, at: AT(1) }).h);
    assert.deepEqual(Object.keys(L.source('adjustments', { itemId: 'k', qty: 1 })).sort(), ['clientId', 'date', 'itemId', 'qty', 'supplierId', 'value']);
  });
});
