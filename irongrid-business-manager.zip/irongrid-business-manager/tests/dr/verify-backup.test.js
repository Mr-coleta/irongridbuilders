// Regression test for the backup gap found on 7 Nov 2026: the daily backup listed people's logs through "audit",
// whose per-person parent records don't exist, so audit/<person>/errors (and days) were silently left out, and the run
// could not confirm the platform's record count. The verifier must now refuse to call such a backup VERIFIED.
// Fixtures are built from the verified 6 Nov production snapshot (dr/prod-snapshot-2026-11-06.json), never retyped.
'use strict';
const assert = require('node:assert'); const results = []; let n = 0;
const test = (name, fn) => { const id = 'BK-' + String(++n).padStart(2, '0'); try { fn(); results.push({ id, name, pass: true, detail: '' }); } catch (e) { results.push({ id, name, pass: false, detail: e.message.split('\n')[0] }); } const r = results.at(-1); console.log(`${r.pass ? 'PASS' : 'FAIL'}  ${id}  ${name}${r.detail ? '  — ' + r.detail : ''}`); }; const fs = require('fs'); const os = require('os'); const path = require('path'); const { execFileSync } = require('child_process');
const ROOT = path.join(__dirname, '../..'); const SNAP = JSON.parse(fs.readFileSync(path.join(ROOT, 'dr/prod-snapshot-2026-11-06.json'), 'utf8'));
const run = (obj) => { const f = path.join(os.tmpdir(), 'vb-' + Math.random().toString(36).slice(2) + '.json'); fs.writeFileSync(f, JSON.stringify(obj));
  try { return { code: 0, out: JSON.parse(execFileSync(process.execPath, [path.join(ROOT, 'tools/verify-backup.js'), f, '--json'], { encoding: 'utf8' })) }; }
  catch (e) { return { code: e.status, out: JSON.parse(e.stdout) }; } finally { fs.unlinkSync(f); } };
const check = (r, label) => r.out.checks.find(c => c.label.startsWith(label));
test('complete backup with a matching platform count is VERIFIED', () => {
  const r = run(SNAP); assert.equal(r.out.verdict, 'VERIFIED', JSON.stringify(r.out.checks.filter(c => !c.ok))); assert.equal(r.code, 0); });
test('a backup missing a record the platform has (an audit/error log) is NOT VERIFIED', () => {
  const r = run({ ...SNAP, usage: { documents: 7 } }); assert.equal(r.out.verdict, 'NOT VERIFIED'); assert.equal(r.code, 1);
  const c = check(r, 'Every record in the store was captured'); assert.ok(c && !c.ok && /backup has 6, the platform reported 7/.test(c.detail), JSON.stringify(c)); });
test('a backup whose platform count could not be read (the 7 Nov case) is NOT VERIFIED', () => {
  const r = run({ ...SNAP, usage: { available: false, note: 'db_usage tool not available in this run' } }); assert.equal(r.out.verdict, 'NOT VERIFIED');
  const c = check(r, 'Every record in the store was captured'); assert.ok(c && !c.ok && /could not be confirmed/.test(c.detail)); });
test('records created during the run and listed are allowed; unlisted extras are not', () => {
  const extra = { ...SNAP.documents, 'audit/u_x/errors/2026-11-07': { version: 1, data: { day: '2026-11-07', events: [] } } };
  assert.equal(run({ ...SNAP, documents: extra, documentsCollected: 7, usage: { documents: 6 }, createdDuringRun: ['audit/u_x/errors/2026-11-07'] }).out.verdict, 'VERIFIED');
  assert.equal(run({ ...SNAP, documents: extra, documentsCollected: 7, usage: { documents: 6 } }).out.verdict, 'NOT VERIFIED'); });
test('a header count that disagrees with the file is NOT VERIFIED', () => {
  const r = run({ ...SNAP, documentsCollected: 9 }); assert.equal(r.out.verdict, 'NOT VERIFIED'); assert.ok(!check(r, 'Header count').ok); });

fs.mkdirSync(path.join(ROOT, 'tests/reports'), { recursive: true }); fs.writeFileSync(path.join(ROOT, 'tests/reports/backup-verifier.json'), JSON.stringify({ ranAt: new Date().toISOString(), results }, null, 1));
process.exit(results.some(r => !r.pass) ? 1 : 0);
