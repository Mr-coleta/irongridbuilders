// Unit tests for the accounting engine (engine/ledger.js). Run: node tests/engine.test.js
const L = require('../engine/ledger.js');
const results = []; let cur = '';
function test(id, name, fn) { cur = id; try { const d = fn(); results.push({ id, name, pass: true, detail: d || '' }); console.log('PASS  ' + id + '  ' + name + (d ? '  — ' + d : '')); } catch (e) { results.push({ id, name, pass: false, detail: e.message }); console.log('FAIL  ' + id + '  ' + name + '  — ' + e.message); } }
const eq = (a, b, m) => { if (JSON.stringify(a) !== JSON.stringify(b)) throw new Error((m || '') + ' expected ' + JSON.stringify(b) + ' got ' + JSON.stringify(a)); };
const ok = (c, m) => { if (!c) throw new Error(m); };
const UGX = 0, USD = 2; const AT = (n) => '2026-11-04T10:00:' + String(n).padStart(2, '0') + '.000Z';

// independent reference: BigInt, half-up, written separately from the engine
const sc = s => { s = String(s); const neg = s[0] === '-'; if (neg) s = s.slice(1); const [a, b = ''] = s.split('.'); return { n: BigInt((neg ? '-' : '') + a + b), d: b.length }; };
const ref = (d, m) => { let num = 0n; const terms = d.items.map(i => { const q = sc(i.qty), p = sc(i.price); return { n: q.n * p.n, d: q.d + p.d }; }); const D = Math.max(0, ...terms.map(t => t.d)); for (const t of terms) num += t.n * 10n ** BigInt(D - t.d);
  const round = (n, from, to) => { if (from <= to) return n * 10n ** BigInt(to - from); const f = 10n ** BigInt(from - to); return (n * 2n + f) / (2n * f); };
  const sub = round(num, D, m); const r = sc(d.vatRate); const vat = round(sub * r.n, m + r.d + 2, m); return { sub: Number(sub), vat: Number(vat), total: Number(sub + vat) }; };

test('M-01', 'Known floating-point failures are now exact (0.5 × 4.35 = 2.175 → 2.18)', () => {
  eq(L.calcDoc({ items: [{ qty: 0.5, price: 4.35 }], vatRate: 16 }, USD).sub, 218);
  const u = L.calcDoc({ items: [{ qty: 0.35, price: 32000 }, { qty: 7, price: 0.7 }, { qty: 0.35, price: 15.5 }, { qty: 0.5, price: 4.35 }], vatRate: 16 }, UGX);
  eq([u.sub, u.vat, u.total], [11213, 1794, 13007]); return 'USD 2.18; UGX 13,007 (float gave 2.17 and 13,006)';
});
test('M-02', '200,000 random documents: engine equals an independent exact reference in every case', () => {
  const rnd = a => a[Math.floor(Math.random() * a.length)]; let n = 0;
  for (let k = 0; k < 200000; k++) { const items = []; const c = 1 + Math.floor(Math.random() * 4); for (let j = 0; j < c; j++) items.push({ qty: rnd([1, 2, 3, 0.5, 0.1, 0.3, 1.25, 2.5, 0.05, 0.15, 7, 12.5, 0.35, 1000, 0.000001]), price: rnd([1000, 32000, 1.005, 0.1, 0.7, 2.675, 1050.5, 999.99, 10.05, 1.15, 4.35, 0.285, 34000.5, 15.5, 123456.789]) });
    const d = { items, vatRate: rnd([0, 18, 16, 7.5, 18.5, 12.5]) };
    for (const m of [UGX, USD]) { const a = L.calcDoc(d, m), b = ref(d, m); if (a.sub !== b.sub || a.vat !== b.vat || a.total !== b.total) throw new Error('mismatch ' + JSON.stringify({ d, a, b })); if (a.lines.reduce((x, y) => x + y, 0) !== a.sub) throw new Error('lines do not add to subtotal ' + JSON.stringify(d)); n++; } }
  return n + ' calculations, 0 differences; line splits always add to the subtotal';
});
test('M-03', 'Amounts with more decimals than the currency allows are rejected, not rounded', () => {
  eq(L.exactMinor('2.175', USD), null); eq(L.exactMinor('1500.5', UGX), null); eq(L.exactMinor('1500', UGX), 1500); eq(L.exactMinor('2.17', USD), 217); eq(L.exactMinor(0.1 + 0.2, USD), null);
  eq(L.exactMinor('abc', UGX), null); eq(L.exactMinor('9007199254740993', UGX), null); eq(L.qtyMicro('0.0000001'), null); return '2.175 USD, 1500.5 UGX, 0.1+0.2 and unsafe sizes refused';
});
test('M-04', 'VAT rounds once on the subtotal, half up (UGX 1,003 × 18% = 180.54 → 181)', () => { const t = L.calcDoc({ items: [{ qty: 1, price: 1003 }], vatRate: 18 }, UGX); eq([t.sub, t.vat, t.total], [1003, 181, 1184]); });

// ---------- postings ----------
const dp = UGX; const meta = n => ({ cur: 'UGX', dp, at: AT(n), by: 'u1' });
function book() { const docs = []; const stock = {}; let n = 0; const counts = {};
  return {
    docs, stock,
    post(coll, id, d, extra = {}) { const r = L.post(coll, d, { dp, stock, ...extra }); if (r.err) return r; L.numberStock(r.lines, counts); for (const l of r.lines) if (l.a === '1200' && l.i) counts[l.i] = l.n + 1;
      const je = L.makeJE(coll, id, d, r.lines, meta(n++)); const doc = { ...d, je }; docs.push({ coll, id, doc }); Object.assign(stock, r.stockAfter); return { doc, je }; },
    void(coll, id, date) { const e = docs.find(x => x.coll === coll && x.id === id); const r = L.reverse(e.doc.je, stock); if (r.err) return r; L.numberStock(r.lines, counts); for (const l of r.lines) if (l.a === '1200' && l.i) counts[l.i] = l.n + 1;
      e.doc = { ...e.doc, void: true, voidedAt: date, jr: L.makeRev(coll, id, e.doc, r.lines, { ...meta(n++), date }) }; Object.assign(stock, r.stockAfter); return e; },
    journals() { return docs.flatMap(e => [e.doc.je, e.doc.jr].filter(Boolean)); },
  };
}
const inv = (id, items, vat = 18) => ({ number: id, date: '2026-11-04', clientId: 'hima', vatRate: vat, items });
const acct = (je, a) => je.lines.filter(l => l.a === a).reduce((t, l) => t + l.d - l.c, 0);

test('P-01', 'Invoice: Dr receivables = Cr sales + Cr output VAT, balanced, posting id = document path', () => {
  const b = book(); const { je } = b.post('invoices', 'i1', inv('INV-1', [{ desc: 'Labour', qty: 2, price: 50000 }]));
  eq([acct(je, '1100'), acct(je, '4000'), acct(je, '2100')], [118000, -100000, -18000]); eq(je.pid, 'invoices/i1'); ok(!L.balanced(je.lines), 'unbalanced'); return 'AR 118,000 = sales 100,000 + VAT 18,000';
});
test('P-02', 'Weighted average: 100 bags @32,000 + 50 @34,000, sell 30 then 120 — cost of sales exact, stock ends at 0/0', () => {
  const b = book(); b.post('purchases', 'p1', { date: '2026-11-01', supplierId: 's', vatRate: 18, items: [{ desc: 'Cement', qty: 100, price: 32000, itemId: 'cem' }] });
  b.post('purchases', 'p2', { date: '2026-11-02', supplierId: 's', vatRate: 18, items: [{ desc: 'Cement', qty: 50, price: 34000, itemId: 'cem' }] });
  eq(b.stock.cem, { q: 150e6, v: 4900000 });
  const s1 = b.post('invoices', 'i1', inv('INV-1', [{ desc: 'Cement', qty: 30, price: 40000, itemId: 'cem' }])).je; eq(acct(s1, '5000'), 980000);
  const s2 = b.post('invoices', 'i2', inv('INV-2', [{ desc: 'Cement', qty: 120, price: 40000, itemId: 'cem' }])).je; eq(acct(s2, '5000'), 3920000);
  eq(b.stock.cem, { q: 0, v: 0 }); const r = L.replayStock(b.journals()); eq(r.issues, []); return 'average 32,666.67; COGS 980,000 + 3,920,000 = 4,900,000';
});
test('P-03', 'A sale bigger than stock on hand is refused', () => {
  const b = book(); b.post('purchases', 'p1', { date: '2026-11-01', supplierId: 's', vatRate: 0, items: [{ desc: 'Cement', qty: 10, price: 32000, itemId: 'cem' }] });
  const r = b.post('invoices', 'i1', inv('INV-1', [{ desc: 'Cement', qty: 11, price: 40000, itemId: 'cem' }])); ok(/Not enough/.test(r.err), 'not refused: ' + r.err); return r.err;
});
test('P-04', 'Purchase with stock and service lines and VAT: inventory + expense + input VAT = payable', () => {
  const b = book(); const { je } = b.post('purchases', 'p1', { date: '2026-11-01', supplierId: 's', vatRate: 18, account: 'Transport & fuel', items: [{ desc: 'Bars', qty: 3, price: 33333.335, itemId: 'bar' }, { desc: 'Delivery', qty: 1, price: 0.5 }] });
  const t = L.calcDoc(je ? { items: [{ qty: 3, price: 33333.335 }, { qty: 1, price: 0.5 }], vatRate: 18 } : {}, dp);
  eq(acct(je, '1200') + acct(je, '6040'), t.sub, 'lines add to subtotal'); eq(acct(je, '1300'), t.vat); eq(-acct(je, '2000'), t.total); return `stock ${acct(je, '1200')} + transport ${acct(je, '6040')} = ${t.sub}; VAT ${t.vat}`;
});
test('P-05', 'Partial payments and an advance: AR per client follows receipts exactly', () => {
  const b = book(); b.post('invoices', 'i1', inv('INV-1', [{ desc: 'Work', qty: 1, price: 1000000 }]));
  b.post('receipts', 'r1', { date: '2026-11-04', clientId: 'hima', amount: 500000, method: 'Bank transfer', invoiceId: 'i1' });
  b.post('receipts', 'r2', { date: '2026-11-04', clientId: 'hima', amount: 300000, method: 'MTN Mobile Money', invoiceId: 'i1' });
  b.post('receipts', 'r3', { date: '2026-11-04', clientId: 'hima', amount: 600000, method: 'Cash' });
  const ar = L.partyBalances(b.journals(), '1100').get('hima'); eq(ar, 1180000 - 1400000); const bal = L.balances(b.journals());
  eq([bal['1030'].d, bal['1010'].d, bal['1000'].d], [500000, 300000, 600000]); return 'client in credit by 220,000 after an advance';
});
test('P-06', 'Credit note with goods returned to stock at the cost charged on the invoice', () => {
  const b = book(); b.post('purchases', 'p1', { date: '2026-11-01', supplierId: 's', vatRate: 0, items: [{ desc: 'Cement', qty: 3, price: 10000, itemId: 'cem' }] });
  b.post('purchases', 'p2', { date: '2026-11-01', supplierId: 's', vatRate: 0, items: [{ desc: 'Cement', qty: 1, price: 10001, itemId: 'cem' }] });
  const i = b.post('invoices', 'i1', inv('INV-1', [{ desc: 'Cement', qty: 3, price: 15000, itemId: 'cem' }])).je; const cost = acct(i, '5000');
  const c = b.post('credits', 'c1', { date: '2026-11-04', clientId: 'hima', invoiceId: 'i1', vatRate: 18, reason: 'returned', items: [{ desc: 'Cement', qty: 1, price: 15000, itemId: 'cem', restock: true }] }, { unitCost: L.unitCosts(i) }).je;
  eq(acct(c, '1200'), L.mulDiv(cost, 1, 3)); eq(acct(c, '1100'), -17700); eq(L.replayStock(b.journals()).issues, []); return `sold 3 at cost ${cost}; return of 1 restocked at ${acct(c, '1200')}; AR −17,700`;
});
test('P-07', 'Client debit note raises AR, sales and output VAT', () => {
  const b = book(); const { je } = b.post('debits', 'd1', { date: '2026-11-04', clientId: 'hima', vatRate: 18, items: [{ desc: 'Extra transport', qty: 1, price: 100000 }] });
  eq([acct(je, '1100'), acct(je, '4000'), acct(je, '2100')], [118000, -100000, -18000]);
});
test('P-08', 'Supplier debit note returns stock at moving-average cost; price difference goes to cost of sales', () => {
  const b = book(); b.post('purchases', 'p1', { date: '2026-11-01', supplierId: 's', vatRate: 18, items: [{ desc: 'Cement', qty: 10, price: 30000, itemId: 'cem' }] });
  b.post('purchases', 'p2', { date: '2026-11-01', supplierId: 's', vatRate: 18, items: [{ desc: 'Cement', qty: 10, price: 34000, itemId: 'cem' }] });
  const { je } = b.post('sdebits', 's1', { date: '2026-11-04', supplierId: 's', purchaseId: 'p2', vatRate: 18, items: [{ desc: 'Cement damaged', qty: 2, price: 34000, itemId: 'cem' }] });
  eq([acct(je, '2000'), acct(je, '1300'), acct(je, '1200'), acct(je, '5000')], [80240, -12240, -64000, -4000]); eq(L.replayStock(b.journals()).issues, []); return 'AP −80,240; stock out at average 64,000; 4,000 difference credited to cost of sales';
});
test('P-09', 'Client settles in cement (no VAT): stock in at agreed value, AR reduced, no cash moves', () => {
  const b = book(); b.post('invoices', 'i1', inv('INV-1', [{ desc: 'Works', qty: 1, price: 1000000 }]));
  const { je } = b.post('receipts', 'r1', { date: '2026-11-04', clientId: 'hima', invoiceId: 'i1', method: L.IN_KIND, amount: 900000, goods: [{ itemId: 'cem', qty: 30, value: 900000 }] });
  eq([acct(je, '1200'), acct(je, '1100')], [900000, -900000]); ok(!je.lines.some(l => ['2100', '1300', '1000', '1030'].includes(l.a)), 'VAT or cash touched');
  eq(L.partyBalances(b.journals(), '1100').get('hima'), 280000); eq(b.stock.cem, { q: 30e6, v: 900000 });
  const bad = L.post('receipts', { date: '2026-11-04', clientId: 'hima', method: L.IN_KIND, amount: 900001, goods: [{ itemId: 'cem', qty: 30, value: 900000 }] }, { dp, stock: {} }); ok(/must equal/.test(bad.err), 'mismatch accepted');
  return 'AR 1,180,000 → 280,000; 30 bags in stock at 900,000';
});
test('P-10', 'Refunds: client refund from a credit balance; supplier refund of an overpayment', () => {
  const b = book(); b.post('receipts', 'r1', { date: '2026-11-04', clientId: 'hima', amount: 500000, method: 'Cash' });
  b.post('refunds', 'f1', { date: '2026-11-04', clientId: 'hima', amount: 200000, method: 'Cash' }); eq(L.partyBalances(b.journals(), '1100').get('hima'), -300000);
  b.post('payments', 'y1', { date: '2026-11-04', supplierId: 's', amount: 100000, method: 'Bank transfer', category: 'Supplier bill' });
  b.post('refunds', 'f2', { date: '2026-11-04', supplierId: 's', amount: 100000, method: 'Bank transfer' }); eq(L.partyBalances(b.journals(), '2000').get('s'), 0);
  const bal = L.balances(b.journals()); eq(bal['1000'].d - bal['1000'].c, 300000); return 'client credit 500,000 → 300,000; supplier back to 0';
});
test('P-11', 'Stock adjustments: count gain at stated value, loss at moving-average cost', () => {
  const b = book(); b.post('purchases', 'p1', { date: '2026-11-01', supplierId: 's', vatRate: 0, items: [{ desc: 'Bars', qty: 3, price: 100, itemId: 'bar' }] });
  const lo = b.post('adjustments', 'a1', { date: '2026-11-04', itemId: 'bar', qty: -1, reason: 'damaged' }).je; eq(acct(lo, '5100'), 100);
  const gn = b.post('adjustments', 'a2', { date: '2026-11-04', itemId: 'bar', qty: 2, value: 250, reason: 'count' }).je; eq(acct(gn, '4900'), -250);
  eq(b.stock.bar, { q: 4e6, v: 450 }); eq(L.replayStock(b.journals()).issues, []);
});
test('P-12', 'Every posting rule produces a balanced journal on 5,000 random documents', () => {
  const rnd = a => a[Math.floor(Math.random() * a.length)]; let n = 0;
  for (let k = 0; k < 5000; k++) { const items = [{ desc: 'x', qty: rnd([1, 0.5, 2.25, 7]), price: rnd([1, 999.5, 32000, 0.333]) }];
    for (const coll of ['invoices', 'debits', 'credits', 'purchases', 'sdebits']) { const r = L.post(coll, { date: '2026-11-04', clientId: 'c', supplierId: 's', vatRate: rnd([0, 18]), items }, { dp: rnd([0, 2]) }); if (r.err && !/zero/.test(r.err)) throw new Error(coll + ': ' + r.err); if (!r.err) { ok(!L.balanced(r.lines), 'unbalanced ' + coll); n++; } } }
  return n + ' journals, all balanced';
});

// ---------- voids, checks ----------
test('V-01', 'Voiding a receipt posts a mirror reversal on the void date; the original stays', () => {
  const b = book(); b.post('receipts', 'r1', { date: '2026-11-01', clientId: 'hima', amount: 500000, method: 'Cash' }); const e = b.void('receipts', 'r1', '2026-11-04');
  eq(e.doc.jr.pid, 'receipts/r1:R'); eq(e.doc.jr.date, '2026-11-04'); eq(acct(e.doc.jr, '1000'), -500000); eq(L.balances(b.journals(), null, '2026-11-03')['1000'].d, 500000);
  eq(L.partyBalances(b.journals(), '1100').get('hima'), 0); eq(L.check(b.docs, { dp }).issues, []); return 'cash 500,000 until 3 Nov, 0 from 4 Nov';
});
test('V-02', 'Voiding a purchase whose stock was partly sold: refused if it would take more stock than is on hand; otherwise out at average', () => {
  const b = book(); b.post('purchases', 'p1', { date: '2026-11-01', supplierId: 's', vatRate: 0, items: [{ desc: 'C', qty: 10, price: 100, itemId: 'cem' }] });
  b.post('invoices', 'i1', inv('INV-1', [{ desc: 'C', qty: 5, price: 150, itemId: 'cem' }])); const r = b.void('purchases', 'p1', '2026-11-04'); ok(r.err && /more stock/.test(r.err), 'not refused');
  b.post('purchases', 'p2', { date: '2026-11-02', supplierId: 's', vatRate: 0, items: [{ desc: 'C', qty: 10, price: 130, itemId: 'cem' }] }); const e = b.void('purchases', 'p1', '2026-11-04');
  ok(!e.err, e.err); eq(L.check(b.docs, { dp }).issues, []); eq(b.stock.cem.q, 5e6); return 'refused while short; later voided at average with the difference in cost of sales, stock checks clean';
});
test('C-01', 'Checks catch: amount changed outside the app, unbalanced journal, duplicate posting, missing journal, void without reversal', () => {
  const b = book(); b.post('receipts', 'r1', { date: '2026-11-01', clientId: 'hima', amount: 500000, method: 'Cash' }); b.post('invoices', 'i1', inv('INV-1', [{ desc: 'W', qty: 1, price: 1000 }]));
  const clean = L.check(b.docs, { dp }).issues; eq(clean, []);
  const t1 = JSON.parse(JSON.stringify(b.docs)); t1[0].doc.amount = 50000; ok(L.check(t1, { dp }).issues.some(i => /fingerprint|doesn't match/.test(i.msg)), 'amount tamper missed');
  const t2 = JSON.parse(JSON.stringify(b.docs)); t2[1].doc.je.lines[0].d += 1; ok(L.check(t2, { dp }).issues.some(i => /don't equal/.test(i.msg)), 'imbalance missed');
  const t3 = JSON.parse(JSON.stringify(b.docs)); t3.push({ coll: 'receipts', id: 'r1', doc: t3[0].doc }); ok(L.check(t3, { dp }).issues.some(i => /Duplicate posting/.test(i.msg)), 'duplicate missed');
  const t4 = JSON.parse(JSON.stringify(b.docs)); delete t4[1].doc.je; ok(L.check(t4, { dp }).issues.some(i => /Not posted/.test(i.msg)), 'unposted missed');
  const t5 = JSON.parse(JSON.stringify(b.docs)); t5[0].doc.void = true; ok(L.check(t5, { dp }).issues.some(i => /no reversal/.test(i.msg)), 'void without reversal missed');
  const t6 = JSON.parse(JSON.stringify(b.docs)); t6[1].doc.je.lines.find(l => l.a === '4000').a = '4900'; t6[1].doc.je.h = L.seal(t6[1].doc.je, 'invoices', t6[1].doc); ok(L.check(t6, { dp }).issues.some(i => /doesn't match/.test(i.msg)), 'resealed wrong account missed');
  return '6 kinds of tampering detected; checks never change anything';
});
test('C-02', 'Two sales computed from the same stock figures (lost lease) are flagged, not silently re-costed', () => {
  const b = book(); b.post('purchases', 'p1', { date: '2026-11-01', supplierId: 's', vatRate: 0, items: [{ desc: 'C', qty: 10, price: 100, itemId: 'cem' }] });
  const before = JSON.parse(JSON.stringify(b.stock)); b.post('invoices', 'i1', inv('INV-1', [{ desc: 'C', qty: 4, price: 150, itemId: 'cem' }]));
  // simulate a second user who read the old stock state and the old sequence number
  const r = L.post('invoices', inv('INV-2', [{ desc: 'C', qty: 4, price: 150, itemId: 'cem' }]), { dp, stock: before }); L.numberStock(r.lines, { cem: 1 });
  b.docs.push({ coll: 'invoices', id: 'i2', doc: { ...inv('INV-2', [{ desc: 'C', qty: 4, price: 150, itemId: 'cem' }]), je: L.makeJE('invoices', 'i2', inv('INV-2', [{ desc: 'C', qty: 4, price: 150, itemId: 'cem' }]), r.lines, meta(9)) } });
  const iss = L.check(b.docs, { dp }).issues; ok(iss.some(i => /out of sequence/.test(i.msg)), 'not flagged: ' + JSON.stringify(iss)); return iss.map(i => i.msg)[0];
});
test('R-01', 'Reports: trial balance and balance sheet balance; P&L, VAT return and stock agree with the postings', () => {
  const b = book(); b.post('purchases', 'p1', { date: '2026-11-01', supplierId: 's', vatRate: 18, items: [{ desc: 'Cement', qty: 100, price: 32000, itemId: 'cem' }] });
  b.post('invoices', 'i1', inv('INV-1', [{ desc: 'Cement', qty: 40, price: 40000, itemId: 'cem' }, { desc: 'Labour', qty: 1, price: 200000 }]));
  b.post('receipts', 'r1', { date: '2026-11-04', clientId: 'hima', amount: 1000000, method: 'Bank transfer', invoiceId: 'i1' });
  b.post('payments', 'y1', { date: '2026-11-04', supplierId: 's', amount: 2000000, method: 'Bank transfer', category: 'Supplier bill' });
  b.post('payments', 'y2', { date: '2026-11-04', amount: 50000, method: 'Cash', category: 'Transport & fuel', payee: 'Boda' });
  b.post('payments', 'y3', { date: '2026-11-04', amount: 100000, method: 'Bank transfer', category: 'VAT paid to URA', payee: 'URA' });
  const J = b.journals(); const tb = L.trialBalance(J); ok(tb.ok, 'TB off'); const bs = L.balanceSheet(J); ok(bs.ok, 'BS off ' + JSON.stringify([bs.assets, bs.liabilities, bs.equity]));
  const pl = L.profitLoss(J); eq([pl.ti, pl.te, pl.net], [1800000, 1280000 + 50000, 1800000 - 1330000]);
  const v = L.vatReturn(J); eq([v.outputVat, v.inputVat, v.netVat, v.sales, v.purchases, v.paidToURA], [324000, 576000, -252000, 1800000, 3200000, 100000]);
  eq(L.balances(J)['1200'].d - L.balances(J)['1200'].c, b.stock.cem.v); return `TB ${tb.dr}=${tb.cr}; profit ${pl.net}; VAT refundable ${-v.netVat}; stock ${b.stock.cem.v}`;
});
const passed = results.filter(r => r.pass).length; console.log(`\n${passed}/${results.length} passed`);
require('fs').writeFileSync(__dirname + '/engine-results.json', JSON.stringify({ ranAt: new Date().toISOString(), passed, total: results.length, results }, null, 1));
process.exit(passed === results.length ? 0 : 1);
