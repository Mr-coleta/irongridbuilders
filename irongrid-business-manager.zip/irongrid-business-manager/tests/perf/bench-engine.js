// Report engine benchmark: the same queries a person runs in a month-end review, timed on journal sets far larger
// than the platform's 25,000-record limit. MODE=old times the original functions (full scan per report);
// MODE=new times the indexed functions. Results go to tests/reports/bench-engine-<mode>.json.
//   node --expose-gc --max-old-space-size=8192 tests/perf/bench-engine.js [sizes...]
'use strict';
const path = require('path'); const fs = require('fs');
const L = require('../../engine/ledger.js'); const { journals } = require('./journals.js');
const MODE = process.env.MODE || 'old'; const R = MODE === 'new' ? require('../../engine/reports.js') : null;
const sizes = process.argv.slice(2).map(Number).filter(Boolean); if (!sizes.length) sizes.push(25000, 250000, 1000000);
const gc = () => { if (global.gc) { global.gc(); global.gc(); } };
const heap = () => process.memoryUsage().heapUsed / 1048576;
const time = (fn, reps = 1) => { const t = process.hrtime.bigint(); let x; for (let i = 0; i < reps; i++) x = fn(); return { ms: Number(process.hrtime.bigint() - t) / 1e6 / reps, x }; };
const out = { mode: MODE, node: process.version, ranAt: new Date().toISOString(), runs: [] };
for (const n of sizes) {
  gc(); const h0 = heap(); const J = journals(n); gc(); const hJ = heap();
  const lastDate = J.reduce((m, j) => j.date > m ? j.date : m, ''); const y = lastDate.slice(0, 4);
  const months = Array.from({ length: 12 }, (_, i) => [`${y}-${String(i + 1).padStart(2, '0')}-01`, new Date(Date.UTC(+y, i + 1, 0)).toISOString().slice(0, 10)]);
  const lines = J.reduce((t, j) => t + j.lines.length, 0); const run = { journals: J.length, lines, dataMB: +(hJ - h0).toFixed(1) };
  let ix = null; if (R) { gc(); const hb = heap(); const b = time(() => R.buildIndex(J)); ix = b.x; gc(); run.indexBuildMs = +b.ms.toFixed(1); run.indexMB = +(heap() - hb).toFixed(1); }
  const q = {
    'trial balance at 12 month-ends': () => months.map(([, to]) => R ? R.trialBalance(ix, to) : L.trialBalance(J, to)),
    'profit & loss for 12 months': () => months.map(([f, t]) => R ? R.profitLoss(ix, f, t) : L.profitLoss(J, f, t)),
    'balance sheet at 12 month-ends': () => months.map(([, to]) => R ? R.balanceSheet(ix, to) : L.balanceSheet(J, to)),
    'VAT return for 12 months': () => months.map(([f, t]) => R ? R.vatReturn(ix, f, t) : L.vatReturn(J, f, t)),
    'general ledger 1100, one month, first page': () => R ? R.generalLedgerPage(ix, '1100', months[5][0], months[5][1], 0, 500) : L.generalLedger(J, '1100', months[5][0], months[5][1]).slice(0, 500),
    'general ledger 1100, all time, last page': () => { if (R) { const n1 = R.glCount(ix, '1100'); return R.generalLedgerPage(ix, '1100', null, null, Math.max(0, n1 - 500), 500); } const rows = L.generalLedger(J, '1100'); return rows.slice(-500); },
    'client balances at year-end': () => R ? R.partyBalances(ix, '1100', months[11][1]) : L.partyBalances(J, '1100', months[11][1]),
  };
  run.queries = {}; for (const [name, fn] of Object.entries(q)) { fn(); const t = time(fn, n >= 1e6 ? 1 : 3); run.queries[name] = +t.ms.toFixed(2); }
  gc(); run.heapMB = +heap().toFixed(1); out.runs.push(run); console.log(JSON.stringify(run));
}
fs.mkdirSync(path.join(__dirname, '../reports'), { recursive: true }); fs.writeFileSync(path.join(__dirname, `../reports/bench-engine-${MODE}.json`), JSON.stringify(out, null, 1));
