// Report screens in the real app at the platform's limit (24,990 posted records): time to render each report,
// longest main-thread freeze, JS heap, and store reads caused by the report. Writes tests/reports/bench-browser-<label>.json.
//   LABEL=before node tests/perf/bench-browser.js
'use strict';
const { chromium } = require('playwright'); const fs = require('fs'); const path = require('path');
const MOCK = require('../mocksrc.js'); const { build } = require('../scale/books.js');
const LABEL = process.env.LABEL || 'run'; const SRV = path.join(__dirname, '../../srv');
(async () => {
  const B = build(24990); fs.writeFileSync(path.join(SRV, 'scale.json'), JSON.stringify([...B.docs.entries()]));
  const busiest = (() => { const n = {}; for (const [k, d] of B.docs) if (k.startsWith('invoices/')) n[d.clientId] = (n[d.clientId] || 0) + 1; return Object.entries(n).sort((a, b) => b[1] - a[1])[0][0]; })();
  const browser = await chromium.launch({ args: ['--enable-precise-memory-info', '--js-flags=--expose-gc'] });
  const p = await browser.newPage({ viewport: { width: 1300, height: 950 } }); p.setDefaultTimeout(120000);
  await p.addInitScript(`${MOCK};window.__mock({});{const x=new XMLHttpRequest();x.open("GET","/scale.json",false);x.send();for(const [k,v] of JSON.parse(x.responseText))window.__S.set(k,v)}
    window.__lt=[];new PerformanceObserver(l=>{for(const e of l.getEntries())window.__lt.push(e.duration)}).observe({type:"longtask",buffered:true});`);
  const t0 = Date.now(); await p.goto('http://localhost:8765/index.html#dashboard'); await p.waitForFunction(n => window.S && S.invoices && S.invoices.length === n, B.counts.invoices); const loadMs = Date.now() - t0;
  await p.waitForTimeout(4000);
  const frame = () => p.evaluate(() => new Promise(r => requestAnimationFrame(() => requestAnimationFrame(r))));
  const measure = async (name, act, ready) => {
    await p.evaluate(() => { window.__lt.length = 0; window.top.__reads = 0; if (window.gc) window.gc(); });
    const t = Date.now(); await act(); if (ready) await p.waitForFunction(ready, null, { timeout: 120000 }); await frame(); const ms = Date.now() - t;
    const m = await p.evaluate(() => ({ longest: Math.round(Math.max(0, ...window.__lt)), reads: window.top.__reads || 0, heap: Math.round(performance.memory.usedJSHeapSize / 1048576) }));
    return { name, ms, longestFreezeMs: m.longest, storeReads: m.reads, heapMB: m.heap };
  };
  const go = async h => { await p.evaluate(h => location.hash = h, h); };
  const tab = async t => { await p.evaluate(t => document.querySelector(`#acTabs [data-t=${t}]`).click(), t); };
  const setRange = async (f, t) => { await p.evaluate(([f, t]) => { const a = document.querySelector('#acFrom'), b = document.querySelector('#acTo'); a.value = f; b.value = t; b.dispatchEvent(new Event('change')); }, [f, t]); };
  const res = [];
  await go('accounts'); await p.waitForTimeout(2500);
  const ready = () => !document.querySelector('#acPreparing');
  if (await p.$('#acTabs [data-t=ar]')) res.push(await measure('First report after the books change (index rebuilt in slices)', async () => { await tab('tb'); await p.evaluate(() => { __dropLedger(); renderAccounts(); }); }, ready));
  res.push(await measure('Trial balance (all time)', () => tab('tb'), ready));
  res.push(await measure('Balance sheet (all time)', () => tab('bs')));
  res.push(await measure('Profit & loss (all time)', () => tab('pl')));
  res.push(await measure('VAT return (all time)', () => tab('vat')));
  res.push(await measure('Trial balance at 30 Jun 2025 (date change)', async () => { await tab('tb'); await setRange('', '2025-06-30'); }));
  res.push(await measure('Profit & loss, one month (date change)', async () => { await tab('pl'); await setRange('2025-06-01', '2025-06-30'); }));
  await setRange('', '');
  res.push(await measure('General ledger 1100 receivables (all time)', async () => { await tab('gl'); await p.selectOption('#acAcct', '1100'); }));
  res.push(await measure('General ledger 1000 cash (all time)', async () => { await p.selectOption('#acAcct', '1000'); }));
  res.push(await measure('Client statement, busiest client', async () => { await p.evaluate(id => showParty('clients', id), busiest); }));
  await p.evaluate(() => { const m = document.querySelector('#modal'); if (m) m.classList.remove('on'); });
  res.push(await measure('Stock / inventory valuation', () => go('stock')));
  // reports added by the optimisation (absent in the 'before' build)
  if (await p.$('#acTabs [data-t=ar]')) { await go('accounts'); await p.waitForTimeout(300);
    for (const [t, name] of [['ar', 'Receivables ageing'], ['ap', 'Payables ageing'], ['cf', 'Cash flow statement'], ['inv', 'Inventory valuation at a date']]) res.push(await measure(name, () => tab(t))); }
  const out = { label: LABEL, ranAt: new Date().toISOString(), records: B.docs.size, journals: B.journals, loadMs, busiestClient: busiest, results: res };
  fs.writeFileSync(path.join(__dirname, `../reports/bench-browser-${LABEL}.json`), JSON.stringify(out, null, 1));
  for (const r of res) console.log(`${r.name.padEnd(48)} ${String(r.ms).padStart(6)} ms  freeze ${String(r.longestFreezeMs).padStart(5)} ms  reads ${r.storeReads}  heap ${r.heapMB} MB`);
  await browser.close();
})();
