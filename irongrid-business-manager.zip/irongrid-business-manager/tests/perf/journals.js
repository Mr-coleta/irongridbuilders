// Fast synthetic journals for report benchmarks at sizes far beyond the platform's 25,000-record limit.
// Same shapes the engine posts (accounts, party and item tags, reversals dated on the void date), so report
// functions see realistic data. Every journal is balanced; deterministic for a given seed.
'use strict';
function rng(seed) { let a = seed >>> 0; return () => { a |= 0; a = a + 0x6D2B79F5 | 0; let t = Math.imul(a ^ a >>> 15, 1 | a); t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t; return ((t ^ t >>> 14) >>> 0) / 4294967296; }; }
const CASH = ['1000', '1010', '1020', '1030'];
const EXP = ['6000', '6020', '6040', '6050', '6060', '6070', '6900'];
function journals(n, seed = 7) {
  const r = rng(seed); const int = (a, b) => a + Math.floor(r() * (b - a + 1)); const pick = a => a[Math.floor(r() * a.length)];
  const J = []; const days = Math.max(365, Math.ceil(n / 120)); const d0 = Date.UTC(2020, 0, 1);
  const date = k => new Date(d0 + Math.floor(k * days / n) * 864e5).toISOString().slice(0, 10);
  const L = (a, d, c, x) => Object.assign({ a, d, c }, x || {});
  for (let k = 0; k < n; k++) {
    const dt = date(k), at = new Date(Date.UTC(2020, 0, 1) + k * 1000).toISOString(); const roll = r(); let lines, pid;
    if (roll < 0.3) { const cl = 'c' + int(0, 199), sub = int(10, 4000) * 1000, vat = Math.round(sub * 0.18), cost = Math.round(sub * 0.7), it = 'i' + int(0, 29);
      pid = 'invoices/' + k; lines = [L('1100', sub + vat, 0, { p: cl }), L('4000', 0, sub), L('2100', 0, vat), L('5000', cost, 0, { i: it }), L('1200', 0, cost, { i: it, q: -1e6, k: 'avg' })]; }
    else if (roll < 0.55) { const cl = 'c' + int(0, 199), amt = int(5, 3000) * 1000; pid = 'receipts/' + k; lines = [L(pick(CASH), amt, 0), L('1100', 0, amt, { p: cl })]; }
    else if (roll < 0.72) { const su = 's' + int(0, 79), sub = int(20, 5000) * 1000, vat = Math.round(sub * 0.18), it = 'i' + int(0, 29);
      pid = 'purchases/' + k; lines = [L('1200', sub, 0, { i: it, q: 5e6 }), L('1300', vat, 0), L('2000', 0, sub + vat, { p: su })]; }
    else if (roll < 0.86) { const su = 's' + int(0, 79), amt = int(10, 4000) * 1000; pid = 'payments/' + k; lines = [L('2000', amt, 0, { p: su }), L(pick(CASH), 0, amt)]; }
    else if (roll < 0.95) { const amt = int(5, 900) * 1000; pid = 'payments/' + k; lines = [L(pick(EXP), amt, 0), L(pick(CASH), 0, amt)]; }
    else if (roll < 0.97) { const amt = int(100, 3000) * 1000; pid = 'payments/' + k; lines = [L('2100', amt, 0), L('1030', 0, amt)]; }
    else { const cl = 'c' + int(0, 199), amt = int(5, 500) * 1000; pid = 'credits/' + k; const vat = Math.round(amt * 0.18); lines = [L('4000', amt, 0), L('2100', vat, 0), L('1100', 0, amt + vat, { p: cl })]; }
    J.push({ v: 1, pid, date: dt, cur: 'UGX', dp: 0, at, lines });
    if (r() < 0.01 && (pid.startsWith('receipts') || pid.startsWith('payments'))) { // ~1% voided later, reversal dated on the void day
      const vd = date(Math.min(n - 1, k + int(1, 2000))); J.push({ v: 1, pid: pid + ':R', date: vd, cur: 'UGX', dp: 0, at: new Date(Date.parse(at) + 3e9).toISOString(), lines: lines.map(l => ({ ...l, d: l.c, c: l.d })) }); }
  }
  return J;
}
module.exports = { journals };
