// Date format suite: everything a person sees or types is DD/MM/YYYY; everything stored stays YYYY-MM-DD.
// Writes tests/reports/dates.json. Usage: node tests/dates/dates.test.js   (server on :8765 serving srv/)
'use strict';
const { chromium } = require('playwright'); const fs = require('fs'); const path = require('path');
const MOCK = require('../mocksrc.js');
const results = []; const assert = (c, m) => { if (!c) throw new Error(m); };
async function test(id, name, fn) {
  if (process.env.ONLY && !process.env.ONLY.split(',').includes(id)) return;
  const t0 = Date.now();
  try { const detail = await fn(); results.push({ id, name, pass: true, ms: Date.now() - t0, detail: detail || '' }); }
  catch (e) { results.push({ id, name, pass: false, ms: Date.now() - t0, detail: e.message.split('\n')[0] }); }
  const r = results.at(-1); console.log(`${r.pass ? 'PASS' : 'FAIL'}  ${id}  ${name}${r.detail ? '  — ' + r.detail : ''}`);
}
const SEED = `st.set("settings/business",{name:"Irongrid Builders Co Limited",currency:"UGX"});st.set("clients/c",{name:"Nansubuga Estates Ltd"});st.set("suppliers/s",{name:"Lake Victoria Cement Ltd"});
st.set("invoices/i1",{number:"INV-0001",date:"2026-03-04",dueDate:"2026-04-03",clientId:"c",vatRate:0,items:[{desc:"Works",qty:1,price:1000}]});
st.set("invoices/i2",{number:"INV-0002",date:"2026-01-31",clientId:"c",vatRate:0,items:[{desc:"Works",qty:1,price:2000}]});`;
let browser;
async function open(hash = 'invoices') {
  const p = await browser.newPage({ viewport: { width: 1366, height: 860 } }); p.setDefaultTimeout(15000); const errs = []; p.on('pageerror', e => errs.push(e.message));
  await p.addInitScript(`${MOCK};window.__mock({});const st=window.__S;${SEED}`); await p.goto('http://localhost:8765/index.html#' + hash); await p.waitForTimeout(1000); return { p, errs };
}
const newInvoice = async p => { await p.evaluate(() => location.hash = 'invoices'); await p.waitForTimeout(150); await p.click('#lNew'); await p.selectOption('#ed [name=party]', 'c'); await p.fill('#ed .d', 'Works'); await p.fill('#ed .p', '100000'); };
const stored = p => p.evaluate(() => [...window.__S.entries()].filter(([k]) => k.startsWith('invoices/') && !['invoices/i1', 'invoices/i2'].includes(k)).map(([, v]) => v));
const close = p => p.click('#mBtns >> text=Close').catch(() => {});

(async () => {
  browser = await chromium.launch();

  await test('DT-01', 'Every date box on every screen and form shows DD/MM/YYYY (no browser-format date boxes remain)', async () => {
    const { p, errs } = await open('dashboard'); const found = [];
    const check = async where => { const r = await p.evaluate(() => ({ native: [...document.querySelectorAll('input[type=date]:not(.dmynat)')].filter(i => i.offsetParent).length,
      boxes: [...document.querySelectorAll('input.dmy')].filter(i => i.offsetParent).map(i => ({ ph: i.placeholder, shown: Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'value').get.call(i) })) }));
      if (r.native) found.push(`${where}: ${r.native} browser-format box(es)`); for (const b of r.boxes) if (b.ph !== 'DD/MM/YYYY' || (b.shown && !/^\d{2}\/\d{2}\/\d{4}$/.test(b.shown))) found.push(`${where}: shows "${b.shown}"`); return r.boxes.length; };
    let n = 0; for (const v of ['invoices', 'receipts', 'purchases', 'accounts', 'settings']) { await p.evaluate(v => location.hash = v, v); await p.waitForTimeout(200); n += await check(v); }
    for (const k of ['invoices', 'receipts', 'proformas', 'lpos', 'purchases', 'payments']) { await p.evaluate(k => { location.hash = k; }, k); await p.waitForTimeout(150); await p.click('#lNew'); await p.waitForTimeout(250); n += await check('new ' + k); await p.evaluate(() => document.querySelector('#modal').classList.remove('on')); }
    assert(!found.length, found.slice(0, 5).join('; ')); assert(!errs.length, errs[0]); await p.close(); return n + ' date boxes checked, all DD/MM/YYYY'; });

  await test('DT-02', 'Typing 31/01/2026 saves 2026-01-31; 03/04/2026 means 3 April (not 4 March); YYYY-MM-DD typed still works', async () => {
    const { p } = await open(); const got = [];
    for (const [typed, want] of [['31/01/2026', '2026-01-31'], ['03/04/2026', '2026-04-03'], ['2026-02-15', '2026-02-15'], ['5/6/2026', '2026-06-05']]) {
      await newInvoice(p); await p.fill('#ed [name=date]', typed); await p.click('#ed [type=submit]'); await p.waitForTimeout(1200); await close(p);
      const s = await stored(p); const d = s.map(x => x.date); assert(d.includes(want), `typed ${typed}: stored ${JSON.stringify(d)}, wanted ${want}`); got.push(typed + ' → ' + want); }
    await p.close(); return got.join('; '); });

  await test('DT-03', 'An impossible date (31/02/2026) or unreadable text is refused with a message and nothing is saved', async () => {
    const { p } = await open(); const before = (await stored(p)).length; const msgs = [];
    for (const typed of ['31/02/2026', '29/02/2025', 'next week']) { await newInvoice(p); await p.fill('#ed [name=date]', typed); await p.click('#ed [type=submit]'); await p.waitForTimeout(700);
      const t = await p.evaluate(() => (document.querySelector('#toast') || {}).textContent || ''); const open = await p.isVisible('#ed'); msgs.push(`${typed}: ${open ? 'form kept open' : 'form closed'} "${t.slice(0, 40)}"`);
      assert(open, `${typed}: the form closed`); await p.evaluate(() => document.querySelector('#modal').classList.remove('on')); }
    const after = (await stored(p)).length; assert(after === before, `${after - before} invoice(s) saved with a bad date`); await p.close(); return msgs.join(' | '); });

  await test('DT-04', 'Dates read DD/MM/YYYY in lists, the open document, the printed page, reports, and the audit log; stored dates stay YYYY-MM-DD', async () => {
    const { p } = await open(); const list = await p.textContent('.view.on tbody');
    await p.click('.view.on tbody tr[data-id=i1]', { timeout: 5000 }).catch(async e => { await p.screenshot({ path: '/tmp/dt04.png' }); throw e; }); await p.waitForTimeout(400); const doc = await p.textContent('#modal');
    const printed = await p.evaluate(() => pageFile('INV', docHTML('invoices', S.invoices.find(x => x.id === 'i1'))));
    await p.click('#mBtns >> text=Close');
    await p.evaluate(() => location.hash = 'accounts'); await p.waitForTimeout(300); await p.evaluate(() => { const t = document.querySelector('#acTo'); t.value = '2026-03-31'; t.dispatchEvent(new Event('input', { bubbles: true })); t.dispatchEvent(new Event('change', { bubbles: true })); });
    await p.click('#acTabs [data-t=ar]'); await p.waitForTimeout(300); const rep = await p.textContent('#acBody');
    const raw = await p.evaluate(() => window.__S.get('invoices/i1').date);
    const stamp = await p.evaluate(() => localStamp(new Date(2026, 10, 8, 14, 30).toISOString())); assert(stamp === '08/11/2026 14:30', 'audit/approvals timestamp: ' + stamp);
    const bad = []; const MONTHS = /\b\d{1,2} (Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)\b/; const ISO = /\b20\d{2}-\d{2}-\d{2}\b/;
    for (const [w, t] of [['list', list], ['document', doc], ['printed page', printed.replace(/<style>[\s\S]*?<\/style>/g, '')], ['report', rep]]) { if (MONTHS.test(t)) bad.push(w + ' has a month-name date'); if (w !== 'document' && ISO.test(t)) bad.push(w + ' shows YYYY-MM-DD: ' + t.match(ISO)[0]); }
    assert(list.includes('04/03/2026') && doc.includes('04/03/2026') && printed.includes('04/03/2026') && doc.includes('03/04/2026'), 'expected 04/03/2026 (date) and 03/04/2026 (due) to appear');
    assert(/31\/03\/2026/.test(rep), 'report as-at date not DD/MM/YYYY: ' + rep.slice(0, 80)); assert(raw === '2026-03-04', 'stored date changed: ' + raw);
    assert(!bad.length, bad.join('; ')); await p.close(); return 'list, document, printed page and report show 04/03/2026; stored 2026-03-04'; });

  await test('DT-05', 'List filters accept DD/MM/YYYY; a half-typed date does not hide records', async () => {
    const { p } = await open(); const rows = async () => p.evaluate(() => document.querySelectorAll('.view.on tbody tr[data-id]').length);
    const all = await rows(); await p.fill('#lFrom', '01/03'); await p.waitForTimeout(300); const partial = await rows();
    await p.fill('#lFrom', '01/03/2026'); await p.waitForTimeout(300); const filtered = await rows(); const ids = await p.evaluate(() => [...document.querySelectorAll('.view.on tbody tr[data-id]')].map(r => r.dataset.id));
    assert(all === 2 && partial === 2, `all ${all}, while typing ${partial}`); assert(filtered === 1 && ids[0] === 'i1', `from 01/03/2026 shows ${ids}`); await p.close(); return `2 → 2 while typing → 1 (INV-0001) from 01/03/2026`; });

  await test('DT-06', 'The calendar button fills the box: picking a date shows DD/MM/YYYY and the form gets YYYY-MM-DD', async () => {
    const { p } = await open(); await newInvoice(p);
    const r = await p.evaluate(() => { const inp = document.querySelector('#ed [name=date]'); const wrap = inp.closest('.dmyw'); const cal = wrap.querySelector('.dmycal'), nat = wrap.querySelector('.dmynat');
      cal.click(); /* the browser's picker opens; simulate the person choosing 9 Nov 2026 */
      Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'value').set.call(nat, '2026-11-09'); nat.dispatchEvent(new Event('change'));
      return { shown: Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'value').get.call(inp), value: inp.value, label: cal.getAttribute('aria-label') }; });
    assert(r.shown === '09/11/2026' && r.value === '2026-11-09', JSON.stringify(r)); assert(r.label === 'Choose a date', 'button has no accessible name');
    await p.close(); return `picked → shows ${r.shown}, form value ${r.value}`; });

  await test('DT-07', 'CSV downloads keep YYYY-MM-DD (unambiguous for spreadsheets and imports)', async () => {
    const { p } = await open(); const csv = await p.evaluate(async () => { let got = null; const orig = window.downloads; window.downloads = { save: async o => { got = o.data; } };
      try { await save('x.csv', 'probe'); } catch (e) {} const k = location.hash.slice(1), L = LISTS[k]; const l = listData(k); const row = L.cols.map(c => c[2](l[0])).join(','); window.downloads = orig; return row; });
    assert(/20\d{2}-\d{2}-\d{2}/.test(csv) && !/\d{2}\/\d{2}\/\d{4}/.test(csv), 'CSV row: ' + csv); await p.close(); return 'CSV row: ' + csv.slice(0, 60); });

  await browser.close();
  fs.mkdirSync(path.join(__dirname, '../reports'), { recursive: true }); fs.writeFileSync(path.join(__dirname, '../reports/dates.json'), JSON.stringify({ ranAt: new Date().toISOString(), results }, null, 1));
  const f = results.filter(r => !r.pass).length; console.log(`${results.length - f}/${results.length} passed`); process.exit(f ? 1 : 0);
})();
