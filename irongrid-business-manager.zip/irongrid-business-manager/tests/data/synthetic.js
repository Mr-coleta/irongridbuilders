// Synthetic but realistic accounting data for Irongrid-style construction trading in Uganda (UGX).
// Every name is invented. Deterministic: the same seed always produces the same data.
'use strict';
function rng(seed) { let a = seed >>> 0; return () => { a |= 0; a = a + 0x6D2B79F5 | 0; let t = Math.imul(a ^ a >>> 15, 1 | a); t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t; return ((t ^ t >>> 14) >>> 0) / 4294967296; }; }
const CLIENTS = ['Kato & Sons Construction Ltd', 'Nansubuga Estates Ltd', 'Mbarara Hardware Depot', 'Gulu Road Works Co.', 'Entebbe Villas Developers', 'Mukono Schools Trust',
  'Jinja Riverside Apartments', 'Wakiso Builders Cooperative', 'Ssemakula Engineering', 'Kira Municipal Works', 'Lubowa Heights Ltd', 'Masaka Agro Stores'];
const SUPPLIERS = ['Lake Victoria Cement Supplies Ltd', 'Kampala Steel Mills (synthetic)', 'Namanve Roofing Sheets Ltd', 'Busega Sand & Aggregates', 'Owino Nails & Fasteners', 'Bweyogerere Timber Yard',
  'Nalukolongo Transporters', 'Kawempe Paints Ltd'];
// Stock items with realistic buy/sell price bands (UGX, excl. VAT)
const ITEMS = [
  { id: 'cem50', name: 'Cement 50kg bag', unit: 'bags', buy: [31000, 35000], sell: [37000, 41000], qty: [50, 400] },
  { id: 'y12', name: 'Y12 bar 12m', unit: 'lengths', buy: [36000, 41000], sell: [43000, 47000], qty: [20, 200] },
  { id: 'y16', name: 'Y16 bar 12m', unit: 'lengths', buy: [62000, 68000], sell: [72000, 78000], qty: [10, 100] },
  { id: 'ish28', name: 'Iron sheet 28 gauge 3m', unit: 'sheets', buy: [38000, 44000], sell: [47000, 52000], qty: [20, 300] },
  { id: 'nails', name: 'Roofing nails', unit: 'kg', buy: [7500, 9000], sell: [10000, 12000], qty: [5, 60], frac: true },
  { id: 'sand', name: 'Lake sand', unit: 'trips', buy: [280000, 330000], sell: [360000, 420000], qty: [1, 6] },
];
const SERVICES = [['Labour — blockwork', 150000, 900000], ['Transport to site', 80000, 450000], ['Site supervision', 200000, 1200000], ['Plumbing works', 300000, 2500000]];
const METHODS = ['Cash', 'MTN Mobile Money', 'Airtel Money', 'Bank transfer', 'Cheque'];
const EXP = [['Transport & fuel', 'Fuel — site lorry', 60000, 400000], ['Utilities', 'UMEME electricity', 90000, 600000], ['Rent', 'Yard rent Nalukolongo', 1500000, 1500000], ['Airtime & data', 'Staff airtime', 20000, 150000], ['Salaries & wages', 'Casual wages', 400000, 2500000], ['VAT paid to URA', 'URA VAT payment', 100000, 2000000]];
function generator(seed) {
  const r = rng(seed); const pick = a => a[Math.floor(r() * a.length)]; const int = (lo, hi) => lo + Math.floor(r() * (hi - lo + 1));
  const round = (x, step) => Math.round(x / step) * step;
  return {
    r, pick, int,
    clients: CLIENTS.map((name, i) => ({ id: 'c' + i, name, tin: String(1000000000 + int(0, 8999999)) })),
    suppliers: SUPPLIERS.map((name, i) => ({ id: 's' + i, name })),
    items: ITEMS,
    price: (band, step = 500) => round(int(band[0], band[1]), step),
    qty: it => it.frac ? Math.round((it.qty[0] + r() * (it.qty[1] - it.qty[0])) * 4) / 4 : int(it.qty[0], it.qty[1]),
    service: () => { const s = pick(SERVICES); return { desc: s[0], qty: 1, price: round(int(s[1], s[2]), 1000) }; },
    method: () => pick(METHODS),
    expense: () => { const e = pick(EXP); return { category: e[0], payee: e[1], amount: round(int(e[2], e[3]), 1000) }; },
  };
}
module.exports = { rng, generator, CLIENTS, SUPPLIERS, ITEMS };
