// reuse the simulator by loading the test file's internals: re-implement minimal count by requiring with a stubbed node:test
const Module=require('module');const orig=Module._load;let sims=[];
Module._load=function(req,...a){if(req==='node:test')return{describe:(n,f)=>f(),it:(n,f)=>{if(/seed|USD/.test(n))sims.push(f)}};return orig.call(this,req,...a)};
const L=require('../../engine/ledger.js');const origPost=L.post;const counts={};L.post=(c,d,x)=>{const r=origPost(c,d,x);if(!r.err)counts[c]=(counts[c]||0)+1;return r};
require('../integration/books.int.test.js');for(const f of sims)f();console.log(sims.length,'books',JSON.stringify(counts));
