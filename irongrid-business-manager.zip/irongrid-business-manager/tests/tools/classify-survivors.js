// Writes tests/reports/mutation-survivors.md: every surviving mutant with the reason it cannot change a result.
const fs = require('fs'); const m = require('../reports/mutation.json');
const R = [
  [[17, 19, 88], 'Sign handling for negative or zero values. Negative quantities, prices and amounts are now refused before this code runs, and for zero both versions give 0.'],
  [[25], 'Display padding: a longer zero-padding produces the same number after conversion.'],
  [[36, 38], 'Working scale for exact decimals: any starting scale that is large enough gives identical exact results.'],
  [[37, 41], 'Values computed for a document that has already been refused (invalid number or VAT); the error stops it before any amount is used.'],
  [[45, 46, 48], 'Rounding split between lines: branches for negative line amounts (now impossible), a remainder of exactly zero, and loop limits that are never reached (the leftover is always smaller than the number of lines). Exact allocations are pinned by 9 tests.'],
  [[50], 'Overflow test ordering: whenever the subtotal overflows, the total does too, so the result is flagged either way.'],
  [[89, 95], 'Stock state defaults: an item with no stock returns "not enough stock" whether its default holds 0 or 1 millionth.'],
  [[102, 106, 117, 134, 145, 147, 119, 146], 'Guards already decided by an earlier check: a quantity of 0 is caught by "!q", negatives are refused earlier, and a cost-difference line is only built when the amounts differ.'],
  [[173], 'Default for a missing quantity on a stock line; every stock line carries one.'],
  [[178, 181], 'Ordering of stock movements that have no sequence number. Every posting carries one, and any movement without one is reported as an error anyway.'],
  [[206, 209], 'Alternative paths for a damaged journal: both versions report the same "damaged" or "not posted" problem.'],
  [[219], 'Recompute queue: purchases and credit notes never draw from it, so including their stock-in lines changes nothing.'],
  [[226], 'Signature defaults used only to compare two journals built the same way.'],
  [[231], 'Trial balance column choice when an account nets to exactly zero: both columns show 0.'],
  [[252], 'General ledger sort: changes only the size of the comparison result (not its sign), or the order of two postings with identical timestamps, which the app never produces. The date-ordering mutant was killed by the 8-posting test.'],
];
const reason = l => (R.find(([ls]) => ls.includes(l)) || [, 'UNCLASSIFIED — investigate'])[1];
let md = `# Surviving mutants — ${m.survivors.length} of ${m.total}\n\nScore ${m.score}% (${m.killed} killed). Each survivor below was reviewed by hand and judged unable to change any accounting result (an "equivalent mutant"). This is reasoned, not machine-proved.\n\n`;
const groups = {}; for (const s of m.survivors) (groups[reason(s.line)] = groups[reason(s.line)] || []).push(s);
for (const [r, ss] of Object.entries(groups)) md += `## ${ss.length} × ${r}\n\n` + ss.map(s => `- #${s.id} line ${s.line}: \`${s.from}\` → \`${s.to}\``).join('\n') + '\n\n';
fs.writeFileSync(__dirname + '/../reports/mutation-survivors.md', md); console.log(Object.entries(groups).map(([r, s]) => s.length + ' ' + r.slice(0, 60)).join('\n')); console.log('unclassified:', (groups['UNCLASSIFIED — investigate'] || []).length);
