// Writes a one-statement-per-line copy of the engine so that LINE coverage is meaningful
// (the source packs many statements per line, which would make line coverage look like 100%).
// The copy is produced by prettier from the exact same code; tests run against it with LEDGER_PATH.
const fs = require('fs'), path = require('path');
const prettier = require('/opt/node-tools/node_modules/prettier');
(async () => {
  const src = fs.readFileSync(path.join(__dirname, '../../engine/ledger.js'), 'utf8');
  const out = await prettier.format(src, { parser: 'babel', printWidth: 100 });
  fs.mkdirSync(path.join(__dirname, '../cov-build'), { recursive: true });
  fs.writeFileSync(path.join(__dirname, '../cov-build/ledger.formatted.js'), out);
  console.log('formatted engine:', src.split('\n').length, 'lines →', out.split('\n').length, 'lines');
})();
