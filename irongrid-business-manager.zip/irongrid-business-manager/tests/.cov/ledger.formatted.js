/* ====================== accounting engine ======================
   Pure functions only: no page, no storage. The same code runs in the app and in the Node unit tests.
   Money is held as whole minor units (shillings, or cents) in integers; quantities in millionths.
   Every multiplication and rounding goes through BigInt decimal arithmetic, rounding half up, so no
   floating-point error can enter an amount. Anything that cannot be represented exactly is rejected. */
const LEDGER = (() => {
  "use strict";
  /* ---------- exact decimals ---------- */
  const QS = 6; /* quantities and unit prices: up to 6 decimal places */
  const P10 = (n) => 10n ** BigInt(n);
  /* Parses a number or numeric string into {n,s}: value = n / 10^s, exactly as written. Returns null when it is not a plain decimal. */
  function dec(v) {
    if (typeof v === "bigint") return { n: v, s: 0 };
    let t =
      typeof v === "number"
        ? Number.isFinite(v)
          ? String(v)
          : ""
        : String(v == null ? "" : v).trim();
    if (/e/i.test(t)) {
      const x = Number(t);
      if (!Number.isFinite(x)) return null;
      t = x.toFixed(20).replace(/0+$/, "").replace(/\.$/, "");
    } /* only for 1e-7 style output of tiny/huge numbers */
    const m = /^([+-]?)(\d*)(?:\.(\d*))?$/.exec(t);
    if (!m || (m[2] === "" && !m[3])) return null;
    const fr = (m[3] || "").replace(/0+$/, "");
    const n = BigInt((m[2] || "0") + fr) * (m[1] === "-" ? -1n : 1n);
    return { n, s: fr.length };
  }
  /* Rounds n/10^s to `to` decimal places, half away from zero. */
  function rnd(n, s, to) {
    if (s <= to) return n * P10(to - s);
    const f = P10(s - to);
    const neg = n < 0n;
    const a = neg ? -n : n;
    const q = (a * 2n + f) / (2n * f);
    return neg ? -q : q;
  }
  /* Exact value of v in minor units when it has no more decimals than the currency allows; otherwise null. */
  function exactMinor(v, dp) {
    const d = dec(v);
    if (!d || d.s > dp) return null;
    const m = d.n * P10(dp - d.s);
    return safe(m);
  }
  /* Value of v rounded half up to minor units (used only on computed amounts such as qty × price). */
  function roundMinor(v, dp) {
    const d = dec(v);
    if (!d) return null;
    return safe(rnd(d.n, d.s, dp));
  }
  function safe(b) {
    const x = Number(b);
    return Number.isSafeInteger(x) ? x : null;
  }
  const toMajor = (m, dp) =>
    dp
      ? Number(
          (m < 0 ? "-" : "") +
            String(Math.abs(m))
              .padStart(dp + 1, "0")
              .replace(new RegExp("(\\d{" + dp + "})$"), ".$1"),
        )
      : m;
  /* Quantity to millionths; null if more than 6 decimals or not a number. */
  function qtyMicro(v) {
    const d = dec(v);
    if (!d || d.s > QS) return null;
    return safe(d.n * P10(QS - d.s));
  }
  const microQty = (q) => q / 1e6; /* for display only */

  /* ---------- document arithmetic ----------
   Line amount = qty × price, exact. Subtotal = sum of exact lines, rounded once to the currency.
   VAT = subtotal × rate%, rounded once. Total = subtotal + VAT. (Same rounding points the app has always
   used; only the arithmetic is now exact.) Line amounts in minor units are allocated by largest remainder
   so they always add up to the subtotal; this splits rounding between lines, it never changes a total. */
  function calcDoc(d, dp) {
    const items = Array.isArray(d && d.items) ? d.items : [];
    const ex = [];
    let S = 0;
    let bad = "";
    for (const i of items) {
      const q = dec(i.qty),
        p = dec(i.price);
      if (!q || !p) {
        bad = "A quantity or price isn't a valid number.";
        ex.push({ n: 0n, s: 0 });
        continue;
      }
      if (q.s > QS || p.s > QS) bad = "Quantities and prices can have at most 6 decimal places.";
      if (q.n < 0n || p.n < 0n) bad = "Quantities and prices can't be negative.";
      ex.push({ n: q.n * p.n, s: q.s + p.s });
      if (q.s + p.s > S) S = q.s + p.s;
    }
    let sumN = 0n;
    const scaled = ex.map((e) => e.n * P10(S - e.s));
    for (const x of scaled) sumN += x;
    const sub = rnd(sumN, S, dp);
    let r = dec(d && d.vatRate != null && d.vatRate !== "" ? d.vatRate : 0);
    if (!r) {
      bad = "The VAT rate isn't a valid number.";
      r = { n: 0n, s: 0 };
    }
    if (r.n < 0n) bad = "VAT can't be negative.";
    else if (r.n > 100n * P10(r.s)) bad = "The VAT rate must be between 0 and 100%.";
    const vat = rnd(sub * r.n, dp + r.s + 2, dp);
    /* largest remainder split of `sub` across lines */
    const fl = scaled.map((x) => {
      const f = P10(S - dp > 0 ? S - dp : 0);
      if (S <= dp) return { q: x * P10(dp - S), r: 0n };
      const neg = x < 0n;
      const a = neg ? -x : x;
      return { q: (neg ? -1n : 1n) * (a / f), r: (neg ? -1n : 1n) * (a % f) };
    });
    let left = sub - fl.reduce((t, x) => t + x.q, 0n);
    const order = fl
      .map((x, i) => i)
      .sort((a, b) => {
        const d = fl[b].r - fl[a].r;
        return d > 0n ? 1 : d < 0n ? -1 : a - b;
      });
    const lines = fl.map((x) => x.q);
    for (let k = 0; left !== 0n && k < order.length * 2; k++) {
      const i = order[k % order.length];
      if (left > 0n) {
        lines[i] += 1n;
        left -= 1n;
      } else {
        lines[i] -= 1n;
        left += 1n;
      }
    }
    const out = {
      sub: safe(sub),
      vat: safe(vat),
      total: safe(sub + vat),
      lines: lines.map(safe),
      err: bad,
    };
    if (out.sub == null || out.vat == null || out.total == null || out.lines.some((x) => x == null))
      out.err = "Amount too large.";
    return out;
  }

  /* A real calendar date in YYYY-MM-DD form (30 February and month 13 are refused). */
  function validDate(s) {
    if (typeof s !== "string" || !/^\d{4}-\d{2}-\d{2}$/.test(s)) return false;
    const [y, m, d] = s.split("-").map(Number);
    if (m < 1 || m > 12 || d < 1) return false;
    return d <= new Date(Date.UTC(y, m, 0)).getUTCDate();
  }
  /* ---------- chart of accounts ---------- */
  const ACC = {
    1000: ["Cash on hand", "asset"],
    1010: ["MTN Mobile Money", "asset"],
    1020: ["Airtel Money", "asset"],
    1030: ["Bank", "asset"],
    1050: ["Other funds", "asset"],
    1100: ["Accounts receivable (clients)", "asset"],
    1200: ["Inventory", "asset"],
    1300: ["Input VAT (claimable)", "asset"],
    2000: ["Accounts payable (suppliers)", "liability"],
    2100: ["Output VAT (owed to URA)", "liability"],
    2300: ["Loans payable", "liability"],
    3000: ["Owner's capital", "equity"],
    3200: ["Owner's drawings", "equity"],
    4000: ["Sales", "income"],
    4900: ["Stock gains", "income"],
    5000: ["Cost of sales", "expense"],
    5100: ["Stock losses and write-offs", "expense"],
    6000: ["Materials & supplies", "expense"],
    6010: ["Equipment hire", "expense"],
    6020: ["Labour / casuals", "expense"],
    6030: ["Salaries & wages", "expense"],
    6040: ["Transport & fuel", "expense"],
    6050: ["Rent", "expense"],
    6060: ["Utilities", "expense"],
    6070: ["Airtime & data", "expense"],
    6080: ["Repairs & maintenance", "expense"],
    6090: ["Taxes & licenses", "expense"],
    6100: ["Professional fees", "expense"],
    6110: ["Marketing", "expense"],
    6900: ["Other expenses", "expense"],
  };
  const CASH = {
    Cash: "1000",
    "MTN Mobile Money": "1010",
    "Airtel Money": "1020",
    "Bank transfer": "1030",
    Cheque: "1030",
    Card: "1030",
    Other: "1050",
  };
  const CASH_ACCTS = ["1000", "1010", "1020", "1030", "1050"];
  /* Payment categories → the account they are charged to. "Supplier bill" with a supplier goes to payables. */
  const CATACC = {
    "Materials & supplies": "6000",
    "Equipment hire": "6010",
    "Labour / casuals": "6020",
    "Salaries & wages": "6030",
    "Transport & fuel": "6040",
    Rent: "6050",
    Utilities: "6060",
    "Airtime & data": "6070",
    "Repairs & maintenance": "6080",
    "Taxes & licenses": "6090",
    "Professional fees": "6100",
    Marketing: "6110",
    "Loan repayment": "2300",
    "Owner withdrawal": "3200",
    "VAT paid to URA": "2100",
    Other: "6900",
    "Supplier bill": "6900",
  };
  const EXPENSE_CATS = [
    "Materials & supplies",
    "Equipment hire",
    "Labour / casuals",
    "Transport & fuel",
    "Repairs & maintenance",
    "Rent",
    "Utilities",
    "Airtime & data",
    "Taxes & licenses",
    "Professional fees",
    "Marketing",
    "Other",
  ];
  const IN_KIND = "Goods (in kind)";
  const isAcc = (a) => Object.prototype.hasOwnProperty.call(ACC, a);
  const NORMAL_DR = (t) => t === "asset" || t === "expense";

  /* ---------- posting rules ----------
   Each rule turns one document into one balanced journal. Lines: {a:account, d:debit, c:credit} in minor units,
   plus p (client/supplier id) on receivable/payable lines and i/q (item id, signed quantity in millionths) on
   inventory lines. Stock lines out of inventory carry k:"avg" — their value must equal the moving-average cost. */
  const STOCK_COLLS = ["invoices", "credits", "purchases", "sdebits", "receipts", "adjustments"];
  const DOC_COLLS = [
    "invoices",
    "credits",
    "debits",
    "receipts",
    "refunds",
    "purchases",
    "sdebits",
    "payments",
    "adjustments",
  ];
  function L(a, d, c, x) {
    const o = { a, d: d || 0, c: c || 0 };
    if (x) Object.assign(o, x);
    return o;
  }
  /* stock: {itemId:{q:micro, v:minor}} = state BEFORE this document, read fresh under the item lease.
   cost(itemId,qOut) = moving-average cost of qOut from that state. */
  /* a×b÷c rounded half up, exact (a,b,c whole numbers, c>0) */
  function mulDiv(a, b, c) {
    const n = BigInt(a) * BigInt(b),
      C = BigInt(c);
    const neg = n < 0n;
    const x = neg ? -n : n;
    const q = (x * 2n + C) / (2n * C);
    return safe(neg ? -q : q);
  }
  function avgCost(st, qOut) {
    if (!st || st.q <= 0) return null;
    if (qOut > st.q) return null;
    if (qOut === st.q) return st.v;
    return mulDiv(st.v, qOut, st.q);
  }
  /* Builds the journal for a document. Returns {lines, err}. ctx: {dp, stock (state before), inv (credited invoice, for return costs)} */
  function post(coll, d, ctx) {
    const dp = ctx.dp;
    const lines = [];
    const err = (m) => ({ lines: [], err: m });
    if (!validDate(d && d.date)) return err("Enter a valid date.");
    const party = d.clientId || d.supplierId || null;
    const costs = ctx.costs ? ctx.costs.slice() : null;
    const stockOut = (itemId, q, st, tag) => {
      if (costs) {
        const x = costs.shift();
        if (!x || x.i !== itemId || x.q !== q) return { e: "Stock lines don't match" };
        return { c: x.c };
      }
      const s = st[itemId] || { q: 0, v: 0 };
      const c = avgCost(s, q);
      if (c == null) return { e: "Not enough " + (tag || "stock") + " in stock for this." };
      s.q -= q;
      s.v -= c;
      st[itemId] = s;
      return { c };
    };
    const st = JSON.parse(JSON.stringify(ctx.stock || {}));
    const stockIn = (itemId, q, v) => {
      const s = st[itemId] || { q: 0, v: 0 };
      s.q += q;
      s.v += v;
      st[itemId] = s;
    };
    if (
      coll === "invoices" ||
      coll === "debits" ||
      coll === "credits" ||
      coll === "purchases" ||
      coll === "sdebits"
    ) {
      const t = calcDoc(d, dp);
      if (t.err) return err(t.err);
      if (t.total <= 0) return err("The total must be more than zero.");
      if (coll === "invoices" || coll === "debits") {
        if (!d.clientId) return err("A client is required.");
        lines.push(L("1100", t.total, 0, { p: d.clientId }), L("4000", 0, t.sub));
        if (t.vat) lines.push(L("2100", 0, t.vat));
        if (coll === "invoices")
          for (const [k, i] of d.items.entries()) {
            if (!i.itemId) continue;
            const q = qtyMicro(i.qty);
            if (!q || q <= 0) return err("Stock lines need a quantity above zero.");
            const o = stockOut(i.itemId, q, st, i.desc);
            if (o.e) return err(o.e + " (" + (i.desc || "item") + ")");
            lines.push(
              L("5000", o.c, 0, { i: i.itemId }),
              L("1200", 0, o.c, { i: i.itemId, q: -q, k: "avg" }),
            );
          }
      } else if (coll === "credits") {
        if (!d.clientId) return err("A client is required.");
        lines.push(L("4000", t.sub, 0));
        if (t.vat) lines.push(L("2100", t.vat, 0));
        lines.push(L("1100", 0, t.total, { p: d.clientId }));
        for (const i of d.items) {
          if (!i.itemId || !i.restock) continue;
          const q = qtyMicro(i.qty);
          if (!q || q <= 0) return err("Returned stock needs a quantity above zero.");
          const uc = ctx.unitCost && ctx.unitCost[i.itemId];
          if (uc == null)
            return err("That item wasn't sold on this invoice, so it can't be returned to stock.");
          const v = mulDiv(uc.v, q, uc.q);
          stockIn(i.itemId, q, v);
          lines.push(L("1200", v, 0, { i: i.itemId, q }), L("5000", 0, v, { i: i.itemId }));
        }
      } else if (coll === "purchases") {
        if (!d.supplierId) return err("A supplier is required.");
        const exp = CATACC[d.account] || "6000";
        let expAmt = 0;
        d.items.forEach((i, k) => {
          const v = t.lines[k];
          if (i.itemId) {
            const q = qtyMicro(i.qty);
            lines.push(L("1200", v, 0, { i: i.itemId, q }));
            stockIn(i.itemId, q, v);
          } else expAmt += v;
        });
        if (d.items.some((i) => i.itemId && !(qtyMicro(i.qty) > 0)))
          return err("Stock lines need a quantity above zero.");
        if (expAmt) lines.push(L(exp, expAmt, 0));
        if (t.vat) lines.push(L("1300", t.vat, 0));
        lines.push(L("2000", 0, t.total, { p: d.supplierId }));
      } else if (coll === "sdebits") {
        if (!d.supplierId) return err("A supplier is required.");
        const exp = CATACC[d.account] || "6000";
        lines.push(L("2000", t.total, 0, { p: d.supplierId }));
        if (t.vat) lines.push(L("1300", 0, t.vat));
        let expAmt = 0;
        for (const [k, i] of d.items.entries()) {
          const v = t.lines[k];
          if (!i.itemId) {
            expAmt += v;
            continue;
          }
          const q = qtyMicro(i.qty);
          if (!q || q <= 0) return err("Stock lines need a quantity above zero.");
          const o = stockOut(i.itemId, q, st, i.desc);
          if (o.e) return err(o.e + " (" + (i.desc || "item") + ")");
          lines.push(L("1200", 0, o.c, { i: i.itemId, q: -q, k: "avg" }));
          if (v !== o.c)
            lines.push(
              v > o.c
                ? L("5000", 0, v - o.c, { i: i.itemId })
                : L("5000", o.c - v, 0, { i: i.itemId }),
            );
        }
        if (expAmt) lines.push(L(exp, 0, expAmt));
      }
    } else if (coll === "receipts") {
      if (!d.clientId) return err("A client is required.");
      if (d.method === IN_KIND) {
        const goods = Array.isArray(d.goods) ? d.goods : [];
        if (!goods.length) return err("List the goods received.");
        let tot = 0;
        for (const g of goods) {
          const q = qtyMicro(g.qty),
            v = exactMinor(g.value, dp);
          if (!g.itemId) return err("Choose the stock item for each line of goods.");
          if (!(q > 0)) return err("Goods need a quantity above zero.");
          if (v == null || v <= 0)
            return err(
              "Each line of goods needs a value above zero" +
                (dp ? "" : " in whole shillings") +
                ".",
            );
          lines.push(L("1200", v, 0, { i: g.itemId, q }));
          stockIn(g.itemId, q, v);
          tot += v;
        }
        const amt = exactMinor(d.amount, dp);
        if (amt !== tot) return err("The receipt amount must equal the total value of the goods.");
        lines.push(L("1100", 0, tot, { p: d.clientId }));
      } else {
        const amt = exactMinor(d.amount, dp);
        if (amt == null || amt <= 0)
          return err(
            "Amount must be above zero" +
              (dp ? " with at most " + dp + " decimals" : " in whole shillings") +
              ".",
          );
        const ca = CASH[d.method];
        if (!ca) return err("Choose how the money was received.");
        lines.push(L(ca, amt, 0), L("1100", 0, amt, { p: d.clientId }));
      }
    } else if (coll === "payments") {
      const amt = exactMinor(d.amount, dp);
      if (amt == null || amt <= 0)
        return err(
          "Amount must be above zero" +
            (dp ? " with at most " + dp + " decimals" : " in whole shillings") +
            ".",
        );
      const ca = CASH[d.method];
      if (!ca) return err("Choose how the money was paid.");
      const dr = d.supplierId ? "2000" : CATACC[d.category] || "6900";
      lines.push(L(dr, amt, 0, d.supplierId ? { p: d.supplierId } : null), L(ca, 0, amt));
    } else if (coll === "refunds") {
      const amt = exactMinor(d.amount, dp);
      if (amt == null || amt <= 0)
        return err(
          "Amount must be above zero" +
            (dp ? " with at most " + dp + " decimals" : " in whole shillings") +
            ".",
        );
      const ca = CASH[d.method];
      if (!ca) return err("Choose the method.");
      if (d.clientId) lines.push(L("1100", amt, 0, { p: d.clientId }), L(ca, 0, amt));
      else if (d.supplierId) lines.push(L(ca, amt, 0), L("2000", 0, amt, { p: d.supplierId }));
      else return err("Choose the client or supplier.");
    } else if (coll === "adjustments") {
      if (!d.itemId) return err("Choose the item.");
      const q = qtyMicro(d.qty);
      if (!q) return err("Enter the quantity change (use a minus sign for stock removed).");
      if (q > 0) {
        const v = exactMinor(d.value, dp);
        if (v == null || v < 0)
          return err(
            "Enter the value of the stock added" + (dp ? "" : " in whole shillings") + ".",
          );
        lines.push(L("1200", v, 0, { i: d.itemId, q }));
        if (v) lines.push(L("4900", 0, v));
        stockIn(d.itemId, q, v);
      } else {
        const o = stockOut(d.itemId, -q, st);
        if (o.e) return err(o.e);
        if (o.c) lines.push(L("5100", o.c, 0, { i: d.itemId }));
        lines.push(L("1200", 0, o.c, { i: d.itemId, q, k: "avg" }));
      }
    } else return err("This document type isn't posted.");
    const chk = balanced(lines);
    if (chk) return err(chk);
    return { lines, stockAfter: st };
  }

  /* Reversal of a posted journal on its void date. Stock leaving inventory is taken at the moving-average cost
   at the time of the void (k:"avg"); any difference from the original value goes to cost of sales, so the
   inventory account always equals the stock valuation. stock = item state before the void. */
  function reverse(je, stock) {
    const st = JSON.parse(JSON.stringify(stock || {}));
    const out = [];
    for (const l of je.lines) {
      if (l.a === "1200" && l.q > 0) {
        const s = st[l.i] || { q: 0, v: 0 };
        const c = avgCost(s, l.q);
        if (c == null)
          return {
            err: "Voiding this would take more stock than is on hand. Record the stock movement that explains it first.",
          };
        s.q -= l.q;
        s.v -= c;
        st[l.i] = s;
        out.push(L("1200", 0, c, { i: l.i, q: -l.q, k: "avg" }));
        if (c !== l.d)
          out.push(c > l.d ? L("5000", c - l.d, 0, { i: l.i }) : L("5000", 0, l.d - c, { i: l.i }));
      } else if (l.a === "1200" && l.q < 0) {
        const s = st[l.i] || { q: 0, v: 0 };
        s.q += -l.q;
        s.v += l.c;
        st[l.i] = s;
        out.push(L("1200", l.c, 0, { i: l.i, q: -l.q }));
      } else {
        const x = {};
        if (l.p) x.p = l.p;
        if (l.i) x.i = l.i;
        out.push(L(l.a, l.c, l.d, Object.keys(x).length ? x : null));
      }
    }
    const chk = balanced(out);
    if (chk) return { err: chk };
    return { lines: out, stockAfter: st };
  }

  function balanced(lines) {
    if (!lines.length) return "The journal has no lines.";
    let d = 0,
      c = 0;
    for (const l of lines) {
      if (!isAcc(l.a)) return "Unknown account " + l.a + ".";
      if (!Number.isSafeInteger(l.d) || !Number.isSafeInteger(l.c) || l.d < 0 || l.c < 0)
        return "A journal amount isn't a whole number of minor units.";
      if (l.d > 0 === l.c > 0 && !(l.a === "1200" && l.d === 0 && l.c === 0))
        return "Each journal line must be either a debit or a credit.";
      d += l.d;
      c += l.c;
    }
    if (!Number.isSafeInteger(d) || !Number.isSafeInteger(c)) return "Journal total is too large.";
    if (d !== c) return "Debits (" + d + ") don't equal credits (" + c + ").";
    return "";
  }

  /* ---------- integrity fingerprint ----------
   FNV-1a over a canonical form of the journal and the source fields it was posted from. It detects records changed
   outside the app (or damaged); it is not a security seal — someone who can run code can recompute it. */
  function canon(v) {
    if (Array.isArray(v)) return "[" + v.map(canon).join(",") + "]";
    if (v && typeof v === "object")
      return (
        "{" +
        Object.keys(v)
          .sort()
          .map((k) => JSON.stringify(k) + ":" + canon(v[k]))
          .join(",") +
        "}"
      );
    return JSON.stringify(v === undefined ? null : v);
  }
  function fnv(s) {
    let h = 0x811c9dc5;
    for (let i = 0; i < s.length; i++) {
      h ^= s.charCodeAt(i);
      h = Math.imul(h, 0x01000193) >>> 0;
    }
    return ("0000000" + h.toString(16)).slice(-8);
  }
  function source(coll, d) {
    const o = {
      date: d.date || "",
      clientId: d.clientId || null,
      supplierId: d.supplierId || null,
    };
    if (["invoices", "credits", "debits", "purchases", "sdebits"].includes(coll)) {
      o.items = (d.items || []).map((i) => [
        String(i.qty),
        String(i.price),
        i.itemId || null,
        !!i.restock,
      ]);
      o.vatRate = String(d.vatRate || 0);
      o.invoiceId = d.invoiceId || null;
      o.purchaseId = d.purchaseId || null;
      o.account = d.account || null;
    }
    if (["receipts", "payments", "refunds"].includes(coll)) {
      o.amount = String(d.amount);
      o.method = d.method || "";
      o.category = d.category || null;
      o.goods = (d.goods || []).map((g) => [g.itemId || null, String(g.qty), String(g.value)]);
    }
    if (coll === "adjustments") {
      o.itemId = d.itemId || null;
      o.qty = String(d.qty);
      o.value = String(d.value || 0);
    }
    return o;
  }
  function seal(j, coll, d) {
    return fnv(
      canon({
        pid: j.pid,
        date: j.date,
        cur: j.cur,
        dp: j.dp,
        lines: j.lines,
        src: d ? source(coll, d) : null,
      }),
    );
  }
  function makeJE(coll, id, d, lines, meta) {
    const j = {
      v: 1,
      pid: coll + "/" + id,
      date: d.date,
      cur: meta.cur,
      dp: meta.dp,
      at: meta.at,
      by: meta.by || "",
      lines,
    };
    j.h = seal(j, coll, d);
    return j;
  }
  function makeRev(coll, id, d, lines, meta) {
    const j = {
      v: 1,
      pid: coll + "/" + id + ":R",
      date: meta.date,
      cur: meta.cur,
      dp: meta.dp,
      at: meta.at,
      by: meta.by || "",
      reason: meta.reason || "",
      lines,
    };
    j.h = seal(j, coll, null);
    return j;
  }

  /* ---------- stock: moving weighted average, replayed from postings ----------
   movements: [{item, q (signed micro), v (minor, signed), k, at, pid}] in posting order. */
  function stockMovements(je) {
    const out = [];
    if (!je || !Array.isArray(je.lines)) return out;
    for (const l of je.lines)
      if (l.a === "1200" && l.i)
        out.push({
          item: l.i,
          q: l.q || 0,
          v: (l.d || 0) - (l.c || 0),
          k: l.k || "",
          at: je.at,
          pid: je.pid,
          n: l.n,
        });
    return out;
  }
  /* Replays every movement in posting order and checks each "avg" movement against the moving average at that point. */
  function replayStock(journals) {
    const st = {};
    const issues = [];
    const by = new Map();
    for (const j of journals)
      for (const m of stockMovements(j)) {
        if (!by.has(m.item)) by.set(m.item, []);
        by.get(m.item).push(m);
      }
    for (const [item, mv] of by) {
      mv.sort(
        (a, b) =>
          (a.n ?? 1e15) - (b.n ?? 1e15) ||
          (a.at < b.at ? -1 : a.at > b.at ? 1 : a.pid < b.pid ? -1 : a.pid > b.pid ? 1 : 0),
      );
      let exp = 0;
      const s = (st[item] = { q: 0, v: 0 });
      for (const m of mv) {
        if (m.n !== exp)
          issues.push({
            pid: m.pid,
            item,
            msg:
              m.n == null
                ? "Stock movement has no sequence number."
                : "Stock movement out of sequence (expected #" +
                  exp +
                  ", found #" +
                  m.n +
                  "): two postings may have used the same stock figures, or a posting is missing.",
          });
        exp = (m.n ?? exp) + 1;
        if (m.k === "avg") {
          const want = avgCost(s, -m.q);
          if (want == null) issues.push({ pid: m.pid, item, msg: "Stock went below zero." });
          else if (-m.v !== want)
            issues.push({
              pid: m.pid,
              item,
              msg: "Cost " + -m.v + " differs from the moving-average cost " + want + ".",
            });
        }
        s.q += m.q;
        s.v += m.v;
        if (s.q < 0 || s.v < 0)
          issues.push({ pid: m.pid, item, msg: "Stock quantity or value went below zero." });
        if (s.q === 0 && s.v !== 0)
          issues.push({
            pid: m.pid,
            item,
            msg: "No stock left but a value of " + s.v + " remains.",
          });
      }
    }
    return { state: st, issues };
  }
  /* Cost per item charged on an invoice (from its posted journal), for pricing returns. {item:{q,v}} */
  function unitCosts(je) {
    const u = {};
    if (je && Array.isArray(je.lines))
      for (const l of je.lines)
        if (l.a === "1200" && l.k === "avg" && l.i) {
          const x = u[l.i] || (u[l.i] = { q: 0, v: 0 });
          x.q += -l.q;
          x.v += l.c;
        }
    return u;
  }
  /* Number every stock line of a new journal: n = how many movements of that item already exist (read fresh). */
  function numberStock(lines, counts) {
    const c = { ...counts };
    for (const l of lines)
      if (l.a === "1200" && l.i) {
        l.n = c[l.i] || 0;
        c[l.i] = l.n + 1;
      }
    return lines;
  }

  /* ---------- checks ----------
   Never fixes anything: it only lists what is wrong. entries: [{coll,id,doc}] for every posted collection. */
  function check(entries, opts) {
    const issues = [];
    const pids = new Map();
    const journals = [];
    const dp = opts.dp;
    const memo = opts.memo || null;
    for (const { coll, id, doc } of entries) {
      const ref = coll + "/" + id;
      const dep = opts.depOf ? opts.depOf(coll, doc) : null;
      /* Each document's own checks depend only on that document (and, for credit notes, the invoice), so unchanged
       documents reuse their earlier result; the cross-document checks below always run in full. */
      let local = memo && memo.get(doc);
      if (!local || local.dp !== dp || local.dep !== dep || local.ref !== ref) {
        local = checkOne(coll, id, ref, doc, dp, opts);
        local.dp = dp;
        local.dep = dep;
        local.ref = ref;
        if (memo) memo.set(doc, local);
      }
      for (const x of local.issues) issues.push(x);
      for (const j of local.journals) {
        if (pids.has(j.pid))
          issues.push({ sev: "error", ref, msg: "Duplicate posting id " + j.pid + "." });
        pids.set(j.pid, ref);
        journals.push(j);
      }
    }
    const rs = replayStock(journals);
    for (const x of rs.issues) issues.push({ sev: "error", ref: x.pid, msg: x.msg });
    return { issues, journals, stock: rs.state };
  }
  /* Fills the per-document results for entries[i0..i1) ahead of time, so the first full check can be spread over several short slices. */
  function warm(entries, opts, i0, i1) {
    const dp = opts.dp,
      memo = opts.memo;
    if (!memo) return;
    for (let k = i0; k < Math.min(i1, entries.length); k++) {
      const { coll, id, doc } = entries[k];
      const ref = coll + "/" + id;
      const dep = opts.depOf ? opts.depOf(coll, doc) : null;
      const local = memo.get(doc);
      if (local && local.dp === dp && local.dep === dep && local.ref === ref) continue;
      const x = checkOne(coll, id, ref, doc, dp, opts);
      x.dp = dp;
      x.dep = dep;
      x.ref = ref;
      memo.set(doc, x);
    }
  }
  function checkOne(coll, id, ref, doc, dp, opts) {
    const issues = [],
      journals = [];
    const add = (sev, r, msg) => issues.push({ sev, ref: r, msg });
    const je = doc.je;
    if (!je || typeof je !== "object" || !Array.isArray(je.lines)) {
      add("error", ref, "Not posted to the ledger: this document has no journal entry.");
      return { issues, journals };
    }
    const jes = [["post", je]];
    if (doc.jr) jes.push(["reversal", doc.jr]);
    if (doc.void && !doc.jr) add("error", ref, "Marked void but has no reversal entry.");
    if (!doc.void && doc.jr) add("error", ref, "Has a reversal entry but is not marked void.");
    for (const [kind, j] of jes) {
      if (!j || typeof j !== "object" || !Array.isArray(j.lines)) {
        add("error", ref, "The " + kind + " journal is damaged.");
        continue;
      }
      const want = kind === "post" ? ref : ref + ":R";
      if (j.pid !== want) add("error", ref, "Posting id is " + j.pid + ", expected " + want + ".");
      const b = balanced(j.lines);
      if (b) add("error", ref, b);
      if (j.dp !== dp) add("error", ref, "Posted in another currency setting (" + j.cur + ").");
      if (!validDate(j.date)) add("error", ref, "Posting date is invalid.");
      if (seal(j, coll, kind === "post" ? doc : null) !== j.h)
        add(
          "error",
          ref,
          kind === "post"
            ? "The document or its journal was changed after posting (fingerprint mismatch)."
            : "The reversal entry was changed after posting (fingerprint mismatch).",
        );
      if (kind === "post" && j.date !== doc.date)
        add("error", ref, "Journal date differs from the document date.");
      if (kind === "reversal" && j.date !== doc.voidedAt)
        add("error", ref, "Reversal date differs from the void date.");
      journals.push(j);
    }
    /* the journal must still say what the document says (non-stock parts are recomputed from the source fields) */
    const re = post(coll, doc, {
      dp,
      costs: je.lines
        .filter((l) => l.a === "1200" && l.k === "avg")
        .map((l) => ({ i: l.i, q: -l.q, c: l.c })),
      unitCost: opts.unitCost && opts.unitCost(coll, doc),
    });
    if (re.err) add("error", ref, "Can't recompute this posting: " + re.err);
    else if (sig(re.lines) !== sig(je.lines))
      add("error", ref, "The journal doesn't match the document's amounts or accounts.");
    if (doc.jr && Array.isArray(doc.jr.lines)) {
      const plain = (ls) => ls.filter((l) => l.a !== "1200" && l.a !== "5000");
      const mirror = plain(je.lines).map((l) => ({ ...l, d: l.c, c: l.d }));
      if (sig(mirror) !== sig(plain(doc.jr.lines)))
        add("error", ref, "The reversal entry doesn't mirror the original posting.");
    }
    return { issues, journals };
  }
  /* Signature of a journal ignoring stock sequence numbers; amounts per account/party/item. */
  function sig(lines) {
    return lines
      .map((l) => [l.a, l.d, l.c, l.p || "", l.i || "", l.q || 0, l.k || ""].join("|"))
      .sort()
      .join(";");
  }

  /* ---------- reports from journals ---------- */
  function inRange(d, from, to) {
    return (!from || d >= from) && (!to || d <= to);
  }
  function balances(journals, from, to) {
    const b = {};
    for (const j of journals) {
      if (!inRange(j.date, from, to)) continue;
      for (const l of j.lines) {
        const x = b[l.a] || (b[l.a] = { d: 0, c: 0 });
        x.d += l.d;
        x.c += l.c;
      }
    }
    return b;
  }
  function trialBalance(journals, to) {
    const b = balances(journals, null, to);
    const rows = Object.keys(ACC)
      .filter((a) => b[a])
      .map((a) => {
        const n = b[a].d - b[a].c;
        return { a, name: ACC[a][0], type: ACC[a][1], dr: n > 0 ? n : 0, cr: n < 0 ? -n : 0 };
      });
    const dr = rows.reduce((t, r) => t + r.dr, 0),
      cr = rows.reduce((t, r) => t + r.cr, 0);
    return { rows, dr, cr, ok: dr === cr };
  }
  function profitLoss(journals, from, to) {
    const b = balances(journals, from, to);
    const inc = [],
      exp = [];
    for (const a of Object.keys(ACC)) {
      if (!b[a]) continue;
      const t = ACC[a][1];
      if (t === "income") inc.push({ a, name: ACC[a][0], amt: b[a].c - b[a].d });
      if (t === "expense") exp.push({ a, name: ACC[a][0], amt: b[a].d - b[a].c });
    }
    const ti = inc.reduce((t, r) => t + r.amt, 0),
      te = exp.reduce((t, r) => t + r.amt, 0);
    const cos = exp.filter((r) => r.a === "5000" || r.a === "5100").reduce((t, r) => t + r.amt, 0);
    const sales = (inc.find((r) => r.a === "4000") || { amt: 0 }).amt;
    return { inc, exp, ti, te, gross: sales - cos, net: ti - te };
  }
  function balanceSheet(journals, to) {
    const b = balances(journals, null, to);
    const sec = { asset: [], liability: [], equity: [] };
    let earn = 0;
    for (const a of Object.keys(ACC)) {
      if (!b[a]) continue;
      const t = ACC[a][1];
      const n = b[a].d - b[a].c;
      if (t === "asset") sec.asset.push({ a, name: ACC[a][0], amt: n });
      else if (t === "liability") sec.liability.push({ a, name: ACC[a][0], amt: -n });
      else if (t === "equity") sec.equity.push({ a, name: ACC[a][0], amt: -n });
      else earn += -n;
    }
    const A = sec.asset.reduce((t, r) => t + r.amt, 0),
      Li = sec.liability.reduce((t, r) => t + r.amt, 0),
      E = sec.equity.reduce((t, r) => t + r.amt, 0) + earn;
    return {
      asset: sec.asset,
      liability: sec.liability,
      equityLines: sec.equity,
      earnings: earn,
      assets: A,
      liabilities: Li,
      equity: E,
      ok: A === Li + E,
    };
  }
  /* VAT return for a period, from the VAT accounts, with the net sales and purchases behind them. */
  function vatReturn(journals, from, to) {
    let out = 0,
      inp = 0,
      sales = 0,
      purch = 0,
      paid = 0;
    for (const j of journals) {
      if (!inRange(j.date, from, to)) continue;
      const isPay = j.pid.startsWith("payments/");
      const isP = /^(purchases|sdebits)\//.test(j.pid);
      for (const l of j.lines) {
        if (l.a === "2100") {
          if (isPay) paid += l.d - l.c;
          else out += l.c - l.d;
        }
        if (l.a === "1300") inp += l.d - l.c;
        if (l.a === "4000") sales += l.c - l.d;
        if (isP) {
          if (l.a === "2000") purch += l.c - l.d;
          if (l.a === "1300") purch -= l.d - l.c;
        }
      }
    }
    return {
      outputVat: out,
      inputVat: inp,
      netVat: out - inp,
      sales,
      purchases: purch,
      paidToURA: paid,
    };
  }
  /* Party ledger (customer or supplier) from the control account lines that carry the party. */
  function partyBalances(journals, acct, to) {
    const m = new Map();
    for (const j of journals) {
      if (to && j.date > to) continue;
      for (const l of j.lines)
        if (l.a === acct && l.p) {
          m.set(l.p, (m.get(l.p) || 0) + (acct === "1100" ? l.d - l.c : l.c - l.d));
        }
    }
    return m;
  }
  function generalLedger(journals, acct, from, to) {
    const rows = [];
    let bal = 0;
    const nd = NORMAL_DR(ACC[acct][1]);
    const js = journals
      .slice()
      .sort((a, b) =>
        a.date < b.date ? -1 : a.date > b.date ? 1 : a.at < b.at ? -1 : a.at > b.at ? 1 : 0,
      );
    for (const j of js) {
      for (const l of j.lines) {
        if (l.a !== acct) continue;
        const amt = nd ? l.d - l.c : l.c - l.d;
        if (from && j.date < from) {
          bal += amt;
          continue;
        }
        if (to && j.date > to) continue;
        bal += amt;
        rows.push({ date: j.date, pid: j.pid, d: l.d, c: l.c, bal, p: l.p || "", i: l.i || "" });
      }
    }
    return rows;
  }

  return {
    dec,
    rnd,
    exactMinor,
    roundMinor,
    toMajor,
    qtyMicro,
    microQty,
    calcDoc,
    ACC,
    CASH,
    CASH_ACCTS,
    CATACC,
    EXPENSE_CATS,
    IN_KIND,
    STOCK_COLLS,
    DOC_COLLS,
    post,
    reverse,
    balanced,
    mulDiv,
    unitCosts,
    warm,
    validDate,
    makeJE,
    makeRev,
    seal,
    fnv,
    canon,
    source,
    stockMovements,
    replayStock,
    numberStock,
    avgCost,
    check,
    sig,
    balances,
    trialBalance,
    profitLoss,
    balanceSheet,
    vatReturn,
    partyBalances,
    generalLedger,
  };
})();
if (typeof module !== "undefined") module.exports = LEDGER;
