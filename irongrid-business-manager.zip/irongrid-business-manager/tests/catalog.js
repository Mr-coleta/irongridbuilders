// Test catalogue: which suite each browser test belongs to, and whether it is MANDATORY for release.
// Mandatory = protects financial integrity, data integrity, security or authorization. A release is blocked if any
// mandatory test fails, is missing, or did not run. Only timing benchmarks (machine-dependent) are advisory.
'use strict';
const SUITES = {
  'e2e': 'End-to-end (whole workflows through the app)',
  'db-integrity': 'Database integrity (atomicity, references, links, backups, migrations)',
  'concurrency': 'Concurrency (simultaneous users, locks, races)',
  'security': 'Security and authorization',
  'regression': 'Regression (one test per defect fixed earlier)',
  'performance': 'Performance benchmarks',
};
const EXPLICIT = {
  // concurrency
  'A-05': ['concurrency'], 'R-01': ['concurrency'], 'R-02': ['concurrency'], 'R-09': ['concurrency'], 'R-11': ['concurrency'], 'H-11': ['concurrency'],
  'L-08': ['concurrency'], 'E-14': ['concurrency'], 'D-01': ['concurrency'], 'D-05': ['concurrency'], 'D-06': ['concurrency'], 'D-07': ['concurrency'], 'D-08': ['concurrency', 'db-integrity'],
  // security & authorization
  'H-01': ['security'], 'H-08': ['security'], 'H-12': ['security'], 'L-06': ['security'], 'E-13': ['security', 'db-integrity'],
  // database integrity
  'A-06': ['db-integrity'], 'R-04': ['db-integrity'], 'R-06': ['db-integrity'], 'R-07': ['db-integrity'], 'R-08': ['db-integrity'], 'R-10': ['db-integrity'], 'R-12': ['db-integrity'], 'R-13': ['db-integrity'],
  'E-12': ['db-integrity'], 'PERF-5': ['db-integrity'], 'PERF-6': ['db-integrity'], 'PERF-2': ['db-integrity'], 'PERF-3': ['db-integrity'], 'H-09': ['db-integrity'],
  // performance (advisory: timings depend on the machine running them)
  'PERF': ['performance'], 'PERF-4': ['performance'],
};
const ADVISORY = new Set(['PERF', 'PERF-4']);
function classify(id) {
  const suites = new Set(EXPLICIT[id] || []);
  if (/^(H|A|R)-/.test(id)) suites.add('regression');
  if (/^(L|E|M|N)-/.test(id) && !EXPLICIT[id]) suites.add('e2e');
  if (/^S-/.test(id)) suites.add('security');
  if (/^D-/.test(id) && !EXPLICIT[id]) suites.add('db-integrity');
  if (!suites.size) suites.add('e2e');
  return { suites: [...suites], mandatory: !ADVISORY.has(id) };
}
module.exports = { SUITES, classify, ADVISORY };
