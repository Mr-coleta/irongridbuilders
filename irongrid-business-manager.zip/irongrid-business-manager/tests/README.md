# Automated testing framework — Irongrid Business Manager

One command decides whether a build may be released:

```
node tests/run-all.js              # everything except mutation testing (~45 min)
node tests/run-all.js --quick      # unit + integration + coverage only (~15 s), reuses the last browser results
node tests/run-all.js --mutation   # also plants ~730 bugs in the engine and checks the tests catch them (~45 min)
```

The gate **blocks a release** (exit code 1) when any mandatory test fails or does not run, when line, branch or
function coverage of the accounting engine is under 90%, or (with `--mutation`) when the mutation score is under 85%.
Reports: `tests/reports/test-report.html` (readable), `test-report.json`, `engine.lcov`, `browser-coverage.json`,
`mutation.json`.

## Suites

| Suite | File | What it proves |
|---|---|---|
| Unit | `unit/ledger.unit.test.js` | Every posting rule, refusal, rounding rule and integrity check in the engine |
| Unit — precision | `unit/ledger.precision.test.js` | Exact figures, names, period boundaries, ordering, reversals (added after mutation testing) |
| Integration | `integration/books.int.test.js` | 35 synthetic two-month books (5,943 postings) agree with an independent oracle; closed months never change; bank ledger reconciles |
| Engine regression | `engine.test.js` | The original 21 engine tests, unchanged |
| Browser (e2e, db-integrity, concurrency, security, regression, performance) | `regression.js` | Whole workflows in the real app against a faithful stand-in for the storage platform, with 1–4 simultaneous users and injected faults |
| Mutation | `mutation/mutate.js` | Tests detect wrong results, not just run the code |
| Scale | `scale/scale.test.js` (+ `scale/books.js`) | 24,990 fully posted records (the platform limit is 25,000): load, books check, every screen, a new posting, full backup and restore, and behaviour when storage is full |
| Printing | `print/print.test.js` | Every document type downloaded from the app, printed to an A4 PDF, and the PDF's text checked against engine totals; long invoices paginate without splitting lines; no screen-only content printed |
| Phones and tablets | `mobile/mobile.test.js` | 320–768 px screens, touch input, landscape: nothing scrolls sideways, posting by touch works, form text ≥ 16 px; old browsers get a clear message |
| Real platform (manual trigger) | `platform/harness.html` | Published as a scratch artifact with its own empty database; three simulated users test the platform's real locks, numbering and overwrites. Not part of the gate (it needs a signed-in browser) |

`catalog.js` tags each browser test with its suite(s) and whether it is mandatory. Only two timing benchmarks
(PERF, PERF-4) are advisory, because their numbers depend on the machine.

## Synthetic data
`data/synthetic.js` — 12 invented clients, 8 invented suppliers, construction stock (cement 50kg, Y12/Y16 bars, iron
sheets, nails, lake sand) at realistic Kampala prices. Seeded, so any failure is exactly reproducible
(`generator(1022)` always produces the same book).

## Coverage
- The engine source packs many statements on a line, so line coverage would be meaningless. `tools/format-for-coverage.js`
  writes a one-statement-per-line copy and the tests run against it (`LEDGER_PATH`). Branches and functions are measured too.
- Browser coverage (`COVERAGE=1 node tests/regression.js`) records which parts of the app's own script ran in any test.

## Rules
- A test states the correct accounting behaviour first. If it fails, fix the code — never weaken the test.
- A test may only be corrected when it is shown to be wrong about wording or mechanism, and the correction must keep
  (or strengthen) what it checks. Every such case is recorded in the test report.
- Every defect fixed gets a test that fails without the fix.

## Setup for browser suites
Copy the app to `srv/index.html` with `mock.js`, `two.html`, `four.html`, then `cd srv && python3 -m http.server 8765`.
Needs Node 22+ and Playwright with Chromium.
