// Security suite: role-based access enforced by the storage rules (security/rules.json, the same rules declared on
// the live app), maker-checker approvals, bypass attempts through the raw platform API, audit log, encrypted backups.
// The owner (u1) and a staff member (u2, Contributor or Editor) use the app side by side on one shared database.
// Usage: node tests/security/security.test.js   (server on :8765 serving srv/)
'use strict';
const { chromium } = require('playwright'); const fs = require('fs'); const path = require('path');
const MOCK = require('../mocksrc.js'); const probe = require('./xss-probe.js');
const results = []; const assert = (c, m) => { if (!c) throw new Error(m); };
async function test(id, name, fn) {
  if (process.env.ONLY && !process.env.ONLY.split(',').includes(id)) return;
  const t0 = Date.now();
  try { const detail = await fn(); results.push({ id, name, pass: true, ms: Date.now() - t0, detail: detail || '' }); }
  catch (e) { results.push({ id, name, pass: false, ms: Date.now() - t0, detail: e.message.split('\n')[0] }); }
  const r = results.at(-1); console.log(`${r.pass ? 'PASS' : 'FAIL'}  ${id}  ${name}${r.detail ? '  — ' + r.detail : ''}`);
}
const SEED = `S.set("settings/business",{name:"Irongrid (synthetic)",currency:"UGX",payDetails:"Stanbic 0000",lockDate:"2026-09-30"});S.set("clients/c",{name:"Nansubuga Estates Ltd"});S.set("suppliers/s",{name:"Lake Victoria Cement Ltd"});S.set("items/cem",{name:"Cement 50kg",unit:"bags"});`;
let browser;
async function pair(staffLevel = 'interact', extraSeed = '') {
  const p = await browser.newPage({ viewport: { width: 2400, height: 950 } }); p.setDefaultTimeout(6000); const errs = []; p.on('pageerror', e => errs.push(e.message));
  await p.addInitScript(`${MOCK};
    if(window===window.top){const S=window.__S=new Map();window.__NAMES={u1:"Alexander (owner)",u2:"Grace (staff)"};${SEED}${extraSeed}}
    else{const as=new URLSearchParams(location.search).get("as");window.__mock(as==="staff"?{level:${JSON.stringify(staffLevel)},uid:"u2",delay:40}:{level:"owner",uid:"u1",delay:40})}`);
  await p.goto('http://localhost:8765/roles.html'); await p.waitForTimeout(1500);
  const fr = p.frames(); const owner = fr.find(f => f.url().includes('as=owner')), staff = fr.find(f => f.url().includes('as=staff'));
  return { p, owner, staff, errs };
}
const DB = p => p.evaluate(() => Object.fromEntries([...window.__S.entries()]));
const books = f => f.evaluate(() => { const L = ledger(); const I = integrity(); return { problems: L.problems, errors: I.errors.map(e => e.msg), n: L.J.length }; });
const toasts = async (f, ms = 1500) => { const seen = []; for (let i = 0; i < ms / 100; i++) { const t = await f.textContent('#toast'); if (t && !seen.includes(t)) seen.push(t); await f.waitForTimeout(100); } return seen; };
// raw platform API from inside a page: exactly what someone going round the app would use
const raw = (f, code) => f.evaluate(async code => { const db = await claude.use('db'); try { const r = await (new Function('db', 'return (async()=>{' + code + '})()'))(db); return { ok: true, r: r === undefined ? null : r }; } catch (e) { return { ok: false, code: e && e.code }; } }, code);
async function buyStock(f, qty, price) { await f.evaluate(() => location.hash = 'purchases'); await f.waitForTimeout(200); await f.click('#lNew'); await f.selectOption('#ed [name=party]', 's'); await f.selectOption('#ed .si', 'cem'); await f.fill('#ed .q', String(qty)); await f.fill('#ed .p', String(price)); await f.fill('#ed [name=vatRate]', '18'); await f.click('#ed [type=submit]'); await f.waitForTimeout(1200); await f.click('#mBtns >> text=Close').catch(() => {}); }

(async () => {
  browser = await chromium.launch();

  await test('SEC-01', 'Payment by a staff member becomes a request: nothing numbered or posted until the owner approves; approval posts it with an owner-written approval record', async () => {
    const { p, owner, staff, errs } = await pair();
    await buyStock(staff, 10, 30000); // purchases stay direct for staff
    const pur = (await staff.evaluate(() => S.purchases[0])); assert(pur && pur.je, 'staff purchase not posted');
    await staff.evaluate(id => openEditor('payments', null, { supplierId: 's', purchaseId: id, category: 'Supplier bill' }), pur.id); await staff.waitForTimeout(300);
    const btn = await staff.textContent('#ed [type=submit]'); await staff.fill('#ed [name=amount]', '200000'); await staff.click('#ed [type=submit]'); await staff.waitForTimeout(1200);
    let db = await DB(p); assert(!Object.keys(db).some(k => k.startsWith('payments/')), 'a payment was written'); assert(!(db['counters/payments']), 'a payment number was taken');
    const req = db['requests/u2'].list[0]; assert(req && req.coll === 'payments' && req.data.amount === 200000 && req.by === 'u2', 'request ' + JSON.stringify(req));
    // owner sees it, approves it in the normal form
    await owner.evaluate(() => location.hash = 'approvals'); await owner.waitForTimeout(400); const row = await owner.textContent('#apList');
    assert(/Grace/.test(row) && /200,000/.test(row), 'owner approvals list: ' + row.slice(0, 200));
    await owner.click('#apList [data-ap=ok]'); await owner.waitForTimeout(400); const note = await owner.textContent('#ed'); const amt = await owner.inputValue('#ed [name=amount]');
    assert(/Approving a request from Grace/.test(note) && amt === '200000', 'form not prefilled: ' + amt);
    await owner.click('#ed [type=submit]'); await owner.waitForTimeout(1500);
    db = await DB(p); const pay = Object.entries(db).find(([k]) => k.startsWith('payments/')); assert(pay && pay[1].je && pay[1].amount === 200000, 'payment not posted');
    const id = pay[0].split('/')[1]; const ap = db['approvals/payments-' + id], dec = db['approvals/rq-' + req.rid];
    assert(ap && ap.by === 'u1' && ap.requestId === req.rid && ap.requestedBy === 'u2', 'approval record ' + JSON.stringify(ap)); assert(dec && dec.decision === 'approved' && dec.posted === 'payments/' + id, 'decision ' + JSON.stringify(dec));
    await staff.evaluate(() => location.hash = 'approvals'); await staff.waitForTimeout(400); const st = await staff.textContent('#apDone'); assert(/Approved/.test(st) && /PAY-0001/.test(st), 'staff view: ' + st.slice(0, 160));
    const b = await books(owner); assert(b.problems === 0 && !b.errors.length, 'checks: ' + JSON.stringify(b)); assert(!errs.length, errs.join('; ')); await p.close();
    return `staff button "${btn}"; no payment or number until approved; PAY-0001 posted by owner with approval record; staff sees Approved; checks clean`;
  });

  await test('SEC-02', 'Going round the app: a staff member writing straight to the platform cannot create or change payments, refunds, credit notes, adjustments, business details or approval records', async () => {
    const { p, staff } = await pair('interact', `S.set("payments/p0",{number:"PAY-0001",date:"2026-10-05",payee:"UMEME",amount:100,method:"Cash",category:"Utilities"});`);
    const before = JSON.stringify(await DB(p)); const tries = {
      'create payment': 'await db.doc("payments/x1").set({number:"PAY-9",amount:5000000,method:"Cash",category:"Utilities",payee:"me"})',
      'edit payment': 'await db.doc("payments/p0").update({amount:999999})', 'delete payment': 'await db.doc("payments/p0").delete()',
      'create refund': 'await db.doc("refunds/x1").set({amount:1})', 'create credit note': 'await db.doc("credits/x1").set({total:1})', 'create stock adjustment': 'await db.doc("adjustments/x1").set({qty:-100})',
      'change banking details': 'await db.doc("settings/business").update({payDetails:"Attacker bank 999"})', 'reopen the period': 'await db.doc("settings/business").update({lockDate:""})',
      'forge approval record': 'await db.doc("approvals/payments-x1").set({by:"u1",requestId:null})', 'approve own request': 'await db.doc("approvals/rq-anything").set({decision:"approved"})',
      'write into another person\'s requests': 'await db.doc("requests/u1").set({list:[]})', 'rewrite the owner\'s audit log': 'await db.doc("audit/u1/days/2026-11-06").set({events:[]})',
      'take the lock on a payment': 'await db.doc("payments/p0").acquire({holder:"x",ttlMs:5000})' };
    const out = {}; for (const [k, c] of Object.entries(tries)) out[k] = await raw(staff, c);
    const allowed = Object.entries(out).filter(([, v]) => v.ok).map(([k]) => k); assert(!allowed.length, 'ALLOWED: ' + allowed.join(', '));
    assert(Object.values(out).every(v => v.code === 'invalid_argument'), 'unexpected codes ' + JSON.stringify(out));
    const readOther = await raw(staff, 'const s=await db.doc("audit/u1/days/2026-11-06").get();const q=await db.collection("requests").get();return [s.exists,q.size]');
    assert(JSON.stringify(await DB(p)) === before, 'the database changed'); await p.close();
    return `${Object.keys(tries).length} direct writes all refused by the storage rules; reading others' audit/requests returns nothing (${JSON.stringify(readOther.r)})`;
  });

  await test('SEC-03', 'An Editor (not the owner) is held to the same rules: cannot post payments, approve, change business details or read the audit log', async () => {
    const { p, staff } = await pair('admin');
    const r = {}; for (const [k, c] of Object.entries({ payment: 'await db.doc("payments/x").set({amount:1})', approve: 'await db.doc("approvals/rq-1").set({decision:"approved"})', settings: 'await db.doc("settings/business").update({payDetails:"x"})' })) r[k] = await raw(staff, c);
    assert(Object.values(r).every(v => !v.ok), 'Editor allowed: ' + JSON.stringify(r));
    const audit = await raw(staff, 'const q=await db.collection("audit").get();return q.size'); const ui = await staff.evaluate(() => secState().isOwnerUser);
    await staff.evaluate(() => location.hash = 'settings'); await staff.waitForTimeout(300); await staff.fill('#fSettings [name=payDetails]', 'New bank 123'); await staff.evaluate(() => document.querySelector('#fSettings').requestSubmit()); await staff.waitForTimeout(900);
    const db = await DB(p); assert(db['settings/business'].payDetails === 'Stanbic 0000', 'bank details changed'); assert((db['requests/u3'] || db['requests/u2']).list.some(q => q.type === 'settings' && q.data.payDetails === 'New bank 123'), 'no change request');
    assert(audit.r === 0 && ui === false, 'audit visible or treated as owner'); await p.close(); return 'payment, approval and bank-detail writes refused; bank change became a request; audit log unreadable';
  });

  await test('SEC-04', 'A void done round the app (allowed by storage on invoices) is caught: Checks report it as a void without an approval record', async () => {
    const { p, owner, staff } = await pair('interact', `S.set("invoices/i9",{number:"INV-0009",date:"2026-10-10",clientId:"c",vatRate:0,items:[{desc:"Works",qty:1,price:500000}]});`);
    const w = await raw(staff, 'await db.doc("invoices/i9").update({void:true,voidedAt:"2026-11-06",voidReason:"quietly"})'); await owner.waitForTimeout(800);
    const b = await books(owner); assert(w.ok, 'storage refused (then this risk is closed outright): ' + JSON.stringify(w));
    assert(b.errors.some(e => /voided without an approval record/.test(e)), 'not detected: ' + JSON.stringify(b.errors));
    await owner.evaluate(() => location.hash = 'accounts'); await owner.click('#acTabs [data-t=chk]'); await owner.waitForTimeout(400); const txt = await owner.textContent('#v-accounts');
    assert(/voided without an approval record/.test(txt) && /Record approval/.test(txt), 'not shown on Checks'); await p.close(); return 'storage allowed the field change; Checks flagged INV-0009 with a "Record approval" action';
  });

  await test('SEC-05', 'Owner rejects a request with a reason: nothing is posted; the staff member sees the rejection', async () => {
    const { p, owner, staff } = await pair();
    await staff.evaluate(() => openEditor('payments', null, { category: 'Utilities' })); await staff.waitForTimeout(300); await staff.selectOption('#ed [name=party]', '').catch(() => {});
    await staff.fill('#ed [name=payee]', 'UMEME Ltd').catch(() => {}); await staff.fill('#ed [name=amount]', '412000'); await staff.click('#ed [type=submit]'); await staff.waitForTimeout(1200);
    await owner.evaluate(() => location.hash = 'approvals'); await owner.waitForTimeout(400); await owner.click('#apList [data-ap=no]'); await owner.fill('#rj [name=reason]', 'No invoice attached'); await owner.click('#rj [type=submit]'); await owner.waitForTimeout(800);
    const db = await DB(p); assert(!Object.keys(db).some(k => k.startsWith('payments/')), 'payment posted'); const dec = Object.entries(db).find(([k]) => k.startsWith('approvals/rq-'));
    assert(dec && dec[1].decision === 'rejected' && dec[1].reason === 'No invoice attached' && dec[1].by === 'u1', 'decision ' + JSON.stringify(dec));
    await staff.evaluate(() => location.hash = 'approvals'); await staff.waitForTimeout(500); const t = await staff.textContent('#v-approvals'); assert(/Rejected/.test(t) && /No invoice attached/.test(t) && /No requests waiting/.test(t), 'staff view');
    await p.close(); return 'rejected with reason; nothing posted; staff sees it';
  });

  await test('SEC-06', 'Void, credit note, refund and stock adjustment requests are each approved and posted with approval records; books and checks stay clean', async () => {
    const { p, owner, staff } = await pair();
    await buyStock(owner, 20, 30000);
    // owner sells and receives so there is something to credit / refund
    await owner.evaluate(() => location.hash = 'invoices'); await owner.waitForTimeout(200); await owner.click('#lNew'); await owner.selectOption('#ed [name=party]', 'c'); await owner.selectOption('#ed .si', 'cem'); await owner.fill('#ed .q', '5'); await owner.fill('#ed .p', '40000'); await owner.fill('#ed [name=vatRate]', '0'); await owner.click('#ed [type=submit]'); await owner.waitForTimeout(1200); await owner.click('#mBtns >> text=Close').catch(() => {});
    const inv = await owner.evaluate(() => S.invoices[0].id);
    await owner.evaluate(id => openEditor('receipts', null, { clientId: 'c' }), inv); await owner.waitForTimeout(300); await owner.fill('#ed [name=amount]', '250000'); await owner.click('#ed [type=submit]'); await owner.waitForTimeout(1200); await owner.click('#mBtns >> text=Close').catch(() => {});
    const rct = await owner.evaluate(() => S.receipts[0].id); await staff.waitForTimeout(600);
    // staff raises four requests
    await staff.evaluate(() => openRefund('clients', 'c')); await staff.waitForTimeout(200); await staff.fill('#rf [name=amount]', '50000'); await staff.fill('#rf [name=reason]', 'Overpaid'); await staff.click('#rf [type=submit]'); await staff.waitForTimeout(1000);
    await staff.evaluate(id => startVoid('receipts', id), rct); await staff.waitForTimeout(200); await staff.fill('#vd [name=reason]', 'Entered twice'); await staff.click('#vd [type=submit]'); await staff.waitForTimeout(1000);
    await staff.evaluate(id => openCreditNote(id), inv); await staff.waitForTimeout(200); await staff.fill('#cn [name=reason]', '1 bag damaged'); await staff.evaluate(() => { const r = document.querySelectorAll('#cn .iRows tr'); r[0].querySelector('.q').value = '1'; r[0].querySelector('.q').dispatchEvent(new Event('input', { bubbles: true })); }); await staff.click('#cn [type=submit]'); await staff.waitForTimeout(1000);
    await staff.evaluate(() => openAdjust('cem')); await staff.waitForTimeout(200); await staff.fill('#aj [name=qty]', '-2'); await staff.fill('#aj [name=reason]', 'Bags burst'); await staff.click('#aj [type=submit]'); await staff.waitForTimeout(1000);
    const n = (await DB(p))['requests/u2'].list.length; assert(n === 4, n + ' requests');
    // owner approves them one by one in the normal forms
    await owner.evaluate(() => location.hash = 'approvals'); await owner.waitForTimeout(400);
    for (let k = 0; k < 4; k++) { await owner.click('#apList [data-ap=ok] >> nth=0'); await owner.waitForTimeout(500); await owner.click('#mBody form [type=submit]'); await owner.waitForTimeout(1500); await owner.click('#mBtns >> text=Close').catch(() => {}); await owner.evaluate(() => location.hash = 'approvals'); await owner.waitForTimeout(400); }
    const db = await DB(p); const keys = Object.keys(db).filter(k => k.startsWith('approvals/')); const voidRec = keys.find(k => k.endsWith('-void'));
    const cr = Object.keys(db).find(k => k.startsWith('credits/')), aj = Object.keys(db).find(k => k.startsWith('adjustments/')), rf = Object.keys(db).find(k => k.startsWith('refunds/'));
    assert(rf && db[rf].je && db[rf].amount === 50000 && keys.includes('approvals/refunds-' + rf.split('/')[1]), 'refund');
    assert(db['receipts/' + rct].void && voidRec, 'void not approved'); assert(cr && db[cr].je && keys.includes('approvals/credits-' + cr.split('/')[1]), 'credit note'); assert(aj && db[aj].je && keys.includes('approvals/adjustments-' + aj.split('/')[1]), 'adjustment');
    assert(keys.filter(k => k.startsWith('approvals/rq-')).length === 4, 'decisions'); const b = await books(owner); assert(b.problems === 0 && !b.errors.length, 'checks: ' + JSON.stringify(b));
    assert(!(await owner.textContent('#apList')).includes('Review'), 'requests still pending'); await p.close();
    return 'refund, void, credit note and adjustment approved and posted; 4 decisions + approval records; checks clean';
  });

  await test('SEC-07', 'Owner changing banking details or reopening a locked period must confirm; the change is recorded with before and after values', async () => {
    const { p, owner } = await pair();
    await owner.evaluate(() => location.hash = 'settings'); await owner.waitForTimeout(300); await owner.fill('#fSettings [name=payDetails]', 'Centenary Bank 111'); await owner.fill('#fSettings [name=lockDate]', '2026-08-31');
    await owner.evaluate(() => document.querySelector('#fSettings').requestSubmit()); await owner.waitForTimeout(400);
    const ask = await owner.textContent('#sc'); let db = await DB(p); assert(db['settings/business'].payDetails === 'Stanbic 0000', 'saved without confirmation');
    assert(/banking/.test(ask) && /reopening the books/.test(ask), 'confirmation text: ' + ask); await owner.click('#scYes'); await owner.waitForTimeout(1200); await owner.evaluate(() => flushAudit()); await owner.waitForTimeout(600);
    db = await DB(p); const rec = Object.entries(db).find(([k]) => k.startsWith('approvals/settings-'));
    assert(db['settings/business'].payDetails === 'Centenary Bank 111' && db['settings/business'].lockDate === '2026-08-31', 'not saved');
    assert(rec && rec[1].payDetailsBefore === 'Stanbic 0000' && rec[1].payDetailsAfter === 'Centenary Bank 111' && rec[1].lockBefore === '2026-09-30' && rec[1].lockAfter === '2026-08-31', 'record ' + JSON.stringify(rec));
    const au = Object.entries(db).find(([k]) => k.startsWith('audit/u1/days/')); assert(au && au[1].events.some(e => e.act === 'settings-sensitive'), 'no audit entry');
    await p.close(); return 'confirmation asked; approval record keeps old and new bank details and lock date; audit entry written';
  });

  await test('SEC-08', 'Audit log: every action is logged under the person who did it; the owner reads everyone\'s; staff can read only their own', async () => {
    const { p, owner, staff } = await pair();
    await buyStock(staff, 5, 30000); await staff.evaluate(() => openAdjust('cem')); await staff.waitForTimeout(200); await staff.fill('#aj [name=qty]', '-1'); await staff.fill('#aj [name=reason]', 'x'); await staff.click('#aj [type=submit]'); await staff.waitForTimeout(800);
    await staff.evaluate(() => flushAudit()); await owner.evaluate(() => flushAudit()); await p.waitForTimeout(800);
    const db = await DB(p); const day = Object.keys(db).find(k => k.startsWith('audit/u2/days/')); const ev = db[day].events.map(e => e.act);
    assert(ev.includes('create') && ev.includes('request'), 'staff events ' + ev); assert(db['audit/u2'], 'staff not listed for the owner');
    await owner.evaluate(() => location.hash = 'audit'); await owner.waitForTimeout(800); const t = await owner.textContent('#auList'); assert(/Grace/.test(t) && /request/.test(t) && /PUR-0001/.test(t), 'owner audit screen: ' + t.slice(0, 200));
    const own = await raw(staff, `const s=await db.doc("${day}").get();return s.exists`); assert(own.r === true, 'staff cannot read own log');
    const tamper = await raw(staff, `await db.doc("${day}").set({events:[]})`); await p.close();
    return `staff events: ${ev.join(', ')}; owner's Audit log shows them by name; staff can read own log; staff can still ${tamper.ok ? 'rewrite their own log (limit: see report)' : 'not rewrite their own log'}`;
  });

  await test('SEC-09', 'Encrypted backup: the file holds no readable data; the wrong passphrase or a changed file restores nothing; the right one restores everything', async () => {
    const { p, owner } = await pair(); await buyStock(owner, 3, 30000);
    await owner.evaluate(() => location.hash = 'settings'); await owner.waitForTimeout(200); await owner.fill('#bkPass', 'correct horse battery'); await owner.click('#bkDown'); await owner.waitForFunction(() => window.__lastDownload, null, { timeout: 20000 });
    const f = await owner.evaluate(() => window.__lastDownload); assert(/-encrypted\.json$/.test(f.filename), f.filename); assert(!/Lake Victoria|Irongrid|PUR-0001|Stanbic/.test(f.data), 'plain text found in the encrypted file');
    const enc = JSON.parse(f.data); assert(enc.encrypted === 'AES-256-GCM' && enc.iterations === 600000, 'format');
    const dec = await owner.evaluate(async t => { const o = JSON.parse(t); const ok = JSON.parse(await decryptBackup(o, 'correct horse battery')); let wrong = 'decrypted'; try { await decryptBackup(o, 'wrong pass phrase') } catch (e) { wrong = 'refused' } const bad = { ...o, data: o.data.slice(0, 40) + (o.data[40] === 'A' ? 'B' : 'A') + o.data.slice(41) }; let tam = 'decrypted'; try { await decryptBackup(bad, 'correct horse battery') } catch (e) { tam = 'refused' } return { n: ok.data.purchases.length, wrong, tam }; }, f.data);
    assert(dec.n === 1 && dec.wrong === 'refused' && dec.tam === 'refused', JSON.stringify(dec));
    fs.writeFileSync('/tmp/enc-bk.json', f.data); await owner.evaluate(() => { window.top.__S.delete('suppliers/s'); for (const l of window.top.__L) l.fire(); }); await owner.waitForTimeout(500);
    await owner.setInputFiles('#bkFile', '/tmp/enc-bk.json'); await owner.waitForTimeout(500); await owner.fill('#pp [name=p]', 'wrong pass phrase'); await owner.click('#pp [type=submit]'); const t1 = await toasts(owner, 1200);
    await owner.setInputFiles('#bkFile', '/tmp/enc-bk.json'); await owner.waitForTimeout(500); await owner.fill('#pp [name=p]', 'correct horse battery'); await owner.click('#pp [type=submit]'); await owner.waitForSelector('#rsGo', { timeout: 15000 }); await owner.click('#rsGo'); await owner.waitForTimeout(1500);
    const db = await DB(p); assert(t1.some(t => /Wrong passphrase/.test(t)), 'wrong passphrase: ' + t1); assert(db['suppliers/s'], 'not restored'); await p.close();
    return 'no readable text in the file; wrong passphrase and a 1-character change refused; right passphrase restored the deleted supplier';
  });

  await test('SEC-10', 'A request approved after things changed is re-checked: a payment above what is now owed is refused at approval', async () => {
    const { p, owner, staff } = await pair(); await buyStock(owner, 10, 30000); const pur = await owner.evaluate(() => S.purchases[0]); await staff.waitForTimeout(500);
    await staff.evaluate(id => openEditor('payments', null, { supplierId: 's', purchaseId: id, category: 'Supplier bill' }), pur.id); await staff.waitForTimeout(300); await staff.fill('#ed [name=amount]', '300000'); await staff.click('#ed [type=submit]'); await staff.waitForTimeout(1000);
    await owner.evaluate(id => openEditor('payments', null, { supplierId: 's', purchaseId: id, category: 'Supplier bill' }), pur.id); await owner.waitForTimeout(300); await owner.fill('#ed [name=amount]', '300000'); await owner.click('#ed [type=submit]'); await owner.waitForTimeout(1200); await owner.click('#mBtns >> text=Close').catch(() => {});
    await owner.evaluate(() => location.hash = 'approvals'); await owner.waitForTimeout(400); await owner.click('#apList [data-ap=ok]'); await owner.waitForTimeout(400); await owner.click('#ed [type=submit]'); const t = await toasts(owner, 1500);
    const db = await DB(p); const pays = Object.keys(db).filter(k => k.startsWith('payments/')); assert(pays.length === 1, pays.length + ' payments'); assert(t.some(x => /more than the balance/.test(x)), 'no refusal: ' + t);
    await p.close(); return 'approval refused: "' + t.find(x => /balance/.test(x)) + '"';
  });

  await test('SEC-11', 'Stored script in any field — including inside a record\'s journal — never runs in the owner\'s browser', async () => {
    const r = await probe(browser); assert(!r.pwned.length && !r.imgs && !r.errs.length, JSON.stringify(r)); return 'every screen, tab and document opened with hostile values; nothing ran';
  });

  await test('SEC-12', 'View-only users see the books but cannot raise requests or write anything', async () => {
    const { p, staff } = await pair('view'); const n = await staff.evaluate(() => S.clients.length);
    const r = await raw(staff, 'await db.doc("requests/u2").set({list:[{rid:"x"}]})'); const r2 = await raw(staff, 'await db.doc("audit/u2/days/2026-11-06").set({events:[]})');
    assert(n === 0 && !r.ok && !r2.ok, JSON.stringify({ n, r, r2 })); await p.close(); return 'requests and audit writes refused (view level reads nothing under these rules)';
  });

  await browser.close();
  fs.writeFileSync(path.join(__dirname, '../reports/security.json'), JSON.stringify({ ranAt: new Date().toISOString(), results }, null, 1));
  const failed = results.filter(r => !r.pass); console.log(`\n${results.length - failed.length}/${results.length} passed`); process.exit(failed.length ? 1 : 0);
})();
