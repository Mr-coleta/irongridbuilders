// Stored-XSS probe: hostile values in every field a record can carry, including inside its journal,
// then every screen, tab and document view is opened. Fails if any script runs or any injected element appears.
const { chromium } = require('playwright'); const fs = require('fs'); const path = require('path');
const MOCK = require('../mocksrc.js');
const X = (t) => `<img src=x onerror="window.__pwned=(window.__pwned||[]).concat('${t}')">`;
const A = (t) => `"><img src=x onerror="window.__pwned=(window.__pwned||[]).concat('${t}')">`;
module.exports = async function probe(browser, extraOpts = {}) {
  const p = await browser.newPage({ viewport: { width: 1300, height: 950 } }); p.setDefaultTimeout(2000); const errs = []; p.on('pageerror', e => errs.push(e.message));
  const seed = `
    st.set("settings/business",{name:${JSON.stringify(X('bizname'))},currency:"UGX",address:${JSON.stringify(X('addr'))},payDetails:${JSON.stringify(X('pay'))},footer:${JSON.stringify(X('foot'))}});
    st.set("clients/c",{name:${JSON.stringify(X('cname'))},address:${JSON.stringify(X('caddr'))},tin:${JSON.stringify(X('ctin'))}});
    st.set("suppliers/s",{name:${JSON.stringify(X('sname'))}});
    st.set("items/i1",{name:${JSON.stringify(X('iname'))},unit:${JSON.stringify(X('iunit'))}});
    st.set("invoices/v1",{number:${JSON.stringify(X('num'))},date:"2026-10-01",clientId:"c",vatRate:18,reference:${JSON.stringify(X('ref'))},notes:${JSON.stringify(X('notes'))},items:[{desc:${JSON.stringify(X('desc'))},unit:${JSON.stringify(X('unit'))},qty:1,price:1000}],
      je:{pid:${JSON.stringify(A('pid'))},date:${JSON.stringify(A('jdate'))},cur:"UGX",dp:0,at:"2026-10-01T00:00:00Z",by:${JSON.stringify(A('by'))},h:"x",lines:[{a:${JSON.stringify(A('acct'))},d:1180,c:0,p:${JSON.stringify(A('lp'))},i:${JSON.stringify(A('li'))}},{a:"4000",d:0,c:1000},{a:"2100",d:0,c:180}]},
      void:true,voidedAt:"2026-10-02",voidReason:${JSON.stringify(X('vreason'))},jr:{pid:${JSON.stringify(A('rpid'))},date:"2026-10-02",cur:"UGX",dp:0,at:"x",by:"x",h:"x",reason:${JSON.stringify(X('jrreason'))},lines:[{a:${JSON.stringify(A('racct'))},d:0,c:1180},{a:"4000",d:1000,c:0},{a:"2100",d:180,c:0}]}});
    st.set("receipts/r1",{number:"RCT-1",date:"2026-10-03",clientId:"c",amount:5,method:${JSON.stringify(X('method'))},reference:${JSON.stringify(X('rref'))}});
    st.set("adjustments/a1",{number:"ADJ-1",date:"2026-10-03",itemId:"i1",qty:1,value:5,reason:${JSON.stringify(X('adj'))},stockItems:["i1"],je:{pid:"adjustments/a1",date:"2026-10-03",cur:"UGX",dp:0,at:"x",by:"x",h:"x",lines:[{a:"1200",d:5,c:0,i:"i1",q:1000000,n:${JSON.stringify(A('n'))}},{a:"4900",d:0,c:5}]}});`;
  await p.addInitScript(`${MOCK};window.__mock(${JSON.stringify(extraOpts)});const st=window.__S;${seed}`);
  await p.goto('http://localhost:8765/index.html#dashboard'); await p.waitForTimeout(900);
  const seen = [];
  for (const h of ['dashboard', 'proformas', 'invoices', 'receipts', 'credits', 'debits', 'refunds', 'clients', 'lpos', 'purchases', 'payments', 'sdebits', 'suppliers', 'stock', 'adjustments', 'settings', 'approvals', 'audit', 'accounts']) {
    await p.evaluate(h => location.hash = h, h); await p.waitForTimeout(150);
    if (h === 'accounts') for (const t of ['tb', 'pl', 'bs', 'vat', 'gl', 'chk']) { await p.click(`#acTabs [data-t=${t}]`).catch(() => {}); await p.waitForTimeout(150); if (t === 'gl') { for (const v of await p.$$eval('#acAcct option', o => o.map(x => x.value))) { await p.selectOption('#acAcct', v).catch(() => {}); } } }
    const rows = await p.$$('#lRows tr[data-id]'); for (let k = 0; k < Math.min(rows.length, 3); k++) { await rows[k].click().catch(() => {}); await p.waitForTimeout(200); await p.click('#mBtns >> text=Close').catch(() => {}); }
  }
  await p.evaluate(() => { try { showItem('i1'); } catch (e) {} }); await p.waitForTimeout(200);
  await p.evaluate(() => { try { showParty('clients', 'c'); } catch (e) {} }); await p.waitForTimeout(200);
  const pw = await p.evaluate(() => window.__pwned || []); const imgs = await p.evaluate(() => document.querySelectorAll('img[src="x"]').length);
  await p.close(); return { pwned: [...new Set(pw)], imgs, errs };
};
if (require.main === module) (async () => { const b = await chromium.launch(); const r = await module.exports(b); console.log(JSON.stringify(r)); await b.close(); process.exit(r.pwned.length || r.imgs ? 1 : 0); })();
