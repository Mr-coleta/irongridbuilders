// Fault-tolerance suite: outages, dropped replies, store restarts, interrupted requests, retry policy, fail-safe
// saving, structured logging, and verified restores. Runs on the fake store with the real access rules switched on.
// Usage: node tests/resilience/ft.test.js   (server on :8765 serving srv/)
'use strict';
const { chromium } = require('playwright'); const fs = require('fs'); const path = require('path');
const MOCK = require('../mocksrc.js');
const results = []; const assert = (c, m) => { if (!c) throw new Error(m); };
async function test(id, name, fn) {
  if (process.env.ONLY && !process.env.ONLY.split(',').includes(id)) return;
  const t0 = Date.now();
  try { const detail = await fn(); results.push({ id, name, pass: true, ms: Date.now() - t0, detail: detail || '' }); }
  catch (e) { results.push({ id, name, pass: false, ms: Date.now() - t0, detail: e.message.split('\n')[0] }); }
  const r = results.at(-1); console.log(`${r.pass ? 'PASS' : 'FAIL'}  ${id}  ${name}${r.detail ? '  — ' + r.detail : ''}`);
}
const SEED = `st.set("settings/business",{name:"Irongrid (synthetic)",currency:"UGX"});st.set("clients/c",{name:"Nansubuga Estates Ltd"});st.set("suppliers/s",{name:"Lake Victoria Cement Ltd"});st.set("items/cem",{name:"Cement 50kg",unit:"bags"});`;
let browser;
async function open(opts = {}, seed = SEED, hash = 'dashboard') {
  const p = await browser.newPage({ viewport: { width: 1300, height: 950 } }); p.setDefaultTimeout(8000); const errs = []; p.on('pageerror', e => errs.push(e.message));
  await p.addInitScript(`${MOCK};window.__mock(${JSON.stringify(opts)});const st=window.__S;${seed}`); await p.goto('http://localhost:8765/index.html#' + hash); await p.waitForTimeout(1000); return { p, errs };
}
const DB = p => p.evaluate(() => Object.fromEntries([...window.__S.entries()]));
const books = p => p.evaluate(() => { const L = ledger(); return { problems: L.problems, n: L.J.length, issues: L.issues.map(i => i.msg).concat(L.integ.errors.map(e => e.msg)) }; });
const toasts = async (p, ms) => { const seen = []; for (let i = 0; i < ms / 100; i++) { const t = await p.textContent('#toast'); if (t && !seen.includes(t)) seen.push(t); await p.waitForTimeout(100); } return seen; };
const events = p => p.evaluate(() => JSON.parse(JSON.stringify(window.__EV ? window.__EV() : [])));
async function invoiceForm(p, price = '100000') { await p.evaluate(() => location.hash = 'invoices'); await p.waitForTimeout(200); await p.click('#lNew'); await p.selectOption('#ed [name=party]', 'c'); await p.fill('#ed .d', 'Site works'); await p.fill('#ed .p', price); await p.fill('#ed [name=vatRate]', '18'); }
async function buyStock(p, qty = 50, price = 30000) { await p.evaluate(() => location.hash = 'purchases'); await p.waitForTimeout(200); await p.click('#lNew'); await p.selectOption('#ed [name=party]', 's'); await p.selectOption('#ed .si', 'cem'); await p.fill('#ed .q', String(qty)); await p.fill('#ed .p', String(price)); await p.fill('#ed [name=vatRate]', '18'); await p.click('#ed [type=submit]'); await p.waitForTimeout(1200); await p.click('#mBtns >> text=Close').catch(() => {}); }
const coll = (db, c) => Object.entries(db).filter(([k]) => k.startsWith(c + '/'));

(async () => {
  browser = await chromium.launch();

  await test('FT-01', 'Temporary failures during a save are retried with growing waits and the invoice is stored exactly once', async () => {
    const { p, errs } = await open(); await invoiceForm(p);
    await p.evaluate(() => { window.__failNextSets = 3; }); await p.click('#ed [type=submit]'); await p.waitForTimeout(8000);
    const db = await DB(p); const inv = coll(db, 'invoices'); const at = await p.evaluate(() => window.__setAttempts || []);
    const gaps = at.slice(1).map((t, i) => t - at[i]); const ev = await events(p);
    assert(inv.length === 1 && inv[0][1].je, inv.length + ' invoices'); assert(at.length === 3, 'failed attempts ' + at.length);
    assert(ev.filter(e => e.event === 'store-call-retry').length >= 3 && ev.some(e => e.event === 'retry-succeeded'), 'events ' + ev.map(e => e.event));
    assert((await books(p)).problems === 0, 'books'); assert(!errs.length, errs.join(';')); await p.close();
    return `3 failures then success; waits between attempts ${gaps.map(g => g + ' ms').join(', ')}; 1 invoice, books clean`;
  });

  await test('FT-02', 'A save whose reply is lost (write landed, connection dropped) is confirmed by reading it back: reported as saved, no duplicate on a second press', async () => {
    const { p } = await open(); await invoiceForm(p); await p.evaluate(() => window.__landThenHang = 1); await p.click('#ed [type=submit]');
    const seen = await toasts(p, 26000); await p.evaluate(() => window.__landThenHang = 0);
    let db = await DB(p); const n1 = coll(db, 'invoices').length; const ev = await events(p);
    assert(ev.some(e => e.event === 'unconfirmed-write-had-landed'), 'read-back not used: ' + ev.map(e => e.event)); assert(seen.some(t => /created/.test(t)), 'not reported saved: ' + seen);
    // a nervous second press on the same form must not create a second invoice
    await p.click('#ed [type=submit]').catch(() => {}); await p.waitForTimeout(1500); db = await DB(p); await p.close();
    assert(n1 === 1 && coll(db, 'invoices').length === 1, 'invoices ' + n1 + ' / ' + coll(db, 'invoices').length); return 'confirmed by read-back after the time limit; "' + seen.find(t => /created/.test(t)) + '"; still 1 invoice';
  });

  await test('FT-03', 'Store down for longer than the time limit: the save fails cleanly with nothing half-written; saving pauses; it resumes and saves once when the store is back', async () => {
    const { p } = await open(); await invoiceForm(p); const before = JSON.stringify(Object.keys(await DB(p)).filter(k => !k.startsWith('audit/')).sort());
    await p.evaluate(() => window.__goDown()); await p.click('#ed [type=submit]'); const seen = await toasts(p, 23000);
    const after = JSON.stringify(Object.keys(await DB(p)).filter(k => !k.startsWith('audit/')).sort()); assert(before === after, 'something was written during the outage');
    await p.evaluate(() => document.querySelector('#hlCheck') && document.querySelector('#hlCheck').click()); await p.waitForTimeout(500); await p.evaluate(() => document.querySelector('#hlCheck').click()); await p.waitForTimeout(800);
    await p.click('#ed [type=submit]'); const paused = await toasts(p, 1500);
    await p.evaluate(() => window.__comeBack()); await p.evaluate(() => document.querySelector('#hlCheck').click()); await p.waitForTimeout(6000);
    await p.click('#ed [type=submit]'); await p.waitForTimeout(2500); const db = await DB(p); await p.close();
    assert(seen.length && seen.every(t => !/created/.test(t)), 'outage messages ' + seen); assert(paused.some(t => /paused|Can't reach/.test(t)), 'not paused: ' + paused);
    assert(coll(db, 'invoices').length === 1, coll(db, 'invoices').length + ' invoices after recovery');
    return `during outage: "${seen[0]}"; then refused at once: "${paused[0]}"; after recovery 1 invoice`;
  });

  await test('FT-04', 'Store restart (live feeds drop): saving is paused while data may be stale and resumes when every feed is back', async () => {
    const { p } = await open(); await buyStock(p); await invoiceForm(p); // someone is already typing an invoice
    await p.evaluate(() => window.__goDown()); await p.waitForTimeout(600);
    await p.evaluate(() => window.__comeBack()); // store is back, but the feeds are still reconnecting with back-off
    await p.click('#ed [type=submit]'); const seen = await toasts(p, 800); const mid = coll(await DB(p), 'invoices').length;
    await p.waitForTimeout(9000); await p.click('#ed [type=submit]'); await p.waitForTimeout(2500); const db = await DB(p); const b = await books(p); await p.close();
    assert(mid === 0 && seen.some(t => /reconnecting|paused/i.test(t)), 'saved while stale: ' + seen); assert(coll(db, 'invoices').length === 1 && b.problems === 0, 'after: ' + JSON.stringify(b));
    return `while reconnecting: "${seen.find(t => /reconnect|paused/i.test(t))}"; after: 1 invoice, books clean`;
  });

  await test('FT-05', 'Interrupted requests: the page is closed in the middle of 10 different postings; the books never hold a half posting, a duplicate number or a broken journal', async () => {
    const out = []; let worst = null;
    for (let k = 0; k < 10; k++) {
      const { p } = await open(); await buyStock(p, 20, 30000); await p.evaluate(() => { window.__delay = 120; }); // slow connection from here on
      await p.evaluate(id => openEditor('payments', null, { supplierId: 's', purchaseId: id, category: 'Supplier bill' }), (await p.evaluate(() => S.purchases[0].id))); await p.waitForTimeout(300);
      await p.fill('#ed [name=amount]', '100000'); await p.click('#ed [type=submit]'); await p.waitForTimeout(400 * k + 100);
      const snap = JSON.stringify([...await p.evaluate(() => [...window.__S.entries()])]); await p.close();       // the tab is gone mid-request
      const q = await browser.newPage(); await q.addInitScript(`${MOCK};window.__mock({});const st=window.__S;for(const [k,v] of ${snap})st.set(k,v);`);
      await q.goto('http://localhost:8765/index.html#accounts'); await q.waitForTimeout(1500); const b = await books(q); const db = await DB(q);
      const nums = coll(db, 'payments').map(([, v]) => v.number); out.push(coll(db, 'payments').length); if (b.problems || new Set(nums).size !== nums.length) worst = { k, b, nums }; await q.close();
    }
    assert(!worst, 'damage after interruption ' + JSON.stringify(worst)); assert(out.includes(0) && out.includes(1), 'interruptions did not cover both outcomes: ' + out);
    return `payments present after each interruption: [${out.join(',')}] (0 = not written, 1 = whole); books clean every time`;
  });

  await test('FT-06', 'Retry policy: a permanent refusal is never retried; temporary failures stop at the 20 s deadline with a clear message', async () => {
    const { p } = await open({ level: 'interact', uid: 'u2' }); await p.evaluate(() => { window.__countSets = 1; window.__setAttempts = []; });
    const r = await p.evaluate(async () => await put('payments', 'x9', { number: 'PAY-9', amount: 1 })); const n = await p.evaluate(() => window.__setAttempts.length);
    await p.evaluate(() => { window.__countSets = 0; window.__failNextSets = 999; window.__setAttempts = []; }); const t0 = Date.now();
    const r2 = await p.evaluate(async () => await put('clients', 'cx', { name: 'Retry Ltd' })); const ms = Date.now() - t0; const tries = await p.evaluate(() => window.__setAttempts.length); await p.evaluate(() => { window.__failNextSets = 0; });
    await p.close(); assert(r === false && n === 1, `refused write tried ${n} times`); assert(r2 === false && ms < 23000 && tries >= 3, `gave up after ${ms} ms, ${tries} tries`);
    return `refusal: 1 attempt; outage: ${tries} attempts in ${(ms / 1000).toFixed(1)} s, then a clear failure`;
  });

  await test('FT-07', 'Structured error log: each event has time, level, event, user and code; warnings are saved to the person\'s own error log; downloadable', async () => {
    const { p } = await open(); await invoiceForm(p); await p.evaluate(() => { window.__failNextSets = 2; }); await p.click('#ed [type=submit]'); await p.waitForTimeout(6000); await p.click('#mBtns >> text=Close').catch(() => {});
    await p.evaluate(() => location.hash = 'health'); await p.waitForTimeout(6500); const ev = await events(p); const w = ev.find(e => e.event === 'store-call-retry');
    assert(w && w.ts && w.level === 'warn' && w.user === 'u1' && w.code === 'unavailable' && w.path && w.attempt === 0, 'fields ' + JSON.stringify(w));
    const db = await DB(p); const saved = Object.entries(db).find(([k]) => k.startsWith('audit/u1/errors/')); assert(saved && saved[1].events.some(e => e.event === 'store-call-retry'), 'not persisted');
    const txt = await p.textContent('#v-health'); assert(/store-call-retry/.test(txt) && /Live/.test(txt), 'health screen');
    await p.click('#hlDown'); await p.waitForTimeout(500); const f = await p.evaluate(() => window.__lastDownload); assert(f && JSON.parse(f.data).events.length, 'download'); await p.close();
    return 'example: ' + JSON.stringify({ ts: w.ts, level: w.level, event: w.event, user: w.user, op: w.op, path: w.path, code: w.code, attempt: w.attempt });
  });

  await test('FT-08', 'Verified restore: after a total loss, restore reports "verified" only after reading everything back and passing every integrity and reconciliation check', async () => {
    const { p } = await open(); await buyStock(p); await invoiceForm(p, '250000'); await p.click('#ed [type=submit]'); await p.waitForTimeout(1500); await p.click('#mBtns >> text=Close').catch(() => {});
    await p.evaluate(() => location.hash = 'settings'); await p.waitForTimeout(300); await p.click('#bkDown'); await p.waitForFunction(() => window.__lastDownload, null, { timeout: 15000 });
    const f = await p.evaluate(() => window.__lastDownload); const m = JSON.parse(f.data).manifest; assert(m.controls && m.controls.journals === 2 && m.controls.balances['1200'] > 0, 'no control totals: ' + JSON.stringify(m.controls));
    fs.writeFileSync('/tmp/ft-bk.json', f.data); await p.close();
    const { p: q } = await open({}, `st.set("settings/business",{name:"Irongrid (synthetic)",currency:"UGX"});`, 'settings');
    await q.setInputFiles('#bkFile', '/tmp/ft-bk.json'); await q.waitForSelector('#rsGo'); await q.click('#rsGo'); await q.waitForSelector('#mTitle:has-text("verified")', { timeout: 30000 }); await q.waitForTimeout(500);
    const title = await q.textContent('#mTitle'); const body = await q.textContent('#mBody'); await q.close();
    assert(title === 'Restore verified' && !/✗/.test(body), title + ' ' + body.slice(0, 300)); return `"${title}": ${(body.match(/✓/g) || []).length} checks passed (records read back, books check, ${m.controls.journals} journals, balances, stock)`;
  });

  await test('FT-09', 'Restore is NOT reported as successful when checks fail: a store that already holds a changed record, or extra records, is flagged', async () => {
    const raw = fs.readFileSync('/tmp/ft-bk.json', 'utf8'); const bk = JSON.parse(raw); const inv = bk.data.invoices[0];
    const seed = `st.set("settings/business",{name:"Irongrid (synthetic)",currency:"UGX"});st.set("invoices/${inv.id}",${JSON.stringify({ ...inv, id: undefined, notes: 'changed after the backup' })});st.set("clients/zz",{name:"Entered after backup"});`;
    const { p } = await open({}, seed, 'settings'); await p.setInputFiles('#bkFile', '/tmp/ft-bk.json'); await p.waitForSelector('#rsGo'); await p.click('#rsGo'); await p.waitForSelector('#mTitle:has-text("verified")', { timeout: 30000 }); await p.waitForTimeout(500);
    const title = await p.textContent('#mTitle'); const body = await p.textContent('#mBody'); await p.close();
    assert(title === 'Restore NOT verified' && /differ/.test(body) && /aren't in the backup/.test(body) && /Don't rely/.test(body), title + ' | ' + body.slice(0, 400));
    return `"${title}" — changed record and extra record both reported`;
  });

  await test('FT-10', 'Offline browser: saving is refused at once with a plain message; the Health screen says why', async () => {
    const { p } = await open(); await p.context().setOffline(true); await p.evaluate(() => window.dispatchEvent(new Event('offline'))); await p.waitForTimeout(300);
    const r = await p.evaluate(async () => await put('clients', 'off', { name: 'Offline Ltd' })); const t = await p.textContent('#toast');
    await p.evaluate(() => location.hash = 'health'); await p.waitForTimeout(400); const h = await p.textContent('#hlBody'); await p.context().setOffline(false); await p.close();
    assert(r === false && /Can't reach/.test(t) && /Unreachable/.test(h) && /Paused/.test(h), JSON.stringify({ r, t, h: h.slice(0, 200) })); return `"${t}"`;
  });

  await browser.close();
  fs.writeFileSync(path.join(__dirname, '../reports/resilience.json'), JSON.stringify({ ranAt: new Date().toISOString(), results }, null, 1));
  const failed = results.filter(r => !r.pass); console.log(`\n${results.length - failed.length}/${results.length} passed`); process.exit(failed.length ? 1 : 0);
})();
