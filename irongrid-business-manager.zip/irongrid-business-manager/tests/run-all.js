// RELEASE GATE — runs every suite and decides whether this build may be published.
//   node tests/run-all.js            unit + integration + coverage + browser suites (≈40 min)
//   node tests/run-all.js --quick    unit + integration + coverage only (≈10 s)
//   node tests/run-all.js --mutation also runs mutation testing (≈25 min)
// Needs the app copied to tests/../srv/index.html and `python3 -m http.server 8765` running in srv/ for browser suites.
// The gate FAILS (exit code 1) if: any mandatory test fails or did not run; line or branch coverage of the
// accounting engine is under 90%; or (with --mutation) the mutation score is under the threshold.
'use strict';
const { spawnSync } = require('child_process'); const fs = require('fs'); const path = require('path');
const ROOT = path.join(__dirname, '..'); const REP = path.join(__dirname, 'reports'); fs.mkdirSync(REP, { recursive: true });
const args = process.argv.slice(2); const QUICK = args.includes('--quick'), MUT = args.includes('--mutation');
const GATE = { lines: 90, branches: 90, functions: 90, mutation: 85 };
const { classify, SUITES } = require('./catalog.js');
const sh = (cmd, a, env = {}) => spawnSync(cmd, a, { cwd: ROOT, env: { ...process.env, ...env }, encoding: 'utf8', maxBuffer: 1 << 28 });
const report = { ranAt: new Date().toISOString(), gate: GATE, suites: {}, failures: [], blocking: [] };

// 1. unit + integration, with coverage measured on a one-statement-per-line copy of the engine
console.log('▶ unit + integration tests (with coverage)');
sh(process.execPath, ['tests/tools/format-for-coverage.js']);
const lcov = path.join(REP, 'engine.lcov');
const r = sh(process.execPath, ['--test', '--experimental-test-coverage', '--test-coverage-include=**/cov-build/*', '--test-reporter=tap', '--test-reporter-destination=stdout', '--test-reporter=lcov', '--test-reporter-destination=' + lcov,
  'tests/unit/ledger.unit.test.js', 'tests/unit/ledger.precision.test.js', 'tests/integration/books.int.test.js'], { LEDGER_PATH: path.join(__dirname, 'cov-build/ledger.formatted.js') });
const tap = r.stdout; const tapTests = [];
{ const lines = tap.split('\n'); for (let i = 0; i < lines.length; i++) { const m = /^(\s*)(ok|not ok) \d+ - (.*)$/.exec(lines[i]); if (!m || m[1].length === 0) continue; // nested = individual tests
  const depth = m[1].length / 4; const isSuite = (lines[i + 1] || '').includes('type: \'suite\'') || (lines.slice(i + 1, i + 4).join('').includes("type: 'suite'")); if (isSuite) continue;
  const file = depth >= 1 ? '' : ''; let detail = ''; if (m[2] === 'not ok') { for (let k = i + 1; k < Math.min(lines.length, i + 30); k++) { const e = /error: '?(.*?)'?$/.exec(lines[k].trim()); if (e) { detail = e[1]; break; } } }
  tapTests.push({ name: m[3].replace(/ # .*$/, ''), pass: m[2] === 'ok', detail }); } }
const unitN = tapTests.filter(t => !/seed|USD book|statement balance|posting id twice|selling more than the synthetic/.test(t.name));
const intN = tapTests.filter(t => /seed|USD book|statement balance|posting id twice|selling more than the synthetic/.test(t.name));
const summ = (arr) => ({ total: arr.length, passed: arr.filter(t => t.pass).length, failed: arr.filter(t => !t.pass).map(t => ({ name: t.name, detail: t.detail })) });
report.suites.unit = { title: 'Unit (accounting engine)', mandatory: true, ...summ(unitN) }; report.suites.integration = { title: 'Integration (synthetic books vs independent oracle)', mandatory: true, ...summ(intN) };
// legacy engine tests (kept unchanged as regression)
const leg = sh(process.execPath, ['tests/engine.test.js']); const lj = JSON.parse(fs.readFileSync(path.join(__dirname, 'engine-results.json'), 'utf8'));
report.suites['engine-regression'] = { title: 'Engine regression (original 21 tests, unchanged)', mandatory: true, total: lj.total, passed: lj.passed, failed: lj.results.filter(x => !x.pass).map(x => ({ name: x.id + ' ' + x.name, detail: x.detail })) };
// coverage from lcov
const cov = { lines: [0, 0], branches: [0, 0], functions: [0, 0] }; const uncovered = [];
if (fs.existsSync(lcov)) { let file = ''; for (const l of fs.readFileSync(lcov, 'utf8').split('\n')) { if (l.startsWith('SF:')) file = l.slice(3); if (!/cov-build/.test(file)) continue;
  const kv = l.split(':'); if (kv[0] === 'LF') cov.lines[1] += +kv[1]; if (kv[0] === 'LH') cov.lines[0] += +kv[1]; if (kv[0] === 'BRF') cov.branches[1] += +kv[1]; if (kv[0] === 'BRH') cov.branches[0] += +kv[1]; if (kv[0] === 'FNF') cov.functions[1] += +kv[1]; if (kv[0] === 'FNH') cov.functions[0] += +kv[1];
  if (kv[0] === 'DA' && kv[1].split(',')[1] === '0') uncovered.push(+kv[1].split(',')[0]); } }
const pct = ([h, t]) => t ? +(100 * h / t).toFixed(2) : 0;
report.coverage = { file: 'engine/ledger.js (measured on a one-statement-per-line copy)', lines: pct(cov.lines), branches: pct(cov.branches), functions: pct(cov.functions), raw: cov, uncoveredLines: uncovered };
console.log(`  coverage: lines ${report.coverage.lines}%  branches ${report.coverage.branches}%  functions ${report.coverage.functions}%`);
for (const k of ['lines', 'branches', 'functions']) if (report.coverage[k] < GATE[k]) report.blocking.push(`Engine ${k} coverage ${report.coverage[k]}% is under the ${GATE[k]}% gate`);

// 2. mutation testing (optional; slow)
if (MUT) { console.log('▶ mutation testing'); const m = sh(process.execPath, ['tests/mutation/mutate.js', '--workers', '4']); process.stdout.write(m.stdout.split('\n').slice(-3).join('\n') + '\n'); }
if (fs.existsSync(path.join(REP, 'mutation.json'))) { const mj = JSON.parse(fs.readFileSync(path.join(REP, 'mutation.json'), 'utf8')); report.mutation = { score: mj.score, total: mj.total, killed: mj.killed, ranAt: mj.ranAt, survivors: mj.survivors.length, byKind: mj.byKind };
  const engineChanged = fs.statSync(path.join(ROOT, 'engine/ledger.js')).mtime > new Date(mj.ranAt); report.mutation.current = !engineChanged;
  if (engineChanged) report.blocking.push('Mutation results are older than the engine code — run with --mutation'); else if (mj.score < GATE.mutation) report.blocking.push(`Mutation score ${mj.score}% is under the ${GATE.mutation}% gate`); }
else report.blocking.push('No mutation results — run with --mutation');

// browser suites need the app served on :8765 — start a server for this run if none is answering
let SERVER = null;
if (!QUICK) { const up = sh('python3', ['-c', 'import urllib.request;urllib.request.urlopen("http://localhost:8765/index.html",timeout=2)']).status === 0;
  if (!up) { SERVER = require('child_process').spawn('python3', ['-m', 'http.server', '8765'], { cwd: path.join(ROOT, 'srv'), stdio: 'ignore' }); spawnSync('sleep', ['1.5']); }
  process.on('exit', () => { if (SERVER) SERVER.kill(); }); }
// 3. browser suites (e2e, db-integrity, concurrency, security, regression, performance) with browser coverage
if (!QUICK) { console.log('▶ browser suites (this takes a while)'); const b = sh(process.execPath, ['tests/regression.js'], { COVERAGE: '1' }); fs.writeFileSync(path.join(REP, 'browser-run.log'), b.stdout + b.stderr); }
if (fs.existsSync(path.join(__dirname, 'results.json'))) { const res = JSON.parse(fs.readFileSync(path.join(__dirname, 'results.json'), 'utf8')); report.browserRanAt = res.ranAt;
  const per = {}; for (const k of Object.keys(SUITES)) per[k] = { title: SUITES[k], total: 0, passed: 0, failed: [] };
  for (const t of res.results) { const c = classify(t.id); for (const s of c.suites) { per[s].total++; if (t.pass) per[s].passed++; else per[s].failed.push({ name: t.id + ' ' + t.name, detail: t.detail, mandatory: c.mandatory }); }
    if (!t.pass) { report.failures.push({ id: t.id, name: t.name, detail: t.detail, mandatory: c.mandatory }); if (c.mandatory) report.blocking.push(`Mandatory test ${t.id} failed: ${t.detail}`); } }
  for (const [k, v] of Object.entries(per)) report.suites[k] = { ...v, mandatory: k !== 'performance' };
  if (fs.existsSync(path.join(REP, 'browser-coverage.json'))) report.browserCoverage = JSON.parse(fs.readFileSync(path.join(REP, 'browser-coverage.json'), 'utf8'));
  if (QUICK) report.note = 'Browser suites not re-run (--quick); results shown are from ' + res.ranAt; }
// 4. untested-risk suites: storage limit (scale), printing to PDF, phones and tablets — all mandatory
const EXTRA = [['scale', 'Scale: 25,000 posted records, storage limit, full backup and restore', 'tests/scale/scale.test.js', 'scale.json'],
  ['print', 'Printing: every document type to an A4 PDF, checked against the engine', 'tests/print/print.test.js', 'print.json'],
  ['mobile', 'Phones and tablets (Chromium device emulation, touch)', 'tests/mobile/mobile.test.js', 'mobile.json'],
  ['security-rbac', 'Security: server-side roles, approvals, bypass attempts, audit log, encrypted backups, stored XSS', 'tests/security/security.test.js', 'security.json'],
  ['resilience', 'Fault tolerance: outages, lost replies, store restarts, interrupted requests, retries, verified restore', 'tests/resilience/ft.test.js', 'resilience.json'],
  ['monitoring', 'Monitoring: safe logs, correlation ids, metrics, every alert rule from a real fault, read-only health checks, no record changes', 'tests/monitoring/mon.test.js', 'monitoring.json'],
  ['backup-verifier', 'Backup verifier: refuses incomplete or unconfirmed backups (regression for the 7 Nov audit-log gap)', 'tests/dr/verify-backup.test.js', 'backup-verifier.json'],
  ['dates', 'Dates: DD/MM/YYYY shown and typed everywhere, YYYY-MM-DD stored, impossible dates refused, CSV unchanged', 'tests/dates/dates.test.js', 'dates.json'],
  ['login', 'Login screen: salted-hash passwords, lockout, idle sign-out, owner-only management, fail closed, app hidden while locked', 'tests/login/login.test.js', 'login.json'],
  ['theme', 'Theme: + New menu, top bar, roles and approvals respected, printed documents unchanged, every screen opens', 'tests/theme/theme.test.js', 'theme.json'],
  ['reports', 'Reports: indexed reports vs an independent reference and the original functions, cutoffs, paging, reconciliations, no stale figures', 'tests/reportcheck/ui.test.js', 'reports.json']];
for (const [k, title, file, out] of EXTRA) {
  if (!QUICK) { console.log('▶ ' + k); const r = sh(process.execPath, [file]); fs.writeFileSync(path.join(REP, k + '-run.log'), r.stdout + r.stderr); }
  const f = path.join(REP, out); if (!fs.existsSync(f)) { report.blocking.push(`No ${k} results — run ${file}`); continue; }
  const res = JSON.parse(fs.readFileSync(f, 'utf8')).results || []; const failed = res.filter(t => !t.pass);
  report.suites[k] = { title, mandatory: true, total: res.length, passed: res.length - failed.length, failed: failed.map(t => ({ name: t.id + ' ' + t.name, detail: t.detail, mandatory: true })) };
  for (const t of failed) { report.failures.push({ id: t.id, name: t.name, detail: t.detail, mandatory: true }); report.blocking.push(`Mandatory test ${t.id} failed: ${t.detail}`); }
}
for (const k of ['unit', 'integration', 'engine-regression']) for (const f of report.suites[k].failed) { report.failures.push({ id: k, name: f.name, detail: f.detail, mandatory: true }); report.blocking.push(`Mandatory ${k} test failed: ${f.name}`); }
report.verdict = report.blocking.length ? 'BLOCKED' : 'RELEASE ALLOWED';
fs.writeFileSync(path.join(REP, 'test-report.json'), JSON.stringify(report, null, 1));
// human-readable HTML
const esc = s => String(s ?? '').replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
const rows = Object.entries(report.suites).map(([k, v]) => `<tr><td>${esc(v.title || k)}</td><td>${v.mandatory ? 'Mandatory' : 'Advisory'}</td><td class=n>${v.total}</td><td class=n>${v.passed}</td><td class=n>${v.total - v.passed}</td></tr>`).join('');
const html = `<!doctype html><meta charset=utf-8><title>Test report — Business Manager</title><style>body{font:14px system-ui;margin:24px;max-width:1100px}td,th{border-bottom:1px solid #ddd;padding:6px 10px;text-align:left}.n{text-align:right}.bad{color:#b42318}.ok{color:#067647}h1{font-size:22px}</style>
<h1>Test report — <span class="${report.verdict === 'BLOCKED' ? 'bad' : 'ok'}">${report.verdict}</span></h1><p>Run ${esc(report.ranAt)}${report.note ? ' · ' + esc(report.note) : ''}</p>
<h2>Suites</h2><table><tr><th>Suite</th><th>Gate</th><th class=n>Tests</th><th class=n>Passed</th><th class=n>Failed</th></tr>${rows}</table>
<h2>Coverage — accounting engine</h2><p>Lines ${report.coverage.lines}% · Branches ${report.coverage.branches}% · Functions ${report.coverage.functions}% (gate ${GATE.lines}% each)</p>
${report.browserCoverage ? `<p>In the app (browser): posting layer ${report.browserCoverage.postingLayer_accountsJs.executedPct}% of code executed, ${report.browserCoverage.postingLayer_accountsJs.functionsPct}% of functions; whole app ${report.browserCoverage.wholeApp.executedPct}%.</p>` : ''}
${report.mutation ? `<h2>Mutation testing</h2><p>${report.mutation.killed} of ${report.mutation.total} deliberate bugs caught — score ${report.mutation.score}% (gate ${GATE.mutation}%).</p>` : ''}
<h2>Failures</h2>${report.failures.length ? '<table>' + report.failures.map(f => `<tr><td>${esc(f.id)}</td><td>${esc(f.name)}</td><td class=bad>${esc(f.detail)}</td><td>${f.mandatory ? 'blocks release' : 'advisory'}</td></tr>`).join('') + '</table>' : '<p class=ok>None.</p>'}
<h2>Release blockers</h2>${report.blocking.length ? '<ul>' + report.blocking.map(b => `<li class=bad>${esc(b)}</li>`).join('') + '</ul>' : '<p class=ok>None.</p>'}`;
fs.writeFileSync(path.join(REP, 'test-report.html'), html);
console.log(`\n${report.verdict}${report.blocking.length ? ':\n  - ' + report.blocking.join('\n  - ') : ''}\nReports: tests/reports/test-report.html, test-report.json`);
process.exit(report.blocking.length ? 1 : 0);
