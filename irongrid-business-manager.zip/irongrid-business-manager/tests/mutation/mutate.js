// MUTATION TESTING — do the tests actually catch wrong results?
// Each mutant changes ONE operator or constant in engine/ledger.js (e.g. + → -, < → <=, an account code swapped).
// The unit + integration suites run against each mutant; a mutant is KILLED if any test fails. Surviving mutants
// are listed: each is either a real gap in the tests or an "equivalent" change that cannot alter any result.
// Usage: node tests/mutation/mutate.js [--limit N] [--workers 4]
'use strict';
const fs = require('fs'), path = require('path'), { spawn } = require('child_process');
const acorn = require('/opt/node-tools/node_modules/acorn');
const ROOT = path.join(__dirname, '../..'); const SRC = fs.readFileSync(path.join(ROOT, 'engine/ledger.js'), 'utf8');
const args = process.argv.slice(2); const opt = k => { const i = args.indexOf(k); return i >= 0 ? +args[i + 1] : null; };
const WORKERS = opt('--workers') || 4, LIMIT = opt('--limit') || Infinity;
const SWAP = { '+': '-', '-': '+', '*': '/', '<': '<=', '<=': '<', '>': '>=', '>=': '>', '===': '!==', '!==': '===', '==': '!=', '!=': '==', '&&': '||', '||': '&&', '??': '||' };
const ACC_SWAP = { '"1100"': '"2000"', '"2000"': '"1100"', '"2100"': '"1300"', '"1300"': '"2100"', '"4000"': '"4900"', '"5000"': '"5100"', '"1200"': '"6000"', '"1000"': '"1010"', '"1030"': '"1000"' };
// Mutate only executable engine code: skip the chart-of-accounts names table and comments (acorn tokens never include comments).
const accStart = SRC.indexOf('const ACC={'), accEnd = SRC.indexOf('const CASH=');
const mutants = [];
for (const t of acorn.tokenizer(SRC, { ecmaVersion: 2022 })) {
  if (t.start > accStart && t.start < accEnd) continue;
  const text = SRC.slice(t.start, t.end); let to = null, kind = null;
  if (t.type.binop != null || t.type.label === '+/-' || ['&&', '||', '??'].includes(text)) { to = SWAP[text]; kind = 'operator'; }
  else if (t.type.label === 'num' && /n$/.test(text)) { const v = BigInt(text.slice(0, -1)); to = (v === 0n ? 1n : v + 1n) + 'n'; kind = 'bigint constant'; }
  else if (t.type.label === 'num' && ['0', '1', '2', '6', '100'].includes(text)) { to = String(+text + 1); kind = 'constant'; }
  else if (t.type.label === 'string' && ACC_SWAP[text]) { to = ACC_SWAP[text]; kind = 'account'; }
  if (to == null || to === text) continue;
  const line = SRC.slice(0, t.start).split('\n').length; mutants.push({ id: mutants.length + 1, start: t.start, end: t.end, from: text, to, kind, line, ctx: SRC.slice(Math.max(0, t.start - 40), t.end + 40).replace(/\s+/g, ' ') });
}
// --resurvey: re-test only the mutants that survived the previous full run, and merge into its results
const RESURVEY = args.includes('--resurvey'); const prevFile = path.join(ROOT, 'tests/reports/mutation.json'); const prev = RESURVEY && fs.existsSync(prevFile) ? JSON.parse(fs.readFileSync(prevFile, 'utf8')) : null;
const todo = prev ? mutants.filter(m => prev.survivors.some(s => s.id === m.id && s.from === m.from && s.to === m.to)) : mutants.slice(0, LIMIT); const dir = path.join(ROOT, 'tests/cov-build/mutants'); fs.mkdirSync(dir, { recursive: true });
const run = m => new Promise(res => {
  const file = path.join(dir, `m${m.id}.js`); fs.writeFileSync(file, SRC.slice(0, m.start) + m.to + SRC.slice(m.end));
  const p = spawn(process.execPath, ['--test', '--test-reporter=dot', path.join(ROOT, 'tests/unit/ledger.unit.test.js'), path.join(ROOT, 'tests/unit/ledger.precision.test.js'), path.join(ROOT, 'tests/integration/books.int.test.js')], { env: { ...process.env, LEDGER_PATH: file }, stdio: 'ignore' });
  const t = setTimeout(() => { p.kill('SIGKILL'); }, 60000);
  p.on('exit', (code, sig) => { clearTimeout(t); fs.unlinkSync(file); res({ ...m, killed: code !== 0, how: sig ? 'timeout' : code !== 0 ? 'test failed' : 'survived' }); });
});
(async () => {
  const t0 = Date.now(); const out = []; let next = 0;
  await Promise.all(Array.from({ length: WORKERS }, async () => { while (next < todo.length) { const m = todo[next++]; out.push(await run(m)); if (out.length % 25 === 0) process.stdout.write(`  ${out.length}/${todo.length}\n`); } }));
  out.sort((a, b) => a.id - b.id); let killed = out.filter(m => m.killed).length;
  if (prev) { const newlyKilled = killed; killed = prev.killed + newlyKilled; const total = prev.total; const surv = out.filter(m => !m.killed);
    const res = { ...prev, ranAt: new Date().toISOString(), resurveyOf: prev.ranAt, killed, score: +(100 * killed / total).toFixed(1), newlyKilled, survivors: surv.map(({ id, line, from, to, kind, ctx }) => ({ id, line, from, to, kind, ctx })) };
    fs.writeFileSync(prevFile, JSON.stringify(res, null, 1)); console.log(`re-survey: ${newlyKilled} more killed; mutation score ${res.score}% — ${killed} of ${total}`); return; }
  const byKind = {}; for (const m of out) { const k = byKind[m.kind] || (byKind[m.kind] = { total: 0, killed: 0 }); k.total++; if (m.killed) k.killed++; }
  const res = { ranAt: new Date().toISOString(), seconds: Math.round((Date.now() - t0) / 1000), total: out.length, killed, score: +(100 * killed / out.length).toFixed(1), byKind, survivors: out.filter(m => !m.killed).map(({ id, line, from, to, kind, ctx }) => ({ id, line, from, to, kind, ctx })) };
  fs.writeFileSync(path.join(ROOT, 'tests/reports/mutation.json'), JSON.stringify(res, null, 1));
  console.log(`mutation score ${res.score}% — ${killed} of ${out.length} mutants killed in ${res.seconds}s`); for (const s of res.survivors.slice(0, 80)) console.log(`  survived #${s.id} line ${s.line} ${s.kind}: ${s.from} → ${s.to}   …${s.ctx}…`);
})();
