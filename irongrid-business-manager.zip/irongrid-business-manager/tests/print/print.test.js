// Print / PDF suite: every document type is downloaded from the app exactly as a user would get it,
// printed to an A4 PDF by Chromium, and the PDF's own text is checked against figures computed by the engine.
// Usage: node tests/print/print.test.js   (server on :8765 serving srv/). PDFs go to tests/reports/print/.
'use strict';
const { chromium } = require('playwright');
const fs = require('fs');
const path = require('path');
const { execFileSync } = require('child_process');
const L = require('../../engine/ledger.js');
const MOCK = require('../mocksrc.js');
const OUT = path.join(__dirname, '../reports/print');
const results = [];
const assert = (c, m) => { if (!c) throw new Error(m); };
async function test(id, name, fn) {
  if (process.env.ONLY && !process.env.ONLY.split(',').includes(id)) return;
  const t0 = Date.now();
  try { const detail = await fn(); results.push({ id, name, pass: true, ms: Date.now() - t0, detail: detail || '' }); }
  catch (e) { results.push({ id, name, pass: false, ms: Date.now() - t0, detail: e.message.split('\n')[0] }); }
  const r = results.at(-1); console.log(`${r.pass ? 'PASS' : 'FAIL'}  ${id}  ${name}${r.detail ? '  — ' + r.detail : ''}`);
}
const fmt = n => Math.round(n).toLocaleString('en-US');
const norm = s => s.replace(/\s+/g, ' ').trim();

// ---------- synthetic but realistic documents, posted through the real engine ----------
function books() {
  const docs = new Map(); const stock = {}; const counts = {};
  const set = (p, d) => docs.set(p, d);
  set('settings/business', { name: 'Irongrid Builders Co Limited (synthetic)', currency: 'UGX', address: 'Plot 14, Nalukolongo Industrial Area\nP.O. Box 0000, Kampala', phone: '+256 700 000 000', email: 'accounts@example.ug', tin: '1000000001',
    payDetails: 'Stanbic Bank Uganda — Account name: Irongrid Builders (synthetic)\nAccount no.: 0000000000000 · Branch: Industrial Area\nMTN MoMo merchant: 000000', footer: 'Thank you for your business. Goods once sold are not returnable without a credit note.',
    proTerms: 'Prices valid for 14 days. 50% deposit before delivery.', lpoTerms: 'Deliver to site between 8am and 5pm. Quote this LPO number on your invoice.', vatDefault: 18 });
  set('clients/c1', { name: 'Ssemakula Engineering & Allied Construction Services (U) Limited', contact: 'Procurement Officer', address: 'Plot 112–118 Jinja Road, Industrial Area, Kampala', phone: '+256 772 000 000', email: 'procurement@example.ug', tin: '1000000777' });
  set('suppliers/s1', { name: 'Lake Victoria Cement Supplies Ltd', address: 'Namanve Industrial Park', tin: '1000000555' });
  set('items/cem', { name: 'Cement 50kg bag', unit: 'bags' }); set('items/y12', { name: 'Y12 bar 12m', unit: 'lengths' });
  let at = 0; const stamp = () => new Date(Date.UTC(2026, 9, 1) + (at++) * 60000).toISOString();
  const post = (coll, id, d, opts = {}) => { const r = L.post(coll, d, { dp: 0, stock, ...opts }); if (r.err) throw new Error(coll + ' ' + r.err); L.numberStock(r.lines, counts);
    for (const l of r.lines) if (l.a === '1200' && l.i) counts[l.i] = l.n + 1; Object.assign(stock, r.stockAfter);
    const si = [...new Set([...(d.items || []), ...(d.goods || [])].map(x => x.itemId).concat(d.itemId ? [d.itemId] : []).filter(Boolean))];
    const doc = { ...d, ...(si.length ? { stockItems: si } : {}), createdAt: stamp(), je: L.makeJE(coll, id, d, r.lines, { cur: 'UGX', dp: 0, at: stamp(), by: 'print-test' }) }; set(coll + '/' + id, doc); return doc; };
  post('purchases', 'p1', { number: 'PUR-0001', date: '2026-10-01', supplierId: 's1', supplierRef: 'LVC/INV/88231', vatRate: 18, items: [{ desc: 'Cement 50kg bag', qty: 400, price: 33000, itemId: 'cem' }, { desc: 'Y12 bar 12m', qty: 200, price: 38500, itemId: 'y12' }, { desc: 'Delivery to yard', qty: 1, price: 250000 }] });
  post('invoices', 'i1', { number: 'INV-0001', date: '2026-10-05', dueDate: '2026-11-04', clientId: 'c1', reference: 'LPO 4471/26', vatRate: 18, notes: 'Delivered to Mukono site.', items: [{ desc: 'Cement 50kg bag', qty: 120, price: 39500, itemId: 'cem' }, { desc: 'Y12 bar 12m', qty: 60, price: 45000, itemId: 'y12' }, { desc: 'Labour — blockwork, ground floor', qty: 1, price: 1850000 }] });
  const long = []; for (let k = 1; k <= 150; k++) long.push({ desc: k % 10 === 0 ? `Line ${k}: supply and fix reinforcement to column C${k}, including cutting, bending, tying wire and spacers as per structural drawing S-${100 + k}` : `Line ${k}: site works item ${k}`, qty: (k % 7) + 1, price: 10000 + k * 250 });
  post('invoices', 'i2', { number: 'INV-0002', date: '2026-10-06', clientId: 'c1', vatRate: 18, items: long });
  post('receipts', 'r1', { number: 'RCT-0001', date: '2026-10-10', clientId: 'c1', invoiceId: 'i1', amount: 5000000, method: 'Bank transfer', reference: 'TT-55120' });
  post('receipts', 'r2', { number: 'RCT-0002', date: '2026-10-12', clientId: 'c1', invoiceId: 'i1', amount: 700000, method: L.IN_KIND, goods: [{ itemId: 'cem', qty: 20, value: 700000 }] });
  const r3 = post('receipts', 'r3', { number: 'RCT-0003', date: '2026-10-13', clientId: 'c1', amount: 150000, method: 'Cash' });
  const rev = L.reverse(r3.je, stock); docs.set('receipts/r3', { ...r3, void: true, voidedAt: '2026-10-14', voidReason: 'Entered twice', jr: L.makeRev('receipts', 'r3', r3, rev.lines, { cur: 'UGX', dp: 0, at: stamp(), by: 'print-test', date: '2026-10-14', reason: 'Entered twice' }) });
  post('payments', 'y1', { number: 'PAY-0001', date: '2026-10-15', supplierId: 's1', purchaseId: 'p1', amount: 10000000, method: 'Cheque', reference: 'CHQ 000412', category: 'Supplier bill' });
  post('payments', 'y2', { number: 'PAY-0002', date: '2026-10-16', payee: 'UMEME Ltd', amount: 412000, method: 'MTN Mobile Money', category: 'Utilities', notes: 'Yard electricity, September' });
  post('credits', 'n1', { number: 'CRN-0001', date: '2026-10-18', clientId: 'c1', invoiceId: 'i1', vatRate: 18, reason: 'Price allowance agreed for late delivery', items: [{ desc: 'Allowance on cement', qty: 1, price: 120000 }] });
  post('debits', 'd1', { number: 'DBN-0001', date: '2026-10-19', clientId: 'c1', invoiceId: 'i1', vatRate: 18, reason: 'Extra transport to second site', items: [{ desc: 'Extra transport', qty: 1, price: 180000 }] });
  post('sdebits', 'e1', { number: 'SDN-0001', date: '2026-10-20', supplierId: 's1', purchaseId: 'p1', vatRate: 18, reason: 'Five bags damaged on delivery', items: [{ desc: 'Cement 50kg bag', qty: 5, price: 33000, itemId: 'cem' }] });
  post('refunds', 'f1', { number: 'RFD-0001', date: '2026-10-21', clientId: 'c1', amount: 50000, method: 'Cash', reason: 'Overpayment on RCT-0001' }, {});
  post('adjustments', 'a1', { number: 'ADJ-0001', date: '2026-10-22', itemId: 'cem', qty: -3, reason: 'Bags burst in store' });
  post('adjustments', 'a2', { number: 'ADJ-0002', date: '2026-10-23', itemId: 'y12', qty: 2, value: 77000, reason: 'Found in stock count' });
  set('proformas/q1', { number: 'PRO-0001', date: '2026-10-02', validUntil: '2026-10-16', clientId: 'c1', reference: 'Mukono school block B', vatRate: 18, items: [{ desc: 'Cement 50kg bag', qty: 300, price: 39000 }, { desc: 'Iron sheets 28g 3m', qty: 150, price: 49000 }] });
  set('lpos/l1', { number: 'LPO-0001', date: '2026-09-28', deliveryDate: '2026-10-01', supplierId: 's1', deliverTo: 'Yard, Nalukolongo', vatRate: 18, items: [{ desc: 'Cement 50kg bag', qty: 400, price: 33000 }, { desc: 'Y12 bar 12m', qty: 200, price: 38500 }] });
  for (const k of ['payments-y1', 'payments-y2', 'credits-n1', 'refunds-f1', 'adjustments-a1', 'adjustments-a2', 'receipts-r3-void']) set('approvals/' + k, { kind: k.endsWith('-void') ? 'void' : 'post', by: 'u1', requestedBy: 'u1', at: '2026-10-25T00:00:00Z' }); // written by the approval workflow
  const counters = { invoices: 2, receipts: 3, purchases: 1, payments: 2, credits: 1, debits: 1, sdebits: 1, refunds: 1, adjustments: 2, proformas: 1, lpos: 1 };
  for (const [c, n] of Object.entries(counters)) set('counters/' + c, { last: n });
  return docs;
}

(async () => {
  fs.mkdirSync(OUT, { recursive: true });
  const docs = books();
  const browser = await chromium.launch();
  const app = await browser.newPage({ viewport: { width: 1300, height: 950 } }); const errs = []; app.on('pageerror', e => errs.push(e.message));
  await app.addInitScript(`${MOCK};window.__mock({});const st=window.__S;for(const [k,v] of ${JSON.stringify([...docs.entries()])})st.set(k,v);`);
  await app.goto('http://localhost:8765/index.html#dashboard'); await app.waitForFunction(() => window.S && S.invoices && S.invoices.length === 2, null, { timeout: 30000 }); await app.waitForTimeout(600);
  const books0 = await app.evaluate(() => { const x = ledger(); return { problems: x.problems, issues: x.issues.map(i => i.msg) }; });
  console.log('seeded books: ' + books0.problems + ' problems ' + books0.issues.slice(0, 2).join('; '));

  async function download(coll, id) {
    await app.evaluate(() => { window.__lastDownload = null; }); await app.evaluate(([c, i]) => showDoc(c, i), [coll, id]); await app.waitForTimeout(250);
    await app.click('#mBtns >> text=Download'); await app.waitForFunction(() => window.__lastDownload, null, { timeout: 10000 });
    const f = await app.evaluate(() => window.__lastDownload); await app.click('#mBtns >> text=Close').catch(() => {}); return f;
  }
  const pdfPage = await browser.newPage();
  await pdfPage.route(/fonts\.(googleapis|gstatic)\.com/, r => r.abort()); // printing offline must still work
  async function toPdf(file) {
    await pdfPage.setContent(file.data, { waitUntil: 'load' }); await pdfPage.emulateMedia({ media: 'print' });
    // A4 printable width at 96 dpi with 12 mm margins: 210 mm - 24 mm = 186 mm = 703 px
    await pdfPage.setViewportSize({ width: 703, height: 1000 });
    const overflow = await pdfPage.evaluate(() => { const W = document.documentElement.clientWidth; const bad = []; for (const el of document.querySelectorAll('body *')) { const r = el.getBoundingClientRect(); if (r.width && r.right > W + 1) bad.push((el.className || el.tagName) + ' ' + Math.round(r.right)); } return { sw: document.documentElement.scrollWidth, W, bad: bad.slice(0, 4) }; });
    const pdfPath = path.join(OUT, file.filename.replace(/\.html$/, '.pdf'));
    await pdfPage.pdf({ path: pdfPath, format: 'A4', margin: { top: '12mm', bottom: '12mm', left: '12mm', right: '12mm' }, printBackground: true });
    const pages = +/Pages:\s+(\d+)/.exec(execFileSync('pdfinfo', [pdfPath]).toString())[1];
    const perPage = []; for (let i = 1; i <= pages; i++) perPage.push(execFileSync('pdftotext', ['-f', String(i), '-l', String(i), pdfPath, '-']).toString());
    return { pdfPath, pages, text: perPage.join('\n'), perPage, overflow };
  }
  const S = Object.fromEntries([...docs.entries()]);
  const totals = p => { const d = S[p]; return L.calcDoc(d, 0); };
  const common = (r, d, num, party) => {
    const t = norm(r.text);
    assert(t.includes(num), 'number ' + num + ' missing'); assert(t.includes('Irongrid Builders Co Limited'), 'business name missing'); assert(t.includes('TIN: 1000000001'), 'business TIN missing');
    if (party) assert(t.includes(norm(party)), 'party name missing or cut: ' + party);
    assert(!/Press Ctrl\+P/.test(t), 'on-screen hint printed'); assert(!/against this invoice|Payments against this purchase|now: total/.test(t), 'screen-only section printed');
    assert(r.overflow.sw <= r.overflow.W + 1 && !r.overflow.bad.length, 'content wider than the A4 page: ' + JSON.stringify(r.overflow));
  };
  const C1 = 'Ssemakula Engineering & Allied Construction Services (U) Limited';
  const cases = [
    ['P-01', 'invoices', 'i1', 'Sales invoice: lines, VAT 18%, total, paid and balance, due date, LPO ref and payment details all print', (r) => {
      const t = norm(r.text); const x = totals('invoices/i1'); common(r, S['invoices/i1'], 'INV-0001', C1);
      for (const s of [fmt(x.sub), fmt(x.vat), fmt(x.total), 'LPO 4471/26', 'Labour — blockwork, ground floor', 'Stanbic Bank Uganda', 'TIN: 1000000777']) assert(t.includes(s), 'missing ' + s);
      const paidCred = 5000000 + 700000 + Number(L.calcDoc(S['credits/n1'], 0).total); assert(t.includes(fmt(paidCred)), 'paid + credited ' + fmt(paidCred) + ' missing');
      return `${r.pages} page; subtotal ${fmt(x.sub)}, VAT ${fmt(x.vat)}, total ${fmt(x.total)}`; }],
    ['P-02', 'invoices', 'i2', '150-line invoice: every line printed once, no line split across pages, totals on the last page', (r) => {
      const d = S['invoices/i2']; const x = totals('invoices/i2'); common(r, d, 'INV-0002', C1); const pages = r.perPage.map(norm); let split = [];
      for (const it of d.items) { const w = norm(it.desc).split(' '); const head = w.slice(0, 4).join(' '), tail = w.length > 8 ? w.slice(-3).join(' ') : head; // long lines wrap; their last words must be on the same page as the first
        const ph = pages.map((p, i) => p.includes(head) ? i : -1).filter(i => i >= 0), pt = pages.map((p, i) => p.includes(tail) ? i : -1).filter(i => i >= 0);
        if (ph.length !== 1 || pt.length !== 1 || ph[0] !== pt[0]) split.push(`${head} (starts p${ph.map(i => i + 1)}, ends p${pt.map(i => i + 1)})`); }
      assert(!split.length, split.length + ' lines missing, repeated or split across pages: ' + split.slice(0, 3).join(' | '));
      assert(pages.at(-1).includes(fmt(x.total)), 'total not on last page'); return `${r.pages} pages; all 150 lines whole; total ${fmt(x.total)} on page ${r.pages}`; }],
    ['P-03', 'receipts', 'r1', 'Receipt: amount in figures and words, invoice, method and reference print', (r) => {
      const t = norm(r.text); common(r, S['receipts/r1'], 'RCT-0001', C1); for (const s of ['5,000,000', 'Bank transfer', 'TT-55120', 'INV-0001']) assert(t.includes(s), 'missing ' + s);
      assert(/five million/i.test(t), 'amount in words missing'); return 'figures and words agree'; }],
    ['P-04', 'receipts', 'r2', 'Receipt in goods (cement): goods table prints, marked no VAT', (r) => { const t = norm(r.text); common(r, S['receipts/r2'], 'RCT-0002', C1); assert(/no VAT/i.test(t) && t.includes('Cement 50kg bag') && t.includes('700,000'), 'goods block'); return 'goods block printed'; }],
    ['P-05', 'receipts', 'r3', 'Voided receipt prints clearly as VOID with the date and reason', (r) => { const t = norm(r.text); common(r, S['receipts/r3'], 'RCT-0003', C1); assert(/VOID/i.test(t) && t.includes('Entered twice'), 'void marking'); return 'VOID + reason printed'; }],
    ['P-06', 'payments', 'y1', 'Payment voucher to supplier: amount, cheque reference, purchase and signature lines', (r) => { const t = norm(r.text); common(r, S['payments/y1'], 'PAY-0001', 'Lake Victoria Cement Supplies Ltd'); for (const s of ['10,000,000', 'CHQ 000412', 'PUR-0001', 'Approved by']) assert(t.includes(s), 'missing ' + s); return 'ok'; }],
    ['P-07', 'payments', 'y2', 'Expense voucher with a payee and no supplier', (r) => { const t = norm(r.text); common(r, S['payments/y2'], 'PAY-0002', 'UMEME Ltd'); assert(t.includes('412,000') && t.includes('Utilities'), 'amount/category'); return 'ok'; }],
    ['P-08', 'purchases', 'p1', 'Purchase: supplier invoice number, lines, VAT and total', (r) => { const t = norm(r.text); const x = totals('purchases/p1'); common(r, S['purchases/p1'], 'PUR-0001', 'Lake Victoria Cement Supplies Ltd'); for (const s of ['LVC/INV/88231', fmt(x.vat), fmt(x.total)]) assert(t.includes(s), 'missing ' + s); return 'total ' + fmt(x.total); }],
    ['P-09', 'credits', 'n1', 'Credit note: invoice reference, reason and total', (r) => { const t = norm(r.text); const x = totals('credits/n1'); common(r, S['credits/n1'], 'CRN-0001', C1); for (const s of ['INV-0001', 'late delivery', fmt(x.total)]) assert(t.includes(s), 'missing ' + s); return 'total ' + fmt(x.total); }],
    ['P-10', 'debits', 'd1', 'Client debit note', (r) => { const t = norm(r.text); const x = totals('debits/d1'); common(r, S['debits/d1'], 'DBN-0001', C1); assert(t.includes(fmt(x.total)) && t.includes('INV-0001'), 'total/ref'); return 'total ' + fmt(x.total); }],
    ['P-11', 'sdebits', 'e1', 'Supplier debit note (return of damaged goods)', (r) => { const t = norm(r.text); const x = totals('sdebits/e1'); common(r, S['sdebits/e1'], 'SDN-0001', 'Lake Victoria Cement Supplies Ltd'); assert(t.includes(fmt(x.total)) && t.includes('PUR-0001'), 'total/ref'); return 'total ' + fmt(x.total); }],
    ['P-12', 'refunds', 'f1', 'Refund to client', (r) => { const t = norm(r.text); common(r, S['refunds/f1'], 'RFD-0001', C1); assert(t.includes('50,000') && t.includes('Overpayment'), 'amount/reason'); return 'ok'; }],
    ['P-13', 'adjustments', 'a1', 'Stock adjustment (removal)', (r) => { const t = norm(r.text); common(r, S['adjustments/a1'], 'ADJ-0001'); assert(t.includes('Cement 50kg bag') && /removed/.test(t) && t.includes('Bags burst'), 'adj'); return 'ok'; }],
    ['P-14', 'adjustments', 'a2', 'Stock adjustment (addition with value)', (r) => { const t = norm(r.text); common(r, S['adjustments/a2'], 'ADJ-0002'); assert(t.includes('77,000') && /added/.test(t), 'adj'); return 'ok'; }],
    ['P-15', 'proformas', 'q1', 'Proforma: validity, terms, payment details, "not a demand for payment" notice', (r) => { const t = norm(r.text); const x = totals('proformas/q1'); common(r, S['proformas/q1'], 'PRO-0001', C1); for (const s of [fmt(x.total), 'Prices valid for 14 days', 'not a demand for payment']) assert(t.includes(s), 'missing ' + s); return 'total ' + fmt(x.total); }],
    ['P-16', 'lpos', 'l1', 'LPO: supplier, deliver-to, terms, authorised signature line', (r) => { const t = norm(r.text); const x = totals('lpos/l1'); common(r, S['lpos/l1'], 'LPO-0001', 'Lake Victoria Cement Supplies Ltd'); for (const s of [fmt(x.total), 'Yard, Nalukolongo', 'Quote this LPO number', 'Authorised signature']) assert(t.includes(s), 'missing ' + s); return 'total ' + fmt(x.total); }],
  ];
  for (const [id, coll, did, name, check] of cases) await test(id, name, async () => { const f = await download(coll, did); const r = await toPdf(f); return check(r); });

  await test('P-17', 'Printing works offline (web fonts blocked) and on a phone-sized screen the download still fits A4', async () => {
    const f = await download('invoices', 'i1'); const ph = await browser.newPage({ viewport: { width: 375, height: 812 }, isMobile: true, deviceScaleFactor: 1 });
    await ph.route(/fonts\.(googleapis|gstatic)\.com/, r => r.abort()); await ph.setContent(f.data); const sw = await ph.evaluate(() => [document.documentElement.scrollWidth, document.documentElement.clientWidth]);
    const pdfPath = path.join(OUT, 'INV-0001-from-phone.pdf'); await ph.emulateMedia({ media: 'print' }); await ph.pdf({ path: pdfPath, format: 'A4', margin: { top: '12mm', bottom: '12mm', left: '12mm', right: '12mm' } });
    const t = norm(execFileSync('pdftotext', ['-layout', pdfPath, '-']).toString()); assert(t.includes(fmt(totals('invoices/i1').total)), 'total missing'); await ph.close();
    assert(sw[0] <= sw[1] + 1, 'on a phone screen the downloaded invoice scrolls sideways: ' + sw); return 'phone view ' + sw[0] + ' px wide (screen ' + sw[1] + '); PDF complete';
  });
  await test('P-18', 'The seeded books are clean and printing changed nothing in the database', async () => {
    assert(books0.problems === 0, 'seed not clean: ' + books0.issues.join('; ')); const after = await app.evaluate(() => [...window.__S.entries()].length); assert(after === docs.size, 'records ' + after); assert(!errs.length, errs.join('; ')); return docs.size + ' records unchanged';
  });
  // first page of the invoice as an image for a person to look at
  try { execFileSync('pdftoppm', ['-png', '-r', '70', '-f', '1', '-l', '1', path.join(OUT, 'INV-0001.pdf'), path.join(OUT, 'INV-0001-page1')]); } catch (e) {}
  await browser.close();
  fs.writeFileSync(path.join(__dirname, '../reports/print.json'), JSON.stringify({ ranAt: new Date().toISOString(), results }, null, 1));
  const failed = results.filter(r => !r.pass); console.log(`\n${results.length - failed.length}/${results.length} passed`); process.exit(failed.length ? 1 : 0);
})();
