// Independent reference results for every report, used only by tests.
// Written separately from engine/reports.js and engine/ledger.js on purpose: no shared code, BigInt arithmetic
// (cannot round or overflow), and the slowest, plainest method — for each question, walk every journal line
// and keep the ones the period and account rules say belong. If the fast reports and this disagree, one of them is wrong.
'use strict';
const TYPES = { asset: ['1000', '1010', '1020', '1030', '1100', '1200', '1300', '1500'], liability: ['2000', '2100', '2200', '2300'], equity: ['3000', '3100', '3200'] };
function typeOf(a, chart) { return chart[a] ? chart[a][1] : null; }
const inPeriod = (d, from, to) => !(from && d < from) && !(to && d > to);
const B = x => BigInt(x);
// net debit-minus-credit per account over a period
function net(J, from, to) { const m = new Map(); for (const j of J) { if (!inPeriod(j.date, from, to)) continue; for (const l of j.lines) { const x = m.get(l.a) || { d: 0n, c: 0n, n: 0 }; x.d += B(l.d); x.c += B(l.c); x.n++; m.set(l.a, x); } } return m; }
function trialBalance(J, chart, to) { const m = net(J, null, to); let dr = 0n, cr = 0n; const rows = {}; for (const a of Object.keys(chart)) { const x = m.get(a); if (!x) continue; const n = x.d - x.c; rows[a] = n; if (n > 0n) dr += n; else cr -= n; } return { rows, dr, cr }; }
function profitLoss(J, chart, from, to) { const m = net(J, from, to); let inc = 0n, exp = 0n, sales = 0n, cos = 0n; const rows = {};
  for (const [a, x] of m) { const t = typeOf(a, chart); if (t === 'income') { rows[a] = x.c - x.d; inc += x.c - x.d; if (a === '4000') sales = x.c - x.d; } if (t === 'expense') { rows[a] = x.d - x.c; exp += x.d - x.c; if (a === '5000' || a === '5100') cos += x.d - x.c; } }
  return { rows, ti: inc, te: exp, net: inc - exp, gross: sales - cos }; }
function balanceSheet(J, chart, to) { const m = net(J, null, to); let A = 0n, Li = 0n, E = 0n, earn = 0n;
  for (const [a, x] of m) { const t = typeOf(a, chart); const n = x.d - x.c; if (t === 'asset') A += n; else if (t === 'liability') Li -= n; else if (t === 'equity') E -= n; else if (t) earn -= n; }
  return { assets: A, liabilities: Li, equity: E + earn, earnings: earn }; }
function vat(J, from, to) { let out = 0n, inp = 0n, sales = 0n, purch = 0n, paid = 0n;
  for (const j of J) { if (!inPeriod(j.date, from, to)) continue; const pay = /^payments\//.test(j.pid), pur = /^(purchases|sdebits)\//.test(j.pid);
    for (const l of j.lines) { const n = B(l.d) - B(l.c);
      if (l.a === '2100') { if (pay) paid += n; else out -= n; } if (l.a === '1300') { inp += n; if (pur) purch -= n; } if (l.a === '4000') sales -= n; if (pur && l.a === '2000') purch -= n; } }
  return { outputVat: out, inputVat: inp, sales, purchases: purch, paidToURA: paid }; }
function parties(J, acct, to) { const m = new Map(); for (const j of J) { if (to && j.date > to) continue; for (const l of j.lines) if (l.a === acct && l.p) m.set(l.p, (m.get(l.p) || 0n) + (acct === '1100' ? B(l.d) - B(l.c) : B(l.c) - B(l.d))); } return m; }
// general ledger: every line of the account in date, then posting-time, then original order, with an all-time running balance
function ledger(J, chart, acct, from, to) { const t = typeOf(acct, chart); const dr = t === 'asset' || t === 'expense'; const all = [];
  J.forEach((j, o) => j.lines.forEach((l, li) => { if (l.a === acct) all.push({ j, l, o, li }); }));
  all.sort((x, y) => (x.j.date < y.j.date ? -1 : x.j.date > y.j.date ? 1 : 0) || (x.j.at < y.j.at ? -1 : x.j.at > y.j.at ? 1 : 0) || x.o - y.o || x.li - y.li);
  let bal = 0n, open = 0n; const rows = []; for (const { j, l } of all) { bal += dr ? B(l.d) - B(l.c) : B(l.c) - B(l.d); if (from && j.date < from) { open = bal; continue; } if (to && j.date > to) continue; rows.push({ date: j.date, pid: j.pid, d: B(l.d), c: B(l.c), bal }); }
  return { rows, open }; }
function stock(J, to) { const m = {}; for (const j of J) { if (to && j.date > to) continue; for (const l of j.lines) if (l.a === '1200' && l.i) { const x = m[l.i] || (m[l.i] = { q: 0n, v: 0n }); x.q += B(l.q || 0); x.v += B(l.d) - B(l.c); } } return m; }
function cash(J, cashAccts, from, to) { let open = 0n, close = 0n, inflow = 0n, outflow = 0n;
  for (const j of J) { let n = 0n; for (const l of j.lines) if (cashAccts.includes(l.a)) n += B(l.d) - B(l.c);
    if (!(to && j.date > to)) close += n; if (from && j.date < from) open += n; else if (!(to && j.date > to)) { if (n > 0n) inflow += n; else outflow -= n; } }
  return { opening: open, closing: close, inflow, outflow }; }
// ageing: oldest-first application, written as an explicit open-item list per party
function ageing(J, acct, to) { const s = acct === '1100' ? 1n : -1n; const lines = [];
  J.forEach((j, o) => j.lines.forEach((l, li) => { if (l.a === acct && l.p && !(to && j.date > to)) lines.push({ p: l.p, date: j.date, at: j.at, o, li, amt: s * (B(l.d) - B(l.c)) }); }));
  lines.sort((x, y) => (x.date < y.date ? -1 : x.date > y.date ? 1 : 0) || (x.at < y.at ? -1 : x.at > y.at ? 1 : 0) || x.o - y.o || x.li - y.li);
  const asAt = to || lines.reduce((m, x) => x.date > m ? x.date : m, '1970-01-01'); const days = d => Math.round((Date.parse(asAt) - Date.parse(d)) / 864e5);
  const per = {}; for (const x of lines) { const q = per[x.p] || (per[x.p] = { items: [], credit: 0n }); let a = x.amt;
    if (a > 0n) { const u = q.credit < a ? q.credit : a; q.credit -= u; a -= u; if (a > 0n) q.items.push({ date: x.date, a }); }
    else if (a < 0n) { let left = -a; for (const it of q.items) { if (!left) break; const u = it.a < left ? it.a : left; it.a -= u; left -= u; } q.items = q.items.filter(i => i.a > 0n); q.credit += left; } }
  const tot = [0n, 0n, 0n, 0n, 0n]; let unapplied = 0n; const byParty = {};
  for (const [p, q] of Object.entries(per)) { const b = [0n, 0n, 0n, 0n, 0n]; for (const it of q.items) { const d = days(it.date); b[d <= 0 ? 0 : d <= 30 ? 1 : d <= 60 ? 2 : d <= 90 ? 3 : 4] += it.a; }
    b.forEach((x, i) => tot[i] += x); unapplied += q.credit; byParty[p] = b.reduce((t, x) => t + x, 0n) - q.credit; }
  return { totals: tot, unapplied, total: tot.reduce((t, x) => t + x, 0n) - unapplied, byParty }; }
module.exports = { trialBalance, profitLoss, balanceSheet, vat, parties, ledger, stock, cash, ageing };
