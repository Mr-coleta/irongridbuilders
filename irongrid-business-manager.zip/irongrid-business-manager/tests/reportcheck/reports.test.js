// Report accuracy suite: the fast indexed reports (engine/reports.js) against
//   (1) the independent BigInt reference (reference.js), and
//   (2) the original report functions in engine/ledger.js,
// on many synthetic books, the 24,990-record scale books, and hand-made cutoff cases, over random periods and
// every boundary date (first day, last day, the day before and after, month ends, a one-day period, open-ended).
// Every figure must match exactly. Writes tests/reports/report-accuracy.json.  node tests/reportcheck/reports.test.js
'use strict';
const fs = require('fs'), path = require('path');
const L = require('../../engine/ledger.js'), R = require('../../engine/reports.js'), REF = require('./reference.js');
const { journals } = require('../perf/journals.js'); const { build } = require('../scale/books.js');
const B = x => BigInt(x); let checks = 0; const fails = [];
const eq = (what, a, b) => { checks++; const sa = typeof a === 'bigint' ? a.toString() : JSON.stringify(a), sb = typeof b === 'bigint' ? b.toString() : JSON.stringify(b); if (sa !== sb) { if (fails.length < 40) fails.push({ what, got: sa.slice(0, 300), want: sb.slice(0, 300) }); else fails.length++; } };
const big = o => JSON.parse(JSON.stringify(o, (k, v) => typeof v === 'bigint' ? v.toString() : v));
const addDays = (d, n) => new Date(Date.parse(d) + n * 864e5).toISOString().slice(0, 10);
function rng(s) { let a = s >>> 0; return () => { a = (a + 0x6D2B79F5) | 0; let t = Math.imul(a ^ a >>> 15, 1 | a); t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t; return ((t ^ t >>> 14) >>> 0) / 4294967296; }; }
function periods(J, seed, nRandom) {
  if (!J.length) return [[null, null], ['2024-01-01', '2024-12-31']];
  const ds = J.map(j => j.date).sort(); const first = ds[0], last = ds[ds.length - 1]; const r = rng(seed); const pick = () => ds[Math.floor(r() * ds.length)];
  const P = [[null, null], [first, last], [first, first], [last, last], [addDays(first, -1), addDays(first, -1)], [addDays(last, 1), addDays(last, 30)], [null, addDays(first, -1)], [addDays(first, 1), null], [null, last], [first, null]];
  const m = first.slice(0, 7); P.push([m + '-01', addDays(addDays(m + '-01', 32).slice(0, 7) + '-01', -1)]);
  for (let k = 0; k < nRandom; k++) { const a = pick(), b = pick(); P.push(a <= b ? [a, b] : [b, a]); P.push([pick(), null]); P.push([null, pick()]); }
  return P;
}
function compare(name, J, seed, nRandom) {
  const t0 = Date.now(); const ix = R.buildIndex(J); const chart = L.ACC; const P = periods(J, seed, nRandom);
  const accts = [...new Set(J.flatMap(j => j.lines.map(l => l.a)))].filter(a => chart[a]);
  for (const [f, t] of P) {
    const tag = `${name} ${f || '…'}..${t || '…'}`;
    // trial balance and balance sheet at the period end
    const tb = R.trialBalance(ix, t), rtb = REF.trialBalance(J, chart, t);
    eq(tag + ' TB debits', B(tb.dr), rtb.dr); eq(tag + ' TB credits', B(tb.cr), rtb.cr); eq(tag + ' TB balanced', tb.ok, rtb.dr === rtb.cr);
    eq(tag + ' TB rows', Object.fromEntries(tb.rows.map(x => [x.a, String(B(x.dr) - B(x.cr))])), big(rtb.rows));
    eq(tag + ' TB = original', tb, L.trialBalance(J, t));
    const bs = R.balanceSheet(ix, t), rbs = REF.balanceSheet(J, chart, t);
    eq(tag + ' BS assets', B(bs.assets), rbs.assets); eq(tag + ' BS liabilities', B(bs.liabilities), rbs.liabilities); eq(tag + ' BS equity', B(bs.equity), rbs.equity); eq(tag + ' BS balances', bs.ok, rbs.assets === rbs.liabilities + rbs.equity);
    eq(tag + ' BS = original', bs, L.balanceSheet(J, t));
    // profit and loss, VAT for the period
    const pl = R.profitLoss(ix, f, t), rpl = REF.profitLoss(J, chart, f, t);
    eq(tag + ' P&L income', B(pl.ti), rpl.ti); eq(tag + ' P&L expenses', B(pl.te), rpl.te); eq(tag + ' P&L net', B(pl.net), rpl.net); eq(tag + ' P&L gross', B(pl.gross), rpl.gross);
    eq(tag + ' P&L rows', Object.fromEntries([...pl.inc, ...pl.exp].map(x => [x.a, String(x.amt)])), big(rpl.rows));
    eq(tag + ' P&L = original', pl, L.profitLoss(J, f, t));
    const v = R.vatReturn(ix, f, t), rv = REF.vat(J, f, t);
    for (const k of ['outputVat', 'inputVat', 'sales', 'purchases', 'paidToURA']) eq(tag + ' VAT ' + k, B(v[k]), rv[k]);
    eq(tag + ' VAT = original', v, L.vatReturn(J, f, t));
    // client and supplier balances
    for (const a of ['1100', '2000']) { const pb = R.partyBalances(ix, a, t), rp = REF.parties(J, a, t);
      eq(tag + ' parties ' + a, [...pb].map(([p, x]) => [p, String(x)]).sort(), [...rp].map(([p, x]) => [p, String(x)]).sort());
      eq(tag + ' parties ' + a + ' = original', [...pb].sort(), [...L.partyBalances(J, a, t)].sort()); }
    // inventory valuation and cash flow
    const st = R.stockAt(ix, t), rst = REF.stock(J, t); eq(tag + ' stock', Object.fromEntries(Object.entries(st).map(([i, x]) => [i, [String(x.q), String(x.v)]]).sort()), Object.fromEntries(Object.entries(rst).map(([i, x]) => [i, [String(x.q), String(x.v)]]).sort()));
    const sv = Object.values(st).reduce((s, x) => s + B(x.v), 0n); const tbr = tb.rows.find(x => x.a === '1200'); eq(tag + ' stock = account 1200', sv, tbr ? B(tbr.dr) - B(tbr.cr) : 0n);
    const cf = R.cashFlow(ix, f, t), rcf = REF.cash(J, L.CASH_ACCTS, f, t);
    eq(tag + ' cash opening', B(cf.opening), rcf.opening); eq(tag + ' cash closing', B(cf.closing), rcf.closing); eq(tag + ' cash in', cf.cats.reduce((s, c) => s + B(c.inflow), 0n), rcf.inflow); eq(tag + ' cash out', cf.cats.reduce((s, c) => s + B(c.outflow), 0n), rcf.outflow); eq(tag + ' cash reconciles', cf.ok, true);
    // ageing as at the period end
    for (const a of ['1100', '2000']) { const ag = R.ageing(ix, a, t), ra = REF.ageing(J, a, t);
      eq(tag + ' ageing ' + a + ' buckets', ag.totals.map(String), ra.totals.map(String)); eq(tag + ' ageing ' + a + ' unapplied', B(ag.unapplied), ra.unapplied); eq(tag + ' ageing ' + a + ' total', B(ag.total), ra.total);
      eq(tag + ' ageing ' + a + ' per party', Object.fromEntries(ag.rows.map(x => [x.p, String(x.total)]).sort()), Object.fromEntries(Object.entries(ra.byParty).filter(([, x]) => x !== 0n).map(([p, x]) => [p, String(x)]).sort()));
      eq(tag + ' ageing ' + a + ' = control account', ag.ok, true); }
  }
  // general ledger: every account, a sample of periods, full rows, brought-forward, and paging that loses or repeats nothing
  for (const a of accts) for (const [f, t] of P.slice(0, 16)) {
    const tag = `${name} GL ${a} ${f || '…'}..${t || '…'}`; const ref = REF.ledger(J, chart, a, f, t); const n = R.glCount(ix, a, f, t);
    eq(tag + ' row count', n, ref.rows.length); eq(tag + ' brought forward', B(R.glOpening(ix, a, f, 0)), ref.open);
    const page = 137; let all = []; for (let o = 0; o < n; o += page) { const pg = R.generalLedgerPage(ix, a, f, t, o, page); if (o) eq(tag + ' page ' + o + ' brought forward', B(R.glOpening(ix, a, f, o)), all.length ? B(all[all.length - 1].bal) : ref.open); all = all.concat(pg); }
    eq(tag + ' rows', all.map(r => [r.date, r.pid, String(r.d), String(r.c), String(r.bal)]), ref.rows.map(r => [r.date, r.pid, String(r.d), String(r.c), String(r.bal)]));
    eq(tag + ' = original', R.generalLedger(ix, a, f, t), L.generalLedger(J, a, f, t));
  }
  return { name, journals: J.length, periods: P.length, ms: Date.now() - t0 };
}
// hand-made cutoff cases
function cutoffBooks() {
  const j = (pid, date, at, lines) => ({ v: 1, pid, date, cur: 'UGX', dp: 0, at, lines }); const l = (a, d, c, x) => Object.assign({ a, d, c }, x || {});
  return [
    j('invoices/a', '2026-01-31', '2026-01-31T23:59:00Z', [l('1100', 118000, 0, { p: 'c1' }), l('4000', 0, 100000), l('2100', 0, 18000)]),              // last day of January
    j('receipts/b', '2026-02-01', '2026-02-01T00:00:00Z', [l('1000', 50000, 0), l('1100', 0, 50000, { p: 'c1' })]),                                   // first day of February
    j('receipts/b:R', '2026-03-15', '2026-03-15T09:00:00Z', [l('1000', 0, 50000), l('1100', 50000, 0, { p: 'c1' })]),                                  // void dated later, in March
    j('payments/c', '2026-01-31', '2026-01-31T10:00:00Z', [l('6000', 20000, 0), l('1010', 0, 20000)]),                                                 // same day, earlier time than the invoice
    j('payments/d', '2026-01-31', '2026-01-31T10:00:00Z', [l('6020', 5000, 0), l('1010', 0, 5000)]),                                                   // same date and time: original order decides
    j('purchases/e', '2026-02-28', '2026-02-28T12:00:00Z', [l('1200', 300000, 0, { i: 'x', q: 3e6 }), l('1300', 54000, 0), l('2000', 0, 354000, { p: 's1' })]),
    j('payments/f', '2026-03-01', '2026-03-01T12:00:00Z', [l('2000', 400000, 0, { p: 's1' }), l('1000', 0, 400000)]),                                  // overpays the supplier: unapplied amount
    j('payments/g', '2026-03-01', '2026-03-01T12:00:00Z', [l('1020', 70000, 0), l('1000', 0, 70000)]),                                                 // bank transfer between cash accounts
    j('invoices/h', '2027-06-30', '2027-06-30T12:00:00Z', [l('1100', 59000, 0, { p: 'c2' }), l('4000', 0, 50000), l('2100', 0, 9000)]),                // future-dated
    j('payments/i', '2026-04-10', '2026-04-10T12:00:00Z', [l('2100', 18000, 0), l('1030', 0, 18000)]),                                                 // VAT paid to URA
    j('credits/k', '2026-04-11', '2026-04-11T12:00:00Z', [l('4000', 10000, 0), l('2100', 1800, 0), l('1100', 0, 11800, { p: 'c1' })]),
    j('payments/m', '2026-04-12', '2026-04-12T12:00:00Z', [l('6000', 9000, 0), l('2000', 1000, 0, { p: 's1' }), l('1000', 0, 10000)]),               // mixed: flagged in cash flow
    j('payments/n', '2026-04-13', '2026-04-13T12:00:00Z', [l('6040', 0, 0), l('1000', 0, 0)]),                                                       // zero-amount lines still show the account
  ];
}
function scaleJournals() { const b = build(24990, 2026); const entries = [...b.docs].filter(([, d]) => d.je).map(([p, doc]) => { const [coll, id] = p.split('/'); return { coll, id, doc }; });
  const inv = new Map(entries.filter(e => e.coll === 'invoices').map(e => [e.id, e.doc]));
  const res = L.check(entries, { dp: 0, depOf: (c, d) => c === 'credits' ? inv.get(d.invoiceId) : null, unitCost: (c, d) => c === 'credits' ? L.unitCosts((inv.get(d.invoiceId) || {}).je) : null });
  if (res.issues.some(i => i.sev === 'error')) throw new Error('scale books did not check clean'); return res.journals; }
const runs = [];
runs.push(compare('empty books', [], 1, 0));
runs.push(compare('cutoff cases', cutoffBooks(), 2, 25));
for (let s = 1; s <= 8; s++) runs.push(compare('synthetic seed ' + s, journals(1500 + s * 400, s), 100 + s, 12));
runs.push(compare('scale books 24,990 records', scaleJournals(), 99, 8));
// a total that cannot be added up exactly must stop the report, not round it
let guard = false; try { R.buildIndex([{ pid: 'payments/z', date: '2026-01-01', at: 'x', lines: [{ a: '6000', d: 2 ** 53, c: 0 }, { a: '1000', d: 0, c: 2 ** 53 }] }]); } catch (e) { guard = /too large/.test(e.message); }
eq('unsafe total stops the report', guard, true);
// the mixed journal is reported as mixed, not hidden inside one category
const cf = R.cashFlow(R.buildIndex(cutoffBooks()), '2026-04-01', '2026-04-30'); eq('mixed journal flagged', cf.cats.some(c => c.key === 'mixed' && c.count === 1), true);
const out = { ranAt: new Date().toISOString(), checks, failed: fails.length, fails, runs };
fs.mkdirSync(path.join(__dirname, '../reports'), { recursive: true }); fs.writeFileSync(path.join(__dirname, '../reports/report-accuracy.json'), JSON.stringify(out, null, 1));
for (const r of runs) console.log(`${r.name}: ${r.journals} journals, ${r.periods} periods, ${r.ms} ms`);
console.log(`${checks} checks, ${fails.length} failed`); if (fails.length) { console.log(JSON.stringify(fails.slice(0, 8), null, 1)); process.exit(1); }
