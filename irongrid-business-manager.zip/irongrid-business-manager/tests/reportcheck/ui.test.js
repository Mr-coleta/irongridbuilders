// Report suite: accuracy of the optimised reports in the app, paging, no stale figures, reconciliations, and
// errors shown rather than hidden. Runs on the fake store. Writes tests/reports/reports.json.
// Usage: node tests/reportcheck/ui.test.js   (server on :8765 serving srv/)
'use strict';
const { chromium } = require('playwright'); const fs = require('fs'); const path = require('path'); const { execFileSync } = require('child_process');
const MOCK = require('../mocksrc.js'); const { build } = require('../scale/books.js');
const results = []; const assert = (c, m) => { if (!c) throw new Error(m); };
async function test(id, name, fn) {
  const t0 = Date.now();
  try { const detail = await fn(); results.push({ id, name, pass: true, ms: Date.now() - t0, detail: detail || '' }); }
  catch (e) { results.push({ id, name, pass: false, ms: Date.now() - t0, detail: e.message.split('\n')[0] }); }
  const r = results.at(-1); console.log(`${r.pass ? 'PASS' : 'FAIL'}  ${id}  ${name}${r.detail ? '  — ' + r.detail : ''}`);
}
const SEED = `st.set("settings/business",{name:"Irongrid (synthetic)",currency:"UGX"});st.set("clients/c",{name:"Nansubuga Estates Ltd"});st.set("suppliers/s",{name:"Lake Victoria Cement Ltd"});st.set("items/cem",{name:"Cement 50kg",unit:"bags"});`;
const SCALE = `{const x=new XMLHttpRequest();x.open("GET","/scale.json",false);x.send();for(const [k,v] of JSON.parse(x.responseText))st.set(k,v)}`;
let browser;
async function open(seed, hash = 'accounts', wait = 1000) {
  const p = await browser.newPage({ viewport: { width: 1300, height: 950 } }); p.setDefaultTimeout(60000); const errs = []; p.on('pageerror', e => errs.push(e.message));
  await p.addInitScript(`${MOCK};window.__mock({});const st=window.__S;${seed};window.__lt=[];new PerformanceObserver(l=>{for(const e of l.getEntries())window.__lt.push(e.duration)}).observe({type:"longtask",buffered:true});`);
  await p.goto('http://localhost:8765/index.html#' + hash); await p.waitForTimeout(wait); return { p, errs };
}
const tab = (p, t) => p.evaluate(t => document.querySelector(`#acTabs [data-t=${t}]`).click(), t);
const ready = p => p.waitForFunction(() => !document.querySelector('#acPreparing') && document.querySelector('#acBody').dataset.waiting !== '1');
const body = p => p.textContent('#acBody');
// in-page: every indexed report against the original full-scan functions, over a set of dates
const SAME = (dates) => { const L = ledger(), J = L.J, RX = reportIndex(L); const s = JSON.stringify; const bad = [];
  for (const t of dates) { if (s(REPORTS.trialBalance(RX, t)) !== s(LEDGER.trialBalance(J, t))) bad.push('TB ' + t); if (s(REPORTS.balanceSheet(RX, t)) !== s(LEDGER.balanceSheet(J, t))) bad.push('BS ' + t);
    for (const f of dates) { if (f && t && f > t) continue; if (s(REPORTS.profitLoss(RX, f, t)) !== s(LEDGER.profitLoss(J, f, t))) bad.push('PL ' + f + '..' + t); if (s(REPORTS.vatReturn(RX, f, t)) !== s(LEDGER.vatReturn(J, f, t))) bad.push('VAT ' + f + '..' + t);
      for (const a of ['1000', '1030', '1100', '1200', '2000', '4000']) if (s(REPORTS.generalLedger(RX, a, f, t)) !== s(LEDGER.generalLedger(J, a, f, t))) bad.push('GL ' + a + ' ' + f + '..' + t); } }
  return { bad, n: J.length }; };

(async () => {
  const B = build(24990); fs.writeFileSync(path.join(__dirname, '../../srv/scale.json'), JSON.stringify([...B.docs.entries()]));
  browser = await chromium.launch();

  await test('RP-01', 'Indexed reports equal an independent BigInt reference and the original report functions (engine, many books and cutoffs)', async () => {
    const out = execFileSync(process.execPath, [path.join(__dirname, 'reports.test.js')], { encoding: 'utf8', timeout: 280000 }); const m = out.match(/(\d+) checks, (\d+) failed/); assert(m && m[2] === '0', 'accuracy failures: ' + (m ? m[2] : out.slice(-300))); return m[1] + ' checks, 0 differences'; });

  await test('RP-02', 'Small books: every report in the app equals the original functions at boundary and random dates', async () => {
    const small = build(600, 5); const seed = `for (const [k,v] of ${JSON.stringify([...small.docs.entries()])}) st.set(k,v);`;
    const { p, errs } = await open(seed, 'accounts'); const ds = [...small.docs.values()].filter(d => d.je).map(d => d.date).sort(); const first = ds[0], last = ds.at(-1), mid = ds[Math.floor(ds.length / 2)];
    const prev = d => new Date(Date.parse(d) - 864e5).toISOString().slice(0, 10), next = d => new Date(Date.parse(d) + 864e5).toISOString().slice(0, 10);
    await p.waitForTimeout(800); const r = await p.evaluate(SAME, [null, prev(first), first, next(first), prev(mid), mid, last, next(last)]); assert(r.n > 300, 'too few journals: ' + r.n);
    assert(!r.bad.length, r.bad.slice(0, 5).join('; ')); assert(!errs.length, errs[0]); await p.close(); return r.n + ' journals, 0 differences'; });

  await test('RP-03', 'No stale figures: a new invoice appears in the reports straight away', async () => {
    const { p } = await open(SEED, 'accounts'); await tab(p, 'tb'); await ready(p); const before = await p.evaluate(() => REPORTS.trialBalance(reportIndex(ledger())).dr);
    await p.evaluate(() => location.hash = 'invoices'); await p.waitForTimeout(200); await p.click('#lNew'); await p.selectOption('#ed [name=party]', 'c'); await p.fill('#ed .d', 'Survey'); await p.fill('#ed .p', '100000'); await p.fill('#ed [name=vatRate]', '18');
    await p.click('#ed [type=submit]'); await p.waitForTimeout(1200); await p.click('#mBtns >> text=Close').catch(() => {});
    await p.waitForTimeout(600); await p.evaluate(() => location.hash = 'accounts'); await tab(p, 'tb'); await ready(p);
    const t = await body(p); const after = await p.evaluate(() => { const L = ledger(); return { ix: REPORTS.trialBalance(reportIndex(L)).dr, raw: LEDGER.trialBalance(L.J).dr }; });
    assert(after.ix === after.raw, 'index ' + after.ix + ' vs journals ' + after.raw); assert(after.ix === before + 118000, 'debits went from ' + before + ' to ' + after.ix + ', expected +118,000');
    assert(/118,000|1,18,000/.test(t) || t.includes('118'), 'trial balance on screen does not show the new receivable'); await p.close(); return 'debits ' + before + ' → ' + after.ix; });

  let sp; // one page with the 24,990-record books, shared by the scale tests
  await test('RP-04', '24,990 records: reports are prepared in slices without freezing the page, then equal the original functions', async () => {
    sp = (await open(SCALE, 'dashboard', 500)).p; await sp.waitForFunction(n => window.S && S.invoices && S.invoices.length === n, B.counts.invoices); await sp.waitForTimeout(3000);
    await sp.evaluate(() => { window.__lt.length = 0; location.hash = 'accounts'; }); await sp.waitForTimeout(100); await sp.evaluate(() => { __dropLedger(); document.querySelector('#acTabs [data-t=tb]').click(); });
    const sawPreparing = await sp.evaluate(() => !!document.querySelector('#acPreparing')); await ready(sp);
    const lt = await sp.evaluate(() => Math.round(Math.max(0, ...window.__lt)));
    const r = await sp.evaluate(SAME, [null, '2022-06-01', '2023-12-31', '2024-06-30', '2025-06-30']);
    assert(sawPreparing, 'no "Preparing reports" state: index was built in one go'); assert(!r.bad.length, r.bad.slice(0, 5).join('; '));
    return `${r.n} journals; longest task while preparing ${lt} ms (browser check work included); 0 differences`; });

  await test('RP-05', '24,990 records: general ledger pages lose and repeat nothing, and each page brings forward the previous closing balance', async () => {
    assert(sp, 'no scale page'); await sp.evaluate(() => { document.querySelector('#acTabs [data-t=gl]').click(); const s = document.querySelector('#acAcct'); s.value = '1100'; s.dispatchEvent(new Event('change')); }); await ready(sp);
    const r = await sp.evaluate(async () => { const all = []; const bfs = []; for (let k = 0; k < 400; k++) { const info = document.querySelector('#glInfo').textContent; bfs.push(info);
        const rows = [...document.querySelectorAll('#acBody tbody tr')].map(tr => [...tr.children].map(td => td.textContent)); all.push(...rows); const nx = document.querySelector('#glNext'); if (!nx || nx.disabled) break; nx.click(); }
      const full = LEDGER.generalLedger(ledger().J, '1100'); return { shown: all.length, want: full.length, pages: bfs.length, firstBal: all[0] && all[0][5], lastBal: all.at(-1) && all.at(-1)[5], wantLast: full.at(-1).bal, bfs: bfs.slice(0, 3), dates: all.map(x => x[0]) }; });
    assert(r.shown === r.want, `shown ${r.shown} rows, ledger has ${r.want}`); assert(r.pages > 1, 'only one page');
    const fmt = n => n.toLocaleString('en-US'); assert(r.lastBal.replace(/[^0-9-]/g, '') === String(r.wantLast), `last balance ${r.lastBal} vs ${fmt(r.wantLast)}`);
    // brought forward on page k = balance on the last row of page k-1
    const bf = await sp.evaluate(() => { const ix = reportIndex(ledger()); const n = REPORTS.glCount(ix, '1100'); const bad = []; for (let o = 500; o < n; o += 500) { const prev = REPORTS.generalLedgerPage(ix, '1100', null, null, o - 1, 1)[0]; if (REPORTS.glOpening(ix, '1100', null, o) !== prev.bal) bad.push(o); } return bad; });
    assert(!bf.length, 'brought-forward wrong at offsets ' + bf.join(',')); return `${r.shown} rows over ${r.pages} pages, last balance ${r.lastBal}`; });

  await test('RP-06', '24,990 records: ageing, cash flow and inventory valuation each agree with the ledger account they summarise', async () => {
    assert(sp, 'no scale page'); const out = [];
    for (const [t, id, want] of [['ar', '#agRecon', /agrees with account 1100/], ['ap', '#agRecon', /agrees with account 2000/], ['cf', '#cfRecon', /Agrees with the cash and bank accounts/], ['inv', '#invRecon', /agrees with account 1200/]]) {
      await tab(sp, t); await ready(sp); const s = await sp.textContent(id); assert(want.test(s), t + ': ' + s); out.push(t); }
    const ok = await sp.evaluate(() => { const ix = reportIndex(ledger()), J = ledger().J; const r = [];
      for (const to of ['2023-01-31', '2024-02-29', null]) { const tb = LEDGER.trialBalance(J, to).rows; const B = a => { const x = tb.find(y => y.a === a); return x ? x.dr - x.cr : 0; };
        r.push(REPORTS.ageing(ix, '1100', to).total === B('1100'), REPORTS.ageing(ix, '2000', to).total === -B('2000'), Object.values(REPORTS.stockAt(ix, to)).reduce((t, x) => t + x.v, 0) === B('1200'), REPORTS.cashFlow(ix, '2023-01-01', to).ok); } return r; });
    assert(ok.every(Boolean), 'a reconciliation failed at an as-at date: ' + JSON.stringify(ok)); return out.join(', ') + ' agree on screen; 12 as-at reconciliations agree'; });

  await test('RP-07', 'A difference is shown in red, not hidden: a receivable line with no client', async () => {
    const { p } = await open(SEED, 'accounts');
    await p.evaluate(() => { const L = ledger(); L.J.push({ v: 1, pid: 'adjustments/x', date: '2026-03-11', at: '2026-03-11T00:00:00Z', lines: [{ a: '1100', d: 5000, c: 0 }, { a: '4000', d: 0, c: 5000 }] }); L.RX = null; });
    await tab(p, 'ar'); await ready(p); const s = await p.textContent('#agRecon'); const red = await p.$('#agRecon b.neg');
    assert(/differs from account 1100 by/.test(s) && red, 'difference not shown: ' + s); await p.close(); return s.trim().slice(0, 90); });

  await test('RP-08', 'A total too large to add exactly stops the report with a message, and no figures are shown', async () => {
    const { p } = await open(SEED, 'accounts');
    await p.evaluate(() => { const L = ledger(); L.J.push({ v: 1, pid: 'payments/z', date: '2026-01-01', at: 'x', lines: [{ a: '6000', d: 2 ** 53, c: 0 }, { a: '1000', d: 0, c: 2 ** 53 }] }); L.RX = null; L.RXERR = null; });
    await tab(p, 'tb'); await p.waitForTimeout(200); const s = await body(p); const rows = await p.$$('#acBody tbody tr');
    assert(/could not be produced/.test(s) && /too large/.test(s), 'no error shown: ' + s.slice(0, 120)); assert(!rows.length, 'figures were still shown'); await p.close(); return s.trim().slice(0, 100); });

  await test('RP-09', 'CSV export of the general ledger contains every row, not just the page on screen', async () => {
    assert(sp, 'no scale page'); await sp.evaluate(() => { document.querySelector('#acTabs [data-t=gl]').click(); const s = document.querySelector('#acAcct'); s.value = '1100'; s.dispatchEvent(new Event('change')); }); await ready(sp);
    const r = await sp.evaluate(() => ({ csv: accountsCSV().length - 1, want: LEDGER.generalLedger(ledger().J, '1100').length, onScreen: document.querySelectorAll('#acBody tbody tr').length }));
    assert(r.csv === r.want, `CSV ${r.csv} rows, ledger ${r.want}`); assert(r.onScreen <= 500, 'page too long'); return `CSV ${r.csv} rows; screen shows ${r.onScreen}`; });

  if (sp) await sp.close(); await browser.close();
  fs.mkdirSync(path.join(__dirname, '../reports'), { recursive: true }); fs.writeFileSync(path.join(__dirname, '../reports/reports.json'), JSON.stringify({ ranAt: new Date().toISOString(), results }, null, 1));
  const f = results.filter(r => !r.pass).length; console.log(`${results.length - f}/${results.length} passed`); process.exit(f ? 1 : 0);
})();
