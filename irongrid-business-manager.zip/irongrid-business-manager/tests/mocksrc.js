// The fake platform database used by every browser test, with the REAL access rules from security/rules.json
// switched on, so each test runs under the same server-side permissions as production.
const fs = require('fs'); const path = require('path');
const rules = JSON.parse(fs.readFileSync(path.join(__dirname, '../security/rules.json'), 'utf8')).db.rules;
module.exports = `window.__DEFAULT_RULES=${JSON.stringify(rules)};\n` + fs.readFileSync(path.join(__dirname, 'mock.js'), 'utf8');
