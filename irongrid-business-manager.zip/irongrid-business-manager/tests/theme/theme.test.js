// Theme suite ("ledger green", QuickBooks-style workspace): the new + New menu and top bar work, respect roles and
// approvals, and printed/downloaded documents keep exactly their previous look. Writes tests/reports/theme.json.
// Usage: node tests/theme/theme.test.js   (server on :8765 serving srv/)
'use strict';
const { chromium } = require('playwright'); const fs = require('fs'); const path = require('path');
const MOCK = require('../mocksrc.js');
const results = []; const assert = (c, m) => { if (!c) throw new Error(m); };
async function test(id, name, fn) {
  if (process.env.ONLY && !process.env.ONLY.split(',').includes(id)) return;
  const t0 = Date.now();
  try { const detail = await fn(); results.push({ id, name, pass: true, ms: Date.now() - t0, detail: detail || '' }); }
  catch (e) { results.push({ id, name, pass: false, ms: Date.now() - t0, detail: e.message.split('\n')[0] }); }
  const r = results.at(-1); console.log(`${r.pass ? 'PASS' : 'FAIL'}  ${id}  ${name}${r.detail ? '  — ' + r.detail : ''}`);
}
const SEED = `st.set("settings/business",{name:"Irongrid Builders Co Limited",currency:"UGX"});st.set("clients/c",{name:"Nansubuga Estates Ltd"});st.set("suppliers/s",{name:"Lake Victoria Cement Ltd"});st.set("items/cem",{name:"Cement 50kg",unit:"bags"});`;
let browser;
async function open(opts = {}, hash = 'dashboard', vp = { width: 1366, height: 860 }) {
  const p = await browser.newPage({ viewport: vp }); p.setDefaultTimeout(15000); const errs = []; p.on('pageerror', e => errs.push(e.message));
  await p.addInitScript(`${MOCK};window.__mock(${JSON.stringify(opts)});const st=window.__S;${SEED}`); await p.goto('http://localhost:8765/index.html#' + hash); await p.waitForTimeout(1000); return { p, errs };
}
(async () => {
  browser = await chromium.launch();

  await test('THM-01', '+ New opens a menu; each item opens the matching form; Escape and outside clicks close it', async () => {
    const { p, errs } = await open(); const seen = [];
    for (const [k, title] of [['invoices', /invoice/i], ['receipts', /receipt/i], ['proformas', /proforma/i], ['lpos', /LPO/i], ['purchases', /purchase/i], ['clients', /client/i], ['suppliers', /supplier/i]]) {
      await p.click('#qbNewBtn'); assert(await p.isVisible('#qbMenu'), 'menu did not open'); assert(await p.getAttribute('#qbNewBtn', 'aria-expanded') === 'true', 'aria-expanded not set');
      await p.click(`#qbMenu [data-qbnew=${k}]`); await p.waitForTimeout(250); assert(!(await p.isVisible('#qbMenu')), 'menu stayed open after choosing');
      const t = await p.textContent('#mTitle'); assert(title.test(t) && await p.isVisible('#ed'), `${k}: opened "${t}"`); seen.push(k);
      await p.evaluate(() => { const m = document.querySelector('#modal'); m.classList.remove('on'); }); }
    // every item must be really visible: the topmost element at its centre is the item itself (not clipped by the side bar)
    for (const vp of [{ width: 1366, height: 860 }, { width: 390, height: 844 }]) { await p.setViewportSize(vp); await p.click('#qbNewBtn');
      const hidden = await p.evaluate(() => [...document.querySelectorAll('#qbMenu [data-qbnew]')].filter(b => { const r = b.getBoundingClientRect(); const x = r.left + r.width / 2, y = r.top + r.height / 2;
        return x < 0 || y < 0 || x > innerWidth || y > innerHeight || document.elementFromPoint(x, y) !== b; }).map(b => b.textContent));
      await p.keyboard.press('Escape'); assert(!hidden.length, `${vp.width} px: hidden menu items: ${hidden.join(', ')}`); }
    await p.setViewportSize({ width: 1366, height: 860 });
    await p.click('#qbNewBtn'); await p.keyboard.press('Escape'); assert(!(await p.isVisible('#qbMenu')), 'Escape did not close it');
    await p.click('#qbNewBtn'); await p.click('main h1'); assert(!(await p.isVisible('#qbMenu')), 'outside click did not close it');
    assert(!errs.length, errs[0]); await p.close(); return seen.length + ' forms opened from the menu; closes on choice, Escape and outside click'; });

  await test('THM-02', 'A view-only person does not see + New; a Contributor choosing Payment gets the approval request, not a posting', async () => {
    const v = await open({ level: 'view', uid: 'u3' }); const shown = await v.p.isVisible('#qbNewBtn'); await v.p.close();
    assert(!shown, '+ New visible to a view-only person');
    const c = await open({ level: 'interact', uid: 'u2' }); await c.p.click('#qbNewBtn'); await c.p.click('#qbMenu [data-qbnew=payments]'); await c.p.waitForTimeout(400);
    const t = await c.p.textContent('#modal'); const before = await c.p.evaluate(() => [...window.__S.keys()].filter(k => k.startsWith('payments/')).length);
    assert(/request|approv/i.test(t), 'no approval wording for a Contributor: ' + t.slice(0, 120)); assert(before === 0, 'a payment record exists');
    await c.p.close(); return 'hidden for view-only; Contributor sees the approval-request form'; });

  await test('THM-03', 'The top bar shows the business name and follows changes to it', async () => {
    const { p } = await open(); const a = await p.textContent('#qbCo');
    await p.evaluate(() => { window.__S.set('settings/business', { name: 'Irongrid Builders (renamed)', currency: 'UGX' }); for (const l of window.__L) l.fire(); }); await p.waitForTimeout(500);
    const b = await p.textContent('#qbCo'); await p.close(); assert(a === 'Irongrid Builders Co Limited' && b === 'Irongrid Builders (renamed)', `${a} → ${b}`); return `${a} → ${b}`; });

  await test('THM-04', 'Printed and downloaded documents keep their previous look: no theme class, their own fonts, the same table headings', async () => {
    const { p } = await open({}, 'invoices');
    await p.click('#lNew'); await p.selectOption('#ed [name=party]', 'c'); await p.fill('#ed .d', 'Works'); await p.fill('#ed .p', '100000'); await p.click('#ed [type=submit]'); await p.waitForTimeout(1200);
    const html = await p.evaluate(() => pageFile('INV', docHTML('invoices', S.invoices[0]))); await p.close();
    const q = await browser.newPage(); await q.setContent(html); await q.waitForTimeout(300);
    const r = await q.evaluate(() => { const g = s => { const e = document.querySelector(s); return e ? getComputedStyle(e) : null; }; const th = g('.doc th'), big = g('.doc .n') || g('.doc .big');
      return { bodyClass: document.body.className, docFont: getComputedStyle(document.querySelector('.doc')).fontFamily, numFont: big && big.fontFamily, thTransform: th && th.textTransform, bg: getComputedStyle(document.body).backgroundColor }; });
    await q.close();
    assert(!/\bqb\b/.test(r.bodyClass), 'printed page carries the theme class'); assert(/Manrope/.test(r.docFont), 'document font changed: ' + r.docFont);
    assert(/JetBrains/.test(r.numFont || ''), 'document number font changed: ' + r.numFont); assert(r.thTransform === 'uppercase', 'table headings changed: ' + r.thTransform);
    assert(r.bg === 'rgb(255, 255, 255)', 'page background ' + r.bg); return `body class "${r.bodyClass}", document font Manrope, numbers JetBrains Mono, headings uppercase`; });

  await test('THM-05', 'Every screen still opens without errors under the theme, and the menu highlights the current screen', async () => {
    const { p, errs } = await open(); const views = await p.evaluate(() => [...document.querySelectorAll('aside a[data-v]')].map(a => a.dataset.v)); const bad = [];
    for (const v of views) { await p.evaluate(v => location.hash = v, v); await p.waitForTimeout(150); const on = await p.evaluate(v => { const a = document.querySelector(`aside a[data-v="${v}"]`); return a.classList.contains('on') && document.querySelector('#v-' + v + '.on, .view.on') !== null; }, v); if (!on) bad.push(v); }
    assert(!bad.length, 'not highlighted: ' + bad.join(', ')); assert(!errs.length, errs[0]); await p.close(); return views.length + ' screens opened, each highlighted, no errors'; });

  await browser.close();
  fs.mkdirSync(path.join(__dirname, '../reports'), { recursive: true }); fs.writeFileSync(path.join(__dirname, '../reports/theme.json'), JSON.stringify({ ranAt: new Date().toISOString(), results }, null, 1));
  const f = results.filter(r => !r.pass).length; console.log(`${results.length - f}/${results.length} passed`); process.exit(f ? 1 : 0);
})();
