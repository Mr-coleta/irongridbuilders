// Phone and tablet suite (Chromium engine with real device sizes, touch input and phone user agents).
// Safari's and Firefox's own engines are NOT available in this environment; see tests/README.md.
// Usage: node tests/mobile/mobile.test.js   (server on :8765 serving srv/)
'use strict';
const { chromium, devices } = require('playwright');
const fs = require('fs');
const path = require('path');
const MOCK = require('../mocksrc.js');
const BASE = 'http://localhost:8765/index.html';
const results = [];
const assert = (c, m) => { if (!c) throw new Error(m); };
async function test(id, name, fn) {
  if (process.env.ONLY && !process.env.ONLY.split(',').includes(id)) return;
  const t0 = Date.now();
  try { const detail = await fn(); results.push({ id, name, pass: true, ms: Date.now() - t0, detail: detail || '' }); }
  catch (e) { results.push({ id, name, pass: false, ms: Date.now() - t0, detail: e.message.split('\n')[0] }); }
  const r = results.at(-1); console.log(`${r.pass ? 'PASS' : 'FAIL'}  ${id}  ${name}${r.detail ? '  — ' + r.detail : ''}`);
}
const SEED = `st.set("settings/business",{name:"Irongrid Builders (synthetic)",currency:"UGX"});st.set("clients/c",{name:"Nansubuga Estates Ltd"});st.set("suppliers/s",{name:"Lake Victoria Cement Supplies Ltd"});st.set("items/cem",{name:"Cement 50kg bag",unit:"bags"});`;
const SCREENS = ['dashboard', 'proformas', 'invoices', 'receipts', 'credits', 'debits', 'refunds', 'clients', 'lpos', 'purchases', 'payments', 'sdebits', 'suppliers', 'stock', 'adjustments', 'accounts', 'settings'];
// Chromium stand-ins for each phone: same screen size, pixel ratio, touch and user agent; the engine is Chromium's.
const PHONES = [['iPhone SE (320 px)', 'iPhone SE'], ['Galaxy S8 (360 px)', 'Galaxy S8'], ['iPhone 13 (390 px)', 'iPhone 13'], ['Pixel 5 (393 px)', 'Pixel 5'], ['iPad Mini (768 px)', 'iPad Mini']];

(async () => {
  const browser = await chromium.launch();
  async function open(dev, landscape) {
    const d = { ...devices[dev] }; delete d.defaultBrowserType; if (landscape) d.viewport = { width: d.viewport.height, height: d.viewport.width };
    const ctx = await browser.newContext(d); const p = await ctx.newPage(); p.__W = d.viewport.width; const errs = []; p.on('pageerror', e => errs.push(e.message));
    await p.addInitScript(`${MOCK};window.__mock({});const st=window.__S;${SEED}`); await p.goto(BASE + '#dashboard'); await p.waitForTimeout(900); return { p, ctx, errs };
  }
  const go = async (p, h) => { await p.evaluate(h => location.hash = h, h); await p.waitForTimeout(150); };
  // compare with the device's real screen width: on a phone the layout viewport (innerWidth) grows to fit wide content, so it can't reveal sideways scrolling
  const pageWidth = async p => ({ sw: await p.evaluate(() => Math.max(document.documentElement.scrollWidth, window.innerWidth)), w: p.__W });
  // tap an element after scrolling it into view; fails if it is hidden under something else
  const tap = async (p, sel) => { const el = p.locator(sel).first(); await el.scrollIntoViewIfNeeded(); await el.tap({ timeout: 5000 }); };

  for (const [label, dev] of PHONES) {
    await test('M-' + dev.replace(/\W+/g, ''), `${label}: no screen scrolls sideways; a stock purchase, sale and receipt can be done by touch; books clean`, async () => {
      const { p, ctx, errs } = await open(dev); const wide = [];
      for (const h of SCREENS) { await go(p, h); const w = await pageWidth(p); if (w.sw > w.w + 1) wide.push(`${h} ${w.sw}/${w.w}`); }
      // purchase 100 bags
      await go(p, 'purchases'); await tap(p, '#lNew'); await p.selectOption('#ed [name=party]', 's'); await p.selectOption('#ed .si', 'cem'); await p.fill('#ed .q', '100'); await p.fill('#ed .p', '33000'); await p.fill('#ed [name=vatRate]', '18');
      const ew = await pageWidth(p); if (ew.sw > ew.w + 1) wide.push(`purchase form ${ew.sw}/${ew.w}`);
      await tap(p, '#ed [type=submit]'); await p.waitForTimeout(1200); await tap(p, '#mBtns >> text=Close');
      // sell 30 bags
      await go(p, 'invoices'); await tap(p, '#lNew'); await p.selectOption('#ed [name=party]', 'c'); await p.selectOption('#ed .si', 'cem'); await p.fill('#ed .q', '30'); await p.fill('#ed .p', '40000'); await p.fill('#ed [name=vatRate]', '18');
      await tap(p, '#ed [type=submit]'); await p.waitForTimeout(1200);
      const dw = await pageWidth(p); if (dw.sw > dw.w + 1) wide.push(`invoice view ${dw.sw}/${dw.w}`);
      // receive part payment from the invoice view
      await tap(p, '#mBtns >> text=Receive payment'); await p.fill('#ed [name=amount]', '500000'); await tap(p, '#ed [type=submit]'); await p.waitForTimeout(1200); await tap(p, '#mBtns >> text=Close');
      const b = await p.evaluate(() => { const L = ledger(); return { problems: L.problems, n: L.J.length, inv: S.invoices.length, rct: S.receipts.length, pur: S.purchases.length, bal: invBal(S.invoices[0]) }; });
      await go(p, 'accounts'); for (const t of ['tb', 'pl', 'bs', 'vat', 'gl', 'chk']) { await tap(p, `#acTabs [data-t=${t}]`); const w = await pageWidth(p); if (w.sw > w.w + 1) wide.push(`accounts:${t} ${w.sw}/${w.w}`); }
      const fs16 = await p.evaluate(() => { const i = document.createElement('input'); document.body.appendChild(i); const f = parseFloat(getComputedStyle(i).fontSize); i.remove(); return f; });
      await ctx.close();
      assert(b.pur === 1 && b.inv === 1 && b.rct === 1, 'documents ' + JSON.stringify(b)); assert(b.problems === 0 && b.n === 3, 'books ' + JSON.stringify(b)); assert(Math.abs(b.bal - (1416000 - 500000)) < 0.01, 'balance ' + b.bal);
      assert(!wide.length, 'page wider than the screen: ' + wide.join(', ')); assert(!errs.length, errs.join('; '));
      if (devices[dev].viewport.width < 768) assert(fs16 >= 16, `form text ${fs16}px (iPhones zoom in on fields under 16 px)`);
      return `17 screens + forms fit ${devices[dev].viewport.width} px; 3 postings by touch; balance 916,000; books clean; field text ${fs16}px`;
    });
  }

  await test('M-figures', 'Phones: every dashboard figure is fully visible (none cut off or hidden behind the screen edge), with amounts in the hundreds of millions', async () => {
    const { build } = require('../scale/books.js'); const big = build(300, 5);
    const bad = [];
    for (const dev of ['iPhone SE', 'iPhone 13', 'Pixel 5']) {
      const d = { ...devices[dev] }; delete d.defaultBrowserType; const ctx = await browser.newContext(d); const p = await ctx.newPage(); const DW = d.viewport.width;
      await p.addInitScript(`${MOCK};window.__mock({});const st=window.__S;for (const [k,v] of ${JSON.stringify([...big.docs.entries()])}) st.set(k,v);`);
      await p.goto(BASE + '#dashboard'); await p.waitForTimeout(1500);
      const r = await p.evaluate(W => [...document.querySelectorAll('#v-dashboard .kpi .val')].map(el => { const b = el.getBoundingClientRect(), c = el.closest('.card').getBoundingClientRect(); return { t: el.textContent, clipped: el.scrollWidth > el.clientWidth + 1, offscreen: c.right > W + 1 || b.right > W + 1 }; }), DW);
      for (const x of r) if (x.clipped || x.offscreen) bad.push(`${dev}: "${x.t}" ${x.clipped ? 'cut off' : 'past the screen edge'}`);
      await ctx.close(); }
    assert(!bad.length, bad.slice(0, 4).join('; ')); return 'all figures fully visible on iPhone SE, iPhone 13 and Pixel 5';
  });

  await test('M-landscape', 'Phone in landscape (Pixel 5 turned sideways): every screen fits', async () => {
    const { p, ctx } = await open('Pixel 5', true); const wide = [];
    for (const h of SCREENS) { await go(p, h); const w = await pageWidth(p); if (w.sw > w.w + 1) wide.push(`${h} ${w.sw}/${w.w}`); }
    await ctx.close(); assert(!wide.length, wide.join(', ')); return 'all screens fit 727 px wide';
  });

  await test('M-tables', 'Wide tables (statement, trial balance) scroll inside their box on a 320 px phone instead of being cut off', async () => {
    const { p, ctx } = await open('iPhone SE'); await go(p, 'accounts'); await tap(p, '#acTabs [data-t=gl]');
    const info = await p.evaluate(() => [...document.querySelectorAll('table')].filter(t => t.offsetParent).map(t => { let e = t.parentElement, scroll = false; while (e && e !== document.body) { const o = getComputedStyle(e).overflowX; if ((o === 'auto' || o === 'scroll') && e.scrollWidth >= t.scrollWidth - 1) { scroll = true; break; } e = e.parentElement; } return { w: t.scrollWidth, fits: t.scrollWidth <= window.innerWidth, scroll }; }));
    await ctx.close(); const cut = info.filter(t => !t.fits && !t.scroll); assert(!cut.length, 'tables cut off: ' + JSON.stringify(cut)); return info.length + ' tables: ' + info.filter(t => t.fits).length + ' fit, ' + info.filter(t => !t.fits).length + ' scroll inside their box';
  });

  await test('M-oldbrowser', 'A browser without exact-number support (old iPhone) gets a clear message instead of a blank page', async () => {
    const ctx = await browser.newContext(devices['iPhone SE']); const p = await ctx.newPage();
    await p.addInitScript(`${MOCK};window.__mock({});delete window.BigInt;`); await p.goto(BASE); await p.waitForTimeout(800);
    const msg = await p.evaluate(() => { const d = document.getElementById('oldBrowser'); return d && d.getBoundingClientRect().height > 100 ? d.innerText : null; });
    const ctx2 = await browser.newContext(devices['iPhone SE']); const q = await ctx2.newPage(); await q.addInitScript(`${MOCK};window.__mock({});`); await q.goto(BASE); await q.waitForTimeout(600);
    const none = await q.evaluate(() => !document.getElementById('oldBrowser')); await ctx.close(); await ctx2.close();
    assert(msg && /too old/.test(msg) && /Nothing has been changed/.test(msg), 'message: ' + msg); assert(none, 'message shown on a modern browser'); return '"' + msg.split('\n')[0] + '"; not shown on modern browsers';
  });

  await browser.close();
  fs.writeFileSync(path.join(__dirname, '../reports/mobile.json'), JSON.stringify({ ranAt: new Date().toISOString(), engine: 'chromium (device emulation)', results }, null, 1));
  const failed = results.filter(r => !r.pass); console.log(`\n${results.length - failed.length}/${results.length} passed`); process.exit(failed.length ? 1 : 0);
})();
