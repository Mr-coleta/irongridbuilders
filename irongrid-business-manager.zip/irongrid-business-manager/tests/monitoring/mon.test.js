// Monitoring suite: safe logs, correlation ids, metrics, every alert rule raised by a real fault and cleared when the
// fault ends, read-only health checks, and proof that monitoring never changes financial records.
// Runs on the fake store with the real access rules. Usage: node tests/monitoring/mon.test.js  (server on :8765)
'use strict';
const { chromium } = require('playwright'); const fs = require('fs'); const path = require('path');
const MOCK = require('../mocksrc.js');
const results = []; const assert = (c, m) => { if (!c) throw new Error(m); };
async function test(id, name, fn) {
  if (process.env.ONLY && !process.env.ONLY.split(',').includes(id)) return;
  const t0 = Date.now();
  try { const detail = await fn(); results.push({ id, name, pass: true, ms: Date.now() - t0, detail: detail || '' }); }
  catch (e) { results.push({ id, name, pass: false, ms: Date.now() - t0, detail: e.message.split('\n')[0] }); }
  const r = results.at(-1); console.log(`${r.pass ? 'PASS' : 'FAIL'}  ${id}  ${name}${r.detail ? '  — ' + r.detail : ''}`);
}
// secrets planted in the data: none of them may appear in any operational log, metric, alert or console line
const SECRETS = ['Nansubuga', '9030123456', '4,560,000', '4560000', 'Hunter2', 'jane.k@example.com', '0703777111'];
const SEED = `st.set("settings/business",{name:"Irongrid (synthetic)",currency:"UGX",phone:"0703777111",email:"jane.k@example.com",payDetails:"Stanbic A/C 9030123456"});st.set("clients/c",{name:"Nansubuga Estates Ltd",phone:"0703777111"});st.set("suppliers/s",{name:"Lake Victoria Cement Ltd"});st.set("items/cem",{name:"Cement 50kg",unit:"bags"});`;
let browser;
async function open(seed = SEED, hash = 'dashboard', opts = {}) {
  const p = await browser.newPage({ viewport: { width: 1300, height: 950 } }); p.setDefaultTimeout(30000); const errs = [], con = [];
  p.on('pageerror', e => errs.push(e.message)); p.on('console', m => con.push(m.text()));
  await p.addInitScript(`${MOCK};window.__mock(${JSON.stringify(opts)});const st=window.__S;${seed}`); await p.goto('http://localhost:8765/index.html#' + hash); await p.waitForTimeout(1200); return { p, errs, con };
}
const DB = p => p.evaluate(() => Object.fromEntries([...window.__S.entries()].map(([k, v]) => [k, JSON.parse(JSON.stringify(v))])));
const nonAudit = db => JSON.stringify(Object.entries(db).filter(([k]) => !k.startsWith('audit/')).sort());
const alerts = p => p.evaluate(() => { monEvaluate(); return [...MON.alerts.values()].map(a => ({ rule: a.rule, sev: a.sev, detail: a.detail })); });
const has = (as, r) => as.find(a => a.rule === r);
async function invoice(p, { qty = '1', price = '4560000', stock = false } = {}) {
  await p.evaluate(() => location.hash = 'invoices'); await p.waitForTimeout(200); await p.click('#lNew'); await p.selectOption('#ed [name=party]', 'c');
  if (stock) await p.selectOption('#ed .si', 'cem'); else await p.fill('#ed .d', 'Site works');
  await p.fill('#ed .q', qty); await p.fill('#ed .p', price); await p.fill('#ed [name=vatRate]', '18'); await p.click('#ed [type=submit]'); await p.waitForTimeout(1500); await p.click('#mBtns >> text=Close').catch(() => {});
}
const leaks = (text) => SECRETS.filter(s => text.includes(s));

(async () => {
  browser = await chromium.launch();

  await test('MON-01', 'Logs, metrics, alerts and the console never contain names, amounts, bank or phone numbers, e-mail addresses or passphrases', async () => {
    const { p, con } = await open();
    await invoice(p); // a real save of UGX 4,560,000 for Nansubuga Estates
    await p.evaluate(() => { // errors whose text carries sensitive values, as real error messages might
      logEvent('error', 'test-error', { message: 'password=Hunter2 for Stanbic A/C 9030123456, mail jane.k@example.com, total 4,560,000', amount: 4560000, name: 'Nansubuga Estates Ltd', payee: 'Nansubuga', phone: '0703777111' });
      setTimeout(() => { throw new Error('Cannot pay Nansubuga 4,560,000 to A/C 9030123456'); }, 0); });
    await p.waitForTimeout(300);
    await p.evaluate(() => window.__goDown()); await p.evaluate(() => put('invoices', 'mon01', { number: 'INV-0091', date: '2026-03-01', clientId: 'c', vatRate: 0, items: [{ desc: 'Nansubuga works', qty: 1, price: 4560000 }] })); await p.evaluate(() => window.__comeBack()); // a save that fails after retries, with its error path logged
    await p.waitForTimeout(500); await p.evaluate(async () => { await heartbeat(); await flushErrors(); await flushMetrics(); });
    await p.evaluate(() => location.hash = 'health'); await p.waitForTimeout(400);
    const db = await DB(p); const ops = JSON.stringify(Object.entries(db).filter(([k]) => /^audit\/[^/]+\/(errors|metrics)\//.test(k)));
    const ev = JSON.stringify(await p.evaluate(() => window.__EV())); const dash = await p.textContent('#monBody'); const consoleLines = con.filter(l => l.includes('[irongrid]')).join('\n');
    const found = { errorLogAndMetrics: leaks(ops), eventLog: leaks(ev), console: leaks(consoleLines), dashboard: leaks(dash) };
    assert(ops.includes('test-error') && ops.includes('metrics'), 'error log or metrics were not written: ' + ops.slice(0, 200));
    assert(Object.values(found).every(x => !x.length), 'leaked: ' + JSON.stringify(found));
    const te = JSON.parse(ev).find(e => e.event === 'test-error'); assert(te.amount === '[redacted]' && te.name === '[redacted]' && /password=\[redacted\]/.test(te.message), 'not redacted: ' + JSON.stringify(te));
    await p.close(); return 'checked ' + SECRETS.length + ' planted values in error log, metrics, event log, console and dashboard: none found'; });

  await test('MON-02', 'One correlation id links the button press, every store call it made, its log lines and its audit-trail entry', async () => {
    const { p } = await open(); await invoice(p, { price: '100000' }); await p.waitForTimeout(2000); await p.evaluate(async () => { await flushAudit(); });
    const r = await p.evaluate(() => { const t = MON.traces.filter(t => t.kind.startsWith('submit') && t.spans.length).at(-1); const db = Object.fromEntries([...window.__S.entries()]);
      const auditDays = Object.entries(db).filter(([k]) => /^audit\/[^/]+\/days\//.test(k)).flatMap(([, v]) => v.events); return { t, audit: auditDays.filter(e => e.cid === (t && t.cid)), all: auditDays.map(e => e.act + ':' + e.cid), traces: MON.traces.map(t => t.kind + ':' + t.cid + ':' + t.spans.length) }; });
    assert(r.t, 'no trace for the submit'); assert(r.t.spans.length >= 2, 'too few spans: ' + r.t.spans.length);
    assert(r.t.spans.some(s => s.path === 'invoices' && s.op === 'set' && s.ok), 'no span for the invoice write: ' + JSON.stringify(r.t.spans));
    assert(r.audit.some(e => e.act === 'create' && /^invoices\//.test(e.ref)), 'audit-trail entry does not carry the trace id ' + r.t.cid + ' audit=' + r.all.join(',') + ' traces=' + r.traces.join(','));
    await p.close(); return `trace ${r.t.cid}: ${r.t.spans.length} store calls (${[...new Set(r.t.spans.map(s => s.op + ' ' + s.path))].join(', ')}), audit entry linked`; });

  await test('MON-03', 'Unusual slowness raises an alert; it is measured against this device\'s usual speed', async () => {
    const { p } = await open();
    for (let i = 0; i < 22; i++) await p.evaluate(() => heartbeat()); // usual speed: sets this session's baseline
    const before = await alerts(p); assert(!has(before, 'latency'), 'latency alert at normal speed');
    await p.evaluate(() => { window.__delay = 2600; }); for (let i = 0; i < 11; i++) await p.evaluate(() => heartbeat());
    const a = await alerts(p); const l = has(a, 'latency'); assert(l, 'no latency alert: ' + JSON.stringify(a));
    await p.evaluate(() => { window.__delay = null; }); await p.close(); return l.sev + ': ' + l.detail; });

  await test('MON-04', 'Failing store calls and failed saves raise a critical error-rate alert and a failed-posting alert; nothing is posted', async () => {
    const { p } = await open(); const before = await DB(p);
    // a real invoice save during an outage: retried with back-off for 20 s, then given up (the fail-safe path)
    await p.evaluate(() => window.__goDown());
    const saved = await p.evaluate(() => put('invoices', 'mon04', { number: 'INV-0090', date: '2026-03-01', clientId: 'c', vatRate: 0, items: [{ desc: 'W', qty: 1, price: 100000 }] }));
    for (let i = 0; i < 20; i++) await p.evaluate(() => heartbeat().catch(() => {}));
    await p.evaluate(() => window.__comeBack()); assert(saved === false, 'the save reported success during the outage');
    const a = await alerts(p); const er = has(a, 'error-rate'), po = has(a, 'posting'); const after = await DB(p);
    assert(er && er.sev === 'critical', 'no critical error-rate alert: ' + JSON.stringify(a)); assert(po, 'no failed-posting alert');
    assert(!Object.keys(after).some(k => k.startsWith('invoices/') && !before[k]), 'an invoice was written during the outage');
    await p.close(); return er.detail + ' | ' + po.detail; });

  await test('MON-05', 'The store unreachable for 2 minutes raises a critical alert, which clears when it answers again', async () => {
    const { p } = await open(); await p.evaluate(() => window.__goDown()); await p.evaluate(async () => { await heartbeat(); await heartbeat(); HEALTH.downSince = Date.now() - 150000; });
    const a = await alerts(p); assert(has(a, 'availability') && has(a, 'availability').sev === 'critical', 'no availability alert: ' + JSON.stringify(a));
    await p.evaluate(() => window.__comeBack()); await p.evaluate(() => heartbeat()); const b = await alerts(p);
    assert(!has(b, 'availability'), 'availability alert did not clear'); const hist = await p.evaluate(() => MON.history.filter(h => h.rule === 'availability').map(h => h.state));
    assert(hist.includes('raised') && hist.includes('cleared'), 'history ' + hist); const badge = await p.evaluate(() => !!document.querySelector('a[data-v=health] .monb'));
    await p.close(); return 'raised then cleared; ' + (badge ? 'menu badge was shown while active' : 'no badge now'); });

  await test('MON-06', 'Repeated crashes (3 unexpected errors in 10 minutes) raise a critical alert', async () => {
    const { p } = await open(); await p.evaluate(() => { for (let i = 0; i < 3; i++) setTimeout(() => { throw new Error('boom ' + i); }, i * 10); }); await p.waitForTimeout(300);
    const a = await alerts(p); assert(has(a, 'crashes'), 'no crash alert: ' + JSON.stringify(a)); await p.close(); return has(a, 'crashes').detail; });

  await test('MON-07', 'A books-integrity violation raises a critical alert, and the alert changes nothing in the records', async () => {
    const tampered = SEED + `st.set("invoices/x1",{number:"INV-0001",date:"2026-03-01",clientId:"c",vatRate:0,items:[{desc:"W",qty:1,price:100000}],je:{v:1,pid:"invoices/x1",date:"2026-03-01",cur:"UGX",dp:0,at:"2026-03-01T00:00:00Z",h:"00000000",lines:[{a:"1100",d:100000,c:0,p:"c"},{a:"4000",d:0,c:90000}]}});`;
    const { p } = await open(tampered); const before = await DB(p); await p.waitForTimeout(500); const a = await alerts(p);
    for (let i = 0; i < 5; i++) await p.evaluate(() => monEvaluate()); await p.evaluate(() => { location.hash = 'health'; }); await p.waitForTimeout(400); const after = await DB(p);
    assert(has(a, 'integrity') && has(a, 'integrity').sev === 'critical', 'no integrity alert: ' + JSON.stringify(a)); assert(nonAudit(before) === nonAudit(after), 'records changed after the alert');
    await p.close(); return has(a, 'integrity').detail.slice(0, 80); });

  await test('MON-08', 'A posting refused by the books (selling stock not on hand) raises a failed-posting alert; nothing is posted', async () => {
    const { p } = await open(); const before = await DB(p); await invoice(p, { stock: true, qty: '5', price: '40000' });
    const a = await alerts(p); for (let i = 0; i < 5; i++) await p.evaluate(() => monEvaluate()); const after = await DB(p); const po = has(a, 'posting');
    const fin = db => JSON.stringify(Object.entries(db).filter(([k]) => /^(invoices|receipts|payments|purchases|credits|debits|refunds|sdebits|adjustments|items|clients)\//.test(k)).sort());
    assert(po, 'no failed-posting alert: ' + JSON.stringify(a)); assert(fin(before) === fin(after), 'financial records changed');
    const ev = await p.evaluate(() => window.__EV().filter(e => e.event === 'posting-not-made')); assert(ev.length && ev[0].coll === 'invoices' && ev[0].cid, 'event missing or without trace id');
    await p.close(); return po.detail; });

  await test('MON-09', 'Background jobs that keep failing (audit-trail writes during an outage) raise an alert', async () => {
    const { p } = await open(); await p.evaluate(() => window.__goDown());
    await p.evaluate(async () => { for (let i = 0; i < 3; i++) { audit('test', 'x/y', {}); await flushAudit(); } }); const a = await alerts(p); await p.evaluate(() => window.__comeBack());
    assert(has(a, 'jobs'), 'no background-job alert: ' + JSON.stringify(a)); await p.evaluate(() => flushAudit()); await p.waitForTimeout(300);
    const cleared = await p.evaluate(() => MON.jobs.auditFail); await p.close(); return has(a, 'jobs').detail + ' (after recovery: ' + cleared + ' failures in a row)'; });

  await test('MON-10', 'Health checks only read: the heartbeat and the full health check write nothing at all', async () => {
    const { p } = await open(); await p.waitForTimeout(500); const before = JSON.stringify(Object.entries(await DB(p)).sort());
    const r = await p.evaluate(async () => { const w0 = window.__writes; await heartbeat(); await heartbeat(); const out = await deepCheck(); return { out, w: window.__writes - w0 }; });
    const after = JSON.stringify(Object.entries(await DB(p)).sort()); assert(before === after, 'the store changed during health checks'); assert(r.out.every(x => x.ok), 'a check failed: ' + JSON.stringify(r.out));
    await p.close(); return r.out.length + ' checks passed; store unchanged'; });

  await test('MON-11', 'Metrics are saved to the person\'s own log once a month record, and added up exactly across saves', async () => {
    const { p } = await open(); for (let i = 0; i < 4; i++) await p.evaluate(() => heartbeat()); await p.evaluate(() => flushMetrics());
    for (let i = 0; i < 3; i++) await p.evaluate(() => heartbeat()); await p.evaluate(() => flushMetrics());
    const r = await p.evaluate(() => { const db = Object.fromEntries([...window.__S.entries()]); const k = Object.keys(db).filter(x => /^audit\/[^/]+\/metrics\//.test(x)); const d = k.length ? db[k[0]].days[new Date().toISOString().slice(0, 10)] : null;
      return { keys: k, hb: d && d.hb.n, lat: d && d.calls['health-read'] && d.calls['health-read'].n, total: MON.hb.length }; });
    assert(r.keys.length === 1 && /^audit\/u1\/metrics\/\d{4}-\d{2}$/.test(r.keys[0]), 'metrics record: ' + r.keys); assert(r.hb === r.total, `saved ${r.hb} health checks, made ${r.total}`);
    await p.close(); return `${r.keys[0]}: ${r.hb} health checks saved for ${r.total} made`; });

  await test('MON-12', 'A Contributor\'s monitoring data goes only to their own log, and they cannot read anyone else\'s', async () => {
    const { p } = await open(SEED, 'dashboard', { level: 'interact', uid: 'u2' }); await p.evaluate(() => heartbeat()); await p.evaluate(() => flushMetrics());
    const r = await p.evaluate(async () => { const db = Object.fromEntries([...window.__S.entries()]); let other = 'refused'; try { await window.claude.use('db').doc('audit/u1/metrics/2026-11').get(); other = 'read'; } catch (e) { other = 'refused'; }
      return { mine: Object.keys(db).filter(k => k.startsWith('audit/u2/metrics/')).length, other }; });
    assert(r.mine === 1, 'contributor metrics not saved under their own id'); assert(r.other === 'refused', "a contributor could read another person's metrics");
    await p.close(); return 'own record written; reading the owner\'s was refused'; });

  await test('MON-13', 'With 24,990 records the storage alert is critical and the dashboard shows every section', async () => {
    const scale = `{const x=new XMLHttpRequest();x.open("GET","/scale.json",false);x.send();for(const [k,v] of JSON.parse(x.responseText))st.set(k,v)}`;
    if (!fs.existsSync(path.join(__dirname, '../../srv/scale.json'))) { const { build } = require('../scale/books.js'); fs.writeFileSync(path.join(__dirname, '../../srv/scale.json'), JSON.stringify([...build(24990).docs.entries()])); }
    const { p, errs } = await open(scale, 'health'); await p.waitForFunction(() => window.S && S.invoices && S.invoices.length > 1000, null, { timeout: 60000 }); await p.waitForTimeout(3000);
    const a = await alerts(p); await p.evaluate(() => renderMonitoring()); const t = await p.textContent('#monBody');
    assert(has(a, 'capacity') && has(a, 'capacity').sev === 'critical', 'no capacity alert: ' + JSON.stringify(a));
    for (const s of ['Alerts', 'Service level', 'Store calls by kind', 'This device', 'Storage and background jobs', 'Recent actions', 'Team']) assert(t.includes(s), 'missing section ' + s);
    await p.click('#monTeamLoad'); await p.waitForTimeout(800); assert(!errs.length, errs[0]); await p.close(); return has(a, 'capacity').detail; });

  await test('MON-14', 'During a restore, or once storage is full, logs create no new records; they wait and are written afterwards', async () => {
    const { p } = await open(); const r = await p.evaluate(async () => { const keys = () => [...window.__S.keys()].filter(k => /^audit\/u1\/(errors|metrics)\//.test(k));
      MON.hold = Date.now(); logEvent('warn', 'test-during-restore', {}); heartbeat(); await flushErrors(); await flushMetrics(); const during = keys().length;
      MON.hold = 0; await flushErrors(); await flushMetrics(); const after = keys().length;
      for (const k of keys()) window.__S.delete(k); MON.fullAt = Date.now(); logEvent('warn', 'test-when-full', {}); await flushErrors(); const full = keys().length; MON.fullAt = 0;
      return { during, after, full, waiting: __errq() }; });
    assert(r.during === 0, r.during + ' log records created during the restore'); assert(r.after === 2, 'logs not written after the restore: ' + r.after);
    assert(r.full === 0 && r.waiting >= 1, 'a log record was created with storage full'); await p.close(); return `during restore 0 new records, after ${r.after}; storage full: 0 new, ${r.waiting} waiting`; });

  await browser.close();
  fs.mkdirSync(path.join(__dirname, '../reports'), { recursive: true }); fs.writeFileSync(path.join(__dirname, '../reports/monitoring.json'), JSON.stringify({ ranAt: new Date().toISOString(), results }, null, 1));
  const f = results.filter(r => !r.pass).length; console.log(`${results.length - f}/${results.length} passed`); process.exit(f ? 1 : 0);
})();
