// Automated regression suite for the Business Manager app.
// Each test names the defect it guards (A-xx = audit finding, H-xx = earlier hardening fix).
// Runs against a fake platform database (tests/mock.js) that imitates leases, slow calls and failures.
// Usage: node tests/regression.js   (needs the app copied to srv/index.html and `python3 -m http.server 8765` in srv/)
const { chromium } = require('playwright');
const fs = require('fs');
const MOCK = require('./mocksrc.js');
const BASE = 'http://localhost:8765/';
let browser;
const results = [];
const assert = (cond, msg) => { if (!cond) throw new Error(msg); };
const wait = ms => new Promise(r => setTimeout(r, ms));

async function single(opts = {}, seed = '', hash = '') {
  const p = await browser.newPage({ viewport: { width: 1300, height: 950 } });
  const errs = []; p.on('pageerror', e => errs.push(e.message));
  await p.addInitScript(`${MOCK};window.__mock(${JSON.stringify(opts)});const st=window.__S;${seed}`);
  await p.goto(BASE + 'index.html' + (hash ? '#' + hash : '')); await p.waitForTimeout(900);
  return { p, errs };
}
async function two(delay = 120) {
  const p = await browser.newPage({ viewport: { width: 2400, height: 950 } });
  const errs = []; p.on('pageerror', e => errs.push(e.message));
  await p.addInitScript(`${MOCK};if(window!==window.top)window.__mock({delay:${delay}});`);
  await p.goto(BASE + 'two.html'); await p.waitForTimeout(1500);
  const [fa, fb] = p.frames().filter(f => f.url().includes('index'));
  return { p, fa, fb, errs };
}
const docs = (p, prefix) => p.evaluate(pre => [...window.top.__S.entries()].filter(([k]) => k.startsWith(pre)).map(([k, v]) => ({ id: k, ...v })), prefix);
async function newInvoice(f, client, price, vat) {
  await f.evaluate(() => location.hash = 'invoices'); await f.waitForTimeout(200); await f.click('#lNew');
  await f.selectOption('#ed [name=party]', '__new'); await f.fill('#ed [name=np_name]', client);
  await f.fill('#ed .d', 'Work'); await f.fill('#ed .p', String(price)); if (vat != null) await f.fill('#ed [name=vatRate]', String(vat));
  await f.click('#ed [type=submit]'); await f.waitForTimeout(900);
}
async function toastSeen(f, ms = 4000) { const seen = []; for (let i = 0; i < ms / 200; i++) { const t = await f.textContent('#toast'); if (t && !seen.includes(t)) seen.push(t); await f.waitForTimeout(200); } return seen; }

/* ---- browser coverage: per-character executed map of the app script, OR-ed across every page ---- */
let COVSRC = null, COVMAP = null; const COVFN = new Map();
function mergeCoverage(entries) {
  for (const e of entries) { if (!/index\.html/.test(e.url) || !e.source || e.source.length < 50000) continue;
    if (!COVSRC) { COVSRC = e.source; COVMAP = new Uint8Array(e.source.length); } if (e.source !== COVSRC) continue;
    const ranges = []; for (const f of e.functions) { for (const r of f.ranges) ranges.push(r); const k = f.ranges[0].startOffset; const was = COVFN.get(k) || { name: f.functionName, hit: false, end: f.ranges[0].endOffset }; was.hit = was.hit || f.ranges[0].count > 0; COVFN.set(k, was); }
    ranges.sort((a, b) => a.startOffset - b.startOffset || b.endOffset - a.endOffset); const local = new Uint8Array(COVSRC.length);
    for (const r of ranges) local.fill(r.count > 0 ? 1 : 0, r.startOffset, r.endOffset); for (let i = 0; i < local.length; i++) if (local[i]) COVMAP[i] = 1; }
}
function writeBrowserCoverage() {
  if (!COVSRC) return null; const region = (a, b) => { const s = COVSRC.indexOf(a), t = COVSRC.indexOf(b, s + 1); return [s + a.length, t]; };
  const measure = ([s, t]) => { let all = 0, hit = 0; for (let i = s; i < t; i++) { if (/\s/.test(COVSRC[i])) continue; all++; if (COVMAP[i]) hit++; }
    let fa = 0, fh = 0; const missed = []; for (const [k, f] of COVFN) if (k >= s && k < t) { fa++; if (f.hit) fh++; else missed.push(f.name || ('anonymous@' + k)); }
    return { codeChars: all, executedPct: +(100 * hit / all).toFixed(1), functions: fa, functionsPct: +(100 * fh / fa).toFixed(1), functionsNeverRun: missed }; };
  const out = { measuredAt: new Date().toISOString(), engineInPage: measure(region('/*<ledger>*/', '/*</ledger>*/')), postingLayer_accountsJs: measure(region('/*<accounts>*/', '/*</accounts>*/')), wholeApp: measure([0, COVSRC.length]) };
  fs.mkdirSync(__dirname + '/reports', { recursive: true }); fs.writeFileSync(__dirname + '/reports/browser-coverage.json', JSON.stringify(out, null, 1)); return out;
}
async function test(id, name, fn) {
  if (process.env.ONLY && !process.env.ONLY.split(',').includes(id)) return;
  const t0 = Date.now();
  try { const detail = await fn(); results.push({ id, name, pass: true, ms: Date.now() - t0, detail: detail || '' }); }
  catch (e) { results.push({ id, name, pass: false, ms: Date.now() - t0, detail: e.message.split('\n')[0] }); }
  const r = results.at(-1); console.log(`${r.pass ? 'PASS' : 'FAIL'}  ${id}  ${name}${r.detail ? '  — ' + r.detail : ''}`);
}

(async () => {
  browser = await chromium.launch();
  /* COVERAGE=1: collect V8 block coverage of the app's script in every page and merge it (see writeBrowserCoverage). */
  if (process.env.COVERAGE) { const orig = browser.newPage.bind(browser); browser.newPage = async (...a) => { const p = await orig(...a); await p.coverage.startJSCoverage({ resetOnNavigation: false });
      const close = p.close.bind(p); p.close = async (...b) => { try { mergeCoverage(await p.coverage.stopJSCoverage()); } catch (e) {} return close(...b); }; return p; }; }

  await test('H-01', 'Damaged or hostile records cannot crash the page or inject HTML', async () => {
    const { p, errs } = await single({}, `st.set("settings/business",{name:"   ",currency:"XXX"});
      st.set("invoices/a",{number:123,date:"<img src=x onerror=window.__pwned=1>",clientId:"nope",items:"garbage",vatRate:"18"});
      st.set("invoices/b",{number:"INV-0002",date:"2026-10-01",clientId:"c1",items:[null,{desc:"<script>window.__pwned=1</script>",qty:"2",price:"1000"},5],status:{a:1}});
      st.set("clients/c1",{name:12345});st.set("lpos/l",{status:"<b>x</b>",items:[{desc:"y",qty:1,price:9e17}]});st.set("payments/p",{});`);
    for (const h of ['invoices', 'clients', 'lpos', 'payments', 'dashboard']) { await p.evaluate(h => location.hash = h, h); await p.waitForTimeout(80); }
    await p.evaluate(() => location.hash = 'invoices'); await p.waitForTimeout(100);
    for (const id of ['a', 'b']) { await p.click(`#lRows tr[data-id=${id}]`); await p.waitForTimeout(60); await p.click('#mBtns >> text=Close'); }
    const pwned = await p.evaluate(() => !!window.__pwned || !!document.querySelector('img[src=x]'));
    assert(!pwned, 'injected markup executed'); assert(!errs.length, 'page errors: ' + errs.join('; '));
    assert((await p.textContent('#logo')) === 'B', 'blank business name broke the header');
    await p.close(); return 'no errors, nothing executed';
  });

  await test('H-02', 'VAT is rounded to whole shillings; paying the shown total marks it Paid', async () => {
    const { p } = await single();
    await newInvoice(p, 'VAT Co', 1003, 18);
    const total = await p.textContent('#mBody .totals');
    assert(total.includes('1,184'), 'total not 1,184: ' + total);
    await p.click('#mBtns >> text=Receive payment'); await p.fill('#ed [name=amount]', '1184'); await p.click('#ed [type=submit]'); await p.waitForTimeout(1200);
    await p.click('#mBtns >> text=Close'); await p.evaluate(() => location.hash = 'invoices'); await p.waitForTimeout(200);
    const status = await p.textContent('#lRows tr[data-id] td:last-child');
    assert(status === 'Paid', 'status is ' + status); await p.close(); return 'UGX 1,184 → Paid';
  });

  await test('H-03', 'Copy text on a receipt gives the full receipt', async () => {
    const ctx = await browser.newContext({ permissions: ['clipboard-read', 'clipboard-write'] });
    const p = await ctx.newPage(); await p.addInitScript(`${MOCK};window.__mock({});`); await p.goto(BASE + 'index.html'); await p.waitForTimeout(900);
    await newInvoice(p, 'Copy Co', 5000);
    await p.click('#mBtns >> text=Receive payment'); await p.fill('#ed [name=amount]', '2000'); await p.click('#ed [type=submit]'); await p.waitForTimeout(1200);
    await p.click('#mBtns >> text=Copy text'); await p.waitForTimeout(200);
    const t = await p.evaluate(() => navigator.clipboard.readText());
    assert(/Amount: UGX 2,000/.test(t) && /Received from: Copy Co/.test(t) && /Two thousand/.test(t), 'text: ' + t);
    await ctx.close(); return 'amount, client and words present';
  });

  await test('H-04', 'Invoice terms of 0 days give a due date equal to the invoice date', async () => {
    const { p } = await single({}, `st.set("settings/business",{currency:"UGX",termsDays:0});`);
    await p.evaluate(() => location.hash = 'invoices'); await p.waitForTimeout(150); await p.click('#lNew');
    const [d, due] = [await p.inputValue('#ed [name=date]'), await p.inputValue('#ed [name=dueDate]')];
    assert(d === due, `date ${d} due ${due}`); await p.close(); return 'due = ' + due;
  });

  await test('H-05', 'Unsaved edits on Business details survive a live update', async () => {
    const { p } = await single({}, '', 'settings');
    await p.fill('#fSettings [name=name]', 'Typing in progress'); await p.click('#v-settings h1');
    await p.evaluate(() => { window.__S.set('clients/x', { name: 'Someone else' }); for (const l of window.__L) l.fire(); }); await p.waitForTimeout(400);
    const v = await p.inputValue('#fSettings [name=name]'); assert(v === 'Typing in progress', 'form was reset to: ' + v);
    await p.close(); return 'kept';
  });

  await test('H-06', 'Two users saving at the same instant get different numbers', async () => {
    const { p, fa, fb } = await two();
    for (const f of [fa, fb]) { await f.evaluate(() => location.hash = 'invoices'); await f.waitForTimeout(200); await f.click('#lNew'); await f.selectOption('#ed [name=party]', '__new'); await f.fill('#ed [name=np_name]', 'C' + Math.random()); await f.fill('#ed .d', 'W'); await f.fill('#ed .p', '100'); }
    await Promise.all([fa.click('#ed [type=submit]'), fb.click('#ed [type=submit]')]); await p.waitForTimeout(4000);
    const nums = (await docs(p, 'invoices/')).map(d => d.number).sort();
    assert(nums.length === 2 && nums[0] !== nums[1], 'numbers: ' + nums); await p.close(); return nums.join(', ');
  });

  await test('H-07', 'Double-clicking Save stores one record', async () => {
    const { p } = await single({ delay: 150 });
    await p.evaluate(() => location.hash = 'clients'); await p.waitForTimeout(150); await p.click('#lNew'); await p.fill('#ed [name=name]', 'Once Ltd');
    await p.evaluate(() => { const b = document.querySelector('#ed [type=submit]'); b.click(); b.click(); document.querySelector('#ed').requestSubmit(); }); await p.waitForTimeout(1200);
    const n = (await docs(p, 'clients/')).filter(d => d.name === 'Once Ltd').length; assert(n === 1, n + ' records'); await p.close(); return '1 record';
  });

  await test('H-08', 'CSV export neutralises spreadsheet formulas', async () => {
    const { p } = await single({}, `st.set("clients/c",{name:"=HYPERLINK(\\"http://evil\\")"});`, 'clients');
    await p.click('#lCsv'); await p.waitForTimeout(300);
    const csv = (await p.evaluate(() => window.__lastDownload)).data;
    assert(csv.includes(`"'=HYPERLINK`), 'csv: ' + csv.split('\n')[1]); await p.close(); return 'prefixed with apostrophe';
  });

  await test('H-09', 'A dropped live connection reconnects by itself', async () => {
    const { p } = await single({ errorColl: 'invoices' }, `st.set("invoices/z",{number:"INV-0009",date:"2026-11-01",items:[{desc:"a",qty:1,price:1}]});`, 'invoices');
    const during = await p.textContent('#banner'); const t0 = Date.now();
    await p.waitForFunction(() => document.querySelectorAll('#lRows tr[data-id]').length === 1, { timeout: 10000 }).catch(() => {});   // back-off is 4–5 s by design
    const rows = await p.$$eval('#lRows tr[data-id]', r => r.length);
    assert(/reconnecting/i.test(during), 'no reconnect notice'); assert(rows === 1, 'rows ' + rows); await p.close(); return 'recovered';
  });

  await test('H-10', 'A converted proforma cannot be deleted; an open one can (issued invoices are never deletable — see L-01)', async () => {
    const { p } = await single({}, `st.set("clients/c",{name:"K"});st.set("proformas/f",{number:"PRO-0001",date:"2026-11-01",clientId:"c",status:"received",invoiceId:"i",items:[{desc:"x",qty:1,price:10}]});
      st.set("invoices/i",{number:"INV-0001",date:"2026-11-01",clientId:"c",proformaId:"f",items:[{desc:"x",qty:1,price:10}]});st.set("proformas/g",{number:"PRO-0002",date:"2026-11-01",clientId:"c",status:"open",items:[{desc:"y",qty:1,price:10}]});`, 'proformas');
    await p.click('#lRows tr[data-id=f]'); const a = await p.$$eval('#mBtns button', b => b.map(x => x.textContent)); assert(!a.includes('Delete'), 'delete offered on converted proforma');
    await p.click('#mBtns >> text=Close'); await p.click('#lRows tr[data-id=g]'); await p.click('#mBtns >> text=Delete'); await p.click('#mYes'); await p.waitForTimeout(800);
    const pf = await docs(p, 'proformas/'); assert(pf.length === 1 && pf[0].id === 'proformas/f', 'proformas ' + pf.map(x => x.id)); await p.close(); return 'converted kept; open deleted';
  });

  await test('H-11', 'An LPO cannot be converted twice', async () => {
    const { p, fa, fb } = await two();
    await fa.evaluate(() => location.hash = 'lpos'); await fa.waitForTimeout(200); await fa.click('#lNew'); await fa.selectOption('#ed [name=party]', '__new'); await fa.fill('#ed [name=np_name]', 'Sup'); await fa.fill('#ed .d', 'Bars'); await fa.fill('#ed .p', '100'); await fa.click('#ed [type=submit]'); await p.waitForTimeout(1500); await fa.click('#mBtns >> text=Close');
    for (const f of [fa, fb]) { await f.evaluate(() => location.hash = 'lpos'); await f.waitForTimeout(300); await f.click('#lRows tr[data-id]'); await f.click('#mBtns >> text=Convert to purchase'); }
    await fa.click('#ed [type=submit]'); await p.waitForTimeout(2000); await fb.click('#ed [type=submit]'); await p.waitForTimeout(1500);
    const n = (await docs(p, 'purchases/')).length; assert(n === 1, n + ' purchases'); await p.close(); return '1 purchase';
  });

  await test('H-12', 'Read-only users get no add buttons and cannot edit settings', async () => {
    const { p } = await single({ readOnly: true });
    assert(!(await p.isVisible('[data-new=invoices]')), 'add button visible'); assert(await p.isDisabled('#fSettings [name=name]'), 'settings editable');
    await p.close(); return 'locked';
  });

  await test('H-13', 'Crediting more than is still owed (up to the invoice total) puts the client in credit; above the total is refused', async () => {
    const { p } = await single({}, `st.set("clients/c",{name:"K"});st.set("invoices/j",{number:"INV-0002",date:"2026-11-01",clientId:"c",items:[{desc:"y",qty:1,price:1000}]});
      st.set("receipts/r",{number:"RCT-0001",date:"2026-11-01",clientId:"c",invoiceId:"j",amount:800,method:"Cash"});`, 'invoices');
    await p.click('#lRows tr[data-id=j]'); await p.click('#mBtns >> text=Credit note'); await p.fill('#cn [name=reason]', 'r'); await p.fill('#cn .p', '1001'); await p.click('#cn [type=submit]');
    const seen = await toastSeen(p, 1200); assert(seen.some(t => /can still be credited/.test(t)) && !(await docs(p, 'credits/')).length, 'over-total credit saved');
    await p.fill('#cn .p', '300'); await p.click('#cn [type=submit]'); await p.waitForTimeout(1200);
    const bal = await p.evaluate(() => [invBal(byId('invoices', 'j')), clientTotals('c').bal]); assert(bal[0] === -100 && bal[1] === -100, 'balances ' + bal); await p.close(); return '1,001 refused; 300 accepted → client in credit 100 (refundable)';
  });
  await test('A-05', 'Two users cannot both pay the same balance', async () => {
    const { p, fa, fb } = await two();
    await newInvoice(fa, 'Race Co', 1000000); await fa.click('#mBtns >> text=Close');
    for (const f of [fa, fb]) { await f.evaluate(() => location.hash = 'invoices'); await f.waitForTimeout(300); await f.click('#lRows tr[data-id]'); await f.click('#mBtns >> text=Receive payment'); await f.fill('#ed [name=amount]', '1000000'); }
    await Promise.all([fa.click('#ed [type=submit]'), fb.click('#ed [type=submit]')]); await p.waitForTimeout(5000);
    const rec = await docs(p, 'receipts/'); assert(rec.length === 1, rec.length + ' receipts saved'); await p.close(); return '1 of 2 accepted';
  });

  await test('A-06', 'Retrying after an unconfirmed (timed-out) save does not duplicate', async () => {
    const { p } = await single({ delay: 50 }, '', 'clients');
    await p.click('#lNew'); await p.fill('#ed [name=name]', 'Slow Ltd'); await p.evaluate(() => window.__hang = 1); await p.click('#ed [type=submit]');
    await p.waitForTimeout(21000); await p.evaluate(() => window.__hang = 0); await p.click('#ed [type=submit]'); await p.waitForTimeout(800);
    const n = (await docs(p, 'clients/')).filter(d => d.name === 'Slow Ltd').length; assert(n === 1, n + ' records'); await p.close(); return '1 record';
  });

  await test('A-07', 'A stalled database call times out and frees the Save button', async () => {
    const { p } = await single({ delay: 50 }, '', 'clients');
    await p.click('#lNew'); await p.fill('#ed [name=name]', 'Stall Ltd'); await p.evaluate(() => window.__hang = 1); await p.click('#ed [type=submit]');
    await p.waitForTimeout(21000); const disabled = await p.isDisabled('#ed [type=submit]'); const msg = await p.textContent('#toast');
    assert(!disabled, 'button still disabled'); assert(/too slow/.test(msg), 'message: ' + msg); await p.evaluate(() => window.__hang = 0); await p.close(); return 'freed after 20 s';
  });

  await test('A-08', 'A second editor cannot silently overwrite the first', async () => {
    const { p, fa, fb } = await two();
    await fa.evaluate(() => location.hash = 'clients'); await fa.waitForTimeout(300); await fa.click('#lNew'); await fa.fill('#ed [name=name]', 'Conflict Ltd'); await fa.click('#ed [type=submit]'); await p.waitForTimeout(1200); await fa.click('#mBtns >> text=Close');
    for (const f of [fa, fb]) { await f.evaluate(() => location.hash = 'clients'); await f.waitForTimeout(300); await f.click('#lRows tr[data-id]'); await f.click('#mBtns >> text=Edit'); }
    await fa.fill('#ed [name=phone]', '0700111111'); await fa.click('#ed [type=submit]'); await p.waitForTimeout(1200);
    await fb.fill('#ed [name=email]', 'b@x.com'); await fb.click('#ed [type=submit]'); const seen = await toastSeen(fb, 1000);
    const c = (await docs(p, 'clients/'))[0]; assert(c.phone === '0700111111' && c.email === '', 'stored ' + JSON.stringify(c));
    assert(seen.some(t => /changed this client/.test(t)), 'no warning'); await p.close(); return 'warned, first edit kept';
  });

  await test('A-09', 'Full backup, wipe, restore brings back every record and balance', async () => {
    const { p } = await single({}, `st.set("clients/c1",{name:"Keep Me"});st.set("invoices/i1",{number:"INV-0001",date:"2026-11-01",clientId:"c1",items:[{desc:"x",qty:1,price:500}]});
      st.set("receipts/r1",{number:"RCT-0001",date:"2026-11-01",clientId:"c1",invoiceId:"i1",amount:200,method:"Cash"});`, 'settings');
    await p.click('#bkDown'); await p.waitForTimeout(500); const dl = await p.evaluate(() => window.__lastDownload);
    await p.evaluate(() => { for (const k of [...window.__S.keys()]) if (!k.startsWith('settings')) window.__S.delete(k); for (const l of window.__L) l.fire(); }); await p.waitForTimeout(500);
    fs.writeFileSync('/tmp/bk.json', dl.data); await p.setInputFiles('#bkFile', '/tmp/bk.json'); await p.waitForTimeout(300); await p.click('#rsGo'); await p.waitForTimeout(2500);
    await p.evaluate(() => location.hash = 'invoices'); await p.waitForTimeout(300);
    const bal = await p.textContent('#lRows tr[data-id] td:nth-child(7)'); assert(bal === '300', 'balance ' + bal); await p.close(); return '3 records, balance 300';
  });

  await test('A-10', 'Currency is locked once documents exist', async () => {
    const { p } = await single({}, `st.set("invoices/i",{number:"INV-0001",date:"2026-11-01",items:[{desc:"x",qty:1,price:1}]});`, 'settings');
    assert(await p.isDisabled('#fSettings [name=currency]'), 'currency still editable'); await p.close(); return 'locked';
  });

  await test('A-11', 'Quick "Save & receive payment" lets the user choose the method', async () => {
    const { p } = await single({}, '', 'invoices');
    await p.click('#lNew'); await p.selectOption('#ed [name=party]', '__new'); await p.fill('#ed [name=np_name]', 'Quick'); await p.fill('#ed .d', 'x'); await p.fill('#ed .p', '700');
    await p.click('#edPaid'); await p.waitForTimeout(1200);
    assert((await p.textContent('#mTitle')).startsWith('New receipt'), 'receipt editor not opened');
    await p.selectOption('#ed [name=method]', 'MTN Mobile Money'); await p.click('#ed [type=submit]'); await p.waitForTimeout(1200);
    const r = (await docs(p, 'receipts/'))[0]; assert(r && r.method === 'MTN Mobile Money' && r.amount === 700, 'receipt ' + JSON.stringify(r)); await p.close(); return 'MTN Mobile Money recorded';
  });

  await test('A-12', 'A receipt cannot be dated before its invoice', async () => {
    const { p } = await single({}, `st.set("clients/c",{name:"K"});st.set("invoices/j",{number:"INV-0002",date:"2026-11-01",clientId:"c",items:[{desc:"y",qty:1,price:1000}]});`, 'invoices');
    await p.click('#lRows tr[data-id=j]'); await p.click('#mBtns >> text=Receive payment'); await p.fill('#ed [name=date]', '2026-10-01'); await p.click('#ed [type=submit]');
    const seen = await toastSeen(p, 1000); assert(!(await docs(p, 'receipts/')).length, 'receipt saved'); assert(seen.some(t => /can't be before/.test(t)), 'no message'); await p.close(); return 'refused';
  });

  await test('A-13', 'Adding is paused when some records failed to load', async () => {
    const { p } = await single({ fatalColl: 'receipts' });
    await p.click('[data-new=invoices]'); await p.waitForTimeout(200);
    assert(!(await p.isVisible('#ed')), 'editor opened'); assert(/paused/.test(await p.textContent('#banner')), 'no banner'); await p.close(); return 'paused';
  });

  await test('A-20', 'If the number counter is unreachable, nothing is saved (no guessed number)', async () => {
    const { p } = await single({ noLease: true }, `st.set("clients/c",{name:"K"});`, 'invoices');
    await p.click('#lNew'); await p.selectOption('#ed [name=party]', { label: 'K' }); await p.fill('#ed .d', 'x'); await p.fill('#ed .p', '10'); await p.click('#ed [type=submit]');
    const seen = await toastSeen(p, 1500); assert(!(await docs(p, 'invoices/')).length, 'invoice saved'); assert(seen.some(t => /next document number/.test(t)), 'no message: ' + seen); await p.close(); return 'refused with message';
  });

  await test('A-20b', 'Duplicate document numbers are flagged in the list', async () => {
    const { p } = await single({}, `st.set("invoices/a",{number:"INV-0005",date:"2026-11-01",items:[{desc:"x",qty:1,price:1}]});st.set("invoices/b",{number:"INV-0005",date:"2026-11-02",items:[{desc:"x",qty:1,price:1}]});`, 'invoices');
    const w = await p.textContent('#dupWarn').catch(() => ''); assert(/INV-0005/.test(w), 'no warning'); await p.close(); return 'flagged';
  });

  // ---------- Second independent review (R-xx) ----------
  await test('R-01', 'Slow network (1.6 s per call): two receipts still cannot overpay one invoice', async () => {
    const { p, fa, fb } = await two(1600);
    await p.evaluate(() => { window.__S.set('clients/c', { name: 'Slow Co' }); window.__S.set('invoices/i', { number: 'INV-0001', date: '2026-11-01', clientId: 'c', items: [{ desc: 'x', qty: 1, price: 1000 }] }); for (const l of window.__L) l.fire(); });
    await p.waitForTimeout(4000);
    for (const f of [fa, fb]) { await f.evaluate(() => location.hash = 'invoices'); await f.waitForTimeout(400); await f.click('#lRows tr[data-id=i]'); await f.click('#mBtns >> text=Receive payment'); await f.fill('#ed [name=amount]', '1000'); }
    await Promise.all([fa.click('#ed [type=submit]'), fb.click('#ed [type=submit]')]); await p.waitForTimeout(45000);
    const rec = await docs(p, 'receipts/'); assert(rec.length === 1, rec.length + ' receipts saved'); await p.close(); return '1 of 2 accepted at 1.6 s/call';
  });

  await test('R-02', 'Two users converting the same proforma at once produce one invoice', async () => {
    const { p, fa, fb } = await two(300);
    await p.evaluate(() => { window.__S.set('clients/c', { name: 'Twin Co' }); window.__S.set('proformas/f', { number: 'PRO-0001', date: '2026-11-01', clientId: 'c', status: 'open', items: [{ desc: 'x', qty: 1, price: 500 }] }); for (const l of window.__L) l.fire(); });
    await p.waitForTimeout(1500);
    for (const f of [fa, fb]) { await f.evaluate(() => location.hash = 'proformas'); await f.waitForTimeout(400); await f.click('#lRows tr[data-id=f]'); await f.click('#mBtns >> text=Convert to invoice'); }
    await Promise.all([fa.click('#ed [type=submit]'), fb.click('#ed [type=submit]')]); await p.waitForTimeout(12000);
    const inv = await docs(p, 'invoices/'); const pf = (await docs(p, 'proformas/'))[0];
    assert(inv.length === 1, inv.length + ' invoices'); assert(pf.invoiceId === inv[0].id.split('/')[1], 'proforma points elsewhere'); await p.close(); return '1 invoice, link consistent';
  });

  await test('R-03', 'When records failed to load, deletes and voids are blocked and the warning stays', async () => {
    const { p } = await single({ fatalColl: 'receipts' }, `st.set("clients/c",{name:"K"});st.set("proformas/f",{number:"PRO-0001",date:"2026-11-01",clientId:"c",status:"open",items:[{desc:"x",qty:1,price:10}]});st.set("payments/y",{number:"PAY-0001",date:"2026-11-01",amount:5,method:"Cash",category:"Rent",payee:"L"});`, 'proformas');
    await p.waitForTimeout(800); await p.click('#lRows tr[data-id=f]'); await p.click('#mBtns >> text=Delete'); if (await p.isVisible('#mYes')) await p.click('#mYes'); await p.waitForTimeout(600);
    await p.evaluate(() => startVoid('payments', 'y')); const opened = await p.isVisible('#vd');
    assert((await docs(p, 'proformas/')).length === 1, 'proforma was deleted'); assert(!opened && !(await docs(p, 'payments/'))[0].void, 'void allowed');
    assert(/paused/.test(await p.textContent('#banner')), 'warning cleared'); await p.close(); return 'blocked, warning kept';
  });

  await test('R-04', 'A receipt that landed but timed out can be re-saved without changing its amount', async () => {
    const { p } = await single({ delay: 50 }, `st.set("clients/c",{name:"K"});st.set("invoices/i",{number:"INV-0001",date:"2026-11-01",clientId:"c",items:[{desc:"x",qty:1,price:1000}]});`, 'invoices');
    await p.click('#lRows tr[data-id=i]'); await p.click('#mBtns >> text=Receive payment'); await p.fill('#ed [name=amount]', '600');
    await p.evaluate(() => window.__landThenHang = 1); await p.click('#ed [type=submit]'); await p.waitForTimeout(21500); await p.evaluate(() => window.__landThenHang = 0);
    if (await p.isVisible('#ed [type=submit]')) await p.click('#ed [type=submit]'); const seen = await toastSeen(p, 1500);
    const rec = await docs(p, 'receipts/'); assert(rec.length === 1 && rec[0].amount === 600, 'receipts ' + JSON.stringify(rec.map(r => r.amount)));
    assert(!seen.some(t => /more than the balance/.test(t)), 'retry wrongly refused'); await p.close(); return 'one receipt of 600';
  });

  await test('R-05', 'Nothing can be added until business details (currency) have loaded', async () => {
    const { p } = await single({ settingsErrorOnce: true }, `st.set("settings/business",{currency:"USD",name:"Dollar Co"});st.set("clients/c",{name:"K"});st.set("invoices/i",{number:"INV-0001",date:"2026-11-01",clientId:"c",items:[{desc:"x",qty:1,price:99.5}]});`);
    await p.click('[data-new=invoices]'); const early = await p.isVisible('#ed'); const seen = await toastSeen(p, 600);
    await p.waitForTimeout(4000); await p.evaluate(() => location.hash = 'invoices'); await p.waitForTimeout(300);
    const row = await p.textContent('#lSum');
    assert(!early, 'editor opened before settings loaded'); assert(/USD/.test(row), 'after reconnect currency is not USD: ' + row); await p.close(); return 'blocked until loaded; USD shown';
  });

  await test('R-06', 'If storage cannot be reached at start-up, nothing pretends to save', async () => {
    const { p } = await single({ useReject: 'db' });
    await p.click('[data-new=invoices]'); await p.waitForTimeout(300);
    assert(!(await p.isVisible('#ed')), 'editor opened'); assert(/storage/.test(await p.textContent('#banner')), 'no banner'); await p.close();
    const r2 = await single({ useReject: 'downloads' }, `st.set("clients/c",{name:"Still Here"});`, 'clients');
    const rows = await r2.p.$$eval('#lRows tr[data-id]', r => r.length); assert(rows === 1, 'records not loaded when downloads failed'); await r2.p.close(); return 'blocked with message; other failures isolated';
  });

  await test('R-07', 'Restore is refused while records are not fully loaded, and keeps business details unless asked', async () => {
    const bk = JSON.stringify({ app: 'business-manager', format: 1, exportedAt: '2026-10-01T00:00:00Z', currency: 'UGX', settings: { name: 'Old Name', currency: 'UGX' }, counters: {}, data: { clients: [{ id: 'old1', name: 'Old Client' }] } });
    fs.writeFileSync('/tmp/bk2.json', bk);
    const a = await single({ fatalColl: 'invoices' }, `st.set("settings/business",{currency:"UGX",name:"Current Name"});`, 'settings');
    await a.p.setInputFiles('#bkFile', '/tmp/bk2.json'); await a.p.waitForTimeout(400); const opened = await a.p.isVisible('#rsGo'); await a.p.close();
    const b = await single({}, `st.set("settings/business",{currency:"UGX",name:"Current Name"});`, 'settings');
    await b.p.setInputFiles('#bkFile', '/tmp/bk2.json'); await b.p.waitForTimeout(400); await b.p.click('#rsGo'); await b.p.waitForTimeout(1500);
    const name = (await b.p.evaluate(() => window.__S.get('settings/business'))).name; const c = (await docs(b.p, 'clients/')).length; await b.p.close();
    assert(!opened, 'restore opened while records missing'); assert(name === 'Current Name', 'settings replaced: ' + name); assert(c === 1, 'client not restored');
    return 'refused when incomplete; settings kept';
  });

  await test('R-08', 'Restore never overwrites a record that still exists', async () => {
    const bk = JSON.stringify({ app: 'business-manager', format: 1, exportedAt: '2026-10-01T00:00:00Z', currency: 'UGX', settings: {}, counters: {}, data: { proformas: [{ id: 'f', number: 'PRO-0001', status: 'open', clientId: 'c', date: '2026-10-01', items: [{ desc: 'x', qty: 1, price: 5 }] }], receipts: [{ id: 'gone', number: 'RCT-0009', clientId: 'c', amount: 1, date: '2026-10-01', method: 'Cash' }] } });
    fs.writeFileSync('/tmp/bk3.json', bk);
    const { p } = await single({}, `st.set("clients/c",{name:"K"});st.set("proformas/f",{number:"PRO-0001",status:"received",invoiceId:"i",clientId:"c",date:"2026-10-01",items:[{desc:"x",qty:1,price:5}]});st.set("invoices/i",{number:"INV-0001",proformaId:"f",clientId:"c",date:"2026-10-02",items:[{desc:"x",qty:1,price:5}]});`, 'settings');
    await p.setInputFiles('#bkFile', '/tmp/bk3.json'); await p.waitForTimeout(400); await p.click('#rsGo'); await p.waitForTimeout(1500);
    const pf = (await docs(p, 'proformas/'))[0]; const r = (await docs(p, 'receipts/')).length; await p.close();
    assert(pf.status === 'received' && pf.invoiceId === 'i', 'proforma overwritten: ' + JSON.stringify(pf)); assert(r === 1, 'missing receipt not restored'); return 'existing kept, missing restored';
  });

  await test('R-09', 'A credit note and a receipt saved at the same moment: receipts never exceed the invoice net of credits', async () => {
    const { p, fa, fb } = await two(300);
    await p.evaluate(() => { window.__S.set('clients/c', { name: 'Edit Co' }); window.__S.set('invoices/i', { number: 'INV-0001', date: '2026-11-01', clientId: 'c', items: [{ desc: 'x', qty: 1, price: 1000 }] }); for (const l of window.__L) l.fire(); });
    await p.waitForTimeout(1500);
    for (const f of [fa, fb]) { await f.evaluate(() => location.hash = 'invoices'); await f.waitForTimeout(400); await f.click('#lRows tr[data-id=i]'); }
    await fa.click('#mBtns >> text=Credit note'); await fa.fill('#cn [name=reason]', 'Discount'); await fa.fill('#cn .p', '500'); await fb.click('#mBtns >> text=Receive payment'); await fb.fill('#ed [name=amount]', '1000');
    await Promise.all([fa.click('#cn [type=submit]'), fb.click('#ed [type=submit]')]); await p.waitForTimeout(12000);
    const rec = await docs(p, 'receipts/'), cr = await docs(p, 'credits/'); const paid = rec.reduce((a, r) => a + r.amount, 0), cred = cr.reduce((a, r) => a + r.total, 0);
    if (paid + cred > 1000) assert(cr[0].je.at > rec[0].je.at, 'receipt saved after the credit note overpaid the invoice');
    assert(paid <= 1000 && cred <= 1000, `paid ${paid}, credited ${cred}`); await p.close(); return `paid ${paid}, credited ${cred}` + (paid + cred > 1000 ? ' (credit after full payment → client credit)' : '');
  });
  await test('R-10', 'A backup is refused while records are not fully loaded', async () => {
    const { p } = await single({ fatalColl: 'payments' }, '', 'settings');
    await p.click('#bkDown'); await p.waitForTimeout(400); const dl = await p.evaluate(() => window.__lastDownload);
    assert(!dl, 'incomplete backup was produced'); await p.close(); return 'refused';
  });

  await test('R-11', 'Slow network (2.8 s per call): simultaneous saves still get different numbers', async () => {
    const { p, fa, fb } = await two(2800);
    await p.evaluate(() => { window.__S.set('clients/c', { name: 'Num Co' }); for (const l of window.__L) l.fire(); }); await p.waitForTimeout(7000);
    for (const f of [fa, fb]) { await f.evaluate(() => location.hash = 'invoices'); await f.waitForTimeout(400); await f.click('#lNew'); await f.selectOption('#ed [name=party]', { label: 'Num Co' }); await f.fill('#ed .d', 'W'); await f.fill('#ed .p', '100'); }
    await Promise.all([fa.click('#ed [type=submit]'), fb.click('#ed [type=submit]')]); await p.waitForTimeout(60000);
    const nums = (await docs(p, 'invoices/')).map(d => d.number); assert(new Set(nums).size === nums.length, 'duplicate numbers: ' + nums);
    await p.close(); return nums.sort().join(', ') || 'none saved';
  });

  await test('R-12', 'A proforma stuck as "Converted" with no invoice can be reopened', async () => {
    const { p } = await single({}, `st.set("clients/c",{name:"K"});st.set("proformas/f",{number:"PRO-0001",status:"received",invoiceId:"deleted",clientId:"c",date:"2026-10-01",items:[{desc:"x",qty:1,price:5}]});`, 'proformas');
    await p.click('#lRows tr[data-id=f]'); await p.click('#mBtns >> text=Reopen (invoice missing)'); await p.waitForTimeout(600);
    const pf = (await docs(p, 'proformas/'))[0]; assert(pf.status === 'open' && !pf.invoiceId, JSON.stringify(pf)); await p.close(); return 'reopened';
  });

  await test('R-13', 'A failed status update on a just-deleted record does not lock the user out', async () => {
    const { p } = await single({ canNull: true }, `st.set("clients/c",{name:"K"});st.set("proformas/f",{number:"PRO-0001",status:"open",clientId:"c",date:"2026-11-01",items:[{desc:"x",qty:1,price:5}]});`, 'proformas');
    await p.click('#lRows tr[data-id=f]'); await p.evaluate(() => window.__S.delete('proformas/f'));
    await p.click('#mBtns >> text=Mark declined'); await p.click('#mYes'); await p.waitForTimeout(600);
    const ro = await p.evaluate(() => document.body.classList.contains('ro')); assert(!ro, 'user switched to view-only'); await p.close(); return 'still able to work';
  });

  // ---------- Performance changes must not change any figure (PERF-xx) ----------
  await test('PERF-2', "Another user's change to a receipt amount updates the balance at once (no stale figures)", async () => {
    const { p } = await single({}, `st.set("clients/c",{name:"K"});st.set("invoices/i",{number:"INV-0001",date:"2026-11-01",clientId:"c",items:[{desc:"x",qty:1,price:1000}]});st.set("receipts/r",{number:"RCT-0001",date:"2026-11-01",clientId:"c",invoiceId:"i",amount:300,method:"Cash"});`, 'invoices');
    const b1 = await p.textContent('#lRows tr[data-id=i] td:nth-child(7)');
    await p.evaluate(() => { window.__S.set('receipts/r', { number: 'RCT-0001', date: '2026-11-01', clientId: 'c', invoiceId: 'i', amount: 500, method: 'Cash' }); for (const l of window.__L) l.fire(); }); await p.waitForTimeout(500);
    const b2 = await p.textContent('#lRows tr[data-id=i] td:nth-child(7)');
    assert(b1 === '700' && b2 === '500', `balance ${b1} then ${b2}`); await p.close(); return '700 → 500';
  });

  await test('PERF-3', 'A receipt deleted by another user disappears and the balance is restored', async () => {
    const { p } = await single({}, `st.set("clients/c",{name:"K"});st.set("invoices/i",{number:"INV-0001",date:"2026-11-01",clientId:"c",items:[{desc:"x",qty:1,price:1000}]});st.set("receipts/r",{number:"RCT-0001",date:"2026-11-01",clientId:"c",invoiceId:"i",amount:300,method:"Cash"});`, 'invoices');
    await p.evaluate(() => { window.__S.delete('receipts/r'); for (const l of window.__L) l.fire(); }); await p.waitForTimeout(500);
    const b = await p.textContent('#lRows tr[data-id=i] td:nth-child(7)'); await p.evaluate(() => location.hash = 'receipts'); await p.waitForTimeout(300);
    const n = await p.$$eval('#lRows tr[data-id]', r => r.length);
    assert(b === '1,000' && n === 0, `balance ${b}, receipts listed ${n}`); await p.close(); return 'balance 1,000, receipt gone';
  });

  await test('PERF-4', 'Long statements: latest 200 rows shown, brought-forward balance correct, download complete', async () => {
    const { p } = await single({}, `st.set("clients/c",{name:"Long Co"});for(let i=0;i<250;i++)st.set("invoices/i"+i,{number:"INV-"+String(i+1).padStart(4,"0"),date:"2026-01-"+String(1+Math.floor(i/10)).padStart(2,"0"),clientId:"c",items:[{desc:"x",qty:1,price:100}]});`, 'clients');
    await p.click('#lRows tr[data-id=c]'); await p.waitForTimeout(300);
    const rows = await p.$$eval('#mBody tbody tr[data-id]', r => r.length); const bf = await p.textContent('#mBody tbody tr:first-child');
    await p.click('#stAll'); await p.waitForTimeout(300); const all = await p.$$eval('#mBody tbody tr[data-id]', r => r.length);
    await p.click('#mBtns >> text=Download statement'); await p.waitForTimeout(300); const file = (await p.evaluate(() => window.__lastDownload)).data;
    const inFile = (file.match(/<tr data-c="invoices"/g) || []).length;
    assert(rows === 200, 'shown ' + rows); assert(/50 earlier/.test(bf) && /5,000/.test(bf), 'brought forward: ' + bf); assert(all === 250, 'show all ' + all); assert(inFile === 250, 'file rows ' + inFile);
    await p.close(); return '200 shown, B/F 5,000, all 250 in file';
  });

  await test('PERF-5', 'Backup built in slices contains exactly the same records', async () => {
    const { p } = await single({}, `st.set("clients/c",{name:"K"});for(let i=0;i<1200;i++)st.set("invoices/i"+i,{number:"INV-"+i,date:"2026-02-01",clientId:"c",items:[{desc:"x",qty:2,price:50+i}],vatRate:18});for(let i=0;i<900;i++)st.set("receipts/r"+i,{number:"RCT-"+i,date:"2026-02-02",clientId:"c",invoiceId:"i"+i,amount:10,method:"Cash"});`, 'settings');
    await p.click('#bkDown'); await p.waitForFunction(() => window.__lastDownload, null, { timeout: 20000 });
    const b = JSON.parse((await p.evaluate(() => window.__lastDownload)).data); const inv = b.data.invoices.find(x => x.id === 'i777');
    assert(b.app === 'business-manager' && b.data.invoices.length === 1200 && b.data.receipts.length === 900 && b.data.clients.length === 1, 'counts wrong');
    assert(inv && inv.items[0].price === 827 && inv.vatRate === 18, 'record differs'); await p.close(); return '1,200 invoices + 900 receipts intact';
  });

  await test('PERF-6', 'Restore retries temporary write failures and restores every missing record', async () => {
    const recs = []; for (let i = 0; i < 300; i++) recs.push({ id: 'k' + i, name: 'Restored ' + i });
    fs.writeFileSync('/tmp/bk4.json', JSON.stringify({ app: 'business-manager', format: 1, exportedAt: '2026-10-01T00:00:00Z', currency: 'UGX', settings: {}, counters: {}, data: { clients: recs } }));
    const { p } = await single({ failFirstSet: true }, '', 'settings');
    await p.setInputFiles('#bkFile', '/tmp/bk4.json'); await p.waitForSelector('#rsGo'); await p.click('#rsGo');
    await p.waitForSelector('#mTitle:has-text("verified")', { timeout: 90000 });
    const msg = await p.textContent('#mTitle') + ' ' + await p.textContent('#mBody'); const n = (await docs(p, 'clients/')).length;
    assert(n === 300, n + ' restored'); assert(/^Restore verified/.test(msg) && /300 records were restored/.test(msg) && !/failed/.test(msg), msg.slice(0, 200)); await p.close(); return '300 of 300 after retries; restore verified';
  });

  await test('PERF', '23,600 records: screens under 300 ms, memory steady after 50 live updates', async () => {
    const seed = `for(let i=0;i<800;i++)st.set("clients/c"+i,{name:"Client "+i});for(let i=0;i<300;i++)st.set("suppliers/s"+i,{name:"Supplier "+i});
      for(let i=0;i<8000;i++)st.set("invoices/i"+i,{number:"INV-"+String(i+1).padStart(5,"0"),date:"2026-"+String(1+i%11).padStart(2,"0")+"-10",dueDate:"2026-11-20",clientId:"c"+(i%800),vatRate:18,items:[{desc:"Item",qty:3,price:10000+i},{desc:"Labour",qty:1,price:50000}]});
      for(let i=0;i<7000;i++)st.set("receipts/r"+i,{number:"RCT-"+i,date:"2026-10-11",clientId:"c"+(i%800),invoiceId:"i"+i,amount:20000,method:"Cash"});
      for(let i=0;i<3000;i++)st.set("purchases/p"+i,{number:"PUR-"+i,date:"2026-10-01",supplierId:"s"+(i%300),items:[{desc:"Cement",qty:10,price:34000}]});
      for(let i=0;i<3000;i++)st.set("payments/y"+i,{number:"PAY-"+i,date:"2026-10-02",supplierId:"s"+(i%300),purchaseId:"p"+i,amount:100000,category:"Supplier bill",method:"Cash"});
      for(let i=0;i<1500;i++)st.set("proformas/f"+i,{number:"PRO-"+i,date:"2026-10-02",clientId:"c"+(i%800),items:[{desc:"Q",qty:1,price:1}]});`;
    const { p, errs } = await single({}, seed); await p.waitForFunction(() => document.querySelector('#dAR tr td.mono'), { timeout: 60000 });
    const times = {}; for (const h of ['invoices', 'clients', 'suppliers', 'purchases', 'receipts', 'payments', 'proformas', 'dashboard']) { const s = Date.now(); await p.evaluate(h => location.hash = h, h); await p.evaluate(() => new Promise(r => requestAnimationFrame(() => requestAnimationFrame(r)))); times[h] = Date.now() - s; }
    const h0 = await p.evaluate(() => performance.memory.usedJSHeapSize);
    for (let k = 0; k < 50; k++) await p.evaluate(k => { window.__S.set('receipts/b' + k, { number: 'B' + k, date: '2026-11-01', clientId: 'c2', invoiceId: 'i2', amount: 1, method: 'Cash' }); for (const l of window.__L) l.fire(); }, k);
    await p.waitForTimeout(3000); await p.evaluate(() => window.gc && window.gc()); const h1 = await p.evaluate(() => performance.memory.usedJSHeapSize);
    const worst = Math.max(...Object.values(times)); assert(worst < 300, 'slowest screen ' + worst + ' ms'); assert(h1 < h0 * 1.5, `heap grew ${h0} → ${h1}`); assert(!errs.length, errs.join(';'));
    await p.close(); return `slowest ${worst} ms; heap ${Math.round(h0 / 1048576)} → ${Math.round(h1 / 1048576)} MB`;
  });

  /* ---------- Phase 1: issued documents are locked ---------- */
  const SEED_INV = `st.set("clients/c",{name:"K"});st.set("invoices/i",{number:"INV-0001",date:"2026-11-01",clientId:"c",vatRate:18,items:[{desc:"Cement",qty:10,price:1000}]});`;
  await test('L-01', 'Issued invoices, receipts, purchases and payments offer no Edit or Delete, and the editor refuses them', async () => {
    const { p } = await single({}, SEED_INV + `st.set("receipts/r",{number:"RCT-0001",date:"2026-11-01",clientId:"c",invoiceId:"i",amount:500,method:"Cash"});st.set("suppliers/s",{name:"S"});st.set("purchases/u",{number:"PUR-0001",date:"2026-11-01",supplierId:"s",items:[{desc:"x",qty:1,price:100}]});st.set("payments/y",{number:"PAY-0001",date:"2026-11-01",supplierId:"s",purchaseId:"u",amount:50,method:"Cash",category:"Supplier bill"});`, 'invoices');
    const bad = [];
    for (const [h, id] of [['invoices', 'i'], ['receipts', 'r'], ['purchases', 'u'], ['payments', 'y']]) {
      await p.evaluate(h => location.hash = h, h); await p.waitForTimeout(250); await p.click(`#lRows tr[data-id=${id}]`);
      const labels = await p.$$eval('#mBtns button', b => b.map(x => x.textContent)); if (labels.includes('Edit') || labels.includes('Delete')) bad.push(h + ':' + labels.join('/'));
      await p.click('#mBtns >> text=Close');
    }
    const before = JSON.stringify(await docs(p, 'invoices/'));
    await p.evaluate(() => openEditor('invoices', byId('invoices', 'i'))); await p.waitForTimeout(200);
    assert(!(await p.isVisible('#ed')), 'editor opened for an issued invoice'); assert(JSON.stringify(await docs(p, 'invoices/')) === before, 'invoice changed');
    assert(!bad.length, 'edit/delete offered: ' + bad.join('; ')); await p.close(); return '4 document types locked';
  });

  await test('L-02', 'A credit note reduces the invoice balance and cannot exceed the invoice total less earlier credits', async () => {
    const { p } = await single({}, SEED_INV + `st.set("receipts/r",{number:"RCT-0001",date:"2026-11-01",clientId:"c",invoiceId:"i",amount:5000,method:"Cash"});`, 'invoices');
    // invoice total 11,800; paid 5,000; owed 6,800
    await p.click('#lRows tr[data-id=i]'); await p.click('#mBtns >> text=Credit note'); await p.waitForTimeout(200);
    assert(await p.$eval('#cn [name=vatRate]', e => e.readOnly && e.value === '18'), 'VAT not fixed at invoice rate');
    await p.fill('#cn [name=reason]', 'Too much'); await p.fill('#cn .p', '10001'); await p.click('#cn [type=submit]');
    const seen = await toastSeen(p, 1200); assert(seen.some(t => /can still be credited/.test(t)), 'over-credit not refused: ' + seen);
    assert((await docs(p, 'credits/')).length === 0, 'over-credit saved');
    await p.fill('#cn .p', '2000'); await p.click('#cn [type=submit]'); await p.waitForTimeout(1200);
    const cr = await docs(p, 'credits/'); assert(cr.length === 1 && cr[0].number === 'CRN-0001' && cr[0].total === 2360 && cr[0].invoiceId === 'i', 'credit ' + JSON.stringify(cr));
    const bal = await p.evaluate(() => invBal(byId('invoices', 'i'))); assert(bal === 4440, 'balance ' + bal);
    const cl = await p.evaluate(() => clientTotals('c')); assert(cl.bal === 4440 && cl.billed === 9440, 'client ' + JSON.stringify(cl));
    const st = await p.evaluate(() => statementRows('clients', 'c').at(-1).bal); assert(st === 4440, 'statement ends at ' + st);
    await p.close(); return 'CRN-0001 2,360; balance 6,800 → 4,440; statement agrees';
  });

  await test('L-03', 'Prefill: untouched invoice gets its full lines; a part-paid one gets one line that fits the balance', async () => {
    const { p } = await single({}, SEED_INV + `st.set("invoices/j",{number:"INV-0002",date:"2026-11-01",clientId:"c",vatRate:18,items:[{desc:"Bars",qty:3,price:3333}]});st.set("receipts/r",{number:"RCT-0001",date:"2026-11-01",clientId:"c",invoiceId:"j",amount:1001,method:"Cash"});`, 'invoices');
    await p.click('#lRows tr[data-id=i]'); await p.click('#mBtns >> text=Credit note'); await p.waitForTimeout(200);
    const a = await p.$$eval('#cn .iRows tr', t => t.map(r => r.querySelector('.d').value + '|' + r.querySelector('.q').value + '|' + r.querySelector('.p').value));
    assert(a.length === 1 && a[0] === 'Cement|10|1000', 'full prefill ' + a);
    await p.fill('#cn [name=reason]', 'Cancelled'); await p.click('#cn [type=submit]'); await p.waitForTimeout(1200);
    const st = await p.evaluate(() => invStatus(byId('invoices', 'i'))); assert(st === 'credited', 'status ' + st);
    await p.click('#mBtns >> text=Close'); await p.evaluate(() => location.hash = 'invoices'); await p.waitForTimeout(250);
    await p.click('#lRows tr[data-id=j]'); await p.click('#mBtns >> text=Credit note'); await p.waitForTimeout(200);
    await p.fill('#cn [name=reason]', 'Write off rest'); await p.click('#cn [type=submit]'); await p.waitForTimeout(1200);
    const bal = await p.evaluate(() => invBal(byId('invoices', 'j'))); assert(bal >= 0 && bal <= 1, 'remaining ' + bal);
    await p.close(); return 'full credit → Credited; part-paid credit leaves ' + bal;
  });

  await test('L-04', 'Voiding a receipt keeps it on file but frees the invoice balance; a reason is required', async () => {
    const { p } = await single({}, SEED_INV + `st.set("receipts/r",{number:"RCT-0001",date:"2026-11-01",clientId:"c",invoiceId:"i",amount:5000,method:"Cash"});`, 'receipts');
    await p.click('#lRows tr[data-id=r]'); await p.click('#mBtns >> text=Void'); await p.waitForTimeout(200);
    await p.click('#vd [type=submit]'); await p.waitForTimeout(300); assert(!(await docs(p, 'receipts/'))[0].void, 'voided without a reason');
    await p.fill('#vd [name=reason]', 'Cheque bounced'); await p.click('#vd [type=submit]'); await p.waitForTimeout(1000);
    const r = await docs(p, 'receipts/'); assert(r.length === 1 && r[0].void === true && r[0].voidReason === 'Cheque bounced' && r[0].amount === 5000, 'receipt ' + JSON.stringify(r));
    const bal = await p.evaluate(() => invBal(byId('invoices', 'i'))); assert(bal === 11800, 'balance ' + bal);
    const body = await p.textContent('#mBody'); assert(/VOID/.test(body) && /Cheque bounced/.test(body), 'no void stamp');
    await p.click('#mBtns >> text=Close'); const sum = await p.textContent('#lSum'); assert(/1 void/.test(sum) && !/5,000/.test(sum.split('·')[0]), 'list sum ' + sum);
    const dash = await p.evaluate(() => S.receipts.filter(x => !x.void).length); assert(dash === 0, 'still counted');
    await p.close(); return 'kept, stamped VOID, balance back to 11,800';
  });

  await test('L-05', 'A purchase can be voided only once its payments are voided; voiding reopens its LPO', async () => {
    const { p } = await single({}, `st.set("suppliers/s",{name:"S"});st.set("lpos/l",{number:"LPO-0001",date:"2026-11-01",supplierId:"s",status:"received",purchaseId:"u",items:[{desc:"x",qty:1,price:100}]});
      st.set("purchases/u",{number:"PUR-0001",date:"2026-11-01",supplierId:"s",lpoId:"l",items:[{desc:"x",qty:1,price:100}]});st.set("payments/y",{number:"PAY-0001",date:"2026-11-01",supplierId:"s",purchaseId:"u",amount:50,method:"Cash",category:"Supplier bill"});`, 'purchases');
    await p.click('#lRows tr[data-id=u]'); let labels = await p.$$eval('#mBtns button', b => b.map(x => x.textContent));
    assert(!labels.includes('Void purchase'), 'void offered while a payment is live');
    // force it anyway: the fresh store check must still refuse
    await p.evaluate(() => startVoid('purchases', 'u')); await p.fill('#vd [name=reason]', 'x'); await p.click('#vd [type=submit]'); const seen = await toastSeen(p, 1000);
    assert(!(await docs(p, 'purchases/'))[0].void && seen.some(t => /Void the 1 payment/.test(t)), 'purchase voided with live payment');
    await p.evaluate(() => startVoid('payments', 'y')); await p.fill('#vd [name=reason]', 'Wrong supplier'); await p.click('#vd [type=submit]'); await p.waitForTimeout(900);
    await p.evaluate(() => startVoid('purchases', 'u')); await p.fill('#vd [name=reason]', 'Goods returned'); await p.click('#vd [type=submit]'); await p.waitForTimeout(1200);
    const u = (await docs(p, 'purchases/'))[0], l = (await docs(p, 'lpos/'))[0];
    assert(u.void && l.status === 'open' && !l.purchaseId, 'purchase ' + u.void + ' lpo ' + JSON.stringify(l));
    const t = await p.evaluate(() => supplierTotals('s')); assert(t.bal === 0 && t.billed === 0, 'supplier ' + JSON.stringify(t));
    await p.close(); return 'refused with live payment; then voided, LPO reopened, supplier balance 0';
  });

  await test('L-06', 'Users without owner/Editor rights see no Void or Credit note buttons and cannot set the lock', async () => {
    const { p } = await single({ noAdmin: true }, SEED_INV + `st.set("receipts/r",{number:"RCT-0001",date:"2026-11-01",clientId:"c",invoiceId:"i",amount:500,method:"Cash"});`, 'invoices');
    await p.waitForTimeout(400); await p.click('#lRows tr[data-id=i]'); const a = await p.$$eval('#mBtns button', b => b.map(x => x.textContent)); await p.click('#mBtns >> text=Close');
    await p.evaluate(() => location.hash = 'receipts'); await p.waitForTimeout(250); await p.click('#lRows tr[data-id=r]'); const b = await p.$$eval('#mBtns button', b => b.map(x => x.textContent));
    assert(!a.includes('Credit note') && !b.includes('Void'), 'buttons shown: ' + a + ' / ' + b);
    assert(a.includes('Receive payment'), 'normal user lost Receive payment');
    assert(await p.isDisabled('#fSettings [name=lockDate]'), 'lock date editable'); await p.close(); return 'hidden; settings locked';
  });

  await test('L-07', 'Month-end lock: nothing issued can be dated on or before the lock date', async () => {
    const { p } = await single({}, `st.set("settings/business",{name:"Irongrid",currency:"UGX",lockDate:"2026-10-31"});` + SEED_INV, 'invoices');
    await p.click('#lNew'); await p.selectOption('#ed [name=party]', { label: 'K' }); await p.fill('#ed [name=date]', '2026-10-31'); await p.fill('#ed .d', 'W'); await p.fill('#ed .p', '100');
    await p.click('#ed [type=submit]'); const seen = await toastSeen(p, 1000); assert(seen.some(t => /locked up to/.test(t)), 'no lock message: ' + seen);
    assert((await docs(p, 'invoices/')).length === 1, 'locked-period invoice saved');
    await p.fill('#ed [name=date]', '2026-11-01'); await p.click('#ed [type=submit]'); await p.waitForTimeout(1200); assert((await docs(p, 'invoices/')).length === 2, 'open-period invoice refused');
    await p.click('#mBtns >> text=Close'); await p.click('#lRows tr[data-id=i]'); await p.click('#mBtns >> text=Credit note'); await p.fill('#cn [name=reason]', 'x'); await p.fill('#cn [name=date]', '2026-10-15');
    await p.click('#cn [type=submit]'); const s2 = await toastSeen(p, 1000); assert(s2.some(t => /locked up to|before its invoice/.test(t)) && !(await docs(p, 'credits/')).length, 'credit in locked period saved');
    await p.close(); return 'Oct 31 refused, Nov 1 accepted';
  });

  await test('L-08', 'Two users issuing full credit notes on the same invoice at once: only one is accepted', async () => {
    const { p, fa, fb } = await two(300);
    await p.evaluate(() => { window.__S.set('clients/c', { name: 'Race Co' }); window.__S.set('invoices/i', { number: 'INV-0001', date: '2026-11-01', clientId: 'c', items: [{ desc: 'x', qty: 1, price: 1000 }] }); for (const l of window.__L) l.fire(); });
    await p.waitForTimeout(1500);
    for (const f of [fa, fb]) { await f.evaluate(() => location.hash = 'invoices'); await f.waitForTimeout(400); await f.click('#lRows tr[data-id=i]'); await f.click('#mBtns >> text=Credit note'); await f.fill('#cn [name=reason]', 'Cancel'); }
    await Promise.all([fa.click('#cn [type=submit]'), fb.click('#cn [type=submit]')]); await p.waitForTimeout(12000);
    const cr = await docs(p, 'credits/'); const tot = cr.reduce((a, r) => a + r.total, 0);
    assert(cr.length === 1 && tot === 1000, cr.length + ' credit notes, ' + tot); await p.close(); return '1 of 2 accepted';
  });

  await test('L-09', 'A voided receipt no longer blocks a new receipt for the same balance (fresh store check skips voids)', async () => {
    const { p } = await single({}, SEED_INV + `st.set("receipts/r",{number:"RCT-0001",date:"2026-11-01",clientId:"c",invoiceId:"i",amount:11800,method:"Cash",void:true,voidedAt:"2026-11-02",voidReason:"bounced"});`, 'invoices');
    await p.click('#lRows tr[data-id=i]'); await p.click('#mBtns >> text=Receive payment'); await p.fill('#ed [name=amount]', '11800'); await p.click('#ed [type=submit]'); await p.waitForTimeout(1200);
    const live = (await docs(p, 'receipts/')).filter(r => !r.void); assert(live.length === 1 && live[0].amount === 11800, 'receipts ' + JSON.stringify(live));
    await p.close(); return 'new receipt accepted';
  });

  await test('L-10', 'Void receipts show on the client statement without moving the balance', async () => {
    const { p } = await single({}, SEED_INV + `st.set("receipts/r",{number:"RCT-0001",date:"2026-11-01",clientId:"c",invoiceId:"i",amount:1800,method:"Cash"});st.set("receipts/v",{number:"RCT-0002",date:"2026-11-01",clientId:"c",invoiceId:"i",amount:9999,method:"Cash",void:true,voidedAt:"2026-11-02"});`, 'clients');
    const rows = await p.evaluate(() => statementRows('clients', 'c').map(r => [r.desc, r.dr, r.cr, r.bal]));
    assert(rows.some(r => /RCT-0002 \(void\)/.test(r[0]) && r[2] === 0), 'void row missing'); assert(rows.at(-1)[3] === 10000, 'balance ' + rows.at(-1)[3]);
    await p.close(); return 'void memo row; balance 10,000';
  });

  await test('L-11', 'Forms opened with lines already filled show VAT in the opening totals (display defect found in Phase 1)', async () => {
    const { p } = await single({}, `st.set("clients/c",{name:"K"});st.set("invoices/i",{number:"INV-0001",date:"2026-11-01",clientId:"c",vatRate:18,items:[{desc:"Cement",qty:10,price:1000}]});st.set("proformas/f",{number:"PRO-0001",date:"2026-11-01",clientId:"c",status:"open",vatRate:18,items:[{desc:"Bars",qty:1,price:1000}]});`, 'invoices');
    await p.click('#lRows tr[data-id=i]'); await p.click('#mBtns >> text=Credit note'); await p.waitForTimeout(200);
    const a = [await p.textContent('#cn .t-vat'), await p.textContent('#cn .t-tot')]; await p.click('#cnCancel'); await p.click('#mBtns >> text=Close');
    await p.evaluate(() => location.hash = 'proformas'); await p.waitForTimeout(250); await p.click('#lRows tr[data-id=f]'); await p.click('#mBtns >> text=Edit'); await p.waitForTimeout(200);
    const b = [await p.textContent('#ed .t-vat'), await p.textContent('#ed .t-tot')];
    assert(a[0] === '1,800' && /11,800/.test(a[1]), 'credit note opened with ' + a); assert(b[0] === '180' && /1,180/.test(b[1]), 'proforma edit opened with ' + b);
    await p.close(); return 'VAT 1,800 and 180 shown on open';
  });

  /* ---------- Accounting engine: end-to-end scenarios through the app ---------- */
  const BASE_SEED = `st.set("settings/business",{name:"Irongrid",currency:"UGX"});st.set("clients/c",{name:"HIMA"});st.set("suppliers/s",{name:"Hardware Ltd"});st.set("items/cem",{name:"Cement 50kg",unit:"bags"});st.set("items/bar",{name:"Y12 bars",unit:"lengths"});`;
  const books = p => p.evaluate(() => { const L = ledger(); return { problems: L.problems, issues: L.issues.map(i => i.msg), recon: L.recon.filter(r => !r.ok).map(r => r.label + ' ' + r.gl + '/' + r.sub), party: L.party.length, stock: L.stock, tb: L.tb.ok, bs: L.bs.ok, n: L.J.length }; });
  const clean = async (p, extra) => { const b = await books(p); assert(b.problems === 0, 'books not clean: ' + JSON.stringify(b)); assert(b.tb && b.bs, 'TB/BS'); return b; };
  async function buyStock(p, item, qty, price, vat = 18) {
    await p.evaluate(() => location.hash = 'purchases'); await p.waitForTimeout(200); await p.click('#lNew'); await p.selectOption('#ed [name=party]', { label: 'Hardware Ltd' });
    await p.selectOption('#ed .si', item); await p.fill('#ed .q', String(qty)); await p.fill('#ed .p', String(price)); await p.fill('#ed [name=vatRate]', String(vat)); await p.click('#ed [type=submit]'); await p.waitForTimeout(1100); await p.click('#mBtns >> text=Close');
  }
  async function sell(p, lines, vat = 18) {
    await p.evaluate(() => location.hash = 'invoices'); await p.waitForTimeout(200); await p.click('#lNew'); await p.selectOption('#ed [name=party]', { label: 'HIMA' });
    for (let k = 0; k < lines.length; k++) { if (k) await p.click('#ed .addLine'); const rows = await p.$$('#ed .iRows tr'); const tr = rows[k]; const [item, qty, price, desc] = lines[k];
      if (item) await (await tr.$('.si')).selectOption(item); if (desc) await (await tr.$('.d')).fill(desc); await (await tr.$('.q')).fill(String(qty)); await (await tr.$('.p')).fill(String(price)); }
    await p.fill('#ed [name=vatRate]', String(vat)); await p.click('#ed [type=submit]'); const seen = await toastSeen(p, 1300); return seen;
  }
  const clk = async (f, sel) => { try { await f.click(sel, { timeout: 8000 }); } catch (e) { throw new Error('could not click ' + sel); } };
  const closeAll = f => f.evaluate(() => { const c = [...document.querySelectorAll('#mBtns button')].find(b => b.textContent === 'Close'); if (c) c.click(); else document.querySelector('#modal').classList.remove('on'); });
  const one = async (p, pre) => (await docs(p, pre))[0];
  const minor = (je, a) => je.lines.filter(l => l.a === a).reduce((t, l) => t + l.d - l.c, 0);

  await test('E-01', 'Stock purchase and sale post cost of sales at weighted average; every reconciliation agrees', async () => {
    const { p, errs } = await single({}, BASE_SEED, 'purchases');
    await buyStock(p, 'cem', 100, 32000); await buyStock(p, 'cem', 50, 34000); await sell(p, [['cem', 30, 40000]]);
    const inv = await one(p, 'invoices/'); assert(minor(inv.je, '5000') === 980000, 'COGS ' + minor(inv.je, '5000'));
    const b = await clean(p); assert(b.stock.cem.q === 120e6 && b.stock.cem.v === 3920000, 'stock ' + JSON.stringify(b.stock)); assert(!errs.length, errs.join(';'));
    await p.close(); return 'COGS 980,000; stock 120 bags = 3,920,000; ' + b.n + ' journals, all checks pass';
  });
  await test('E-02', 'Selling more than is in stock is refused and nothing is saved', async () => {
    const { p } = await single({}, BASE_SEED, 'purchases'); await buyStock(p, 'cem', 10, 32000); const seen = await sell(p, [['cem', 11, 40000]]);
    assert(seen.some(t => /Not enough/.test(t)), 'no refusal: ' + seen); assert(!(await docs(p, 'invoices/')).length, 'invoice saved'); await clean(p); await p.close(); return 'refused';
  });
  await test('E-03', 'Partial payments: two receipts settle an invoice; client account and ledger agree at each step', async () => {
    const { p } = await single({}, BASE_SEED, 'invoices'); await sell(p, [[null, 1, 1000000, 'Works']]); await p.click('#mBtns >> text=Close');
    for (const amt of ['500000', '680000']) { await p.click('#lRows tr[data-id]'); await p.click('#mBtns >> text=Receive payment'); await p.fill('#ed [name=amount]', amt); await p.click('#ed [type=submit]'); await p.waitForTimeout(1100); await p.click('#mBtns >> text=Close'); await clean(p); }
    const st = await p.evaluate(() => invStatus(S.invoices[0])); assert(st === 'paid', 'status ' + st); await p.close(); return 'part paid → paid; checks clean after each receipt';
  });
  await test('E-04', 'Advance payment applied to a later invoice: no new posting, invoice paid, advance used up', async () => {
    const { p } = await single({}, BASE_SEED, 'receipts');
    await p.click('#lNew'); await p.selectOption('#ed [name=party]', { label: 'HIMA' }); await p.fill('#ed [name=amount]', '700000'); await p.click('#ed [type=submit]'); await p.waitForTimeout(1100); await p.click('#mBtns >> text=Close');
    await sell(p, [[null, 1, 500000, 'Roofing']], 18); const n0 = (await books(p)).n; await p.click('#mBtns >> text=Apply advance'); await p.click('#ap [type=submit]'); await p.waitForTimeout(1200);
    const inv = await p.evaluate(() => [invStatus(S.invoices[0]), invBal(S.invoices[0])]); const r = await one(p, 'receipts/');
    assert(inv[0] === 'paid' && inv[1] === 0, 'invoice ' + inv); assert(r.alloc.length === 1 && r.alloc[0].amount === 590000 && r.allocInv[0], 'alloc ' + JSON.stringify(r.alloc));
    const b = await clean(p); assert(b.n === n0, 'a journal was added'); const left = await p.evaluate(() => S.receipts[0].amount - S.receipts[0].alloc[0].amount); assert(left === 110000, 'left ' + left);
    await p.close(); return '590,000 of 700,000 applied; 110,000 still on account; no extra journal';
  });
  await test('E-05', 'Credit note after full payment returns goods to stock, client goes into credit, refund clears it', async () => {
    const { p } = await single({}, BASE_SEED, 'purchases'); await buyStock(p, 'cem', 10, 30000); await sell(p, [['cem', 10, 40000]]); await p.click('#mBtns >> text=Receive payment'); await p.click('#ed [type=submit]'); await p.waitForTimeout(1100); await p.click('#mBtns >> text=Close');
    await p.evaluate(() => location.hash = 'invoices'); await p.waitForTimeout(200); await p.click('#lRows tr[data-id]'); await p.click('#mBtns >> text=Credit note'); await p.fill('#cn [name=reason]', '2 bags returned');
    await p.fill('#cn .q', '2'); assert(await p.$eval('#cn .rs', e => e.checked), 'return-to-stock not ticked'); await p.click('#cn [type=submit]'); await p.waitForTimeout(1200);
    const cr = await one(p, 'credits/'); assert(minor(cr.je, '1200') === 60000 && minor(cr.je, '1100') === -94400, 'credit je ' + JSON.stringify(cr.je.lines));
    let bal = await p.evaluate(() => clientTotals('c').bal); assert(bal === -94400, 'client ' + bal); await clean(p);
    await p.click('#mBtns >> text=Close'); await p.evaluate(() => showParty('clients', 'c')); await p.click('#mBtns >> text=Refund'); await p.fill('#rf [name=reason]', 'returned goods'); await p.click('#rf [type=submit]'); await p.waitForTimeout(1200);
    bal = await p.evaluate(() => clientTotals('c').bal); assert(bal === 0, 'after refund ' + bal); const b = await clean(p); assert(b.stock.cem.q === 2e6 && b.stock.cem.v === 60000, 'stock ' + JSON.stringify(b.stock.cem));
    await p.close(); return 'credit 94,400 → client in credit → refund 94,400 → 0; 2 bags back in stock at 60,000';
  });
  await test('E-06', 'A refund larger than the client credit is refused (fresh ledger check)', async () => {
    const { p } = await single({}, BASE_SEED, 'receipts');
    await p.click('#lNew'); await p.selectOption('#ed [name=party]', { label: 'HIMA' }); await p.fill('#ed [name=amount]', '100000'); await p.click('#ed [type=submit]'); await p.waitForTimeout(1100);
    await p.evaluate(() => showParty('clients', 'c')); await p.click('#mBtns >> text=Refund'); await p.fill('#rf [name=amount]', '100001'); await p.fill('#rf [name=reason]', 'x'); await p.click('#rf [type=submit]');
    const seen = await toastSeen(p, 1000); assert(seen.some(t => /more than/.test(t)) && !(await docs(p, 'refunds/')).length, 'over-refund saved'); await p.close(); return 'refused';
  });
  await test('E-07', 'Client debit note adds to what the client owes, with output VAT', async () => {
    const { p } = await single({}, BASE_SEED, 'debits'); await p.click('#lNew'); await p.selectOption('#dn [name=clientId]', 'c'); await p.fill('#dn [name=reason]', 'Extra transport'); await p.fill('#dn .d', 'Transport'); await p.fill('#dn .p', '100000'); await p.fill('#dn [name=vatRate]', '18');
    await p.click('#dn [type=submit]'); await p.waitForTimeout(1200); const d = await one(p, 'debits/'); assert(d.number === 'DBN-0001' && minor(d.je, '1100') === 118000 && minor(d.je, '2100') === -18000, JSON.stringify(d.je));
    assert((await p.evaluate(() => clientTotals('c').bal)) === 118000, 'client'); await clean(p); await p.close(); return 'DBN-0001: AR +118,000, VAT 18,000';
  });
  await test('E-08', 'Supplier debit note returns stock at average cost, cuts what we owe; overpaid supplier refunds us', async () => {
    const { p } = await single({}, BASE_SEED, 'purchases'); await buyStock(p, 'cem', 10, 30000); await buyStock(p, 'cem', 10, 34000);
    await p.evaluate(() => location.hash = 'purchases'); await p.waitForTimeout(200); const pid = await p.evaluate(() => S.purchases.find(x => x.items[0].price === 34000).id);
    await p.evaluate(id => showDoc('purchases', id), pid); await p.click('#mBtns >> text=Make payment'); await p.click('#ed [type=submit]'); await p.waitForTimeout(1100);
    await p.evaluate(id => showDoc('purchases', id), pid); await p.click('#mBtns >> text=Supplier debit note'); await p.fill('#dn [name=reason]', 'Damaged'); await p.fill('#dn .q', '2'); await p.click('#dn [type=submit]'); await p.waitForTimeout(1300);
    const sd = await one(p, 'sdebits/'); assert(minor(sd.je, '1200') === -64000 && minor(sd.je, '2000') === 80240 && minor(sd.je, '5000') === -4000, JSON.stringify(sd.je.lines));
    const s1 = await p.evaluate(() => supplierTotals('s').bal); assert(s1 === 354000 - 80240, 'supplier ' + s1); await clean(p);
    const p1 = await p.evaluate(() => S.purchases.find(x => x.items[0].price === 30000).id); await p.evaluate(id => showDoc('purchases', id), p1); await p.click('#mBtns >> text=Make payment'); await p.fill('#ed [name=amount]', '354000'); await p.click('#ed [type=submit]'); await p.waitForTimeout(1100);
    assert((await p.evaluate(() => supplierTotals('s').bal)) === -80240, 'supplier not in debit');
    await p.evaluate(() => showParty('suppliers', 's')); await p.click('#mBtns >> text=Refund received'); await p.fill('#rf [name=reason]', 'refund for damaged cement'); await p.click('#rf [type=submit]'); await p.waitForTimeout(1200);
    assert((await p.evaluate(() => supplierTotals('s').bal)) === 0, 'supplier after refund'); await clean(p); await p.close(); return 'SDN: AP −80,240, stock −64,000 at average, 4,000 to cost of sales; supplier refunded 80,240';
  });
  await test('E-09', 'Client settles in cement: stock in at agreed value, invoice paid, no VAT and no cash posted', async () => {
    const { p } = await single({}, BASE_SEED, 'invoices'); await sell(p, [[null, 1, 1000000, 'Works']], 18);
    await p.click('#mBtns >> text=Receive payment'); await p.selectOption('#ed [name=method]', 'Goods (in kind)'); await p.selectOption('#ed .gi', 'cem'); await p.fill('#ed .gq', '30'); await p.fill('#ed .gv', '900000');
    assert(await p.$eval('#ed [name=amount]', e => e.readOnly && e.value === '900000'), 'amount not from goods'); await p.click('#ed [type=submit]'); await p.waitForTimeout(1200);
    const r = await one(p, 'receipts/'); assert(r.je.lines.every(l => ['1200', '1100'].includes(l.a)), 'other accounts ' + JSON.stringify(r.je.lines));
    const b = await clean(p); assert(b.stock.cem.v === 900000 && b.stock.cem.q === 30e6, 'stock'); assert((await p.evaluate(() => invBal(S.invoices[0]))) === 280000, 'balance');
    const dash = await p.evaluate(() => { location.hash = 'dashboard'; return 1; }); await p.waitForTimeout(300); assert(/UGX 0/.test(await p.textContent('#kIn')), 'goods counted as money received');
    await p.close(); return 'invoice 1,180,000 → 280,000 owed; 30 bags in stock at 900,000; money received unchanged';
  });
  await test('E-10', 'Stock adjustments: loss at average cost, gain at stated value; stock page and ledger agree', async () => {
    const { p } = await single({}, BASE_SEED, 'purchases'); await buyStock(p, 'bar', 3, 100, 0);
    for (const [q, v] of [['-1', ''], ['2', '250']]) { await p.evaluate(() => openAdjust('bar')); await p.fill('#aj [name=qty]', q); if (v) await p.fill('#aj [name=value]', v); await p.fill('#aj [name=reason]', 'count'); await p.click('#aj [type=submit]'); await p.waitForTimeout(1100); }
    const b = await clean(p); assert(b.stock.bar.q === 4e6 && b.stock.bar.v === 450, 'stock ' + JSON.stringify(b.stock.bar));
    await p.evaluate(() => location.hash = 'stock'); await p.waitForTimeout(300); assert(/450/.test(await p.textContent('#stRows')), 'stock page'); await p.close(); return 'ADJ-0001 −1 at 100, ADJ-0002 +2 at 250; 4 lengths = 450';
  });
  await test('E-11', 'Voiding a stock purchase posts a reversal on the void date; reports before that date still show it', async () => {
    const { p } = await single({}, BASE_SEED, 'purchases'); await buyStock(p, 'cem', 10, 30000, 0);
    await p.evaluate(() => { const x = S.purchases[0]; startVoid('purchases', x.id) }); await p.fill('#vd [name=reason]', 'Wrong supplier'); await p.click('#vd [type=submit]'); await p.waitForTimeout(1200);
    const u = await one(p, 'purchases/'); assert(u.void && u.jr && u.jr.pid.endsWith(':R'), 'no reversal'); const b = await clean(p); assert(b.stock.cem.q === 0 && b.stock.cem.v === 0, 'stock not reversed');
    const before = await p.evaluate(() => LEDGER.trialBalance(ledger().J, '2026-11-03').rows.find(r => r.a === '1200')); await p.close();
    return 'original kept, reversal ' + u.jr.pid.split('/')[1].slice(-2) + ' posted; checks clean';
  });
  await test('E-12', 'Idempotency: a save that landed but timed out is retried — one document, one posting', async () => {
    const { p } = await single({ delay: 50 }, BASE_SEED + `st.set("invoices/i",{number:"INV-0001",date:"2026-11-01",clientId:"c",items:[{desc:"x",qty:1,price:1000}]});`, 'invoices');
    await p.click('#lRows tr[data-id=i]'); await p.click('#mBtns >> text=Receive payment'); await p.fill('#ed [name=amount]', '600');
    await p.evaluate(() => window.__landThenHang = 1); await p.click('#ed [type=submit]'); await p.waitForTimeout(21500); await p.evaluate(() => window.__landThenHang = 0); if (await p.isVisible('#ed [type=submit]')) await p.click('#ed [type=submit]'); await p.waitForTimeout(1500);
    const rec = await docs(p, 'receipts/'); assert(rec.length === 1 && rec[0].je.pid === 'receipts/' + rec[0].id.split('/')[1], 'receipts ' + rec.length);
    const pids = await p.evaluate(() => ledger().J.map(j => j.pid)); assert(new Set(pids).size === pids.length, 'duplicate posting'); await p.close(); return '1 receipt, 1 posting';
  });
  await test('E-13', 'Tampering with a posted record outside the app is reported (and not corrected)', async () => {
    const { p } = await single({}, BASE_SEED, 'receipts');
    await p.click('#lNew'); await p.selectOption('#ed [name=party]', { label: 'HIMA' }); await p.fill('#ed [name=amount]', '100000'); await p.click('#ed [type=submit]'); await p.waitForTimeout(1100); await clean(p);
    await p.evaluate(() => { const [k, v] = [...window.__S.entries()].find(([k]) => k.startsWith('receipts/')); window.__S.set(k, { ...v, amount: 10000 }); for (const l of window.__L) l.fire(); });
    await p.waitForTimeout(2500); const b = await books(p); assert(b.problems > 0 && b.issues.some(m => /fingerprint|doesn't match/.test(m)), 'not reported ' + JSON.stringify(b));
    const stored = await one(p, 'receipts/'); assert(stored.amount === 10000, 'store was changed by the app'); assert(/problem/.test(await p.textContent('#kBooks')), 'dashboard not flagged');
    await p.close(); return b.problems + ' problems reported; record left as found';
  });
  await test('E-14', 'Two users selling the last stock at the same moment: one sale refused, stock never negative, sequence intact', async () => {
    const { p, fa, fb } = await two(200);
    await p.evaluate(() => { window.__S.set('settings/business', { name: 'Irongrid', currency: 'UGX' }); window.__S.set('clients/c', { name: 'HIMA' }); window.__S.set('suppliers/s', { name: 'Hardware Ltd' }); window.__S.set('items/cem', { name: 'Cement 50kg', unit: 'bags' }); for (const l of window.__L) l.fire(); });
    await p.waitForTimeout(1500); await buyStock(fa, 'cem', 100, 30000, 0); await p.waitForTimeout(2500);
    for (const f of [fa, fb]) { await f.evaluate(() => location.hash = 'invoices'); await f.waitForTimeout(300); await f.click('#lNew'); await f.selectOption('#ed [name=party]', { label: 'HIMA' }); await f.selectOption('#ed .si', 'cem'); await f.fill('#ed .q', '60'); await f.fill('#ed .p', '40000'); }
    await Promise.all([fa.click('#ed [type=submit]'), fb.click('#ed [type=submit]')]); await p.waitForTimeout(12000);
    const inv = await docs(p, 'invoices/'); assert(inv.length === 1, inv.length + ' invoices'); await fa.waitForTimeout(2500); const b = await clean(fa);
    assert(b.stock.cem.q === 40e6, 'stock ' + JSON.stringify(b.stock.cem)); await p.close(); return '1 of 2 sales accepted; 40 bags left; checks clean';
  });
  await test('E-15', 'Exact money in the app: USD 0.5 × 4.35 = 2.18; an amount with too many decimals is refused, not rounded', async () => {
    const { p } = await single({}, `st.set("settings/business",{name:"X",currency:"USD"});st.set("clients/c",{name:"K"});`, 'invoices');
    await p.click('#lNew'); await p.selectOption('#ed [name=party]', { label: 'K' }); await p.fill('#ed .q', '0.5'); await p.fill('#ed .p', '4.35'); await p.fill('#ed [name=vatRate]', '0'); const sub = await p.textContent('#ed .t-sub'); await p.click('#ed [type=submit]'); await p.waitForTimeout(1100);
    assert(sub === '2.18', 'subtotal shown ' + sub); const inv = await one(p, 'invoices/'); assert(minor(inv.je, '4000') === -218, 'posted ' + minor(inv.je, '4000'));
    await p.click('#mBtns >> text=Receive payment'); await p.fill('#ed [name=amount]', '2.175'); await p.click('#ed [type=submit]'); const seen = await toastSeen(p, 1000);
    assert(seen.some(t => /at most 2 decimal/.test(t)) && !(await docs(p, 'receipts/')).length, 'not refused'); await p.close(); return 'subtotal 2.18 (float gave 2.17); 2.175 refused';
  });
  await test('E-16', 'Posting dates: future-dated receipts and next-month invoices are refused', async () => {
    const { p } = await single({}, BASE_SEED, 'receipts'); const loc = "const f=d=>d.getFullYear()+'-'+String(d.getMonth()+1).padStart(2,'0')+'-'+String(d.getDate()).padStart(2,'0');";
    const tmr = await p.evaluate(loc + 'const d=new Date();d.setDate(d.getDate()+1);f(d)');
    await p.click('#lNew'); await p.selectOption('#ed [name=party]', { label: 'HIMA' }); await p.fill('#ed [name=amount]', '1000'); await p.fill('#ed [name=date]', tmr); await p.click('#ed [type=submit]'); const a = await toastSeen(p, 900);
    await p.click('#edCancel'); await p.evaluate(() => location.hash = 'invoices'); await p.waitForTimeout(200); await p.click('#lNew'); await p.selectOption('#ed [name=party]', { label: 'HIMA' }); await p.fill('#ed .d', 'x'); await p.fill('#ed .p', '10');
    const nm = await p.evaluate(loc + 'const d=new Date();d.setDate(1);d.setMonth(d.getMonth()+1);f(d)'); await p.fill('#ed [name=date]', nm); await p.click('#ed [type=submit]'); const b = await toastSeen(p, 900);
    assert(a.some(t => /future/.test(t)), 'future receipt allowed'); assert(b.some(t => /future month/.test(t)), 'next-month invoice allowed'); assert(!(await docs(p, 'receipts/')).length && !(await docs(p, 'invoices/')).length, 'saved');
    await p.close(); return 'both refused';
  });

  await test('E-17', 'Every report tab renders from posted data without errors (balance sheet defect found in review)', async () => {
    const { p, errs } = await single({}, BASE_SEED, 'purchases'); await buyStock(p, 'cem', 10, 30000); await sell(p, [['cem', 4, 40000], [null, 1, 50000, 'Labour']]); await p.click('#mBtns >> text=Close');
    await p.evaluate(() => location.hash = 'accounts'); await p.waitForTimeout(300); const seen = {};
    for (const t of ['tb', 'pl', 'bs', 'vat', 'gl', 'chk']) { await p.click(`#acTabs [data-t=${t}]`); await p.waitForTimeout(150); seen[t] = await p.textContent('#acBody'); }
    assert(!errs.length, errs.join(';')); assert(/Total assets/.test(seen.bs) && /Total equity/.test(seen.bs) && /Assets = liabilities \+ equity/.test(seen.bs), 'balance sheet: ' + seen.bs.slice(0, 120));
    assert(/Net profit/.test(seen.pl) && /VAT payable|refundable/.test(seen.vat) && /All checks passed/.test(seen.chk) && /Debits equal credits/.test(seen.tb), 'a tab is wrong');
    await p.click('#acTabs [data-t=gl]'); await p.selectOption('#acAcct', '1200'); await p.waitForTimeout(150); assert((await p.$$('#acBody tbody tr')).length === 2, 'GL rows');
    await p.close(); return '6 tabs rendered; balance sheet balances';
  });
  /* ---------- Database integrity: failure simulations ---------- */
  async function four(delay = 150) {
    const p = await browser.newPage({ viewport: { width: 2600, height: 1960 } }); const errs = []; p.on('pageerror', e => errs.push(e.message));
    await p.addInitScript(`${MOCK};if(window!==window.top)window.__mock({delay:${delay}});`); await p.goto(BASE + 'four.html'); await p.waitForTimeout(1500);
    return { p, fr: p.frames().filter(f => f.url().includes('index')), errs };
  }
  const seedTop = (p, seed) => p.evaluate(seed => { const st = window.__S; new Function('st', seed)(st); for (const l of window.__L) l.fire(); }, seed);
  const lastToasts = async (f, ms = 1500) => toastSeen(f, ms);

  await test('D-01', 'A save whose lease lapsed (stalled past 60 s, taken over by another user) writes nothing', async () => {
    const { p } = await single({}, BASE_SEED + `st.set("invoices/i",{number:"INV-0001",date:"2026-11-01",clientId:"c",items:[{desc:"x",qty:1,price:1000}]});`, 'invoices');
    await p.click('#lRows tr[data-id=i]'); await p.click('#mBtns >> text=Receive payment'); await p.fill('#ed [name=amount]', '600');
    await p.evaluate(() => window.top.__steal = 'invoices/'); await p.click('#ed [type=submit]'); const seen = await lastToasts(p, 1500); await p.evaluate(() => window.top.__steal = '');
    const n = (await docs(p, 'receipts/')).length, stolen = await p.evaluate(() => window.top.__stolen);
    assert(stolen > 0, 'lease was never re-checked'); assert(n === 0, n + ' receipts written after the lease was lost'); assert(seen.some(t => /took too long/.test(t)), 'no message: ' + seen);
    await p.close(); return 'lease re-check failed → nothing written, user told to retry';
  });
  await test('D-02', 'Storage disconnects mid-posting (queries fail): nothing saved; retry after reconnect saves exactly once', async () => {
    const { p } = await single({}, BASE_SEED, 'purchases'); await buyStock(p, 'cem', 10, 30000, 0);
    await p.evaluate(() => location.hash = 'invoices'); await p.waitForTimeout(200); await p.click('#lNew'); await p.selectOption('#ed [name=party]', { label: 'HIMA' }); await p.selectOption('#ed .si', 'cem'); await p.fill('#ed .q', '4'); await p.fill('#ed .p', '40000');
    await p.evaluate(() => window.top.__failQuery = '*'); await p.click('#ed [type=submit]'); const seen = await lastToasts(p, 1500); await p.evaluate(() => window.top.__failQuery = '');
    assert(!(await docs(p, 'invoices/')).length, 'invoice written while disconnected'); assert(seen.some(t => /Couldn't save/.test(t)), 'no message ' + seen);
    await p.click('#ed [type=submit]'); await p.waitForTimeout(1300); const inv = await docs(p, 'invoices/'); assert(inv.length === 1 && inv[0].je, inv.length + ' invoices');
    const b = await clean(p); await p.close(); return 'refused while down; one posting after reconnect; books clean';
  });
  await test('D-03', 'Crash between the two writes of a proforma conversion: the link break is reported, a second conversion is refused, and it can be repaired', async () => {
    const { p } = await single({}, BASE_SEED + `st.set("proformas/f",{number:"PRO-0001",date:"2026-11-01",clientId:"c",status:"open",items:[{desc:"Works",qty:1,price:500000}]});`, 'proformas');
    await p.click('#lRows tr[data-id=f]'); await p.click('#mBtns >> text=Convert to invoice');
    await p.evaluate(() => window.top.__failPrefix = 'proformas/'); await p.click('#ed [type=submit]'); await p.waitForTimeout(22000); await p.evaluate(() => window.top.__failPrefix = '');
    const pf = await one(p, 'proformas/'); assert(pf.status === 'open' && (await docs(p, 'invoices/')).length === 1, 'setup: ' + pf.status);
    await p.waitForTimeout(1800); const b1 = await books(p); const integ = await p.evaluate(() => ledger().integ.errors.map(e => e.msg)); assert(integ.some(m => /made from it/.test(m)), 'not reported: ' + integ);
    await p.evaluate(() => showDoc('proformas', 'f')); await p.click('#mBtns >> text=Convert to invoice'); await p.click('#ed [type=submit]'); const warn = await lastToasts(p, 900);
    assert(warn.some(t => /duplicate of INV-0001/.test(t)), 'no duplicate warning'); await p.click('#ed [type=submit]'); const seen = await lastToasts(p, 1500);   // insist: the link guard must still refuse
    assert((await docs(p, 'invoices/')).length === 1 && seen.some(t => /already made from this proforma/.test(t)), 'converted twice: ' + seen);
    await p.click('#edCancel'); await p.evaluate(() => showDoc('proformas', 'f')); await p.click('#mBtns >> text=/Mark converted/'); await p.waitForTimeout(800);
    await p.waitForTimeout(1800); const b2 = await books(p); assert(b2.problems === 0, 'not clean after repair ' + JSON.stringify(b2)); await p.close(); return 'reported; 2nd conversion refused; repaired by Mark converted';
  });
  await test('D-04', 'Crash between voiding a purchase and reopening its LPO: reported, and Reopen repairs it', async () => {
    const { p } = await single({}, BASE_SEED + `st.set("lpos/l",{number:"LPO-0001",date:"2026-11-01",supplierId:"s",status:"open",items:[{desc:"Bars",qty:1,price:1000}]});`, 'lpos');
    await p.click('#lRows tr[data-id=l]'); await p.click('#mBtns >> text=Convert to purchase'); await p.click('#ed [type=submit]'); await p.waitForTimeout(1300);
    const pid = (await one(p, 'purchases/')).id.split('/')[1]; await p.evaluate(id => startVoid('purchases', id), pid); await p.fill('#vd [name=reason]', 'wrong');
    await p.evaluate(() => window.top.__failPrefix = 'lpos/'); await p.click('#vd [type=submit]'); await p.waitForTimeout(22000); await p.evaluate(() => window.top.__failPrefix = '');
    assert((await one(p, 'purchases/')).void && (await one(p, 'lpos/')).status === 'received', 'setup');
    await p.waitForTimeout(1800); const integ = await p.evaluate(() => ledger().integ.errors.map(e => e.msg)); assert(integ.some(m => /missing or void/.test(m)), 'not reported ' + integ);
    await p.evaluate(() => showDoc('lpos', 'l')); await p.click('#mBtns >> text=/Reopen/'); await p.waitForTimeout(1800);
    assert((await one(p, 'lpos/')).status === 'open' && (await books(p)).problems === 0, 'not repaired'); await p.close(); return 'reported; reopened; books clean';
  });
  await test('D-05', 'Browser crashes after taking the lease but before writing: no partial record; others proceed once the lease expires', async () => {
    const { p, fa, fb } = await two(1500);
    await seedTop(p, BASE_SEED + `st.set("invoices/i",{number:"INV-0001",date:"2026-11-01",clientId:"c",items:[{desc:"x",qty:1,price:1000}]});`); await p.waitForTimeout(6000);
    await fa.evaluate(() => location.hash = 'invoices'); await fa.waitForTimeout(400); await fa.click('#lRows tr[data-id=i]'); await fa.click('#mBtns >> text=Receive payment'); await fa.fill('#ed [name=amount]', '1000');
    fa.click('#ed [type=submit]').catch(() => {}); await p.waitForTimeout(9500);   // number taken, leases held, write not yet sent
    const held = await p.evaluate(() => [...window.__Le.entries()].filter(([k, v]) => k === 'invoices/i' && v.exp > Date.now() + 30000).length); await p.evaluate(() => document.querySelector('iframe').src = 'about:blank'); await p.waitForTimeout(3000);
    assert(!(await docs(p, 'receipts/')).length, 'partial write'); assert(held === 1, 'lease not held at crash time');
    await fb.evaluate(() => location.hash = 'invoices'); await fb.waitForTimeout(400); await fb.click('#lRows tr[data-id=i]'); await fb.click('#mBtns >> text=Receive payment'); await fb.fill('#ed [name=amount]', '1000');
    await p.evaluate(() => { for (const v of window.__Le.values()) v.exp = Date.now() - 1; });   // fast-forward the 60 s lease expiry
    await fb.click('#ed [type=submit]'); await p.waitForTimeout(26000); const r = await docs(p, 'receipts/'); assert(r.length === 1 && r[0].amount === 1000, 'receipts ' + r.length);
    await p.close(); return 'nothing written by the crashed user; the other user saved after expiry (real wait: 60 s)';
  });
  await test('D-06', 'Four users at once: same invoice paid in full by all four, then 30 bags each from 100 — one payment, three sales, books consistent', async () => {
    const { p, fr } = await four(150);
    await seedTop(p, BASE_SEED + `st.set("invoices/i",{number:"INV-0001",date:"2026-11-01",clientId:"c",items:[{desc:"x",qty:1,price:1000}]});`); await p.waitForTimeout(2500);
    await fr[0].evaluate(() => { const d = S.invoices.find(x => x.id === 'i'); const r = LEDGER.post('invoices', d, { dp: 0, stock: {} }); const je = LEDGER.makeJE('invoices', 'i', d, r.lines, { cur: 'UGX', dp: 0, at: new Date().toISOString(), by: 'u1' });
      const T = window.top; T.__S.set('invoices/i', { ...T.__S.get('invoices/i'), je, stockItems: [] }); for (const l of T.__L) l.fire(); }); await p.waitForTimeout(1500);   // seed it as a posted invoice
    for (const f of fr) { await f.evaluate(() => location.hash = 'invoices'); await f.waitForTimeout(300); await f.click('#lRows tr[data-id=i]'); await f.click('#mBtns >> text=Receive payment'); await f.fill('#ed [name=amount]', '1000'); }
    const sub = f => f.evaluate(() => document.querySelector('#ed').requestSubmit());   // lower frames sit outside the test viewport
    await Promise.all(fr.map(sub)); await p.waitForTimeout(15000);
    const rec = await docs(p, 'receipts/'); assert(rec.length === 1, rec.length + ' receipts for one invoice');
    for (const f of fr) await closeAll(f);
    await buyStock(fr[0], 'cem', 100, 30000, 0); await p.waitForTimeout(3000);
    for (const f of fr) { await f.evaluate(() => location.hash = 'invoices'); await f.waitForTimeout(300); await f.evaluate(() => document.querySelector('#lNew').click()); await f.waitForTimeout(200);
      await f.evaluate(() => { const set = (s, v) => { const e = document.querySelector(s); e.value = v; e.dispatchEvent(new Event('input', { bubbles: true })); e.dispatchEvent(new Event('change', { bubbles: true })); };
        const ps = document.querySelector('#ed [name=party]'); ps.value = [...ps.options].find(o => o.text === 'HIMA').value; ps.dispatchEvent(new Event('change', { bubbles: true })); set('#ed .si', 'cem'); set('#ed .q', '30'); set('#ed .p', '40000'); }); }
    await Promise.all(fr.map(sub)); await p.waitForTimeout(25000);
    const inv = (await docs(p, 'invoices/')).filter(x => x.je && x.je.lines.some(l => l.a === '1200')); assert(inv.length === 3, inv.length + ' stock sales');
    const nums = (await docs(p, 'invoices/')).map(x => x.number); assert(new Set(nums).size === nums.length, 'duplicate invoice numbers');
    await fr[1].waitForTimeout(2500); const b = await clean(fr[1]); assert(b.stock.cem.q === 10e6, 'stock ' + JSON.stringify(b.stock.cem));
    const integ = await fr[2].evaluate(() => ledger().integ.errors.length); assert(integ === 0, 'integrity errors'); await p.close(); return '1 of 4 payments; 3 of 4 sales; 10 bags left; numbers unique; all checks pass';
  });
  await test('D-07', 'Lost updates: two users editing the same client, and the business details, at once — the later save is refused, nothing silently overwritten', async () => {
    const { p, fa, fb } = await two(200); await seedTop(p, BASE_SEED); await p.waitForTimeout(2000);
    for (const f of [fa, fb]) { await f.evaluate(() => showParty('clients', 'c')); await f.click('#mBtns >> text=Edit'); }
    await fa.fill('#ed [name=phone]', '0700 111111'); await fb.fill('#ed [name=email]', 'b@hima.ug'); await fa.click('#ed [type=submit]'); await p.waitForTimeout(3000); await fb.click('#ed [type=submit]'); const seen = await lastToasts(fb, 2500);
    const c = (await docs(p, 'clients/'))[0]; assert(c.phone === '0700 111111' && !c.email, 'client ' + JSON.stringify(c)); assert(seen.some(t => /changed this client/.test(t)), 'no refusal ' + seen);
    for (const f of [fa, fb]) await f.evaluate(() => { document.querySelector('#modal').classList.remove('on'); location.hash = 'settings'; }); await p.waitForTimeout(500);
    await fa.fill('#fSettings [name=phone]', '111'); await fb.fill('#fSettings [name=email]', 'x@y.z'); await fa.evaluate(() => document.querySelector('#fSettings').requestSubmit()); await p.waitForTimeout(3000); await fb.evaluate(() => document.querySelector('#fSettings').requestSubmit()); const s2 = await lastToasts(fb, 2500);
    const st = await p.evaluate(() => window.__S.get('settings/business')); assert(st.phone === '111' && !st.email && s2.some(t => /changed the business details/.test(t)), 'settings ' + JSON.stringify(st) + s2);
    await p.close(); return 'second save refused both times; first change kept';
  });
  await test('D-08', 'Deleting a client while another user invoices them: never an invoice for a missing client', async () => {
    const results = [];
    for (let k = 0; k < 2; k++) { const { p, fa, fb } = await two(250); await seedTop(p, `st.set("clients/z",{name:"Zed Ltd"});`); await p.waitForTimeout(2000);
      await fa.evaluate(() => showParty('clients', 'z')); await fa.click('#mBtns >> text=Delete');
      await fb.evaluate(() => location.hash = 'invoices'); await fb.waitForTimeout(300); await fb.click('#lNew'); await fb.selectOption('#ed [name=party]', { label: 'Zed Ltd' }); await fb.fill('#ed .d', 'x'); await fb.fill('#ed .p', '100');
      if (k === 0) await Promise.all([fa.click('#mYes'), fb.click('#ed [type=submit]')]); else await Promise.all([fb.click('#ed [type=submit]'), fa.click('#mYes')]);
      await p.waitForTimeout(12000); const cl = await docs(p, 'clients/'), inv = await docs(p, 'invoices/');
      assert(!(inv.length && !cl.length), 'orphan invoice: client deleted but invoice saved'); results.push(cl.length ? 'client kept, invoice saved' : 'client deleted, invoice refused'); await p.close(); }
    return results.join('; ');
  });
  await test('D-09', 'Backup → total loss → restore: every record, journal and counter comes back identical; a damaged backup is refused', async () => {
    const { p } = await single({}, BASE_SEED, 'purchases'); await buyStock(p, 'cem', 10, 30000); await sell(p, [['cem', 4, 40000]]); await clk(p,'#mBtns >> text=Receive payment'); await clk(p,'#ed [type=submit]'); await p.waitForTimeout(1200);
    const rid = (await one(p, 'receipts/')).id.split('/')[1]; await p.evaluate(id => startVoid('receipts', id), rid); await p.fill('#vd [name=reason]', 'bounced'); await clk(p,'#vd [type=submit]'); await p.waitForTimeout(1200);
    // audit logs are per person and, by design, can't be written by anyone else (so a restore can't recreate them); everything else must come back
    const before = await p.evaluate(() => JSON.stringify([...window.__S.entries()].filter(([k]) => !k.startsWith('settings/') && !k.startsWith('audit/')).sort()));
    await closeAll(p); await p.evaluate(() => location.hash = 'settings'); await p.waitForTimeout(300); await clk(p,'#bkDown'); await p.waitForTimeout(1500); const file = await p.evaluate(() => window.__lastDownload); assert(file && /"manifest"/.test(file.data), 'no manifest');
    await p.close();
    const { p: q } = await single({}, `st.set("settings/business",{name:"Irongrid",currency:"UGX"});`, 'settings');      // a brand-new, empty database
    const restore = async (text) => { await q.evaluate(t => { const dt = new DataTransfer(); dt.items.add(new File([t], 'b.json', { type: 'application/json' })); const i = document.querySelector('#bkFile'); i.files = dt.files; i.dispatchEvent(new Event('change')); }, text); await q.waitForTimeout(1500); };
    const bad = file.data.replace(/"amount":(\d+)/, (m, n) => '"amount":' + (+n + 1)); await restore(bad); const sBad = await toastSeen(q, 800);
    assert(!(await q.$('#rsGo')) && (await q.evaluate(() => [...window.__S.keys()].length)) === 1, 'damaged backup was accepted');
    await restore(file.data); await clk(q,'#rsGo'); await q.waitForTimeout(4000);
    const after = await q.evaluate(() => JSON.stringify([...window.__S.entries()].filter(([k]) => !k.startsWith('settings/') && !k.startsWith('audit/')).sort()));
    const strip = s => JSON.parse(s).map(([k, v]) => [k, v]); const A = strip(before), B = strip(after);
    const diff = A.filter(([k, v], i) => !B[i] || B[i][0] !== k || JSON.stringify(v) !== JSON.stringify(B[i][1])).map(x => x[0]); assert(!diff.length, 'restored differently: ' + diff.join(', '));
    await q.waitForTimeout(1800); const b = await clean(q); await q.close(); return `${A.length} records restored byte-identical (incl. ${b.n} journals, counters); tampered file refused`;
  });
  await test('D-10', 'The same receipt entered twice by mistake is caught before saving', async () => {
    const { p } = await single({}, BASE_SEED, 'receipts');
    for (let k = 0; k < 2; k++) { await p.click('#lNew'); await p.selectOption('#ed [name=party]', { label: 'HIMA' }); await p.fill('#ed [name=amount]', '250000'); await p.click('#ed [type=submit]'); await p.waitForTimeout(1300); if (k === 0) await p.click('#mBtns >> text=Close'); }
    const seen = await lastToasts(p, 500); const n1 = (await docs(p, 'receipts/')).length; assert(n1 === 1, n1 + ' receipts after the warning');
    await p.click('#ed [type=submit]'); await p.waitForTimeout(1300); const n2 = (await docs(p, 'receipts/')).length; assert(n2 === 2, 'second press did not save');
    await p.close(); return 'warned on first press; saved only when pressed again';
  });
  await test('D-11', 'Posting documents saved before the ledger: dry run, blocked without a backup, posts without changing any field, and undo restores them exactly', async () => {
    const legacy = `st.set("settings/business",{name:"Irongrid",currency:"UGX"});st.set("clients/mw",{name:"HIMA"});st.set("invoices/inv1",{clientId:"mw",createdAt:"2026-11-03T20:55:25.302Z",date:"2026-11-03",dueDate:"2026-12-03",items:[{desc:"CEMENT",price:50000,qty:40,unit:""}],notes:"",number:"INV-0001",proformaId:null,reference:"",total:2000000,vatRate:0});st.set("receipts/rc1",{amount:2000000,clientId:"mw",date:"2026-11-03",invoiceId:"inv1",method:"Cash",notes:"",number:"RCT-0001",reference:""});`;
    const { p } = await single({}, legacy, 'accounts'); await p.waitForTimeout(1800);
    const orig = await p.evaluate(() => ({ i: window.__S.get('invoices/inv1'), r: window.__S.get('receipts/rc1') }));
    const b0 = await books(p); assert(b0.issues.filter(m => /Not posted/.test(m)).length === 2 && b0.recon.some(x => /Cash on hand/.test(x)), 'legacy not reported ' + JSON.stringify(b0));
    await p.click('#acTabs [data-t=chk]'); await p.click('#lgPreview'); await p.waitForTimeout(300); const txt = await p.textContent('#mBody');
    assert(/dry run/.test(txt) && /Dr 1100/.test(txt) && /Cr 4000/.test(txt) && /Dr 1000/.test(txt), 'preview ' + txt.slice(0, 200)); assert(await p.isDisabled('#lgGo'), 'posting allowed without a backup');
    await p.click('#lgClose'); await p.evaluate(() => location.hash = 'settings'); await p.waitForTimeout(300); await p.click('#bkDown'); await p.waitForTimeout(1500);
    await p.evaluate(() => location.hash = 'accounts'); await p.waitForTimeout(300); await p.click('#acTabs [data-t=chk]'); await p.click('#lgPreview'); await p.click('#lgGo'); await p.waitForTimeout(3000);
    const now = await p.evaluate(() => ({ i: window.__S.get('invoices/inv1'), r: window.__S.get('receipts/rc1') }));
    for (const k of ['i', 'r']) { const { je, stockItems, postedLater, updatedAt, updatedBy, ...rest } = now[k]; const { updatedAt: u0, updatedBy: b0x, ...o } = orig[k]; assert(JSON.stringify(rest) === JSON.stringify(o), 'a field changed on ' + k); assert(je && postedLater, 'not posted ' + k); }
    await p.waitForTimeout(1800); await clean(p);
    const u = await p.evaluate(() => undoLegacy()); assert(u.ok === 2, 'undo ' + JSON.stringify(u)); await p.waitForTimeout(500);
    const back = await p.evaluate(() => ({ i: window.__S.get('invoices/inv1'), r: window.__S.get('receipts/rc1') }));
    for (const k of ['i', 'r']) assert(JSON.stringify(back[k]) === JSON.stringify(orig[k]), 'undo left ' + k + ' different: ' + JSON.stringify(back[k]));
    await p.close(); return 'preview shown; blocked until backup; posted (Dr 1100/Cr 4000, Dr 1000/Cr 1100), books clean; undo restored both exactly';
  });

  /* ---------- Security, authorization, month-end and input-validation tests ---------- */
  await test('S-01', 'UNAUTHORIZED APPROVALS: a Contributor cannot post a void, credit note, refund or stock adjustment, run legacy posting, or change business details — each becomes a request at most, and nothing is posted even by calling the code directly', async () => {
    const { p } = await single({ noAdmin: true, uid: 'u2' }, BASE_SEED + `st.set("receipts/r",{number:"RCT-0001",date:"2026-11-01",clientId:"c",amount:500,method:"Cash"});st.set("invoices/i",{number:"INV-0001",date:"2026-11-01",clientId:"c",items:[{desc:"x",qty:1,price:1000}]});`, 'invoices');
    await p.waitForTimeout(500); const snap = () => p.evaluate(() => JSON.stringify([...window.__S.entries()].filter(([k]) => !/^(requests|audit)\//.test(k)).sort()));
    const before = await snap();
    // forms a Contributor may open now only send a request
    await p.evaluate(() => startVoid('receipts', 'r')); await p.waitForTimeout(200); await p.fill('#vd [name=reason]', 'test'); await p.click('#vd [type=submit]'); await p.waitForTimeout(900);
    await p.evaluate(() => openCreditNote('i')); await p.waitForTimeout(200); await p.fill('#cn [name=reason]', 'test'); await p.click('#cn [type=submit]'); await p.waitForTimeout(900);
    await p.evaluate(() => openAdjust('cem')); await p.waitForTimeout(200); await p.fill('#aj [name=qty]', '-1'); await p.fill('#aj [name=reason]', 'test'); await p.click('#aj [type=submit]'); await p.waitForTimeout(900);
    await p.evaluate(() => { try { openNote('debits', { clientId: 'c' }) } catch (e) {} }); await p.waitForTimeout(150); assert(!(await p.isVisible('#dn')), 'debit note form opened for a Contributor');
    const r1 = await p.evaluate(async () => { try { await runLegacy(legacyPlan()); return 'ran' } catch (e) { return e.message } }); const r2 = await p.evaluate(async () => { try { await undoLegacy(); return 'ran' } catch (e) { return e.message } });
    assert(/Only the owner/.test(r1) && /Only the owner/.test(r2), 'legacy posting allowed: ' + r1 + ' / ' + r2);
    await p.evaluate(() => { location.hash = 'settings'; document.querySelectorAll('#fSettings input').forEach(e => e.disabled = false); document.querySelector('#fSettings [name=lockDate]').value = '2026-12-31'; document.querySelector('#fSettings').requestSubmit(); }); await p.waitForTimeout(900);
    // calling the save functions directly: the storage rules refuse owner-only collections and business details
    const direct = await p.evaluate(async () => [await put('payments', 'zz', { number: 'PAY-9', date: '2026-11-02', amount: 1, method: 'Cash', category: 'Utilities' }), await put('credits', 'zz', { number: 'CRN-9' }), await put('adjustments', 'zz', { number: 'ADJ-9' }), await put('refunds', 'zz', { number: 'RFD-9' })]);
    assert(direct.every(x => x === false), 'a direct write succeeded: ' + direct);
    const reqs = await p.evaluate(() => (window.__S.get('requests/u2') || {}).list || []);
    assert((await snap()) === before, 'the books changed'); assert(reqs.length === 4 && reqs.map(q => q.type + ':' + q.coll).sort().join() === 'post:adjustments,post:credits,settings:settings,void:receipts', 'requests ' + JSON.stringify(reqs.map(q => q.type + ':' + q.coll)));
    await p.close(); return 'void, credit note, adjustment and lock change became 4 requests; debit note, legacy posting and 4 direct writes refused; books unchanged';
  });
  await test('S-02', 'View-only users cannot write anything, even by calling the save functions directly', async () => {
    const { p } = await single({ readOnly: true }, BASE_SEED, 'clients'); await p.waitForTimeout(400); const before = await p.evaluate(() => [...window.__S.keys()].length);
    const r = await p.evaluate(async () => [await put('clients', 'zz', { name: 'Hacker' }), await patch('clients', 'c', { name: 'Changed' }), await remove('clients', 'c')]);
    assert(r.every(x => x === false), 'a write returned ' + r); assert((await p.evaluate(() => [...window.__S.keys()].length)) === before && (await p.evaluate(() => window.__S.get('clients/c').name)) === 'HIMA', 'database changed');
    await p.close(); return 'put/patch/remove refused';
  });
  await test('S-03', 'Hostile text in every new field (items, reasons, references) is shown as text everywhere — no script runs, no HTML injected', async () => {
    const X = `<img src=x onerror=window.__xss=1>`;
    const { p, errs } = await single({}, BASE_SEED + `st.set("items/evil",{name:${JSON.stringify(X)},unit:${JSON.stringify(X)}});st.set("clients/e",{name:${JSON.stringify(X)}});`, 'purchases');
    await buyStock(p, 'evil', 5, 1000, 0); await p.evaluate(() => location.hash = 'refunds'); await p.waitForTimeout(200);
    await p.evaluate(X => { const s = window.__S; s.set('adjustments/a', { number: 'ADJ-0001', date: '2026-11-04', itemId: 'evil', qty: 1, value: 0, reason: X }); s.set('debits/d', { number: 'DBN-0001', date: '2026-11-04', clientId: 'e', reason: X, items: [{ desc: X, qty: 1, price: 1 }] }); for (const l of window.__L) l.fire(); }, X);
    for (const h of ['stock', 'adjustments', 'debits', 'accounts']) { await p.evaluate(h => location.hash = h, h); await p.waitForTimeout(300); }
    for (const t of ['tb', 'gl', 'chk']) { await p.click(`#acTabs [data-t=${t}]`); await p.waitForTimeout(150); }
    await p.evaluate(() => { showItem('evil'); }); await p.waitForTimeout(200); await p.evaluate(() => { showDoc('debits', 'd'); }); await p.waitForTimeout(200); await p.evaluate(() => { showDoc('adjustments', 'a'); }); await p.waitForTimeout(200);
    const injected = await p.evaluate(() => document.querySelectorAll('img[src="x"]').length); const ran = await p.evaluate(() => window.__xss);
    assert(!ran && !injected, `script ran: ${ran}, injected images: ${injected}`); assert(!errs.length, errs.join(';')); await p.close(); return 'nothing executed across 9 screens';
  });
  await test('S-04', 'Spreadsheet formula injection is neutralised in the accounts CSV export', async () => {
    const { p } = await single({}, BASE_SEED + `st.set("items/f",{name:"=HYPERLINK(\\"http://evil\\",\\"x\\")",unit:"u"});`, 'purchases'); await buyStock(p, 'f', 2, 100, 0);
    await p.evaluate(() => location.hash = 'accounts'); await p.waitForTimeout(300); await p.click('#acTabs [data-t=pl]'); await p.click('#acCsv'); await p.waitForTimeout(600);
    const csv = (await p.evaluate(() => window.__lastDownload)).data; assert(/'=HYPERLINK/.test(csv) && !/(^|,)"?=HYPERLINK/m.test(csv), 'formula not neutralised'); await p.close(); return 'prefixed with an apostrophe';
  });
  await test('S-05', 'A crafted backup cannot pollute the page (prototype keys) or inject records with bad ids', async () => {
    const { p } = await single({}, `st.set("settings/business",{name:"Irongrid",currency:"UGX"});`, 'settings');
    const file = JSON.stringify({ app: 'business-manager', format: 1, exportedAt: '2026-11-04T00:00:00Z', currency: 'UGX', data: { clients: [{ id: 'ok1', name: 'Good' }, { id: '../../settings/business', name: 'Path trick' }, { id: 'p2', name: 'Proto', __proto__: { polluted: 1 }, constructor: { prototype: { polluted: 1 } } }] } }).replace('"name":"Proto"', '"name":"Proto","__proto__":{"polluted":1}');
    await p.evaluate(t => { const dt = new DataTransfer(); dt.items.add(new File([t], 'b.json')); const i = document.querySelector('#bkFile'); i.files = dt.files; i.dispatchEvent(new Event('change')); }, file); await p.waitForTimeout(1200);
    if (await p.$('#rsGo')) { await p.click('#rsGo'); await p.waitForTimeout(2000); }
    const keys = await p.evaluate(() => [...window.__S.keys()]); const polluted = await p.evaluate(() => ({}).polluted);
    assert(!polluted, 'Object.prototype polluted'); assert(!keys.some(k => k.includes('..')), 'path-trick id written: ' + keys); assert(keys.includes('clients/ok1'), 'good record not restored'); await p.close(); return 'bad id skipped; no pollution';
  });
  await test('M-01', 'MONTH-END CLOSE: once October is locked, nothing can be dated in October, and October\'s figures never change — even when an October receipt is voided in November', async () => {
    const { p } = await single({}, BASE_SEED, 'receipts');
    await p.click('#lNew'); await p.selectOption('#ed [name=party]', { label: 'HIMA' }); await p.fill('#ed [name=amount]', '300000'); await p.fill('#ed [name=date]', '2026-10-20'); await p.click('#ed [type=submit]'); await p.waitForTimeout(1200); await closeAll(p);
    const octTB = async () => p.evaluate(() => JSON.stringify(LEDGER.trialBalance(ledger().J, '2026-10-31')));
    const before = await octTB(); await p.evaluate(() => { location.hash = 'settings' }); await p.waitForTimeout(300); await p.fill('#fSettings [name=lockDate]', '2026-10-31'); await p.evaluate(() => document.querySelector('#fSettings').requestSubmit()); await p.waitForTimeout(1000);
    await p.evaluate(() => location.hash = 'receipts'); await p.waitForTimeout(300); await p.click('#lNew'); await p.selectOption('#ed [name=party]', { label: 'HIMA' }); await p.fill('#ed [name=amount]', '1000'); await p.fill('#ed [name=date]', '2026-10-31'); await p.click('#ed [type=submit]'); const s1 = await toastSeen(p, 900);
    assert(s1.some(t => /locked up to/.test(t)), 'October posting allowed after close'); await p.click('#edCancel');
    const rid = (await one(p, 'receipts/')).id.split('/')[1]; await p.evaluate(id => startVoid('receipts', id), rid); await p.fill('#vd [name=reason]', 'bounced'); await p.click('#vd [type=submit]'); await p.waitForTimeout(1300);
    assert((await one(p, 'receipts/')).jr.date > '2026-10-31', 'reversal dated inside the closed month'); await p.waitForTimeout(1800);
    assert((await octTB()) === before, 'October trial balance changed after close'); await clean(p); await p.close(); return 'Oct posting refused; Nov void left October identical';
  });
  await test('N-01', 'NEGATIVE VALUES: an invoice with a negative quantity or price is refused in the app', async () => {
    const { p } = await single({}, BASE_SEED, 'invoices'); await p.click('#lNew'); await p.selectOption('#ed [name=party]', { label: 'HIMA' });
    await p.fill('#ed .d', 'Works'); await p.fill('#ed .q', '10'); await p.fill('#ed .p', '1000'); await p.click('#ed .addLine'); const rows = await p.$$('#ed .iRows tr'); await (await rows[1].$('.d')).fill('Hidden discount'); await (await rows[1].$('.q')).fill('-5'); await (await rows[1].$('.p')).fill('1000');
    await p.click('#ed [type=submit]'); await p.waitForTimeout(600);
    const blocked = await (await rows[1].$('.q')).evaluate(e => !e.validity.valid); assert(blocked && !(await docs(p, 'invoices/')).length, 'layer 1: the form accepted a negative quantity');
    // layer 2: remove the browser's own check (as a script or old browser could); the app must still refuse
    await p.evaluate(() => document.querySelectorAll('#ed input[min]').forEach(e => e.removeAttribute('min')));
    await p.click('#ed [type=submit]'); const seen = await toastSeen(p, 1000); assert(seen.some(t => /negative/.test(t)) && !(await docs(p, 'invoices/')).length, 'layer 2: negative line saved: ' + seen);
    await (await rows[1].$('.q')).fill('5'); await (await rows[1].$('.p')).fill('-1000'); await p.click('#ed [type=submit]'); const s2 = await toastSeen(p, 1000); assert(s2.some(t => /negative/.test(t)) && !(await docs(p, 'invoices/')).length, 'negative price saved');
    await p.close(); return 'refused by the form and, with that bypassed, by the app (quantity and price)';
  });
  await test('N-02', 'INVALID DATES: a stored document with an impossible date (30 Feb) is reported by the books check', async () => {
    const { p } = await single({}, BASE_SEED, 'accounts'); await p.waitForTimeout(400);
    await p.evaluate(() => { const d = { number: 'RCT-0009', date: '2026-02-30', clientId: 'c', amount: 1000, method: 'Cash' }; const r = { lines: [{ a: '1000', d: 1000, c: 0 }, { a: '1100', d: 0, c: 1000, p: 'c' }] };
      const je = LEDGER.makeJE('receipts', 'bad', d, r.lines, { cur: 'UGX', dp: 0, at: new Date().toISOString() }); window.__S.set('receipts/bad', { ...d, je }); for (const l of window.__L) l.fire(); });
    await p.waitForTimeout(2200); const b = await books(p); assert(b.problems > 0 && b.issues.some(m => /date/i.test(m)), 'impossible date not reported: ' + JSON.stringify(b.issues)); await p.close(); return b.issues.find(m => /date/i.test(m));
  });

  await browser.close();
  const passed = results.filter(r => r.pass).length;
  console.log(`\n${passed}/${results.length} passed`);
  fs.writeFileSync(__dirname + '/results.json', JSON.stringify({ ranAt: new Date().toISOString(), passed, total: results.length, results }, null, 1));
  if (process.env.COVERAGE) { const c = writeBrowserCoverage(); if (c) console.log('browser coverage — posting layer: ' + c.postingLayer_accountsJs.executedPct + '% of code, ' + c.postingLayer_accountsJs.functionsPct + '% of functions; whole app: ' + c.wholeApp.executedPct + '%'); }
  process.exit(passed === results.length ? 0 : 1);
})();
