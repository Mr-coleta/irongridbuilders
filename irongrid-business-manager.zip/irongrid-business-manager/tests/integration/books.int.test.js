// INTEGRATION TESTS — two months of synthetic trading posted through the engine, checked against an
// independent oracle (plain integer arithmetic written separately from the engine). Covers sales, purchases,
// receipts (partial, advance, in goods), supplier payments, credit/debit notes, refunds, stock adjustments,
// voids, VAT, reports, month-end cut-off and closed-period immutability, and bank reconciliation.
'use strict';
const { describe, it } = require('node:test');
const assert = require('node:assert/strict');
const L = require(process.env.LEDGER_PATH || '../../engine/ledger.js');
const { generator } = require('../data/synthetic.js');

// ---------- independent oracle arithmetic (deliberately NOT using the engine) ----------
const B = BigInt;
const halfUp = (num, den) => { const neg = (num < 0n) !== (den < 0n); const a = num < 0n ? -num : num, d = den < 0n ? -den : den; const q = (a * 2n + d) / (2n * d); return neg ? -q : q; };
// qty may be a quarter (0.25 steps), prices are whole shillings (UGX) or cents (USD, already in minor units here)
const lineMinor = (qty, priceMinor) => halfUp(B(Math.round(qty * 4)) * B(priceMinor), 4n);
function docTotals(lines, vatPct, dp) { let sub = 0n; for (const l of lines) sub += B(Math.round(l.qty * 4)) * B(l.pm); sub = halfUp(sub, 4n); const vat = halfUp(sub * B(vatPct), 100n); return { sub: Number(sub), vat: Number(vat), total: Number(sub + vat) }; }
const major = (m, dp) => dp ? m / 100 : m;

function simulate(seed, dp = 0) {
  const g = generator(seed); const dps = dp ? 100 : 1;
  const docs = [], stock = {}, counts = {}; let n = 0, ids = 0;
  const O = { ar: {}, ap: {}, vatOut: { '2026-10': 0, '2026-11': 0 }, vatIn: { '2026-10': 0, '2026-11': 0 }, sales: 0, cogs: 0, losses: 0, gains: 0, cash: {}, stock: {}, invoices: [], purchases: [], expenses: 0 };
  const add = (m, k, v) => { m[k] = (m[k] || 0) + v; };
  const at = () => new Date(Date.UTC(2026, 11, 1) + (n++) * 1000).toISOString();
  const postDoc = (coll, d, extra = {}) => { const id = coll[0] + (ids++); const r = L.post(coll, d, { dp, stock, ...extra }); if (r.err) return { err: r.err };
    L.numberStock(r.lines, counts); for (const l of r.lines) if (l.a === '1200' && l.i) counts[l.i] = l.n + 1; Object.assign(stock, r.stockAfter);
    const je = L.makeJE(coll, id, d, r.lines, { cur: dp ? 'USD' : 'UGX', dp, at: at(), by: 'sim' }); const e = { coll, id, doc: { ...d, je } }; docs.push(e); return e; };
  const voidDoc = (e, date) => { const r = L.reverse(e.doc.je, stock); if (r.err) return r; L.numberStock(r.lines, counts); for (const l of r.lines) if (l.a === '1200' && l.i) counts[l.i] = l.n + 1; Object.assign(stock, r.stockAfter);
    e.doc = { ...e.doc, void: true, voidedAt: date, jr: L.makeRev(e.coll, e.id, e.doc, r.lines, { cur: 'UGX', dp, at: at(), by: 'sim', date, reason: 'sim' }) }; return e; };
  // oracle stock: moving average, rounding half up — written independently
  const oIn = (it, q4, v) => { const s = O.stock[it] || (O.stock[it] = { q4: 0n, v: 0n }); s.q4 += q4; s.v += B(v); };
  const oOut = (it, q4) => { const s = O.stock[it]; const c = q4 === s.q4 ? s.v : halfUp(s.v * q4, s.q4); s.q4 -= q4; s.v -= c; return Number(c); };
  const onHand = it => (O.stock[it] ? O.stock[it].q4 : 0n);
  const priceM = band => g.price(band) * dps + (dp ? g.int(0, 3) * 100 : 0);   // USD: whole dollars, so quarter quantities stay exact; cents come from VAT
  const days = []; for (const [mo, len] of [[10, 31], [11, 30]]) for (let d = 1; d <= len; d++) days.push(`2026-${mo}-${String(d).padStart(2, '0')}`);
  const snapshots = {};
  for (const date of days) {
    const ym = date.slice(0, 7); const events = g.int(1, 5);
    for (let k = 0; k < events; k++) {
      const roll = g.r();
      if (roll < 0.22) { // purchase of stock (+ sometimes a non-stock line)
        const s = g.pick(g.suppliers); const lines = []; for (let j = g.int(1, 2); j > 0; j--) { const it = g.pick(g.items); lines.push({ it: it.id, qty: g.qty(it), pm: priceM(it.buy) }); }
        const svc = g.r() < 0.3 ? { qty: 1, pm: g.int(50, 400) * 1000 * dps } : null; const all = svc ? [...lines, svc] : lines; const vat = g.r() < 0.85 ? 18 : 0; const t = docTotals(all, vat, dp);
        const d = { date, supplierId: s.id, vatRate: vat, account: 'Transport & fuel', items: all.map(l => ({ desc: l.it || 'Delivery', qty: l.qty, price: major(l.pm, dp), ...(l.it ? { itemId: l.it } : {}) })) };
        const e = postDoc('purchases', d); assert.ok(!e.err, e.err);
        // oracle: stock lines get their exact share; with whole-shilling lines the split equals the line amount
        for (const l of lines) oIn(l.it, B(Math.round(l.qty * 4)), Number(lineMinor(l.qty, l.pm)));
        add(O.ap, s.id, t.total); O.vatIn[ym] += t.vat; if (svc) O.expenses += Number(lineMinor(1, svc.pm)); O.purchases.push({ e, total: t.total, s: s.id, paid: 0 });
      } else if (roll < 0.47) { // sale: stock lines limited to what is on hand, plus services
        const c = g.pick(g.clients); const lines = [];
        for (let j = g.int(1, 2); j > 0; j--) { const it = g.pick(g.items); const want = B(Math.round(g.qty(it) * 4)); const have = onHand(it.id) - lines.filter(l => l.it === it.id).reduce((a, l) => a + B(Math.round(l.qty * 4)), 0n); if (have <= 0n) continue; const q4 = want < have ? want : have; lines.push({ it: it.id, qty: Number(q4) / 4, pm: priceM(it.sell) }); }
        if (!lines.length || g.r() < 0.3) lines.push({ qty: 1, pm: g.service().price * dps, desc: 'service' });
        const vat = g.r() < 0.9 ? 18 : 0; const t = docTotals(lines, vat, dp);
        const d = { date, clientId: c.id, vatRate: vat, items: lines.map(l => ({ desc: l.it || 'Service', qty: l.qty, price: major(l.pm, dp), ...(l.it ? { itemId: l.it } : {}) })) };
        const e = postDoc('invoices', d); assert.ok(!e.err, e.err + ' ' + JSON.stringify(d));
        const costs = {}; for (const l of lines) if (l.it) { const c0 = oOut(l.it, B(Math.round(l.qty * 4))); O.cogs += c0; costs[l.it] = (costs[l.it] || { q4: 0n, v: 0 }); costs[l.it].q4 += B(Math.round(l.qty * 4)); costs[l.it].v += c0; }
        add(O.ar, c.id, t.total); O.vatOut[ym] += t.vat; O.sales += t.sub; O.invoices.push({ e, total: t.total, c: c.id, costs, returned: {}, credited: 0 });
      } else if (roll < 0.62) { // receipt: part or full payment of an open invoice, or an advance; sometimes in goods
        const open = O.invoices.filter(i => i.e.doc.je && (O.ar[i.c] || 0) > 0); const inv = open.length ? g.pick(open) : null; const c = inv ? inv.c : g.pick(g.clients).id;
        const owed = O.ar[c] || 0; let amt = inv && owed > 0 ? (g.r() < 0.5 ? owed : Math.max(1, Math.floor(owed * (0.2 + g.r() * 0.6)))) : g.int(1, 20) * 100000 * dps;
        if (inv && g.r() < 0.12 && owed > 50000 * dps) { // settlement in cement: goods valued at an agreed price, no VAT
          const q = g.int(5, 40); const unit = Math.floor(owed / (q * 2) / dps) * dps || dps; const v = q * unit;
          const d = { date, clientId: c, method: L.IN_KIND, amount: major(v, dp), goods: [{ itemId: 'cem50', qty: q, value: major(v, dp) }] };
          const e = postDoc('receipts', d); assert.ok(!e.err, e.err); oIn('cem50', B(q * 4), v); add(O.ar, c, -v); O.receipts = (O.receipts || []).concat({ e, amt: v, c, inkind: true });
        } else { const m = g.method(); const d = { date, clientId: c, amount: major(amt, dp), method: m, ...(inv ? { invoiceId: inv.e.id } : {}) };
          const e = postDoc('receipts', d); assert.ok(!e.err, e.err); add(O.ar, c, -amt); add(O.cash, L.CASH[m], amt); O.receipts = (O.receipts || []).concat({ e, amt, c, m }); }
      } else if (roll < 0.74) { // supplier payment or expense
        const due = O.purchases.filter(p => (O.ap[p.s] || 0) > 0);
        if (due.length && g.r() < 0.7) { const p = g.pick(due); const amt = g.r() < 0.6 ? O.ap[p.s] : Math.max(1, Math.floor(O.ap[p.s] / 2)); const m = g.method();
          const e = postDoc('payments', { date, supplierId: p.s, amount: major(amt, dp), method: m, category: 'Supplier bill' }); assert.ok(!e.err, e.err); add(O.ap, p.s, -amt); add(O.cash, L.CASH[m], -amt); O.pays = (O.pays || []).concat({ e, amt, s: p.s, m });
        } else { const x = g.expense(); const m = g.method(); const amt = x.amount * dps;
          const e = postDoc('payments', { date, amount: major(amt, dp), method: m, category: x.category, payee: x.payee }); assert.ok(!e.err, e.err); add(O.cash, L.CASH[m], -amt);
          if (x.category === 'VAT paid to URA') O.vatPaid = (O.vatPaid || 0) + amt; else O.expenses += amt; O.pays = (O.pays || []).concat({ e, amt, m, exp: x.category }); }
      } else if (roll < 0.80) { // credit note: goods returned to stock at the invoice cost, or a price allowance
        const cand = O.invoices.filter(i => i.credited < i.total); if (!cand.length) continue; const iv = g.pick(cand);
        const its = Object.keys(iv.costs).filter(it => iv.costs[it].q4 - (iv.returned[it] || 0n) > 0n);
        let lines, back = null;
        if (its.length && g.r() < 0.6) { const it = g.pick(its); const left = iv.costs[it].q4 - (iv.returned[it] || 0n); const q4 = left > 4n ? 4n : left; const item = iv.e.doc.items.find(x => x.itemId === it);
          lines = [{ it, qty: Number(q4) / 4, pm: Math.round(item.price * dps) }]; back = { it, q4 }; }
        else lines = [{ qty: 1, pm: Math.max(dps, Math.floor((iv.total - iv.credited) / 3 / dps) * dps) }];
        const t = docTotals(lines, iv.e.doc.vatRate, dp); if (t.total > iv.total - iv.credited || t.total <= 0) continue;
        const d = { date, clientId: iv.c, invoiceId: iv.e.id, vatRate: iv.e.doc.vatRate, reason: 'sim', items: lines.map(l => ({ desc: 'Return', qty: l.qty, price: major(l.pm, dp), ...(l.it ? { itemId: l.it, restock: true } : {}) })) };
        const e = postDoc('credits', d, { unitCost: L.unitCosts(iv.e.doc.je) }); assert.ok(!e.err, e.err);
        if (back) { const c0 = iv.costs[back.it]; const v = Number(halfUp(B(c0.v) * back.q4, c0.q4)); oIn(back.it, back.q4, v); O.cogs -= v; iv.returned[back.it] = (iv.returned[back.it] || 0n) + back.q4; }
        add(O.ar, iv.c, -t.total); O.vatOut[ym] -= t.vat; O.sales -= t.sub; iv.credited += t.total;
      } else if (roll < 0.84) { // client debit note for an extra charge
        const c = g.pick(g.clients); const lines = [{ qty: 1, pm: g.int(20, 300) * 1000 * dps }]; const t = docTotals(lines, 18, dp);
        const e = postDoc('debits', { date, clientId: c.id, vatRate: 18, reason: 'Extra transport', items: [{ desc: 'Extra transport', qty: 1, price: major(lines[0].pm, dp) }] }); assert.ok(!e.err, e.err);
        add(O.ar, c.id, t.total); O.vatOut[ym] += t.vat; O.sales += t.sub;
      } else if (roll < 0.88) { // supplier debit note: damaged stock returned (out at average; price difference to cost of sales)
        const its = g.items.filter(it => onHand(it.id) >= 4n); if (!its.length) continue; const it = g.pick(its); const s = g.pick(g.suppliers); const pm = priceM(it.buy);
        const t = docTotals([{ qty: 1, pm }], 18, dp);
        const e = postDoc('sdebits', { date, supplierId: s.id, vatRate: 18, reason: 'damaged', items: [{ desc: it.name, qty: 1, price: major(pm, dp), itemId: it.id }] }); assert.ok(!e.err, e.err);
        const c0 = oOut(it.id, 4n); O.cogs += c0 - t.sub; add(O.ap, s.id, -t.total); O.vatIn[ym] -= t.vat;
      } else if (roll < 0.91) { // refund to a client who is in credit
        const cr = Object.keys(O.ar).filter(c => O.ar[c] < 0); if (!cr.length) continue; const c = g.pick(cr); const amt = -O.ar[c]; const m = g.method();
        const e = postDoc('refunds', { date, clientId: c, amount: major(amt, dp), method: m, reason: 'overpaid' }); assert.ok(!e.err, e.err); add(O.ar, c, amt); add(O.cash, L.CASH[m], -amt); O.refs = (O.refs || []).concat({ e, amt, c, m });
      } else if (roll < 0.95) { // stock count adjustment
        const it = g.pick(g.items); if (g.r() < 0.6 && onHand(it.id) >= 4n) { const e = postDoc('adjustments', { date, itemId: it.id, qty: -1, reason: 'damaged' }); assert.ok(!e.err, e.err); O.losses += oOut(it.id, 4n); }
        else { const v = priceM(it.buy); const e = postDoc('adjustments', { date, itemId: it.id, qty: 1, value: major(v, dp), reason: 'found' }); assert.ok(!e.err, e.err); oIn(it.id, 4n, v); O.gains += v; }
      } else { // void a recent cash receipt or payment (reversal dated today)
        const pool = [...(O.receipts || []).filter(x => !x.inkind && !x.e.doc.void), ...(O.pays || []).filter(x => !x.e.doc.void)]; if (!pool.length) continue; const x = g.pick(pool);
        const r = voidDoc(x.e, date); assert.ok(!r.err, r.err);
        if (x.e.coll === 'receipts') { add(O.ar, x.c, x.amt); add(O.cash, L.CASH[x.m], -x.amt); } else { add(O.cash, L.CASH[x.m], x.amt); if (x.s) add(O.ap, x.s, x.amt); else if (x.exp === 'VAT paid to URA') O.vatPaid -= x.amt; else O.expenses -= x.amt; }
      }
    }
    if (date === '2026-10-31') { const J = docs.flatMap(e => [e.doc.je, e.doc.jr].filter(Boolean)); snapshots.oct = JSON.stringify([L.profitLoss(J, '2026-10-01', '2026-10-31'), L.vatReturn(J, '2026-10-01', '2026-10-31'), L.trialBalance(J, '2026-10-31')]); }
  }
  return { docs, stock, O, snapshots, J: docs.flatMap(e => [e.doc.je, e.doc.jr].filter(Boolean)) };
}

function verify(sim, dp) {
  const { docs, O, J } = sim;
  const chk = L.check(docs, { dp, unitCost: (c, d) => c === 'credits' ? L.unitCosts((docs.find(x => x.coll === 'invoices' && x.id === d.invoiceId) || { doc: {} }).doc.je) : null });
  assert.deepEqual(chk.issues, [], 'integrity check');
  for (const j of J) assert.equal(L.balanced(j.lines), '', 'every journal balances');
  const tb = L.trialBalance(J), bs = L.balanceSheet(J); assert.ok(tb.ok, 'trial balance'); assert.ok(bs.ok, 'balance sheet');
  const ar = L.partyBalances(J, '1100'), ap = L.partyBalances(J, '2000');
  for (const [c, v] of Object.entries(O.ar)) assert.equal(ar.get(c) || 0, v, 'customer ledger ' + c);
  for (const [s, v] of Object.entries(O.ap)) assert.equal(ap.get(s) || 0, v, 'supplier ledger ' + s);
  for (const ym of ['2026-10', '2026-11']) { const v = L.vatReturn(J, ym + '-01', ym + (ym.endsWith('10') ? '-31' : '-30')); assert.equal(v.outputVat, O.vatOut[ym], 'output VAT ' + ym); assert.equal(v.inputVat, O.vatIn[ym], 'input VAT ' + ym); }
  const bal = L.balances(J); const B0 = a => bal[a] ? bal[a].d - bal[a].c : 0;
  assert.equal(0 - B0('4000'), O.sales, 'net sales'); assert.equal(B0('5000'), O.cogs, 'cost of sales'); assert.equal(B0('5100'), O.losses, 'stock losses'); assert.equal(0 - B0('4900'), O.gains, 'stock gains');
  for (const a of L.CASH_ACCTS) assert.equal(B0(a), O.cash[a] || 0, 'cash account ' + a);
  for (const [it, s] of Object.entries(O.stock)) { const st = chk.stock[it] || { q: 0, v: 0 }; assert.equal(st.q, Number(s.q4) * 250000, 'stock qty ' + it); assert.equal(st.v, Number(s.v), 'stock value ' + it); }
  assert.equal(B0('1200'), Object.values(chk.stock).reduce((t, s) => t + s.v, 0), 'inventory account = stock valuation');
  const pO = L.profitLoss(J, '2026-10-01', '2026-10-31'), pN = L.profitLoss(J, '2026-11-01', '2026-11-30'); assert.equal(pO.net + pN.net, L.profitLoss(J).net, 'monthly P&L adds up');
  assert.equal(JSON.stringify([L.profitLoss(J, '2026-10-01', '2026-10-31'), L.vatReturn(J, '2026-10-01', '2026-10-31'), L.trialBalance(J, '2026-10-31')]), sim.snapshots.oct, 'closed October unchanged by November activity (incl. voids of October documents)');
  return { docs: docs.length, journals: J.length };
}

describe('Synthetic trading — two months, independent oracle', () => {
  const SEEDS = Array.from({ length: 30 }, (_, i) => 1000 + i);
  for (const seed of SEEDS) it(`UGX book, seed ${seed}: ledgers, VAT, stock, cash, reports, cut-off and closed period all agree`, () => { const sim = simulate(seed, 0); const r = verify(sim, 0); assert.ok(r.docs > 100, 'enough activity: ' + r.docs); });
  for (const seed of [7, 8, 9, 10, 11]) it(`USD book (cents), seed ${seed}`, () => { const sim = simulate(seed, 2); verify(sim, 2); });
});

describe('Bank reconciliation (bank ledger vs a synthetic bank statement)', () => {
  // The system has no statement-import feature; this proves the bank ledger (1030) can be reconciled to a statement
  // with the standard reconciling items: cheques not yet presented, and bank charges not yet recorded.
  it('statement balance = ledger balance − unpresented cheques + deposits in transit − unrecorded charges; differences are found, not hidden', () => {
    const sim = simulate(2024, 0); const rows = L.generalLedger(sim.J, '1030'); const ledgerBal = rows.length ? rows.at(-1).bal : 0;
    const g = generator(77); let unpresented = 0, inTransit = 0; const stmt = [];
    for (const r of rows) { const isChequeOut = r.c > 0 && /payments\//.test(r.pid) && g.r() < 0.15; const isLateIn = r.d > 0 && r.date >= '2026-11-29'; if (isChequeOut) { unpresented += r.c; continue } if (isLateIn) { inTransit += r.d; continue } stmt.push(r.d - r.c); }
    const charges = 4 * 15000; stmt.push(-charges); const stmtBal = stmt.reduce((a, b) => a + b, 0);
    assert.equal(stmtBal, ledgerBal + unpresented - inTransit - charges, 'reconciles exactly with the reconciling items');
    assert.notEqual(stmtBal + 1, ledgerBal + unpresented - inTransit - charges, 'a one-shilling difference would be visible');
  });
});

describe('Duplicate and edge transactions in a running book', () => {
  it('the same posting id twice is reported as a duplicate', () => { const sim = simulate(3, 0); const d = [...sim.docs, { ...sim.docs[5] }]; assert.ok(L.check(d, { dp: 0 }).issues.some(i => /Duplicate posting/.test(i.msg))); });
  it('selling more than the synthetic stock on hand is refused mid-book', () => { const sim = simulate(4, 0); const it = Object.keys(sim.stock)[0]; const q = sim.stock[it].q / 1e6 + 1;
    const r = L.post('invoices', { date: '2026-11-30', clientId: 'c0', vatRate: 18, items: [{ desc: 'x', qty: q, price: 1000, itemId: it }] }, { dp: 0, stock: sim.stock }); assert.match(r.err, /Not enough/); });
});
