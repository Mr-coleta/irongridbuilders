// Builds a large set of fully posted synthetic books (every document carries its journal), close to the
// platform's 25,000-record limit. Postings go through the real engine, so stock movement numbers, costs and
// seals are exactly what the app would have written. Deterministic for a given seed.
'use strict';
const L = require(process.env.LEDGER_PATH || '../../engine/ledger.js');
const { generator } = require('../data/synthetic.js');

function build(target = 24990, seed = 2026) {
  const g = generator(seed);
  const out = new Map();
  const put = (p, d) => out.set(p, d);
  put('settings/business', { name: 'Irongrid Builders (synthetic scale test)', currency: 'UGX', vatDefault: 18 });
  for (const c of g.clients) put('clients/' + c.id, { name: c.name, tin: c.tin });
  for (const s of g.suppliers) put('suppliers/' + s.id, { name: s.name });
  for (const it of g.items) put('items/' + it.id, { name: it.name, unit: it.unit });
  const PREFIX = { invoices: 'INV-', receipts: 'RCT-', purchases: 'PUR-', payments: 'PAY-' };
  const num = {}; const stock = {}; const counts = {}; let ids = 0, tick = 0;
  const open = []; // invoices with an amount still owed: {id, c, owed}
  const ap = {};
  const post = (coll, d) => {
    const id = coll[0] + (ids++); num[coll] = (num[coll] || 0) + 1; d.number = PREFIX[coll] + String(num[coll]).padStart(4, '0');
    const r = L.post(coll, d, { dp: 0, stock }); if (r.err) throw new Error(coll + ': ' + r.err + ' ' + JSON.stringify(d));
    L.numberStock(r.lines, counts); for (const l of r.lines) if (l.a === '1200' && l.i) counts[l.i] = l.n + 1; Object.assign(stock, r.stockAfter);
    const at = new Date(Date.UTC(2022, 5, 1) + (tick++) * 60000).toISOString();
    const si = [...new Set((d.items || []).map(x => x.itemId).filter(Boolean))];
    put(coll + '/' + id, { ...d, ...(si.length ? { stockItems: si } : {}), createdAt: at, je: L.makeJE(coll, id, d, r.lines, { cur: 'UGX', dp: 0, at, by: 'scale' }) });
    if (coll === 'payments') put('approvals/payments-' + id, { kind: 'post', coll, docId: id, number: d.number, amount: d.amount, requestId: null, requestedBy: 'u1', by: 'u1', at }); // posted under the approval rules
    return id;
  };
  const day0 = Date.UTC(2022, 5, 1);
  for (let day = 0; out.size < target - Object.keys(PREFIX).length; day++) {
    const date = new Date(day0 + day * 86400000).toISOString().slice(0, 10);
    for (let k = g.int(10, 22); k > 0 && out.size < target - Object.keys(PREFIX).length; k--) {
      const roll = g.r();
      if (roll < 0.2) { // stock purchase
        const s = g.pick(g.suppliers); const it = g.pick(g.items); const qty = g.qty(it) * 2; const price = g.price(it.buy);
        post('purchases', { date, supplierId: s.id, vatRate: 18, items: [{ desc: it.name, qty, price, itemId: it.id }] });
        ap[s.id] = (ap[s.id] || 0) + Math.round(qty * price * 1.18);
      } else if (roll < 0.5) { // sale within stock on hand, sometimes with a service line
        const c = g.pick(g.clients); const it = g.pick(g.items); const have = stock[it.id] ? Number(stock[it.id].q || 0) / 1e6 : 0;
        const items = []; const want = g.qty(it); if (have >= want) items.push({ desc: it.name, qty: want, price: g.price(it.sell), itemId: it.id });
        if (!items.length || g.r() < 0.3) { const sv = g.service(); items.push({ desc: sv.desc, qty: 1, price: sv.price }); }
        const id = post('invoices', { date, clientId: c.id, vatRate: 18, items });
        const t = L.calcDoc({ items, vatRate: 18 }, 0); open.push({ id, c: c.id, owed: Number(t.total) });
      } else if (roll < 0.8 && open.length) { // receipt: full or part payment of an open invoice
        const i = g.int(0, open.length - 1); const iv = open[i]; const amt = g.r() < 0.6 ? iv.owed : Math.max(1000, Math.floor(iv.owed / 2));
        post('receipts', { date, clientId: iv.c, invoiceId: iv.id, amount: amt, method: g.method() }); iv.owed -= amt; if (iv.owed <= 0) open.splice(i, 1);
      } else { // supplier payment or an expense
        const due = Object.keys(ap).filter(s => ap[s] > 0);
        if (due.length && g.r() < 0.6) { const s = g.pick(due); const amt = ap[s]; post('payments', { date, supplierId: s, amount: amt, method: g.method(), category: 'Supplier bill' }); ap[s] = 0; }
        else { const x = g.expense(); if (x.category === 'VAT paid to URA') continue; post('payments', { date, amount: x.amount, method: g.method(), category: x.category, payee: x.payee }); }
      }
    }
  }
  for (const c of Object.keys(PREFIX)) put('counters/' + c, { last: num[c] || 0 });
  const J = [...out.entries()].filter(([, d]) => d.je).map(([p, d]) => ({ coll: p.split('/')[0], je: d.je }));
  return { docs: out, counts: Object.fromEntries(Object.keys(PREFIX).map(c => [c, num[c] || 0])), journals: J.length };
}
module.exports = { build };
if (require.main === module) { const t = Date.now(); const b = build(+process.argv[2] || 24990); console.log(b.docs.size, 'records', b.counts, b.journals, 'journals', Date.now() - t, 'ms'); }
