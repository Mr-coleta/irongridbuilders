// Scale suite: the whole app with ~25,000 fully posted records, the platform's storage limit.
// Usage: node tests/scale/scale.test.js   (needs the server on :8765 serving srv/, like the browser suite)
// Writes tests/reports/scale.json. Every figure the app shows is compared with the engine run directly in Node.
'use strict';
const { chromium } = require('playwright');
const fs = require('fs');
const path = require('path');
const L = require('../../engine/ledger.js');
const { build } = require('./books.js');
const MOCK = require('../mocksrc.js');
const BASE = 'http://localhost:8765/';
const SRV = path.join(__dirname, '../../srv');
const results = [];
const assert = (c, m) => { if (!c) throw new Error(m); };
async function test(id, name, fn) {
  if (process.env.ONLY && !process.env.ONLY.split(',').includes(id)) return;
  const t0 = Date.now();
  try { const detail = await fn(); results.push({ id, name, pass: true, ms: Date.now() - t0, detail: detail || '' }); }
  catch (e) { results.push({ id, name, pass: false, ms: Date.now() - t0, detail: e.message.split('\n')[0] }); }
  const r = results.at(-1); console.log(`${r.pass ? 'PASS' : 'FAIL'}  ${id}  ${name}${r.detail ? '  — ' + r.detail : ''}`);
}

(async () => {
  const TARGET = +process.env.SCALE_N || 24990;
  const B = build(TARGET);
  fs.writeFileSync(path.join(SRV, 'scale.json'), JSON.stringify([...B.docs.entries()]));
  // What the engine says, computed in Node straight from the same documents
  const entries = [...B.docs.entries()].filter(([, d]) => d.je).map(([p, d]) => ({ coll: p.split('/')[0], id: p.split('/')[1], doc: d }));
  const chk = L.check(entries, { dp: 0 });
  const J = chk.journals; const tb = L.trialBalance(J); const bs = L.balanceSheet(J);
  const ar = L.partyBalances(J, '1100'), ap = L.partyBalances(J, '2000'); const bal = L.balances(J);
  const expect = { problems: chk.issues.length, tbOk: tb.ok, bsOk: bs.ok, ar, ap, b1200: bal['1200'] ? bal['1200'].d - bal['1200'].c : 0 };
  console.log(`books: ${B.docs.size} records, ${B.journals} journals, ${JSON.stringify(B.counts)}; engine check: ${expect.problems} problems`);

  const browser = await chromium.launch();
  const open = async (opts = {}, empty = false) => {
    const p = await browser.newPage({ viewport: { width: 1300, height: 950 } }); const errs = []; p.on('pageerror', e => errs.push(e.message));
    await p.addInitScript(`${MOCK};window.__mock(${JSON.stringify(opts)});${empty ? '' : `{const x=new XMLHttpRequest();x.open("GET","/scale.json",false);x.send();for(const [k,v] of JSON.parse(x.responseText))window.__S.set(k,v)}`}`);
    const t0 = Date.now(); await p.goto(BASE + 'index.html#dashboard');
    if (!empty) await p.waitForFunction(n => window.S && S.invoices && S.invoices.length === n, B.counts.invoices, { timeout: 120000 });
    else await p.waitForTimeout(1200);
    return { p, errs, loadMs: Date.now() - t0 };
  };
  const appBooks = p => p.evaluate(() => { LCACHE = null; const t = performance.now(); const Lx = ledger(); const ms = performance.now() - t;
    return { ms: Math.round(ms), problems: Lx.problems, issues: Lx.issues.slice(0, 3).map(i => i.msg), recon: Lx.recon.filter(r => !r.ok).map(r => r.label), tb: Lx.tb.ok, bs: Lx.bs.ok, n: Lx.J.length,
      ar: LEDGER.partyBalances(Lx.J, '1100'), ap: LEDGER.partyBalances(Lx.J, '2000') }; });
  const same = (a, b) => JSON.stringify(a, (k, v) => typeof v === 'bigint' ? String(v) : v) === JSON.stringify(b, (k, v) => typeof v === 'bigint' ? String(v) : v);
  const report = { records: B.docs.size, journals: B.journals, counts: B.counts };

  await test('SC-1', `${TARGET.toLocaleString()} posted records load, and the books check finds 0 problems with every figure equal to the engine's`, async () => {
    const { p, errs, loadMs } = await open(); const b = await appBooks(p);
    assert(expect.problems === 0, 'engine itself found problems in the synthetic books: ' + chk.issues.slice(0, 2).map(i => i.msg));
    assert(b.problems === 0, 'app found problems: ' + b.issues.join('; ')); assert(!b.recon.length, 'reconciliations off: ' + b.recon);
    assert(b.tb && b.bs, 'TB/BS not balanced'); assert(b.n === B.journals, `journals ${b.n} vs ${B.journals}`);
    assert(same(b.ar, expect.ar) && same(b.ap, expect.ap), 'customer/supplier balances differ from engine');
    assert(!errs.length, errs.join(';')); report.loadMs = loadMs; report.checkMs = b.ms; await p.close();
    return `loaded in ${(loadMs / 1000).toFixed(1)} s; full books check ${b.ms} ms; ${b.n.toLocaleString()} journals; 0 problems; TB, BS, AR and AP equal the engine`;
  });

  await test('SC-2', 'Every screen and every accounts report opens in under 1 s at full size, without freezing the page for more than 1 s', async () => {
    const { p, errs } = await open(); const times = {};
    // first visit to Accounts builds the ledger; measure it separately (it runs in slices, so the page stays responsive)
    for (const h of ['invoices', 'receipts', 'purchases', 'payments', 'clients', 'suppliers', 'stock', 'dashboard', 'accounts']) {
      const s = Date.now(); await p.evaluate(h => location.hash = h, h); await p.evaluate(() => new Promise(r => requestAnimationFrame(() => requestAnimationFrame(r)))); times[h] = Date.now() - s; }
    for (const t of ['tb', 'pl', 'bs', 'vat', 'gl', 'chk']) { const s = Date.now(); await p.click(`#acTabs [data-t=${t}]`); await p.evaluate(() => new Promise(r => requestAnimationFrame(() => requestAnimationFrame(r)))); times['accounts:' + t] = Date.now() - s; }
    // longest single block of the main thread while the ledger is rebuilt after a live change
    const longest = await p.evaluate(async () => { let worst = 0; const po = new PerformanceObserver(l => { for (const e of l.getEntries()) worst = Math.max(worst, e.duration); }); po.observe({ type: 'longtask', buffered: false });
      window.__S.set('receipts/live1', { number: 'RCT-LIVE', date: '2026-01-05', clientId: 'c1', amount: 1000, method: 'Cash' }); for (const l of window.__L) l.fire(); await new Promise(r => setTimeout(r, 4000)); po.disconnect(); return Math.round(worst); });
    const worst = Math.max(...Object.values(times)); report.screens = times; report.longestTaskMs = longest;
    assert(worst < 1000, 'slowest ' + JSON.stringify(times)); assert(longest < 1000, 'page froze ' + longest + ' ms'); assert(!errs.length, errs.join(';')); await p.close();
    const top = Object.entries(times).sort((a, b) => b[1] - a[1]).slice(0, 3).map(([k, v]) => `${k} ${v} ms`).join(', ');
    return `slowest: ${top}; longest freeze after a live change ${longest} ms`;
  });

  await test('SC-3', 'A new stock sale can be posted at full size; posting time measured; books still clean', async () => {
    const { p, errs } = await open();
    const t0 = Date.now();
    await p.evaluate(() => location.hash = 'invoices'); await p.waitForTimeout(300); await p.click('#lNew');
    const item = await p.evaluate(() => { const st = ledger().stock; return Object.keys(st).sort((a, b) => st[b].q - st[a].q)[0]; });
    await p.selectOption('#ed [name=party]', 'c0'); await p.selectOption('#ed .si', item); await p.fill('#ed .q', '1'); await p.fill('#ed .p', '40000'); await p.fill('#ed [name=vatRate]', '18');
    await p.click('#ed [type=submit]'); await p.waitForFunction(n => S.invoices.length === n + 1 && S.invoices.some(i => i.je && i.number === 'INV-' + String(n + 1).padStart(4, '0')), B.counts.invoices, { timeout: 30000 }).catch(() => {});
    const postMs = Date.now() - t0; const inv = await p.evaluate(n => S.invoices.find(i => i.number === 'INV-' + String(n + 1).padStart(4, '0')), B.counts.invoices);
    assert(inv && inv.je, 'invoice not posted (number ' + (inv && inv.number) + ')'); const b = await appBooks(p); assert(b.problems === 0 && b.tb && b.bs, 'books not clean after posting: ' + b.issues);
    assert(!errs.length, errs.join(';')); report.postMs = postMs; await p.close();
    return `invoice ${inv.number} posted in ${(postMs / 1000).toFixed(1)} s (form open to saved); books clean`;
  });

  await test('SC-4', 'Full backup at full size, then restore into an empty database: every record identical, books identical', async () => {
    const { p } = await open(); await p.evaluate(() => location.hash = 'settings'); await p.waitForTimeout(300);
    const t0 = Date.now(); await p.click('#bkDown'); await p.waitForFunction(() => window.__lastDownload, null, { timeout: 120000 }); const bkMs = Date.now() - t0;
    const raw = (await p.evaluate(() => window.__lastDownload)).data; fs.writeFileSync('/tmp/scale-backup.json', raw); await p.close();
    const bk = JSON.parse(raw); const n = Object.values(bk.data).reduce((a, x) => a + x.length, 0);
    const { p: q, errs } = await open({}, true); await q.evaluate(() => location.hash = 'settings'); await q.waitForTimeout(300);
    const t1 = Date.now(); await q.setInputFiles('#bkFile', '/tmp/scale-backup.json'); await q.waitForSelector('#rsGo', { timeout: 60000 }); await q.check('#rsSettings'); await q.click('#rsGo');
    await q.waitForSelector('#mTitle:has-text("verified")', { timeout: 900000 }); const rsMs = Date.now() - t1;
    const msg = await q.textContent('#mTitle') + ' ' + await q.textContent('#mBody'); await q.click('#mBtns >> text=Close');
    const diff = await q.evaluate(src => { const canon = x => JSON.stringify(x, (k, v) => v && typeof v === 'object' && !Array.isArray(v) ? Object.fromEntries(Object.keys(v).sort().map(j => [j, v[j]])) : v); let missing = 0, changed = 0; const which = []; for (const [k, v] of src) { if (k.startsWith('counters/')) continue; const d = window.__S.get(k); if (!d) { missing++; which.push(k); } else if (canon(d) !== canon(v)) { changed++; which.push(k + ' ' + JSON.stringify(d) + ' vs ' + JSON.stringify(v)); } } return { missing, changed, which: which.slice(0, 3) }; }, [...B.docs.entries()]);
    const b = await appBooks(q); assert(/^Restore verified/.test(msg) && !/failed|stopped/.test(msg), msg.slice(0, 300));
    assert(diff.missing === 0 && diff.changed === 0, JSON.stringify(diff)); assert(b.problems === 0 && same(b.ar, expect.ar) && same(b.ap, expect.ap), 'books differ after restore');
    assert(!errs.length, errs.join(';')); report.backup = { ms: bkMs, mb: +(raw.length / 1048576).toFixed(1), records: n }; report.restoreMs = rsMs; await q.close();
    return `backup ${n.toLocaleString()} records, ${(raw.length / 1048576).toFixed(1)} MB in ${(bkMs / 1000).toFixed(1)} s; restore + verification ${(rsMs / 1000).toFixed(0)} s; "Restore verified"; 0 missing, 0 changed; books identical`;
  });

  await test('SC-5', 'At the storage limit a new invoice is refused with a clear message and nothing half-saved', async () => {
    const { p, errs } = await open(); const size0 = await p.evaluate(() => window.__S.size); await p.evaluate(n => { window.top.__cap = n; }, size0);
    const before = await p.evaluate(() => JSON.stringify([...window.__S.entries()].filter(([k]) => !k.startsWith('counters/'))).length);
    await p.evaluate(() => location.hash = 'invoices'); await p.waitForTimeout(300); await p.click('#lNew');
    await p.selectOption('#ed [name=party]', 'c0'); await p.fill('#ed .d', 'Works'); await p.fill('#ed .p', '100000');
    await p.click('#ed [type=submit]'); const seen = []; for (let i = 0; i < 30; i++) { const t = await p.textContent('#toast'); if (t && !seen.includes(t)) seen.push(t); await p.waitForTimeout(200); }
    const after = await p.evaluate(() => JSON.stringify([...window.__S.entries()].filter(([k]) => !k.startsWith('counters/'))).length);
    const b = await appBooks(p); const ctr = await p.evaluate(() => window.__S.get('counters/invoices'));
    assert(seen.some(t => /Storage is full/.test(t)), 'message: ' + JSON.stringify(seen)); assert(before === after, 'records changed');
    assert(b.problems === 0, 'books not clean: ' + b.issues.join('; ')); assert(!errs.length, errs.join(';')); await p.close();
    return `"${seen.find(t => /Storage/.test(t))}"; no record added; counter ${ctr.last === B.counts.invoices ? 'unchanged' : 'reserved ' + ctr.last + ' for this form (see SC-8)'}; books clean`;
  });

  await test('SC-8', 'After a save refused at the limit: retrying keeps the same number; abandoning it leaves a gap that the Checks screen reports', async () => {
    const { p } = await open(); const n0 = B.counts.invoices; const size0 = await p.evaluate(() => window.__S.size);
    const fill = async (price) => { await p.evaluate(() => location.hash = 'invoices'); await p.waitForTimeout(300); await p.click('#lNew'); await p.selectOption('#ed [name=party]', 'c0'); await p.fill('#ed .d', 'Works'); await p.fill('#ed .p', String(price)); };
    const nums = () => p.evaluate(n => S.invoices.map(i => i.number).filter(x => +x.slice(4) > n).sort(), n0);
    // (a) refused, then retried in the same form once space is available
    await p.evaluate(n => { window.top.__cap = n; }, size0); await fill(100000); await p.click('#ed [type=submit]'); await p.waitForTimeout(2500);
    await p.evaluate(() => { window.top.__cap = 0; }); await p.click('#ed [type=submit]'); await p.waitForTimeout(2500); await p.click('#mBtns >> text=Close').catch(() => {});
    const a = await nums(); assert(a.length === 1 && a[0] === 'INV-' + (n0 + 1), 'retry: ' + a);
    // (b) refused, then the form is abandoned; the next invoice takes the following number
    const size1 = await p.evaluate(() => window.__S.size); await p.evaluate(n => { window.top.__cap = n; }, size1); await fill(200000); await p.click('#ed [type=submit]'); await p.waitForTimeout(2500);
    await p.click('#edCancel'); await p.waitForTimeout(400);
    await p.evaluate(() => { window.top.__cap = 0; }); await fill(300000); await p.click('#ed [type=submit]'); await p.waitForTimeout(2500); await p.click('#mBtns >> text=Close').catch(() => {});
    const b = await nums(); await p.evaluate(() => location.hash = 'accounts'); await p.waitForTimeout(400); await p.click('#acTabs [data-t=chk]'); await p.waitForTimeout(1500);
    const g = await p.evaluate(() => document.body.innerText.split('\n').filter(l => /never used/.test(l)));
    const skipped = 'INV-' + (n0 + 2); assert(b.length === 2 && !b.includes(skipped), 'abandon: ' + b); assert(g.length && g[0].includes(skipped), 'gap not reported: ' + JSON.stringify(g));
    await p.close(); return `retry kept ${a[0]}; abandoned save skipped ${skipped}, next was ${b[1]}; Checks: "${g[0].slice(0, 120)}"`;
  });

  await test('SC-6', 'An unexpected refusal code at the limit is still reported as a failed save (not shown as saved)', async () => {
    const { p } = await open(); const size0 = await p.evaluate(() => window.__S.size); await p.evaluate(n => { window.top.__cap = n; window.top.__capCode = 'failed_precondition'; }, size0);
    await p.evaluate(() => location.hash = 'invoices'); await p.waitForTimeout(300); await p.click('#lNew');
    await p.selectOption('#ed [name=party]', 'c0'); await p.fill('#ed .d', 'Works'); await p.fill('#ed .p', '100000'); await p.click('#ed [type=submit]');
    const seen = []; for (let i = 0; i < 30; i++) { const t = await p.textContent('#toast'); if (t && !seen.includes(t)) seen.push(t); await p.waitForTimeout(200); }
    const n = await p.evaluate(() => S.invoices.length); assert(n === B.counts.invoices, 'invoice appeared locally: ' + n);
    assert(seen.length && !seen.some(t => /saved|posted/i.test(t) && !/not|n't/i.test(t)), 'messages: ' + JSON.stringify(seen)); await p.close();
    return 'shown: ' + JSON.stringify(seen);
  });

  await test('SC-7', 'Restoring into a database that fills up stops cleanly, says so, and reports how many were restored', async () => {
    const { p } = await open({}, true); await p.evaluate(() => { window.top.__cap = 5000; }); await p.evaluate(() => location.hash = 'settings'); await p.waitForTimeout(300);
    await p.setInputFiles('#bkFile', '/tmp/scale-backup.json'); await p.waitForSelector('#rsGo', { timeout: 60000 }); await p.click('#rsGo');
    await p.waitForSelector('#mTitle:has-text("verified")', { timeout: 600000 });
    const msg = await p.textContent('#mTitle') + ' ' + await p.textContent('#mBody'); const size = await p.evaluate(() => window.__S.size);
    assert(/^Restore NOT verified/.test(msg) && /Storage is full/.test(msg) && /5000 records were written/.test(msg) && !/run the restore again/.test(msg), msg.slice(0, 300)); assert(size === 5000, 'size ' + size); await p.close(); return `"${msg}" with ${size} records in the database`;
  });

  await browser.close();
  report.results = results; report.ranAt = new Date().toISOString();
  fs.mkdirSync(path.join(__dirname, '../reports'), { recursive: true }); fs.writeFileSync(path.join(__dirname, '../reports/scale.json'), JSON.stringify(report, null, 1));
  const failed = results.filter(r => !r.pass); console.log(`\n${results.length - failed.length}/${results.length} passed`); process.exit(failed.length ? 1 : 0);
})();
