// Login screen suite: username + password in front of the whole app (on top of the platform's Claude sign-in).
// Writes tests/reports/login.json. Usage: node tests/login/login.test.js   (server on :8765 serving srv/)
'use strict';
const { chromium } = require('playwright'); const fs = require('fs'); const path = require('path'); const crypto = require('crypto');
const MOCK = require('../mocksrc.js');
const results = []; const assert = (c, m) => { if (!c) throw new Error(m); };
async function test(id, name, fn) {
  if (process.env.ONLY && !process.env.ONLY.split(',').includes(id)) return;
  const t0 = Date.now();
  try { const detail = await fn(); results.push({ id, name, pass: true, ms: Date.now() - t0, detail: detail || '' }); }
  catch (e) { results.push({ id, name, pass: false, ms: Date.now() - t0, detail: e.message.split('\n')[0] }); }
  const r = results.at(-1); console.log(`${r.pass ? 'PASS' : 'FAIL'}  ${id}  ${name}${r.detail ? '  — ' + r.detail : ''}`);
}
const PW = 'Kampala#Site42', STAFF_PW = 'Mortar&Brick77';
const rec = (u, pw, extra = {}) => { const salt = crypto.randomBytes(16); return { kind: 'login', username: u, name: u.toUpperCase(), role: 'staff', disabled: false, salt: salt.toString('base64'), iter: 210000,
  hash: crypto.pbkdf2Sync(pw, salt, 210000, 32, 'sha256').toString('base64'), createdAt: '2026-11-08T00:00:00Z', createdBy: 'u1', updatedAt: '2026-11-08T00:00:00Z', updatedBy: 'u1', ...extra }; };
const BASE = `st.set("settings/business",{name:"Irongrid Builders Co Limited",currency:"UGX"});st.set("clients/c",{name:"Nansubuga Estates Ltd"});`;
const withLogins = () => BASE + `st.set("settings/login-alex",${JSON.stringify(rec('alex', PW, { role: 'owner', name: 'Alex' }))});st.set("settings/login-ruth",${JSON.stringify(rec('ruth', STAFF_PW, { name: 'Ruth' }))});`;
let browser;
async function open({ seed = BASE, opts = {}, hash = 'clients', pre = '' } = {}) {
  const ctx = await browser.newContext({ viewport: { width: 1366, height: 860 } }); const p = await ctx.newPage(); p.setDefaultTimeout(15000); const errs = []; p.on('pageerror', e => errs.push(e.message));
  await p.addInitScript(`${pre};${MOCK};window.__mock(${JSON.stringify(opts)});const st=window.__S;if(!st.size){${seed}}`); await p.goto('http://localhost:8765/index.html#' + hash); await p.waitForTimeout(900); return { p, errs, ctx };
}
const state = p => p.evaluate(() => { const g = document.querySelector('#loginGate'); const app = document.querySelector('.app');
  return { gate: !!(g && !g.hidden), inert: !!(app && app.hasAttribute('inert')), appVisible: !!app && getComputedStyle(app).visibility !== 'hidden', title: (document.querySelector('#lgTitle') || {}).textContent || '',
    err: (document.querySelector('#lgErr') || {}).textContent || '', who: !document.querySelector('#qbWho').hidden }; });
const signIn = async (p, u, pw) => { await p.fill('#lgUser', u); await p.fill('#lgPass', pw); await p.click('#lgGo'); await p.waitForFunction(() => { const e = document.querySelector('#lgErr'); return !e || e.textContent !== 'Checking…'; }, null, { timeout: 15000 }); await p.waitForTimeout(150); };
const locked = s => s.gate && s.inert && !s.appVisible;
const unlocked = s => !s.gate && !s.inert && s.appVisible;

(async () => {
  browser = await chromium.launch();

  await test('LG-01', 'No logins set up: the app opens exactly as before; the owner is told how to turn logins on', async () => {
    const { p, errs, ctx } = await open(); const s = await state(p); assert(unlocked(s), 'app should be open: ' + JSON.stringify(s));
    assert(await p.isVisible('text=Nansubuga Estates Ltd'), 'records should show');
    await p.evaluate(() => location.hash = 'settings'); await p.waitForTimeout(300); assert(await p.isVisible('#lgNone'), 'owner should see the "No logins yet" note');
    assert(!errs.length, errs[0]); await ctx.close(); return 'open, records visible, set-up note shown'; });

  await test('LG-02', 'Owner adds the first login: stays signed in; after Sign out the screen asks for a password; wrong password refused; right password opens', async () => {
    const { p, errs, ctx } = await open({ hash: 'settings' });
    await p.fill('#lgAU', 'alex'); await p.fill('#lgAN', 'Alex Kalungi'); await p.fill('#lgAP', PW); await p.fill('#lgAP2', PW); await p.click('#lgAddGo');
    await p.waitForFunction(() => !!window.__S.get('settings/login-alex'), null, { timeout: 15000 }); await p.waitForTimeout(400);
    let s = await state(p); assert(unlocked(s) && s.who, 'owner should stay signed in after set-up: ' + JSON.stringify(s));
    await p.click('#qbSignOut'); await p.waitForTimeout(200); s = await state(p); assert(locked(s), 'sign out should lock: ' + JSON.stringify(s));
    await signIn(p, 'alex', 'wrong-password'); s = await state(p); assert(locked(s) && /Wrong username or password/.test(s.err), 'wrong password: ' + JSON.stringify(s));
    await signIn(p, 'nobody', PW); s = await state(p); assert(locked(s) && /Wrong username or password/.test(s.err), 'unknown user gets the same message: ' + s.err);
    await signIn(p, 'ALEX ', PW); s = await state(p); assert(unlocked(s), 'right password (any case, spaces trimmed) should open: ' + JSON.stringify(s));
    assert(!errs.length, errs[0]); await ctx.close(); return 'set-up → signed in → sign out → wrong refused → right opens'; });

  await test('LG-03', 'Passwords are never stored or logged: only a salted PBKDF2 hash; no plaintext in the store, logs, audit or browser storage', async () => {
    const { p, errs, ctx } = await open({ hash: 'settings' });
    await p.fill('#lgAU', 'alex'); await p.fill('#lgAP', PW); await p.fill('#lgAP2', PW); await p.click('#lgAddGo'); await p.waitForFunction(() => !!window.__S.get('settings/login-alex'));
    await p.click('#qbSignOut'); await signIn(p, 'alex', 'Wrong' + PW); await signIn(p, 'alex', PW); await p.waitForTimeout(2500);
    const r = await p.evaluate(() => { try { flushErrors && flushErrors(); } catch (e) { } return { store: JSON.stringify([...window.__S.entries()]), ev: JSON.stringify(window.__EV()), ls: JSON.stringify({ ...localStorage }), ss: JSON.stringify({ ...sessionStorage }), rec: window.__S.get('settings/login-alex') }; });
    for (const [k, v] of Object.entries(r)) if (k !== 'rec') { assert(!v.includes(PW), `password found in ${k}`); assert(!v.includes('Wrong' + PW), `wrong attempt's password found in ${k}`); }
    assert(r.rec.salt && r.rec.hash && r.rec.iter >= 210000 && !('password' in r.rec), 'record should hold salt+hash only: ' + Object.keys(r.rec));
    const salt = Buffer.from(r.rec.salt, 'base64'); assert(salt.length === 16, 'salt is 16 random bytes');
    assert(crypto.pbkdf2Sync(PW, salt, r.rec.iter, 32, 'sha256').toString('base64') === r.rec.hash, 'hash is PBKDF2-SHA-256 of the password');
    assert(!errs.length, errs[0]); await ctx.close(); return 'store, logs, audit, local/session storage checked'; });

  await test('LG-04', '5 wrong attempts lock this device for a minute — even the right password is refused until then', async () => {
    const { p, errs, ctx } = await open({ seed: withLogins() }); assert(locked(await state(p)), 'should start locked');
    for (let i = 0; i < 5; i++) await signIn(p, 'ruth', 'nope' + i);
    let s = await state(p); assert(/Too many wrong attempts/.test(s.err), 'should say too many: ' + s.err);
    await signIn(p, 'ruth', STAFF_PW); s = await state(p); assert(locked(s) && /Too many/.test(s.err), 'right password must be refused while locked out: ' + JSON.stringify(s));
    await p.evaluate(() => { const f = JSON.parse(localStorage.getItem('ig.loginFail')); f.until = Date.now() - 1; localStorage.setItem('ig.loginFail', JSON.stringify(f)); });
    await signIn(p, 'ruth', STAFF_PW); s = await state(p); assert(unlocked(s), 'after the wait the right password works: ' + JSON.stringify(s));
    assert(!errs.length, errs[0]); await ctx.close(); return 'lockout enforced, then released'; });

  await test('LG-05', 'Signed in for this tab: reload keeps you in; 30 minutes idle locks; a stale session is refused', async () => {
    const { p, errs, ctx } = await open({ seed: withLogins() }); await signIn(p, 'ruth', STAFF_PW); assert(unlocked(await state(p)), 'signed in');
    await p.reload(); await p.waitForTimeout(900); assert(unlocked(await state(p)), 'reload in the same tab keeps the session');
    await p.evaluate(() => { const s = JSON.parse(sessionStorage.getItem('ig.session')); s.at = Date.now() - 31 * 60000; sessionStorage.setItem('ig.session', JSON.stringify(s)); LOGIN.session.at = s.at; });
    await p.mouse.click(5, 5); await p.waitForTimeout(200); assert(locked(await state(p)), 'idle for 31 minutes should lock on the next activity');
    await p.reload(); await p.waitForTimeout(900); assert(locked(await state(p)), 'stale session after reload is refused');
    const p2 = await ctx.newPage(); await p2.addInitScript(`${MOCK};window.__mock({});const st=window.__S;if(!st.size){${withLogins()}}`); await p2.goto('http://localhost:8765/index.html#clients'); await p2.waitForTimeout(900);
    assert(locked(await state(p2)), 'a new tab must sign in again');
    assert(!errs.length, errs[0]); await ctx.close(); return 'reload ok, idle lock, new tab locked'; });

  await test('LG-06', 'Staff (Contributor) cannot add, change or remove logins — the screen says so and the platform refuses the write', async () => {
    const { p, errs, ctx } = await open({ seed: withLogins(), opts: { level: 'interact', uid: 'u2' } }); await signIn(p, 'ruth', STAFF_PW);
    await p.evaluate(() => location.hash = 'settings'); await p.waitForTimeout(300);
    assert(await p.isVisible('text=Only the owner can add or change logins.'), 'staff should see the owner-only note'); assert(!(await p.$('#lgAdd')), 'no add form for staff');
    const w = await p.evaluate(async () => { const db = await claude.use('db'); const out = {}; try { await db.doc('settings/login-ruth').set({ kind: 'login', username: 'ruth', salt: 'x', hash: 'y' }); out.set = 'allowed'; } catch (e) { out.set = e.code; }
      try { await db.doc('settings/login-alex').delete(); out.del = 'allowed'; } catch (e) { out.del = e.code; } return out; });
    assert(w.set === 'invalid_argument' && w.del === 'invalid_argument', 'platform should refuse staff writes: ' + JSON.stringify(w));
    await p.click('#qbSignOut'); await p.waitForTimeout(200); assert(await p.isHidden('#lgOwner'), 'staff should not get the owner password-reset link');
    assert(!errs.length, errs[0]); await ctx.close(); return 'UI hidden, set and delete refused'; });

  await test('LG-07', 'A disabled login cannot sign in, and disabling someone who is signed in locks them out straight away', async () => {
    const { p, errs, ctx } = await open({ seed: withLogins() }); await signIn(p, 'ruth', STAFF_PW); assert(unlocked(await state(p)), 'signed in');
    await p.evaluate(() => { const r = window.__S.get('settings/login-ruth'); window.__S.set('settings/login-ruth', { ...r, disabled: true }); for (const l of window.__L) l.fire(); }); await p.waitForTimeout(300);
    assert(locked(await state(p)), 'disabling should lock the signed-in person');
    await signIn(p, 'ruth', STAFF_PW); const s = await state(p); assert(locked(s) && /Wrong username or password/.test(s.err), 'disabled login refused: ' + JSON.stringify(s));
    // owner can disable/enable from Business details
    const o = await open({ seed: withLogins() }); await signIn(o.p, 'alex', PW); await o.p.evaluate(() => location.hash = 'settings'); await o.p.waitForTimeout(300);
    await o.p.click('tr[data-lu=ruth] [data-lact=toggle]'); await o.p.waitForFunction(() => window.__S.get('settings/login-ruth').disabled === true);
    await o.p.waitForTimeout(300); await o.p.click('tr[data-lu=alex] [data-lact=toggle]'); await o.p.waitForTimeout(200);
    assert(await o.p.evaluate(() => window.__S.get('settings/login-alex').disabled === false), 'the last active owner login cannot be disabled');
    assert(!errs.length && !o.errs.length, errs[0] || o.errs[0]); await ctx.close(); await o.ctx.close(); return 'live lock-out; owner toggle works; last owner kept'; });

  await test('LG-08', 'Forgotten password: the app owner sets a new one from the login screen; old password stops working, new one works', async () => {
    const { p, errs, ctx } = await open({ seed: withLogins() }); assert(await p.isVisible('#lgForgot'), 'owner should see "Forgot your password?"');
    await p.click('#lgForgot'); await p.fill('#lgRUser', 'alex'); await p.fill('#lgRPass', 'short'); await p.fill('#lgRPass2', 'short'); await p.click('#lgReset button[type=submit]');
    assert(/at least 8/.test(await p.textContent('#lgRErr')), 'short password refused');
    const NEW = 'Entebbe!Road2026'; await p.fill('#lgRPass', NEW); await p.fill('#lgRPass2', NEW); await p.click('#lgReset button[type=submit]');
    await p.waitForFunction(() => /Password changed/.test(document.querySelector('#lgErr').textContent), null, { timeout: 15000 });
    await signIn(p, 'alex', PW); assert(locked(await state(p)), 'old password must stop working');
    await signIn(p, 'alex', NEW); assert(unlocked(await state(p)), 'new password works');
    assert(!errs.length, errs[0]); await ctx.close(); return 'reset from the screen works'; });

  await test('LG-09', 'While locked nothing of the app is visible or reachable: hidden, inert, not clickable, not reachable with Tab', async () => {
    const { p, errs, ctx } = await open({ seed: withLogins() }); const s = await state(p); assert(locked(s), JSON.stringify(s));
    const r = await p.evaluate(() => { const hit = document.elementFromPoint(683, 430); const visibleText = document.body.innerText;
      return { hitGate: !!(hit && hit.closest('#loginGate')), leak: visibleText.includes('Nansubuga'), modalInert: document.querySelector('#modal').hasAttribute('inert') }; });
    assert(r.hitGate, 'clicks land on the login screen'); assert(!r.leak, 'client names must not be visible'); assert(r.modalInert, 'pop-ups are inert too');
    const tabs = []; for (let i = 0; i < 12; i++) { await p.keyboard.press('Tab'); tabs.push(await p.evaluate(() => !!document.activeElement.closest('#loginGate') || document.activeElement === document.body)); }
    assert(tabs.every(Boolean), 'Tab must stay inside the login screen');
    await p.evaluate(() => location.hash = 'invoices'); await p.waitForTimeout(200); assert(locked(await state(p)), 'changing the address does not get past it');
    await p.emulateMedia({ media: 'print' }); assert(await p.evaluate(() => getComputedStyle(document.querySelector('.app')).visibility === 'hidden'), 'printing while locked shows nothing'); await p.emulateMedia({ media: 'screen' });
    assert(!errs.length, errs[0]); await ctx.close(); return 'hidden, inert, click/Tab/hash/print checked'; });

  await test('LG-10', 'Fail closed: on a device that has seen logins, if the list of logins cannot be read the app stays locked', async () => {
    const { p, errs, ctx } = await open({ seed: BASE, opts: { fatalColl: 'settings' }, pre: `try{localStorage.setItem("ig.loginsOn","1")}catch(e){}` });
    await p.waitForTimeout(400); let s = await state(p); assert(locked(s), 'should stay locked: ' + JSON.stringify(s));
    await signIn(p, 'alex', PW); s = await state(p); assert(locked(s) && /Can't check logins/.test(s.err), 'sign-in refused with a clear reason: ' + s.err);
    const q = await open({ seed: BASE, opts: { fatalColl: 'settings' } }); await q.p.waitForTimeout(400); assert(unlocked(await state(q.p)), 'a device that never had logins is not locked out by a read error');
    assert(!errs.length && !q.errs.length, errs[0] || q.errs[0]); await ctx.close(); await q.ctx.close(); return 'locked with flag; open without'; });

  await test('LG-11', 'The login screen fits a 320 px phone with no sideways scrolling, and the fields are usable', async () => {
    const ctx = await browser.newContext({ viewport: { width: 320, height: 568 }, isMobile: true, hasTouch: true }); const p = await ctx.newPage(); const errs = []; p.on('pageerror', e => errs.push(e.message));
    await p.addInitScript(`${MOCK};window.__mock({});const st=window.__S;if(!st.size){${withLogins()}}`); await p.goto('http://localhost:8765/index.html#clients'); await p.waitForTimeout(900);
    const r = await p.evaluate(() => ({ sw: document.documentElement.scrollWidth, wide: [...document.querySelectorAll('#loginGate *')].filter(e => e.offsetParent && e.getBoundingClientRect().right > 320.5).map(e => e.id || e.className) }));
    assert(r.sw <= 320 && !r.wide.length, 'too wide: ' + JSON.stringify(r)); await signIn(p, 'ruth', STAFF_PW); assert(unlocked(await state(p)), 'sign-in works on a phone');
    assert(!errs.length, errs[0]); await ctx.close(); return 'fits 320 px; sign-in works'; });

  await browser.close();
  const out = path.join(__dirname, '../reports/login.json'); fs.mkdirSync(path.dirname(out), { recursive: true });
  fs.writeFileSync(out, JSON.stringify({ suite: 'login', results }, null, 1)); const f = results.filter(r => !r.pass).length; console.log(`\n${results.length - f}/${results.length} passed`); process.exit(f ? 1 : 0);
})();
