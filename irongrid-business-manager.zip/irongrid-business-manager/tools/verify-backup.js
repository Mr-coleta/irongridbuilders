#!/usr/bin/env node
// Verifies an Irongrid backup on its own, with the accounting engine and no browser. Used by the scheduled restore
// test and by people after any recovery. A backup or restored copy is called VERIFIED only if every check passes.
//
//   node tools/verify-backup.js <backup.json> [--against <other.json>] [--json]
//
// <backup.json> may be an app backup ({app,data,manifest}) or a scheduled backup ({documents:{"coll/id":{data}}}).
// --against compares every record with a second copy (e.g. the backup vs. what was read back from a restored store).
// Exit code 0 = verified, 1 = checks failed, 2 = file unreadable.
'use strict';
const fs = require('fs'); const path = require('path');
const L = require(process.env.LEDGER_PATH || path.join(__dirname, '../engine/ledger.js'));
const COLLS = ['clients', 'suppliers', 'items', 'proformas', 'invoices', 'receipts', 'credits', 'debits', 'refunds', 'lpos', 'purchases', 'payments', 'sdebits', 'adjustments'];
const OWNER_ONLY = ['payments', 'refunds', 'credits', 'adjustments'];

function fnv(t) { let h = 0x811c9dc5; for (let k = 0; k < t.length; k++) { h ^= t.charCodeAt(k); h = Math.imul(h, 0x01000193) >>> 0; } return ('0000000' + h.toString(16)).slice(-8); }
const canon = x => JSON.stringify(x, (k, v) => v && typeof v === 'object' && !Array.isArray(v) ? Object.fromEntries(Object.keys(v).sort().map(j => [j, v[j]])) : v);

/* both formats -> {settings, data:{coll:[{id,...}]}, approvals:Map, manifest} */
function load(file) {
  const raw = JSON.parse(fs.readFileSync(file, 'utf8'));
  if (raw.encrypted) throw new Error('This backup is encrypted. Decrypt it in the app (Business details → restore) or supply the decrypted copy.');
  if (raw.app === 'business-manager' && raw.data) {
    const approvals = new Map((raw.data.approvals || []).map(r => { const d = { ...r }; delete d.id; return [r.id, d]; }));
    return { kind: 'app', settings: raw.settings || {}, data: raw.data, approvals, manifest: raw.manifest || null, counters: raw.counters || {}, raw };
  }
  if (raw.documents) {
    const data = {}; for (const c of COLLS) data[c] = []; const approvals = new Map(); let settings = {}; const counters = {};
    for (const [key, v] of Object.entries(raw.documents)) {
      const parts = key.split('/'); const c = parts[0], id = parts.slice(1).join('/'); const d = v && v.data !== undefined ? v.data : v;
      if (c === 'settings' && id === 'business') settings = d; else if (c === 'counters') counters[id] = d;
      else if (c === 'approvals') approvals.set(id, d); else if (COLLS.includes(c) && parts.length === 2) data[c].push({ id, ...d });
    }
    return { kind: 'scheduled', settings, data, approvals, manifest: null, counters, raw };
  }
  throw new Error('Not an Irongrid backup.');
}

function verify(b, opt = {}) {
  const checks = []; const add = (label, ok, detail) => checks.push({ label, ok: !!ok, detail: detail || '' });
  const dp = ['UGX', 'TZS', 'RWF'].includes(b.settings.currency || 'UGX') ? 0 : 2;
  const by = {}; for (const c of COLLS) by[c] = new Map((b.data[c] || []).map(r => [r.id, r]));
  // 1. the file itself
  if (b.kind === 'app' && b.manifest) {
    const fp = fnv(JSON.stringify(b.raw.data)); add('Backup fingerprint matches its manifest', fp === b.manifest.fingerprint, fp !== b.manifest.fingerprint ? `file ${fp}, manifest ${b.manifest.fingerprint}` : '');
    const bad = Object.entries(b.manifest.counts || {}).filter(([c, n]) => ((b.raw.data[c] || []).length) !== n); add('Record counts match the manifest', !bad.length, bad.map(([c, n]) => `${c}: ${(b.raw.data[c] || []).length} vs ${n}`).join('; '));
  }
  // 1b. a scheduled backup of the live store must hold every record the platform says it has; a count that could not
  //     be confirmed is a failure, never a pass (people's audit and error logs were once silently left out this way)
  if (b.kind === 'scheduled' && b.raw.source && !opt.readBack) {
    const n = Object.keys(b.raw.documents).length; const u = b.raw.usage || {};
    if (Number.isInteger(u.documents)) { const during = Array.isArray(b.raw.createdDuringRun) ? b.raw.createdDuringRun.length : 0;
      add('Every record in the store was captured (platform count ' + u.documents + ')', n >= u.documents && n <= u.documents + during, !(n >= u.documents && n <= u.documents + during) ? `backup has ${n}, the platform reported ${u.documents}${during ? ` (${during} listed as created during the run)` : ''} — missing records, for example people's audit or error logs (audit/<person>/days|errors|metrics)` : ''); }
    else add('Every record in the store was captured', false, 'the platform record count was not recorded in this backup, so completeness could not be confirmed');
    if (Number.isInteger(b.raw.documentsCollected)) add('Header count matches the records in the file', b.raw.documentsCollected === n, `header ${b.raw.documentsCollected}, file ${n}`);
  }
  // 2. engine: every journal balanced, sealed, matching its document, valid accounts and dates, stock consistent
  const entries = []; for (const c of L.DOC_COLLS) for (const r of b.data[c] || []) entries.push({ coll: c, id: r.id, doc: r });
  const res = L.check(entries, { dp, depOf: (c, d) => c === 'credits' ? by.invoices.get(d.invoiceId) : null, unitCost: (c, d) => c === 'credits' ? L.unitCosts((by.invoices.get(d.invoiceId) || {}).je) : null });
  add('Every journal balanced, sealed and matching its document', res.issues.length === 0, res.issues.slice(0, 5).map(i => i.ref + ': ' + i.msg).join(' | '));
  const J = res.journals; const tb = L.trialBalance(J), bs = L.balanceSheet(J); const bal = L.balances(J); const B = a => bal[a] ? bal[a].d - bal[a].c : 0;
  add('Trial balance: debits = credits', tb.ok, tb.ok ? '' : `${tb.dr} vs ${tb.cr}`);
  add('Balance sheet: assets = liabilities + equity', bs.ok, bs.ok ? '' : `${bs.assets} vs ${bs.liabilities + bs.equity}`);
  // 3. control accounts against their subledgers
  const sum = m => [...m.values()].reduce((a, x) => a + x, 0);
  add('Receivables control (1100) = sum of client balances', B('1100') === sum(L.partyBalances(J, '1100')), `${B('1100')} vs ${sum(L.partyBalances(J, '1100'))}`);
  add('Payables control (2000) = sum of supplier balances', -B('2000') === sum(L.partyBalances(J, '2000')), `${-B('2000')} vs ${sum(L.partyBalances(J, '2000'))}`); // a credit balance
  const stockVal = Object.values(res.stock || {}).reduce((t, s) => t + s.v, 0); add('Inventory (1200) = weighted-average stock valuation', B('1200') === stockVal, `${B('1200')} vs ${stockVal}`);
  const mi = x => L.exactMinor(x, dp); const live = c => (b.data[c] || []).filter(x => !x.void);
  for (const a of L.CASH_ACCTS) { const ms = Object.keys(L.CASH).filter(m => L.CASH[m] === a); const f = c => live(c).filter(x => ms.includes(x.method));
    const sub = f('receipts').reduce((t, x) => t + mi(x.amount), 0) - f('payments').reduce((t, x) => t + mi(x.amount), 0) + f('refunds').reduce((t, x) => t + (x.supplierId ? 1 : -1) * mi(x.amount), 0);
    if (B(a) || sub) add(`Cash account ${a} = receipts − payments ± refunds by that method`, B(a) === sub, `${B(a)} vs ${sub}`); }
  const vat = c => live(c).reduce((t, x) => { const r = L.calcDoc(x, dp); return t + (r.err ? 0 : r.vat); }, 0);
  const outV = vat('invoices') + vat('debits') - vat('credits') - live('payments').filter(x => x.category === 'VAT paid to URA' && !x.supplierId).reduce((t, x) => t + mi(x.amount), 0);
  add('Output VAT (2100) = VAT on sales − credit notes − VAT paid', -B('2100') === outV, `${-B('2100')} vs ${outV}`);
  add('Input VAT (1300) = VAT on purchases − supplier debit notes', B('1300') === vat('purchases') - vat('sdebits'), `${B('1300')} vs ${vat('purchases') - vat('sdebits')}`);
  // 4. referential integrity and numbering
  const ref = []; const need = (c, r, f, t) => { if (r[f] && !by[t].has(r[f])) ref.push(`${c}/${r.id}.${f}`); };
  for (const c of COLLS) for (const r of b.data[c] || []) { need(c, r, 'clientId', 'clients'); need(c, r, 'supplierId', 'suppliers'); need(c, r, 'invoiceId', 'invoices'); need(c, r, 'purchaseId', 'purchases'); need(c, r, 'itemId', 'items'); for (const i of r.items || []) if (i && i.itemId && !by.items.has(i.itemId)) ref.push(`${c}/${r.id} item ${i.itemId}`); }
  add('Every reference points to an existing record', !ref.length, ref.slice(0, 5).join(', '));
  const dup = []; for (const c of COLLS) { const seen = new Set(); for (const r of b.data[c] || []) if (r.number) { if (seen.has(r.number)) dup.push(c + ' ' + r.number); seen.add(r.number); } }
  add('No duplicate document numbers', !dup.length, dup.slice(0, 5).join(', '));
  // 5. approvals (only meaningful when the copy carries approval records)
  if (b.approvals.size || b.kind === 'app' && Array.isArray(b.raw.data.approvals)) {
    const miss = []; for (const c of OWNER_ONLY) for (const r of b.data[c] || []) if (r.je && !b.approvals.has(c + '-' + r.id)) miss.push(c + '/' + (r.number || r.id));
    for (const c of L.DOC_COLLS) for (const r of b.data[c] || []) if (r.void && !b.approvals.has(c + '-' + r.id + '-void')) miss.push(c + '/' + (r.number || r.id) + ' (void)');
    add('Every payment, refund, credit note, adjustment and void has an approval record', !miss.length, miss.slice(0, 5).join(', '));
  }
  // 6. control totals recorded when the backup was made
  const C = b.manifest && b.manifest.controls;
  if (C) { const keys = new Set([...Object.keys(C.balances || {}), ...Object.keys(bal)]); const d = [...keys].filter(k => (C.balances[k] || 0) !== B(k));
    add(`Journal count equals the backup's control total (${C.journals})`, J.length === C.journals, `${J.length}`);
    add("Every account balance equals the backup's control totals", !d.length, d.slice(0, 6).map(k => `${k}: ${C.balances[k] || 0} vs ${B(k)}`).join('; ')); }
  const totals = { records: COLLS.reduce((t, c) => t + (b.data[c] || []).length, 0), journals: J.length, approvals: b.approvals.size, receivables: B('1100'), payables: -B('2000'), inventory: B('1200'), cash: L.CASH_ACCTS.reduce((t, a) => t + B(a), 0) };
  return { checks, totals };
}

function compare(a, b) { // record-by-record: every record of a must be in b, identical; and nothing extra
  const out = { missing: [], changed: [], extra: [] };
  for (const c of [...COLLS]) { const A = new Map((a.data[c] || []).map(r => [r.id, r])), Bm = new Map((b.data[c] || []).map(r => [r.id, r]));
    for (const [id, r] of A) { if (!Bm.has(id)) out.missing.push(c + '/' + id); else if (canon(r) !== canon(Bm.get(id))) out.changed.push(c + '/' + id); }
    for (const id of Bm.keys()) if (!A.has(id)) out.extra.push(c + '/' + id); }
  for (const [k, v] of a.approvals) { if (!b.approvals.has(k)) out.missing.push('approvals/' + k); else if (canon(v) !== canon(b.approvals.get(k))) out.changed.push('approvals/' + k); }
  for (const k of b.approvals.keys()) if (!a.approvals.has(k)) out.extra.push('approvals/' + k);
  return out;
}

module.exports = { load, verify, compare };
if (require.main === module) {
  const args = process.argv.slice(2); const file = args.find(x => !x.startsWith('--')); const ai = args.indexOf('--against'); const json = args.includes('--json');
  let b; try { b = load(file); } catch (e) { console.error('Cannot read backup: ' + e.message); process.exit(2); }
  const r = verify(b); let cmp = null;
  if (ai > 0) { const other = load(args[ai + 1]); cmp = compare(b, other); const o = verify(other, { readBack: true });
    r.checks.push({ label: 'Second copy: every record present and identical, nothing extra', ok: !cmp.missing.length && !cmp.changed.length && !cmp.extra.length, detail: `missing ${cmp.missing.length}, changed ${cmp.changed.length}, extra ${cmp.extra.length}` + (cmp.missing.concat(cmp.changed).length ? ' — ' + cmp.missing.concat(cmp.changed).slice(0, 5).join(', ') : '') });
    for (const x of o.checks) r.checks.push({ ...x, label: 'Second copy — ' + x.label }); r.totalsAgainst = o.totals; }
  const ok = r.checks.every(x => x.ok); const report = { file: path.basename(file), verifiedAt: new Date().toISOString(), verdict: ok ? 'VERIFIED' : 'NOT VERIFIED', ...r };
  if (json) console.log(JSON.stringify(report, null, 1));
  else { console.log(`${report.verdict} — ${report.file}`); for (const c of r.checks) console.log(`  ${c.ok ? 'PASS' : 'FAIL'}  ${c.label}${c.detail && !c.ok ? '  — ' + c.detail : ''}`); console.log('  totals: ' + JSON.stringify(r.totals)); }
  process.exit(ok ? 0 : 1);
}
