# Injects engine/ledger.js and src/accounts.js into system.html between their markers.
p='index.html';s=open(p).read()
def inject(a,b,code,anchor):
    global s
    if a not in s:
        assert s.count(anchor)==1,anchor;s=s.replace(anchor,a+'\n'+b+'\n'+anchor)
    i=s.index(a)+len(a);j=s.index(b);s=s[:i]+'\n'+code+'\n'+s[j:]
inject('/*<ledger>*/','/*</ledger>*/',open('engine/ledger.js').read().replace('if(typeof module!=="undefined")module.exports=LEDGER;',''),'/* ====================== config ====================== */')
inject('/*<reports>*/','/*</reports>*/',open('engine/reports.js').read().replace('if(typeof module!=="undefined")module.exports=REPORTS;',''),'/* ====================== config ====================== */')
inject('/*<accounts>*/','/*</accounts>*/',open('src/accounts.js').read(),'function lockMsg(date){')
inject('/*<security>*/','/*</security>*/',open('src/security.js').read(),'function lockMsg(date){')
inject('/*<monitoring>*/','/*</monitoring>*/',open('src/monitoring.js').read(),'function lockMsg(date){')
inject('/*<resilience>*/','/*</resilience>*/',open('src/resilience.js').read(),'function lockMsg(date){')
inject('/*<login>*/','/*</login>*/',open('src/login.js').read(),'function lockMsg(date){')
open(p,'w').write(s);print('built')
