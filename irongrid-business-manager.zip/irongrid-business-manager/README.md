# Irongrid Business Manager

Accounting app for Irongrid Builders Co Limited (Uganda, UGX). It covers invoices, receipts, proformas, LPOs, purchases, payments, credit and debit notes, stock, VAT, a general ledger and reports. The whole app is one self-contained page, `index.html`. It runs as a claude.ai artifact and uses the platform's `db`, `user` and `downloads` capabilities.

Live app: https://claude.ai/artifact/Wwmq2mwnuMpq6TvhKt9Amq (only people it is shared with can open it).

## Layout

| Path | What it is |
|---|---|
| `index.html` | The built app (this is what gets published) |
| `engine/ledger.js` | Accounting engine: exact-money (BigInt) posting rules, validation, integrity seal |
| `engine/reports.js` | Report index (trial balance, GL, ageing, stock, cash flow) |
| `src/accounts.js` | Accounts screen and posting builder |
| `src/security.js` | Owner approvals, audit trail |
| `src/monitoring.js` | Health checks, alert rules and redacted logging |
| `src/resilience.js` | Retries, reconnects, health page |
| `src/login.js` | Username and password login screen (PBKDF2-SHA-256, salted) |
| `theme/qb.css` | Visual theme |
| `security/rules.json` | Server-side access rules declared on the artifact |
| `tools/build.py` | Puts the `engine/` and `src/` files into `index.html` between their markers |
| `tools/verify-backup.js` | Checks that a backup is complete and reconciles |
| `tests/` | Automated tests and the release gate (see `tests/README.md`) |

## Build and test

```
python3 tools/build.py                 # rebuild index.html after editing engine/ or src/
mkdir -p srv && cp index.html srv/index.html
npm i playwright && npx playwright install chromium
node tests/run-all.js --quick          # engine unit + integration + coverage (~15 s)
node tests/run-all.js                  # everything, including the browser suites (~40 min)
```

The gate blocks a release if any mandatory test fails, or if engine coverage is under 90%. With `--mutation` it also blocks one where the mutation score is under 85%. The last full run passed 387 of 387 tests.

## Rules for changes

See the project's engineering rules. In short:
- Financial accuracy, data integrity and security come before features.
- Any change to accounting calculations or posting rules needs explicit approval.
- Every fix comes with a regression test.
- Run all tests after every change.

No business data or backups are kept in this repository.
