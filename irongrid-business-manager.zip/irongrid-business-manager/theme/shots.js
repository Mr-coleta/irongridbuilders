// Screenshots of key screens and a printed invoice. LABEL=before|after. Server on :8765 serving srv/.
const { chromium } = require('playwright'); const MOCK = require('../tests/mocksrc.js'); const fs = require('fs'); const crypto = require('crypto');
const { build } = require('../tests/scale/books.js'); const small = build(300, 5);
const SEED = `for (const [k,v] of ${JSON.stringify([...small.docs.entries()])}) st.set(k,v); st.set("settings/business",{name:"Irongrid Builders Co Limited",currency:"UGX",address:"Lubowa",phone:"0700 000000"});`;
(async () => { const L = process.env.LABEL || 'before'; const b = await chromium.launch(); const out = {};
  for (const [w, h, tag] of [[1366, 860, 'desk'], [390, 844, 'phone']]) {
    const p = await b.newPage({ viewport: { width: w, height: h } }); await p.addInitScript(`${MOCK};window.__mock({});const st=window.__S;${SEED}`);
    for (const v of (tag === 'desk' ? ['dashboard', 'invoices', 'accounts', 'settings'] : ['dashboard', 'invoices'])) { await p.goto('http://localhost:8765/index.html#' + v); await p.waitForTimeout(1500); await p.screenshot({ path: `/home/claude/theme/${L}-${tag}-${v}.png` }); }
    if (tag === 'desk') { await p.goto('http://localhost:8765/index.html#invoices'); await p.waitForTimeout(1200); await p.click('.view.on tbody tr[data-id]'); await p.waitForTimeout(500);
      await p.screenshot({ path: `/home/claude/theme/${L}-desk-invoice-open.png` });
      const html = await p.evaluate(() => pageFile('INV', docHTML('invoices', S.invoices.find(x => x.je) || S.invoices[0])));
      const q = await b.newPage({ viewport: { width: 900, height: 1200 } }); await q.setContent(html); await q.waitForTimeout(400);
      const png = await q.screenshot({ path: `/home/claude/theme/${L}-print-invoice.png`, fullPage: true }); out.printPng = crypto.createHash('sha256').update(png).digest('hex'); await q.close(); }
    await p.close(); }
  fs.writeFileSync(`/home/claude/theme/${L}.json`, JSON.stringify(out)); console.log(out); await b.close(); })();
