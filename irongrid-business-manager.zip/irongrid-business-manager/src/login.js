/* ====================== app login (username + password) ======================
   A login screen in front of the whole app, on top of the Claude sign-in that the platform already requires.
   What it protects against: someone using a phone or computer that is already signed in to Claude, and sharing one
   device between people. What it cannot do: it runs in the browser, so it is not a substitute for the platform's
   own sign-in, which stays the real access control (the app is only reachable by people it is shared with).

   Storage: one record per login at settings/login-<username>, under the existing "settings" access rule — only the
   owner can create or change a login; everyone the app is shared with can read them (needed to check a password).
   Passwords are never stored: each record holds a random salt and a PBKDF2-SHA-256 hash (210,000 rounds).
   No platform access rule changes. Backward compatible: with no logins set up, the app opens exactly as before.

   When the screen is shown: when at least one login exists, or when this device has seen logins before and can't
   yet confirm the list (fail closed). Signing in lasts for this browser tab; 30 minutes without activity, closing the
   tab, or "Sign out" locks it again. 5 wrong attempts lock this device for 1 minute, doubling each time.
   The platform owner can always reset a password from the login screen, so the owner can't be locked out. */
const LOGIN={loaded:false,list:new Map(),session:null,iter:210000,idleMs:30*60000,last:Date.now(),busy:false};
const LS=(k,v)=>{try{if(v===undefined)return localStorage.getItem(k);if(v===null)localStorage.removeItem(k);else localStorage.setItem(k,v)}catch(e){return null}};
const SS=(k,v)=>{try{if(v===undefined)return sessionStorage.getItem(k);if(v===null)sessionStorage.removeItem(k);else sessionStorage.setItem(k,v)}catch(e){return null}};
const unameOk=u=>/^[a-z0-9][a-z0-9._-]{2,31}$/.test(u);
const b64=buf=>btoa(String.fromCharCode(...new Uint8Array(buf)));const unb64=s=>Uint8Array.from(atob(s),c=>c.charCodeAt(0));
async function pwHash(pw,saltB64,iter){const key=await crypto.subtle.importKey("raw",new TextEncoder().encode(pw),"PBKDF2",false,["deriveBits"]);
  const bits=await crypto.subtle.deriveBits({name:"PBKDF2",hash:"SHA-256",salt:unb64(saltB64),iterations:iter},key,256);return b64(bits)}
const sameStr=(a,b)=>{if(typeof a!=="string"||typeof b!=="string"||a.length!==b.length)return false;let d=0;for(let i=0;i<a.length;i++)d|=a.charCodeAt(i)^b.charCodeAt(i);return d===0};
function pwProblem(pw,u){if(typeof pw!=="string"||pw.length<8)return"Use at least 8 characters.";if(pw.length>128)return"Use at most 128 characters.";if(u&&pw.toLowerCase().includes(u))return"Don't include the username in the password.";return""}
/* ---------- session ---------- */
function loadSession(){try{const s=JSON.parse(SS("ig.session")||"null");if(s&&s.u&&Date.now()-s.at<LOGIN.idleMs)return s}catch(e){}return null}
function saveSession(u){LOGIN.session={u,at:Date.now()};SS("ig.session",JSON.stringify(LOGIN.session))}
function endSession(why){LOGIN.session=null;SS("ig.session",null);if(why)logEvent("info","signed-out",{state:why});gateUpdate()}
function touchSession(){if(!LOGIN.session)return;const now=Date.now();if(now-LOGIN.session.at>LOGIN.idleMs){endSession("idle");return}if(now-LOGIN.session.at>15000){LOGIN.session.at=now;SS("ig.session",JSON.stringify(LOGIN.session))}}
["click","keydown","touchstart"].forEach(ev=>document.addEventListener(ev,()=>touchSession(),{capture:true,passive:true}));
setInterval(()=>{if(LOGIN.session&&Date.now()-LOGIN.session.at>LOGIN.idleMs)endSession("idle")},20000);
/* ---------- attempts limit (this device) ---------- */
function failState(){try{return JSON.parse(LS("ig.loginFail")||"null")||{n:0,until:0,round:0}}catch(e){return{n:0,until:0,round:0}}}
function lockedFor(){const f=failState();return Math.max(0,f.until-Date.now())}
function noteFail(){const f=failState();f.n++;if(f.n>=5){f.round=(f.round||0)+1;f.until=Date.now()+60000*2**(f.round-1);f.n=0}LS("ig.loginFail",JSON.stringify(f))}
const clearFails=()=>LS("ig.loginFail",null);
/* ---------- state ---------- */
/* waiting = the list of logins hasn't arrived yet. The app stays covered until it does (no flash of records), and a
   device that has seen logins before stays locked if the list can't be read at all (fail closed). */
LOGIN.waiting=true;
const loginsOn=()=>LOGIN.list.size>0||(!LOGIN.loaded&&LS("ig.loginsOn")==="1");
const sessionOk=()=>!!(LOGIN.session&&LOGIN.list.has(LOGIN.session.u)&&!LOGIN.list.get(LOGIN.session.u).disabled);
function gateLocked(){if(!db)return false;if(LOGIN.waiting)return true;return loginsOn()&&!sessionOk()}
function loginBoot(){LOGIN.session=loadSession();if(!db){LOGIN.loaded=true;LOGIN.waiting=false;gateUpdate();return}gateUpdate();
  const stopWait=()=>{if(LOGIN.waiting){LOGIN.waiting=false;gateUpdate()}};
  setTimeout(stopWait,12000)/* never cover the app forever: after 12 s the normal rules decide */;
  const subL=(n=0)=>{try{db.collection("settings").onSnapshot(snap=>{const m=new Map();for(const x of snap.docs){if(!/^login-/.test(x.id))continue;let d;try{d=x.data()}catch(e){continue}if(d&&d.kind==="login"&&unameOk(d.username))m.set(d.username,d)}
      LOGIN.list=m;LOGIN.loaded=true;LOGIN.waiting=false;LS("ig.loginsOn",m.size?"1":null);gateUpdate();if(view==="settings")loginsMaybe()},
    err=>{if(err&&(err.code==="unavailable"||err.code==="resource_exhausted")){stopWait();setTimeout(()=>subL(n+1),Math.min(60000,2000*2**Math.min(n,5)));return}
      /* can't read the list: stay locked if this device has seen logins (fail closed) */LOGIN.loaded=false;LOGIN.list=new Map();stopWait()})}catch(e){stopWait()}};
  subL()}
/* ---------- the screen ---------- */
function gateEl(){let g=$("#loginGate");if(g)return g;g=document.createElement("div");g.id="loginGate";g.setAttribute("role","dialog");g.setAttribute("aria-modal","true");g.setAttribute("aria-labelledby","lgTitle");
  g.innerHTML=`<div class="lgcard"><div class="lglogo" id="lgLogo">I</div><h1 id="lgTitle">Sign in</h1><p class="lgbiz" id="lgBiz"></p>
    <form id="lgForm" autocomplete="on" novalidate><label for="lgUser">Username</label><input id="lgUser" name="username" autocomplete="username" autocapitalize="none" spellcheck="false" required>
      <label for="lgPass">Password</label><div class="lgpw"><input id="lgPass" name="password" type="password" autocomplete="current-password" required><button type="button" class="lgshow" id="lgShow" aria-label="Show password">Show</button></div>
      <p class="lgerr" id="lgErr" role="alert"></p><button class="btn lgbtn" type="submit" id="lgGo">Sign in</button></form>
    <form id="lgReset" hidden novalidate><p class="lgnote">You're the owner of this app, so you can set a new password for any login.</p>
      <label for="lgRUser">Username</label><input id="lgRUser" autocapitalize="none" spellcheck="false" required>
      <label for="lgRPass">New password</label><input id="lgRPass" type="password" autocomplete="new-password" required>
      <label for="lgRPass2">New password again</label><input id="lgRPass2" type="password" autocomplete="new-password" required>
      <p class="lgerr" id="lgRErr" role="alert"></p><button class="btn lgbtn" type="submit">Set new password</button><button class="btn ghost lgbtn" type="button" id="lgRBack">Back to sign in</button></form>
    <p class="lgfoot"><span id="lgOwner" hidden><a href="#" id="lgForgot">Forgot your password?</a> · </span>Ask the owner if you need a login.</p></div>`;
  document.body.appendChild(g);
  $("#lgShow").onclick=()=>{const p=$("#lgPass");const s=p.type==="password";p.type=s?"text":"password";$("#lgShow").textContent=s?"Hide":"Show";$("#lgShow").setAttribute("aria-label",s?"Hide password":"Show password")};
  $("#lgForm").onsubmit=async e=>{e.preventDefault();if(LOGIN.busy)return;const err=$("#lgErr");const u=$("#lgUser").value.trim().toLowerCase(),pw=$("#lgPass").value;
    const wait=lockedFor();if(wait){err.textContent=`Too many wrong attempts. Try again in ${Math.ceil(wait/1000)} seconds.`;return}
    if(!u||!pw){err.textContent="Enter your username and password.";return}
    if(!LOGIN.loaded){err.textContent="Can't check logins right now — check your connection and try again.";return}
    LOGIN.busy=true;$("#lgGo").disabled=true;err.textContent="Checking…";let ok=false;
    try{const r=LOGIN.list.get(u);if(r&&!r.disabled&&r.salt&&r.hash){ok=sameStr(await pwHash(pw,r.salt,r.iter||LOGIN.iter),r.hash)}else{await pwHash(pw,"AAAAAAAAAAAAAAAAAAAAAA==",LOGIN.iter)/* same delay either way */}}catch(x){ok=false}
    LOGIN.busy=false;$("#lgGo").disabled=false;$("#lgPass").value="";
    if(!ok){noteFail();logEvent("warn","login-failed",{});const w=lockedFor();err.textContent=w?`Too many wrong attempts. Try again in ${Math.ceil(w/1000)} seconds.`:"Wrong username or password.";$("#lgPass").focus();return}
    clearFails();saveSession(u);err.textContent="";try{audit("sign-in","logins/"+u,{})}catch(x){}logEvent("info","signed-in",{});gateUpdate()};
  $("#lgForgot").onclick=e=>{e.preventDefault();$("#lgForm").hidden=true;$("#lgReset").hidden=false;$("#lgOwner").hidden=true;$("#lgRUser").focus()};
  $("#lgRBack").onclick=()=>{$("#lgReset").hidden=true;$("#lgForm").hidden=false;gateUpdate()};
  $("#lgReset").onsubmit=async e=>{e.preventDefault();const err=$("#lgRErr");if(!isOwnerUser){err.textContent="Only the owner can do this.";return}
    const u=$("#lgRUser").value.trim().toLowerCase(),p1=$("#lgRPass").value,p2=$("#lgRPass2").value;const r=LOGIN.list.get(u);
    if(!r){err.textContent="There is no login with that username.";return}const pp=pwProblem(p1,u);if(pp){err.textContent=pp;return}if(p1!==p2){err.textContent="The two passwords don't match.";return}
    err.textContent="Saving…";const res=await saveLogin({...r,disabled:false},p1);if(!res){err.textContent="Couldn't save — check your connection and try again.";return}
    $("#lgRPass").value=$("#lgRPass2").value="";$("#lgReset").hidden=true;$("#lgForm").hidden=false;$("#lgUser").value=u;$("#lgErr").textContent="Password changed. Sign in with the new password.";$("#lgPass").focus()};
  return g}
function gateUpdate(){const locked=gateLocked();const app=document.querySelector(".app"),modal=$("#modal");
  if(locked){const g=gateEl();g.hidden=false;document.body.classList.add("lg-locked");[app,modal].forEach(x=>{if(x){x.setAttribute("inert","");x.setAttribute("aria-hidden","true")}});
    const bn=(typeof settings!=="undefined"&&settings&&settings.name)||"";$("#lgBiz").textContent=bn;$("#lgLogo").textContent=(bn[0]||"I").toUpperCase();$("#lgOwner").hidden=!isOwnerUser||!$("#lgReset").hidden;
    g.classList.toggle("wait",LOGIN.waiting);$("#lgTitle").textContent=LOGIN.waiting?"Loading…":"Sign in";
    if(document.activeElement===document.body||!g.contains(document.activeElement)){const f=$("#lgUser");if(f&&!$("#lgForm").hidden)setTimeout(()=>{if(gateLocked())f.focus()},0)}}
  else{const g=$("#loginGate");if(g)g.hidden=true;document.body.classList.remove("lg-locked");[app,modal].forEach(x=>{if(x){x.removeAttribute("inert");x.removeAttribute("aria-hidden")}})}
  const who=$("#qbWho");if(who){const on=!!(LOGIN.session&&LOGIN.list.size);who.hidden=!on;if(on)$("#qbWhoName").textContent=(LOGIN.list.get(LOGIN.session.u)||{}).name||LOGIN.session.u}}
/* ---------- owner: manage logins (Business details) ---------- */
async function saveLogin(rec,newPw){const u=rec.username;if(!unameOk(u))return false;const out={kind:"login",username:u,name:String(rec.name||"").slice(0,60),role:rec.role==="owner"?"owner":"staff",disabled:!!rec.disabled,
    salt:rec.salt,hash:rec.hash,iter:rec.iter||LOGIN.iter,createdAt:rec.createdAt||nowISO(),createdBy:rec.createdBy||myId||"",updatedAt:nowISO(),updatedBy:myId||""};
  if(newPw){const s=new Uint8Array(16);crypto.getRandomValues(s);out.salt=b64(s);out.iter=LOGIN.iter;out.hash=await pwHash(newPw,out.salt,out.iter)}
  if(!out.salt||!out.hash)return false;
  try{await withRetry(()=>db.doc("settings/login-"+u).set(out),{ctx:{op:"set",path:"settings/login-"+u}});try{audit(newPw?"login-password-set":"login-update","logins/"+u,{})}catch(e){}return true}catch(e){return false}}
async function removeLogin(u){try{await withRetry(()=>db.doc("settings/login-"+u).delete(),{ctx:{op:"delete",path:"settings/login-"+u}});try{audit("login-removed","logins/"+u,{})}catch(e){}return true}catch(e){return false}}
function loginsMaybe(){const box=$("#loginsBox");if(!box)return;const sig=isOwnerUser+"|"+JSON.stringify([...LOGIN.list.values()].map(r=>[r.username,r.name,r.role,r.disabled]));if(sig!==LOGIN.sig||!box.firstChild)renderLogins()}
function renderLogins(){const box=$("#loginsBox");if(!box)return;LOGIN.sig=isOwnerUser+"|"+JSON.stringify([...LOGIN.list.values()].map(r=>[r.username,r.name,r.role,r.disabled]));if(!isOwnerUser){box.innerHTML=`<p class="sub">Only the owner can add or change logins.</p>`;return}
  const rows=[...LOGIN.list.values()].sort((a,b)=>a.username.localeCompare(b.username));
  box.innerHTML=(rows.length?`<table class="lgtable"><thead><tr><th>Username</th><th>Name</th><th>Role</th><th>Status</th><th></th></tr></thead><tbody>${rows.map(r=>`<tr data-lu="${esc(r.username)}"><td class="mono">${esc(r.username)}</td><td>${esc(r.name||"")}</td><td>${r.role==="owner"?"Owner":"Staff"}</td><td>${r.disabled?'<span class="tag t-void">Disabled</span>':'<span class="tag t-paid">Active</span>'}</td>
      <td style="white-space:nowrap"><button type="button" class="btn ghost small" data-lact="reset">Set password</button> <button type="button" class="btn ghost small" data-lact="toggle">${r.disabled?"Enable":"Disable"}</button> <button type="button" class="btn red small" data-lact="remove">Remove</button></td></tr>`).join("")}</tbody></table>`
    :`<p class="sub" id="lgNone">No logins yet, so the app opens without a login screen. Add your own login first, then one for each person you share the app with.</p>`)+
   `<form id="lgAdd" class="lgadd" novalidate><div class="row r4"><div><label for="lgAU">Username</label><input id="lgAU" autocapitalize="none" spellcheck="false" placeholder="e.g. alex"></div><div><label for="lgAN">Full name</label><input id="lgAN" placeholder="e.g. Alex Kalungi"></div>
      <div><label for="lgAP">Password</label><input id="lgAP" type="password" autocomplete="new-password"></div><div><label for="lgAP2">Password again</label><input id="lgAP2" type="password" autocomplete="new-password"></div></div>
      <div class="row r2"><div><label for="lgAR">Role</label><select id="lgAR"><option value="staff">Staff</option><option value="owner"${rows.length?"":" selected"}>Owner (you)</option></select></div><div class="actions" style="align-self:end;margin:0"><button class="btn" type="submit" id="lgAddGo">${rows.length?"Add login":"Add my login and turn on the login screen"}</button></div></div>
      <p class="lgerr" id="lgAErr" role="alert"></p><p class="hint">Usernames: 3–32 lowercase letters, numbers, dots, dashes or underscores. Passwords: at least 8 characters. Passwords are stored only as a salted hash.</p></form>`;
  $("#lgAdd").onsubmit=async e=>{e.preventDefault();const err=$("#lgAErr");const u=$("#lgAU").value.trim().toLowerCase(),n=$("#lgAN").value.trim(),p1=$("#lgAP").value,p2=$("#lgAP2").value,role=$("#lgAR").value;
    if(!unameOk(u)){err.textContent="Usernames are 3–32 characters: lowercase letters, numbers, dots, dashes or underscores, starting with a letter or number.";return}
    if(LOGIN.list.has(u)){err.textContent="That username is already taken.";return}const pp=pwProblem(p1,u);if(pp){err.textContent=pp;return}if(p1!==p2){err.textContent="The two passwords don't match.";return}
    if(writesBlocked()){err.textContent=writesBlocked();return}err.textContent="Saving…";$("#lgAddGo").disabled=true;
    const first=!LOGIN.list.size;if(first)saveSession(u)/* the owner who sets it up stays signed in on this tab */;
    const ok=await saveLogin({username:u,name:n,role},p1);$("#lgAddGo").disabled=false;
    if(!ok){if(first)endSession();err.textContent="Couldn't save — check your connection and try again.";return}gateUpdate();toast(first?"Login screen is on. You're signed in as "+u+".":"Login added for "+u+".")};
  box.querySelectorAll("[data-lact]").forEach(b=>b.onclick=async()=>{const u=b.closest("tr").dataset.lu;const r=LOGIN.list.get(u);if(!r)return;const act=b.dataset.lact;
    if(act==="toggle"){if(!r.disabled&&r.role==="owner"&&[...LOGIN.list.values()].filter(x=>x.role==="owner"&&!x.disabled).length===1){toast("Keep at least one active owner login.");return}if(await saveLogin({...r,disabled:!r.disabled}))toast((r.disabled?"Enabled ":"Disabled ")+u)}
    if(act==="remove"){if(r.role==="owner"&&[...LOGIN.list.values()].filter(x=>x.role==="owner").length===1&&LOGIN.list.size>1){toast("Remove the staff logins first, or add another owner login.");return}
      askConfirm(`Remove the login "${u}"? ${LOGIN.list.size===1?"This is the last login, so the login screen will turn off.":"They won't be able to sign in."}`,async()=>{closeModal();if(await removeLogin(u)){toast("Removed "+u);if(LOGIN.session&&LOGIN.session.u===u)endSession("removed")}},"Remove")}
    if(act==="reset"){const tr=b.closest("tr");if(tr.nextElementSibling&&tr.nextElementSibling.classList.contains("lgresetrow"))return;const row=document.createElement("tr");row.className="lgresetrow";
      row.innerHTML=`<td colspan="5"><form class="lgreset" novalidate><div class="row r4"><div><label>New password for ${esc(u)}</label><input type="password" class="p1" autocomplete="new-password"></div><div><label>Again</label><input type="password" class="p2" autocomplete="new-password"></div><div class="actions" style="align-self:end;margin:0"><button class="btn small" type="submit">Save password</button> <button class="btn ghost small" type="button" data-x>Cancel</button></div></div><p class="lgerr"></p></form></td>`;
      tr.after(row);const f=row.querySelector("form");row.querySelector("[data-x]").onclick=()=>row.remove();
      f.onsubmit=async ev=>{ev.preventDefault();const p1=f.querySelector(".p1").value,p2=f.querySelector(".p2").value,er=f.querySelector(".lgerr");const pp=pwProblem(p1,u);if(pp){er.textContent=pp;return}if(p1!==p2){er.textContent="The two passwords don't match.";return}
        er.textContent="Saving…";if(await saveLogin(r,p1)){row.remove();toast("Password set for "+u)}else er.textContent="Couldn't save — try again."}}})}
document.addEventListener("click",e=>{if(e.target.closest("#qbSignOut")){e.preventDefault();endSession("sign-out")}});
