/* ====================== ledger: posting, stock, checks, reports ======================
   Every financial document carries its own journal entry (je) inside the same record, written in the same single
   save, so a posting can never be half done: the document and its journal are stored together or not at all.
   A void adds the reversal entry (jr) to the same record in one update. Posting ids are the document path
   ("invoices/<id>", "invoices/<id>:R"), so the same document can never be posted twice; a retried save reuses
   the same id and replaces the same record. Nothing here ever edits a posted line or adds a balancing entry. */
const POSTED=new Set(LEDGER.DOC_COLLS);
const M=x=>LEDGER.toMajor(x||0,DP());             /* minor units → amount for display */
const mm=x=>money(M(x)),mm0=x=>money0(M(x));
const accName=a=>(LEDGER.ACC[a]||["?"])[0];
const itemName=id=>{const i=byId("items",id);return i?i.name:"(deleted item)"};
const stockIdsOf=(coll,d)=>{const s=new Set();if(coll==="adjustments"&&d.itemId)s.add(d.itemId);(d.items||[]).forEach(i=>{if(i.itemId)s.add(i.itemId)});(d.goods||[]).forEach(g=>{if(g.itemId)s.add(g.itemId)});return[...s]};
const stockRefs=(coll,d)=>stockIdsOf(coll,d).map(i=>["items",i]);
function periodMsg(coll,date){if(!DRE.test(date||""))return"Enter a valid date.";const lm=lockMsg(date);if(lm)return lm;
  if(["receipts","payments","refunds"].includes(coll)&&date>today())return"Money received or paid can't be dated in the future.";
  if(date.slice(0,7)>today().slice(0,7))return"Documents can't be dated in a future month.";return""}
/* Item stock state read FRESH from the store (every posted movement of those items), minus the given posting ids. */
async function freshStock(itemIds,exclude){const js=new Map();const ex=new Set(exclude||[]);
  const take=(j)=>{if(j&&typeof j.pid==="string"&&Array.isArray(j.lines)&&!ex.has(j.pid))js.set(j.pid,j)};
  if(itemIds.length){
    if(!db){for(const c of LEDGER.STOCK_COLLS)for(const r of S[c])if(stockIdsOf(c,r).some(i=>itemIds.includes(i))){take(r.je);take(r.jr)}}
    else{const qs=[];for(const i of itemIds)for(const c of LEDGER.STOCK_COLLS)qs.push(withTimeout(db.collection(c).where("stockItems","array-contains",i).get(),10000).then(q=>q.docs.forEach(d=>{const x=d.data()||{};take(x.je);take(x.jr)})));await Promise.all(qs)}}
  const rs=LEDGER.replayStock([...js.values()]);const st={},counts={};
  for(const i of itemIds){st[i]=rs.state[i]?{...rs.state[i]}:{q:0,v:0};counts[i]=0}
  for(const j of js.values())for(const m of LEDGER.stockMovements(j))if(itemIds.includes(m.item))counts[m.item]++;
  return{st,counts,issues:rs.issues.filter(x=>itemIds.includes(x.item))}}
/* Builds the journal for a document about to be saved. Call while holding the leases on the linked documents AND its stock items. */
/* Re-reads, straight from the store, everything a posting depends on that isn't already leased and re-checked by the caller:
   the business settings (currency and month-end lock may have just changed), the client or supplier, and every stock item. */
async function freshRefsMsg(d,items,date){const party=d.clientId?["clients",d.clientId]:d.supplierId?["suppliers",d.supplierId]:null;
  const [st,p,its]=await Promise.all([db?withTimeout(db.doc("settings/business").get(),10000).then(x=>normSettings(x.exists?x.data():null)):Promise.resolve(settings),party?freshDoc(party[0],party[1]):Promise.resolve(true),Promise.all(items.map(i=>freshDoc("items",i)))]);
  if(!st||st.currency!==cur())return"The business currency setting just changed. Reload the page before saving.";
  if(st.lockDate&&date<=st.lockDate)return"The books were just locked up to "+fmtDate(st.lockDate)+". Use a later date.";
  if(!p)return"That "+(party[0]==="clients"?"client":"supplier")+" was just deleted by someone else.";
  const gone=items.find((i,k)=>!its[k]);if(gone)return"A stock item on this document was just deleted.";return""}
async function buildPosting(coll,id,data,extra){const d=norm(data,id);const items=stockIdsOf(coll,d);
  const rm=await freshRefsMsg(d,items,d.date);if(rm)return{err:rm};
  const fs=await freshStock(items,[coll+"/"+id]);
  if(fs.issues.length)return{err:"The stock records for "+itemName(fs.issues[0].item)+" have a discrepancy, so nothing was posted. See Accounts → Checks."};
  const r=LEDGER.post(coll,d,{dp:DP(),stock:fs.st,unitCost:extra&&extra.unitCost});if(r.err){monPosting(coll,"refused",r.err);return{err:r.err}}
  LEDGER.numberStock(r.lines,fs.counts);
  return{je:LEDGER.makeJE(coll,id,d,r.lines,{cur:cur(),dp:DP(),at:nowISO(),by:myId||""}),stockItems:items}}
async function buildReversal(coll,id,doc,date,reason){if(!doc.je)return{jr:null};const items=stockIdsOf(coll,doc);
  {const st=db?await withTimeout(db.doc("settings/business").get(),10000).then(x=>normSettings(x.exists?x.data():null)):settings;if(!st||st.currency!==cur())return{err:"The business currency setting just changed. Reload the page."};if(st.lockDate&&date<=st.lockDate)return{err:"The books were just locked up to "+fmtDate(st.lockDate)+"."}}
  const fs=await freshStock(items,[coll+"/"+id+":R"]);
  if(fs.issues.length)return{err:"The stock records for "+itemName(fs.issues[0].item)+" have a discrepancy, so nothing was changed. See Accounts → Checks."};
  const r=LEDGER.reverse(doc.je,fs.st);if(r.err){monPosting(coll,"void-refused",r.err);return{err:r.err}}LEDGER.numberStock(r.lines,fs.counts);
  return{jr:LEDGER.makeRev(coll,id,doc,r.lines,{cur:cur(),dp:DP(),at:nowISO(),by:myId||"",date,reason})}}
/* What a client has paid on an invoice, fresh: receipts linked to it plus advances applied to it. */
async function freshInvPaid(invId,selfId){
  if(!db){let t=0;for(const r of S.receipts){if(r.void||r.id===selfId)continue;if(r.invoiceId===invId)t+=r.amount;for(const a of r.alloc||[])if(a.invoiceId===invId)t+=a.amount}return r2(t)}
  const [a,b]=await Promise.all([withTimeout(db.collection("receipts").where("invoiceId","==",invId).get(),10000),withTimeout(db.collection("receipts").where("allocInv","array-contains",invId).get(),10000)]);
  let t=0;for(const d of a.docs){if(d.id===selfId)continue;const x=d.data()||{};if(x.void)continue;t+=num(x.amount)}
  for(const d of b.docs){const x=d.data()||{};if(x.void)continue;for(const al of (Array.isArray(x.alloc)?x.alloc:[]))if(al&&al.invoiceId===invId)t+=num(al.amount)}return r2(t)}
async function freshNoteSum(coll,field,id,selfId){if(!db)return r2(S[coll].filter(x=>x[field]===id&&x.id!==selfId&&!x.void).reduce((a,x)=>a+calc(x).total,0));
  const q=await withTimeout(db.collection(coll).where(field,"==",id).get(),10000);let t=0;for(const d of q.docs){if(d.id===selfId)continue;const x=norm(d.data()||{},d.id);if(x.void)continue;t+=calc(x).total}return r2(t)}
/* A client's or supplier's balance straight from the posted ledger lines, fresh. Positive = they owe us (client) / we owe them (supplier). */
async function freshPartyBal(kind,id){const isC=kind==="clients",acct=isC?"1100":"2000",field=isC?"clientId":"supplierId";
  const colls=isC?["invoices","debits","credits","receipts","refunds"]:["purchases","sdebits","payments","refunds"];let t=0,unposted=0;
  const take=x=>{if(!x.je){unposted++;return}for(const j of [x.je,x.jr])if(j&&Array.isArray(j.lines))for(const l of j.lines)if(l.a===acct&&l.p===id)t+=isC?l.d-l.c:l.c-l.d};
  if(!db)colls.forEach(c=>S[c].filter(x=>x[field]===id).forEach(take));
  else await Promise.all(colls.map(c=>withTimeout(db.collection(c).where(field,"==",id).get(),10000).then(q=>q.docs.forEach(d=>take(d.data()||{})))));
  return{bal:t,unposted}}

/* ---------- the whole ledger, rebuilt only when records change ---------- */
let LCACHE=null;const CHECKMEMO=new WeakMap();  /* per-document check results, reused while the record object is unchanged */
const ledgerEntries=()=>{const e=[];for(const c of LEDGER.DOC_COLLS)for(const r of S[c])e.push({coll:c,id:r.id,doc:r});return e};
const checkOpts=()=>({dp:DP(),memo:CHECKMEMO,depOf:(c,d)=>c==="credits"?byId("invoices",d.invoiceId):null,unitCost:(c,d)=>c==="credits"?LEDGER.unitCosts((byId("invoices",d.invoiceId)||{}).je):null});
/* Verifies documents in slices of 250 between frames, so a large book never freezes the page; then builds the ledger. */
async function warmLedger(){const e=ledgerEntries(),o=checkOpts();for(let i=0;i<e.length;i+=250){LEDGER.warm(e,o,i,i+250);await sleep(0)}}
function ledger(){if(LCACHE)return LCACHE;const dp=DP();const entries=ledgerEntries();
  const res=LEDGER.check(entries,checkOpts());
  const J=res.journals,recon=[];const mi=x=>LEDGER.exactMinor(r2(x),dp)??NaN;
  const cmp=(label,gl,sub)=>{const ok=gl===sub;recon.push({label,gl,sub,ok});return ok};
  /* subsidiary ledgers (built from the documents) against the control accounts (built from the journals) */
  const glAR=LEDGER.partyBalances(J,"1100"),glAP=LEDGER.partyBalances(J,"2000");const bal=LEDGER.balances(J);const B=a=>bal[a]?bal[a].d-bal[a].c:0;
  let subAR=0,subAP=0;const party=[];
  for(const c of S.clients){const s=mi(clientTotals(c.id).bal),g=glAR.get(c.id)||0;subAR+=s;if(s!==g)party.push({kind:"Client",name:c.name,coll:"clients",id:c.id,gl:g,sub:s})}
  for(const c of S.suppliers){const s=mi(supplierTotals(c.id).bal),g=glAP.get(c.id)||0;subAP+=s;if(s!==g)party.push({kind:"Supplier",name:c.name,coll:"suppliers",id:c.id,gl:g,sub:s})}
  cmp("Accounts receivable (1100) = total of client accounts",B("1100"),subAR);
  cmp("Accounts payable (2000) = total of supplier accounts",-B("2000"),subAP);
  const stockVal=Object.values(res.stock).reduce((t,s)=>t+s.v,0);cmp("Inventory (1200) = stock valuation (weighted average)",B("1200"),stockVal);
  const live=c=>S[c].filter(x=>!x.void);const vatOf=c=>live(c).reduce((t,x)=>t+(calc(x).m.vat||0),0);
  cmp("Output VAT (2100) = VAT on invoices + debit notes − credit notes − VAT paid to URA",-B("2100"),vatOf("invoices")+vatOf("debits")-vatOf("credits")-live("payments").filter(x=>x.category==="VAT paid to URA"&&!x.supplierId).reduce((t,x)=>t+mi(x.amount),0));
  cmp("Input VAT (1300) = VAT on purchases − supplier debit notes",B("1300"),vatOf("purchases")-vatOf("sdebits"));
  for(const a of LEDGER.CASH_ACCTS){const ms=Object.keys(LEDGER.CASH).filter(m=>LEDGER.CASH[m]===a);const f=c=>live(c).filter(x=>ms.includes(x.method));
    const sub=f("receipts").reduce((t,x)=>t+mi(x.amount),0)-f("payments").reduce((t,x)=>t+mi(x.amount),0)+f("refunds").reduce((t,x)=>t+(x.supplierId?1:-1)*mi(x.amount),0);
    if(B(a)||sub)cmp(accName(a)+" ("+a+") = receipts − payments ± refunds by that method",B(a),sub)}
  const tb=LEDGER.trialBalance(J),bs=LEDGER.balanceSheet(J);
  recon.push({label:"Trial balance: total debits = total credits",gl:tb.dr,sub:tb.cr,ok:tb.ok});
  recon.push({label:"Balance sheet: assets = liabilities + equity",gl:bs.assets,sub:bs.liabilities+bs.equity,ok:bs.ok});
  const integ=integrity();
  const problems=res.issues.length+recon.filter(x=>!x.ok).length+party.length+integ.errors.length;
  LCACHE={...res,J,recon,party,problems,tb,bs,integ};return LCACHE}
/* The store has no foreign keys or unique indexes, so these are checked here: every reference must point at an existing record,
   conversion links must agree in both directions, and document numbers must be unique. Gaps are listed for information. */
function integrity(){const errors=[],gaps=[];const E=(c,r,msg)=>errors.push({ref:c+"/"+r.id,msg});approvalIssues(E);
  const need=(c,r,field,target)=>{if(r[field]&&!byId(target,r[field]))E(c,r,field+" points at a "+NAMES[target].toLowerCase()+" that no longer exists.")};
  for(const c of ["proformas","invoices","receipts","credits","debits","refunds"])for(const r of S[c])need(c,r,"clientId","clients");
  for(const c of ["lpos","purchases","payments","sdebits","refunds"])for(const r of S[c])need(c,r,"supplierId","suppliers");
  for(const c of ["proformas","invoices","receipts","credits","debits","refunds"])for(const r of S[c])if(c!=="refunds"&&!r.clientId)E(c,r,"has no client.");
  for(const c of ["lpos","purchases","sdebits"])for(const r of S[c])if(!r.supplierId)E(c,r,"has no supplier.");
  for(const r of S.refunds)if(!r.clientId&&!r.supplierId)E("refunds",r,"has no client or supplier.");
  for(const r of S.receipts){need("receipts",r,"invoiceId","invoices");for(const a of r.alloc)if(!byId("invoices",a.invoiceId))E("receipts",r,"an applied advance points at a missing invoice.");
    const i=byId("invoices",r.invoiceId);if(i&&i.clientId!==r.clientId)E("receipts",r,"is for a different client than its invoice "+i.number+".")}
  for(const r of S.credits){need("credits",r,"invoiceId","invoices");const i=byId("invoices",r.invoiceId);if(i&&i.clientId!==r.clientId)E("credits",r,"is for a different client than its invoice.")}
  for(const r of S.payments){need("payments",r,"purchaseId","purchases");const p=byId("purchases",r.purchaseId);if(p&&p.supplierId!==r.supplierId)E("payments",r,"is for a different supplier than its purchase.")}
  for(const r of S.sdebits)need("sdebits",r,"purchaseId","purchases");
  for(const c of LEDGER.STOCK_COLLS)for(const r of S[c])for(const i of stockIdsOf(c,r))if(!byId("items",i))E(c,r,"uses a stock item that no longer exists.");
  for(const p of S.proformas){const inv=S.invoices.filter(x=>x.proformaId===p.id);
    if(p.status==="received"&&p.invoiceId&&byId("invoices",p.invoiceId)&&byId("invoices",p.invoiceId).proformaId!==p.id)E("proformas",p,"says it became "+byId("invoices",p.invoiceId).number+", but that invoice doesn't point back to it.");
    if(p.status!=="received"&&inv.length)E("proformas",p,"shows as not converted, but "+inv[0].number+" was made from it (its status update didn't save). Open it and use Mark converted.");
    if(inv.length>1)E("proformas",p,"was converted into more than one invoice: "+inv.map(x=>x.number).join(", ")+".")}
  for(const l of S.lpos){const pu=S.purchases.filter(x=>x.lpoId===l.id&&!x.void);
    if(l.status!=="received"&&pu.length)E("lpos",l,"shows as not converted, but "+pu[0].number+" was made from it (its status update didn't save).");
    if(l.status==="received"&&l.purchaseId&&!pu.some(x=>x.id===l.purchaseId))E("lpos",l,"points at a purchase that is missing or void. Open it and use Reopen.");
    if(pu.length>1)E("lpos",l,"was converted into more than one purchase.")}
  for(const c of Object.keys(PREFIX)){const seen=new Map();let max=0;const pre=PREFIX[c]+"-";
    for(const r of S[c]){if(seen.has(r.number))E(c,r,"has the same number as another "+NAMES[c].toLowerCase()+" ("+r.number+").");seen.set(r.number,r);if(r.number.startsWith(pre)){const n=parseInt(r.number.slice(pre.length),10);if(n>max)max=n}}
    const miss=[];for(let n=1;n<=max&&miss.length<20;n++)if(!seen.has(fmtNo(c,n)))miss.push(fmtNo(c,n));if(miss.length)gaps.push({c,miss})}
  return{errors,gaps}}

/* ---------- stock items ---------- */
function openItem(existing){if(!canWrite)return;{const wb=writesBlocked();if(wb){toast(wb);return}}const r=existing||{};
  let h=`<form id="it" autocomplete="off"><div class="row r2"><div><label>Item name *</label><input name="name" required maxlength="120" placeholder="e.g. Cement 50kg (Hima)"></div><div><label>Unit</label><input name="unit" maxlength="20" placeholder="bags" list="unitList"></div></div>
   <div><label>Notes</label><input name="notes" maxlength="300"></div><div class="actions"><button type="button" class="btn ghost" id="itCancel">Cancel</button><button class="btn" type="submit">${existing?"Save":"Add item"}</button></div></form>`;
  openModal(existing?"Edit item":"New stock item",[],h,{kind:"edit"});$("#mBtns").innerHTML="";const f=$("#it");f.name.value=r.name||"";f.unit.value=r.unit||"";f.notes.value=r.notes||"";f.name.focus();$("#itCancel").onclick=closeModal;
  const id=existing?existing.id:newId();let busy=false;
  f.addEventListener("submit",async e=>{e.preventDefault();if(busy||!f.reportValidity())return;busy=true;try{const name=f.name.value.trim();
    if(S.items.some(x=>x.id!==id&&x.name.trim().toLowerCase()===name.toLowerCase())){toast("An item with that name already exists.");return}
    const data={...(existing?byId("items",id):{}),name,unit:f.unit.value.trim(),notes:f.notes.value.trim(),createdAt:r.createdAt||nowISO()};delete data.id;
    const L=existing?await leaseAll([["items",id]]):{ok:true,release:()=>{},hold:async()=>true};if(!L.ok){toast(busyMsg(L));return}
    try{if(existing){const fd=await freshDoc("items",id);if(!fd||fd.updatedAt!==r.updatedAt){toast("Someone else changed this item after you opened it. Close and open it again.");return}}
      const dup=db?(await withTimeout(db.collection("items").where("name","==",name).get(),10000)).docs.some(x=>x.id!==id):false;if(dup){toast("An item with that name already exists.");return}
      if(await put("items",id,stamp(data,!existing),existing?L:null)){toast(existing?"Item saved":"Item added");closeModal()}}finally{L.release()}}finally{busy=false}})}
function openAdjust(itemId){const it=byId("items",itemId);if(!it||!canWrite)return;{const wb=writesBlocked();if(wb){toast(wb);return}}
  const s=ledger().stock[itemId]||{q:0,v:0};
  let h=`<form id="aj" autocomplete="off"><p><b>${esc(it.name)}</b> — on hand ${esc(fmtQty(s.q))} ${esc(it.unit||"")}, value ${mm(s.v)}.</p>
   <div class="row"><div><label>Change in quantity *</label><input name="qty" required placeholder="e.g. -3 or 10" inputmode="decimal"><div class="hint">Minus for stock lost, damaged or used; plus for stock found.</div></div>
   <div class="vrow"><label>Value of stock added</label><input name="value" inputmode="decimal" placeholder="0"><div class="hint">Only for an increase. Decreases are valued at the average cost.</div></div><div><label>Date *</label><input type="date" name="date" required></div></div>
   <label>Reason *</label><input name="reason" required maxlength="300" placeholder="e.g. Stock count 31 Oct: 3 bags hardened">
   <div class="actions"><button type="button" class="btn ghost" id="ajCancel">Cancel</button><button class="btn" type="submit">Post adjustment</button></div></form>`;
  openModal("Stock adjustment",[],h,{kind:"edit"});$("#mBtns").innerHTML="";const f=$("#aj");f.date.value=today();if(needsApproval("adjustments"))f.querySelector("[type=submit]").textContent="Submit for approval";$("#ajCancel").onclick=closeModal;
  const id=newId();let busy=false,allocated=null;
  f.addEventListener("submit",async e=>{e.preventDefault();if(busy||!f.reportValidity())return;busy=true;const btns=$$("#aj button");btns.forEach(b=>b.disabled=true);try{
    const wb=writesBlocked();if(wb){toast(wb);return}const pm=periodMsg("adjustments",f.date.value);if(pm){toast(pm);return}
    const q=LEDGER.qtyMicro(f.qty.value.trim());if(!q){toast("Enter the change in quantity (at most 6 decimals), e.g. -3.");return}
    let value=0;if(q>0){value=exactAmt(f.value.value.trim()||"0");if(value==null||value<0){toast(DP()?"Value can have at most 2 decimals.":"Value is in whole shillings.");return}}
    const data={number:"",date:f.date.value,itemId,qty:Number(f.qty.value.trim()),value,reason:f.reason.value.trim(),createdAt:nowISO()};
    if(needsApproval("adjustments")){if(await raiseRequest("post","adjustments",data,{}))showItem(itemId);return}
    if(!allocated)allocated=await allocNumber("adjustments");data.number=allocated;
    const L=await leaseAll([["items",itemId]]);if(!L.ok){toast(busyMsg(L));return}
    try{const P=await buildPosting("adjustments",id,data);if(P.err){toast(P.err);return}data.je=P.je;data.stockItems=P.stockItems;
      if(!(await put("adjustments",id,stamp(data,true),L)))return}finally{L.release()}
    allocated=null;toast("Adjustment "+data.number+" posted");showDoc("adjustments",id)
  }catch(err){console.error(err);toast(err&&err.code==="numbering"?"Couldn't get the next document number, so nothing was saved. Try again.":"Couldn't save — please try again.")}finally{busy=false;btns.forEach(b=>b.disabled=false)}})}
const localStamp=iso=>{const d=new Date(iso);return isNaN(d)?"":pad(d.getDate())+"/"+pad(d.getMonth()+1)+"/"+d.getFullYear()+" "+pad(d.getHours())+":"+pad(d.getMinutes())};
const fmtQty=q=>{const x=LEDGER.microQty(q);return Number.isInteger(x)?x.toLocaleString("en-US"):x.toLocaleString("en-US",{maximumFractionDigits:6})};

/* ---------- debit notes (client and supplier) ---------- */
function openNote(coll,P){P=P||{};{const wb=writesBlocked();if(wb){toast(wb);return}}if(!canAdmin)return;
  const isS=coll==="sdebits";const pur=isS?byId("purchases",P.purchaseId):null;if(isS&&!pur)return;
  const room=isS?r2(calc(pur).total-sdebited(pur)):null;if(isS&&room<=0.004){toast("Purchase "+pur.number+" has already been fully reversed by debit notes.");return}
  const v=isS?(+pur.vatRate||0):(settings.vatDefault||0);
  const items=isS?(sdebited(pur)<=0.004?(pur.items||[]).map(i=>({...i})):[{desc:"Adjustment to purchase "+pur.number,qty:1,price:""}]):[{}];
  const clientOpts=S.clients.slice().sort(byName).map(c=>`<option value="${esc(c.id)}" ${c.id===P.clientId?"selected":""}>${esc(c.name)}</option>`).join("");
  let h=`<form id="dn" autocomplete="off">${isS?`<p>To <b>${esc(nameOf("suppliers",pur.supplierId))}</b> against purchase <b>${esc(pur.number)}</b>${pur.supplierRef?" (their invoice "+esc(pur.supplierRef)+")":""}. Up to <b>${money(room)}</b> can still be debited. VAT is fixed at the purchase's rate. Goods returned leave stock at average cost.</p>`
     :`<p>Charges a client for something extra (e.g. transport, variations). It adds to what the client owes, with VAT.</p><div class="row r2"><div><label>Client *</label><select name="clientId" required><option value="">— Choose —</option>${clientOpts}</select></div><div><label>Related invoice</label><select name="invoiceId"><option value="">— None —</option></select></div></div>`}
   <div class="row r2"><div><label>Date *</label><input name="date" type="date" required></div><div><label>Reason *</label><input name="reason" required maxlength="300" placeholder="${isS?"e.g. 4 bags returned damaged":"e.g. Extra transport to site"}"></div></div>
   ${itemsBlock({stock:isS})}
   <div class="actions"><button type="button" class="btn ghost" id="dnCancel">Cancel</button><button class="btn" type="submit">Issue debit note</button></div></form>`;
  openModal(isS?"New supplier debit note":"New client debit note",[],h,{kind:"edit"});$("#mBtns").innerHTML="";const f=$("#dn");f.date.value=today();
  const I=bindItems(f,items,v);if(isS)f.vatRate.readOnly=true;$("#dnCancel").onclick=()=>isS?showDoc("purchases",pur.id):closeModal();
  if(!isS){const fill=()=>{const c=f.clientId.value;f.invoiceId.innerHTML=`<option value="">— None —</option>`+S.invoices.filter(x=>x.clientId===c).sort(byDateDesc).map(x=>`<option value="${esc(x.id)}">${esc(x.number)} · ${money0(calc(x).total)}</option>`).join("")};f.clientId.addEventListener("change",fill);fill();if(P.invoiceId)f.invoiceId.value=P.invoiceId}
  let busy=false,allocated=null;const id=newId();
  f.addEventListener("submit",async e=>{e.preventDefault();if(busy||!f.reportValidity())return;busy=true;const btns=$$("#dn button");btns.forEach(b=>b.disabled=true);try{
    const wb=writesBlocked();if(wb){toast(wb);return}const pm=periodMsg(coll,f.date.value);if(pm){toast(pm);return}
    if(isS&&f.date.value<pur.date){toast("A debit note can't be dated before its purchase ("+fmtDate(pur.date)+").");return}
    const it=I.get();if(!it.length){toast("Add at least one line.");return}if(it.some(i=>i.qty<0||i.price<0)){toast("Quantities and prices can't be negative.");return}
    const data=isS?{number:"",date:f.date.value,supplierId:pur.supplierId,purchaseId:pur.id,account:pur.account||"",reason:f.reason.value.trim(),items:it,vatRate:v,createdAt:nowISO()}
      :{number:"",date:f.date.value,clientId:f.clientId.value,invoiceId:f.invoiceId.value||null,reason:f.reason.value.trim(),items:it,vatRate:+f.vatRate.value||0,createdAt:nowISO()};
    const c=calc(data);if(c.err){toast(c.err);return}if(c.total<=0){toast("The total must be more than zero.");return}data.total=c.total;
    if(isS&&c.total>room+0.004){toast("That's more than the "+money(room)+" that can still be debited on "+pur.number+".");return}
    if(!allocated)allocated=await allocNumber(coll);data.number=allocated;
    const L=await leaseAll([isS?["purchases",pur.id]:["clients",data.clientId],...(isS?[["suppliers",pur.supplierId]]:[]),...stockRefs(coll,data)]);if(!L.ok){toast(busyMsg(L));return}
    try{if(isS){const [d,prior]=await Promise.all([freshDoc("purchases",pur.id),freshNoteSum("sdebits","purchaseId",pur.id,id)]);if(!d||d.void){toast("That purchase no longer exists or was voided.");return}
        if(c.total>r2(calc(d).total-prior)+0.004){toast("Only "+money(r2(calc(d).total-prior))+" can still be debited on "+pur.number+" (it was just updated by someone else).");return}}
      const P2=await buildPosting(coll,id,data);if(P2.err){toast(P2.err);return}data.je=P2.je;data.stockItems=P2.stockItems;
      if(!(await put(coll,id,stamp(data,true),L)))return}finally{L.release()}
    allocated=null;toast("Debit note "+data.number+" issued");showDoc(coll,id)
  }catch(err){console.error(err);toast(err&&err.code==="numbering"?"Couldn't get the next document number, so nothing was saved. Try again.":"Couldn't save — please try again.")}finally{busy=false;btns.forEach(b=>b.disabled=false)}})}
const sdebited=p=>r2(idx().sd.get(p.id)||0);

/* ---------- refunds: money back to a client in credit, or from a supplier we overpaid ---------- */
function openRefund(kind,partyId){const isC=kind==="clients";const p=byId(kind,partyId);if(!p||!canWrite)return;{const wb=writesBlocked();if(wb){toast(wb);return}}
  const t=isC?clientTotals(partyId):supplierTotals(partyId);const credit=r2(-t.bal);if(credit<=0.004){toast(isC?"This client has no credit balance to refund.":"This supplier doesn't owe you anything.");return}
  let h=`<form id="rf" autocomplete="off"><p>${isC?`<b>${esc(p.name)}</b> is in credit by <b>${money(credit)}</b> (paid more than billed). Record money you paid back to them.`:`<b>${esc(p.name)}</b> owes you <b>${money(credit)}</b> (overpaid or goods returned). Record money they paid back.`}</p>
   <div class="row"><div><label>Amount *</label><input name="amount" required inputmode="decimal"></div><div><label>Date *</label><input name="date" type="date" required></div><div><label>Method *</label><select name="method">${opts(METHODS,"Bank transfer")}</select></div></div>
   <div class="row r2"><div><label>Reference</label><input name="reference"></div><div><label>Reason *</label><input name="reason" required maxlength="300"></div></div>
   <div class="actions"><button type="button" class="btn ghost" id="rfCancel">Cancel</button><button class="btn" type="submit">Record refund</button></div></form>`;
  openModal(isC?"Refund to client":"Refund from supplier",[],h,{kind:"edit"});$("#mBtns").innerHTML="";const f=$("#rf");f.date.value=today();f.amount.value=credit;if(needsApproval("refunds"))f.querySelector("[type=submit]").textContent="Submit for approval";$("#rfCancel").onclick=()=>showParty(kind,partyId);
  let busy=false,allocated=null;const id=newId();
  f.addEventListener("submit",async e=>{e.preventDefault();if(busy||!f.reportValidity())return;busy=true;const btns=$$("#rf button");btns.forEach(b=>b.disabled=true);try{
    const wb=writesBlocked();if(wb){toast(wb);return}const pm=periodMsg("refunds",f.date.value);if(pm){toast(pm);return}
    const amt=exactAmt(f.amount.value);if(amt==null||amt<=0){toast(DP()?"Enter an amount with at most 2 decimals.":"Enter an amount in whole shillings.");return}
    if(amt>credit+0.004){toast("That's more than the "+money(credit)+" "+(isC?"credit":"owed")+".");return}
    const data={number:"",date:f.date.value,[isC?"clientId":"supplierId"]:partyId,amount:amt,method:f.method.value,reference:f.reference.value.trim(),reason:f.reason.value.trim(),createdAt:nowISO()};
    if(needsApproval("refunds")){if(await raiseRequest("post","refunds",data,{}))showParty(kind,partyId);return}
    if(!allocated)allocated=await allocNumber("refunds");data.number=allocated;
    const L=await leaseAll([[kind,partyId]]);if(!L.ok){toast(busyMsg(L));return}
    try{const fb=await freshPartyBal(kind,partyId);if(fb.unposted){toast("Some of this "+(isC?"client":"supplier")+"'s records aren't posted to the ledger, so a refund can't be checked. See Accounts → Checks.");return}
      const room=M(-fb.bal);if(amt>room+0.004){toast("Only "+money(Math.max(0,room))+" is available to refund (it was just updated by someone else).");return}
      const P2=await buildPosting("refunds",id,data);if(P2.err){toast(P2.err);return}data.je=P2.je;data.stockItems=[];
      if(!(await put("refunds",id,stamp(data,true),L)))return}finally{L.release()}
    allocated=null;toast("Refund "+data.number+" recorded");showDoc("refunds",id)
  }catch(err){console.error(err);toast(err&&err.code==="numbering"?"Couldn't get the next document number, so nothing was saved. Try again.":"Couldn't save — please try again.")}finally{busy=false;btns.forEach(b=>b.disabled=false)}})}

/* ---------- apply an advance (unlinked receipt) to an invoice: no new money, so no journal; recorded on the receipt with who and when ---------- */
const unapplied=r=>r.void||r.invoiceId?0:r2(r.amount-(r.alloc||[]).reduce((a,x)=>a+x.amount,0));
function openApply(invId){const inv=byId("invoices",invId);if(!inv)return;{const wb=writesBlocked();if(wb){toast(wb);return}}
  const adv=S.receipts.filter(r=>r.clientId===inv.clientId&&unapplied(r)>0.004).sort(byDateDesc);const bal=invBal(inv);
  if(!adv.length||bal<=0.004){toast("There's no unapplied advance from this client.");return}
  let h=`<form id="ap" autocomplete="off"><p>Invoice <b>${esc(inv.number)}</b> balance <b>${money(bal)}</b>. Choose an advance received from ${esc(nameOf("clients",inv.clientId))}.</p>
   <div class="row r2"><div><label>Advance *</label><select name="rid">${adv.map(r=>`<option value="${esc(r.id)}">${esc(r.number)} · ${fmtDate(r.date)} · unapplied ${money0(unapplied(r))}</option>`).join("")}</select></div><div><label>Amount to apply *</label><input name="amount" required inputmode="decimal"></div></div>
   <div class="actions"><button type="button" class="btn ghost" id="apCancel">Cancel</button><button class="btn" type="submit">Apply</button></div></form>`;
  openModal("Apply advance to "+inv.number,[],h,{kind:"edit"});$("#mBtns").innerHTML="";const f=$("#ap");const fillAmt=()=>{const r=byId("receipts",f.rid.value);f.amount.value=r?Math.min(unapplied(r),bal):""};fillAmt();f.rid.addEventListener("change",fillAmt);$("#apCancel").onclick=()=>showDoc("invoices",invId);
  let busy=false;
  f.addEventListener("submit",async e=>{e.preventDefault();if(busy||!f.reportValidity())return;busy=true;const btns=$$("#ap button");btns.forEach(b=>b.disabled=true);try{
    const wb=writesBlocked();if(wb){toast(wb);return}const rid=f.rid.value;const amt=exactAmt(f.amount.value);if(amt==null||amt<=0){toast("Enter the amount to apply.");return}
    const L=await leaseAll([["invoices",invId],["receipts",rid]]);if(!L.ok){toast(busyMsg(L));return}
    try{const [d,paid,cred,rc0]=await Promise.all([freshDoc("invoices",invId),freshInvPaid(invId,null),freshNoteSum("credits","invoiceId",invId,null),freshDoc("receipts",rid)]);
      if(!d||!rc0||rc0.void||rc0.invoiceId){toast("That advance or invoice changed. Close and try again.");return}
      const left=r2(rc0.amount-(rc0.alloc||[]).reduce((a,x)=>a+x.amount,0)),ib=r2(calc(d).total-paid-cred);
      if(amt>left+0.004){toast("Only "+money(left)+" of "+rc0.number+" is unapplied.");return}if(amt>ib+0.004){toast("The invoice balance is only "+money(ib)+".");return}
      const alloc=[...(rc0.alloc||[]),{invoiceId:invId,amount:amt,at:nowISO(),by:myId||""}];
      if(!(await patch("receipts",rid,{alloc,allocInv:[...new Set(alloc.map(a=>a.invoiceId))]},L)))return}finally{L.release()}
    toast(money(amt)+" applied to "+inv.number);showDoc("invoices",invId)
  }catch(err){console.error(err);toast("Couldn't apply — nothing was changed. Please try again.")}finally{busy=false;btns.forEach(b=>b.disabled=false)}})}

/* ---------- documents: the ledger entry shown under every posted document (screen only) ---------- */
function jeBox(r){const js=[r.je,r.jr].filter(j=>j&&Array.isArray(j.lines));if(!js.length)return POSTED.has(r._coll||"")?"":"";
  return`<div class="box no-export"><div class="k" style="margin-bottom:6px">Ledger entries</div>${js.map(j=>`<div class="muted" style="font-size:12px;margin:4px 0">${esc(j.pid)} · ${fmtDate(j.date)}${j.reason?" · "+esc(j.reason):""} · posted ${esc(localStamp(j.at))}${j.by?" by "+esc(j.by===myId?"you":"user "+j.by.slice(0,6)):""}</div>
    <table><thead><tr><th>Account</th><th>Detail</th><th class="num">Debit</th><th class="num">Credit</th></tr></thead><tbody>${j.lines.map(l=>`<tr><td><span class="mono">${esc(l.a)}</span> ${esc(accName(l.a))}</td><td>${l.p?esc(nameOf(byId("clients",l.p)?"clients":"suppliers",l.p)):""}${l.i?esc(itemName(l.i))+(l.q?" · "+(l.q>0?"+":"")+esc(fmtQty(l.q)):""):""}</td><td class="num">${l.d?mm0(l.d):""}</td><td class="num">${l.c?mm0(l.c):""}</td></tr>`).join("")}</tbody></table>`).join("")}</div>`}

/* ---------- views: stock, accounts ---------- */
let acTab="tb";
function renderStock(){const L=ledger();const rows=S.items.slice().sort(byName);
  $("#stRows").innerHTML=rows.length?rows.map(it=>{const s=L.stock[it.id]||{q:0,v:0};return`<tr data-item="${esc(it.id)}"><td>${esc(it.name)}</td><td>${esc(it.unit)}</td><td class="num">${esc(fmtQty(s.q))}</td><td class="num">${s.q>0?mm0(LEDGER.mulDiv(s.v,1e6,s.q)):"—"}</td><td class="num">${mm0(s.v)}</td></tr>`}).join("")
    :`<tr><td colspan="5" class="empty">No stock items yet.${canWrite?` <span class="link" id="stFirst">Add your first item</span>`:""}</td></tr>`;
  const tot=Object.values(L.stock).reduce((t,s)=>t+s.v,0);$("#stSum").innerHTML=`${rows.length} item${rows.length===1?"":"s"} · Stock value <b>${mm(tot)}</b> (weighted average cost)`}
function showItem(id){const it=byId("items",id);if(!it)return;const L=ledger();const s=L.stock[id]||{q:0,v:0};
  const mv=[];for(const j of L.J)for(const m of LEDGER.stockMovements(j))if(m.item===id)mv.push({...m,date:j.date});mv.sort((a,b)=>(a.n??0)-(b.n??0));let q=0,v=0;
  const b=[];if(canWrite)b.push({label:isOwnerUser?"Adjust stock":"Request stock adjustment",write:1,fn:()=>openAdjust(id)});b.push({label:"Edit",write:1,fn:()=>openItem(it)});
  openModal(it.name,b,`<p>On hand <b>${esc(fmtQty(s.q))} ${esc(it.unit||"")}</b> · value <b>${mm(s.v)}</b>${s.q>0?" · average cost "+mm(LEDGER.mulDiv(s.v,1e6,s.q))+" per "+esc(it.unit||"unit"):""}</p>
   <table><thead><tr><th>#</th><th>Date</th><th>Document</th><th class="num">Qty</th><th class="num">Value</th><th class="num">On hand</th><th class="num">Stock value</th></tr></thead><tbody>${mv.map(m=>{q+=m.q;v+=m.v;const [c,rid]=m.pid.replace(/:R$/,"").split("/");const doc=byId(c,rid);
    return`<tr data-c="${esc(c)}" data-id="${esc(rid)}"><td>${esc(m.n??"")}</td><td>${fmtDate(m.date)}</td><td class="mono">${esc(doc?doc.number:m.pid)}${/:R$/.test(m.pid)?" (void)":""}</td><td class="num">${(m.q>0?"+":"")+esc(fmtQty(m.q))}</td><td class="num">${mm0(m.v)}</td><td class="num">${esc(fmtQty(q))}</td><td class="num">${mm0(v)}</td></tr>`}).join("")||`<tr><td colspan="7" class="empty">No movements yet.</td></tr>`}</tbody></table>`,{kind:"item",id})}
function acRange(){return{from:$("#acFrom").value||null,to:$("#acTo").value||null}}
/* Reports read a prebuilt index of the journals (engine/reports.js) instead of scanning every journal for every report.
   The index belongs to one exact set of journals (the ledger() result); any change to the books makes a new ledger()
   and so a new index, so a report can never show figures from an older set of journals. Large books are indexed in
   slices so the page stays responsive; until it is ready the report says so instead of showing partial figures. */
const RX_SYNC=6000;
function reportIndex(L){if(L.RX)return L.RX;if(L.RXERR)return null;
  if(L.J.length<=RX_SYNC){try{L.RX=REPORTS.buildIndex(L.J)}catch(e){L.RXERR=e.message;logEvent("error","report-index-failed",{msg:e.message});monJob("indexFail",false)}return L.RX||null}
  if(!L.RXP)L.RXP=REPORTS.buildIndexAsync(L.J,3000,()=>new Promise(r=>setTimeout(r,0))).then(ix=>{L.RX=ix},e=>{L.RXERR=e.message;logEvent("error","report-index-failed",{msg:e.message});monJob("indexFail",false)}).then(()=>{if(LCACHE===L&&$("#acBody").dataset.waiting==="1")renderAccounts()});
  return null}
let acGl={key:"",page:0};const GL_PAGE=500;
const CF_LABEL=k=>k==="customers"?"Received from clients (net of refunds)":k==="suppliers"?"Paid to suppliers (net of refunds)":k==="vat"?"VAT paid to / refunded by URA":k==="loans"?"Loans received / repaid":k==="capital"?"Capital introduced / withdrawn":k==="drawings"?"Owner's drawings":k==="transfer"?"Transfers between cash accounts":k==="mixed"?"Entries that touch several other accounts at once":/^(exp|inc|other):/.test(k)?accName(k.split(":")[1])+" ("+k.split(":")[1]+")":k;
function renderAccounts(){const L=ledger();const {from,to}=acRange();const J=L.J;let h="";
  $$("#acTabs button").forEach(b=>b.classList.toggle("on",b.dataset.t===acTab));
  const RX=acTab==="chk"?null:reportIndex(L);const body=$("#acBody");
  if(acTab!=="chk"&&!RX){$("#acAcctWrap").style.display=acTab==="gl"?"":"none";body.dataset.waiting=L.RXERR?"":"1";
    setHTML(body,L.RXERR?`<div class="box" style="border-color:var(--out)"><b class="neg">This report could not be produced.</b> ${esc(L.RXERR)} No figures are shown rather than figures that might be wrong.</div>`:`<p class="sub" id="acPreparing">Preparing reports from ${J.length.toLocaleString("en-US")} journal entries…</p>`);return}
  body.dataset.waiting="";
  const tbl=(head,rows,foot)=>`<table><thead><tr>${head.map(x=>`<th class="${x[1]?"num":""}">${x[0]}</th>`).join("")}</tr></thead><tbody>${rows}</tbody>${foot?`<tfoot>${foot}</tfoot>`:""}</table>`;
  if(acTab==="tb"){const t=REPORTS.trialBalance(RX,to);h=`<p class="sub">As at ${to?fmtDate(to):"today"}. ${t.ok?"Debits equal credits.":`<b class="neg">Debits and credits differ by ${mm(t.dr-t.cr)}.</b>`}</p>`+
    tbl([["Account"],["Name"],["Debit",1],["Credit",1]],t.rows.map(r=>`<tr data-acct="${esc(r.a)}"><td class="mono">${esc(r.a)}</td><td>${esc(r.name)}</td><td class="num">${r.dr?mm0(r.dr):""}</td><td class="num">${r.cr?mm0(r.cr):""}</td></tr>`).join("")||`<tr><td colspan="4" class="empty">Nothing posted yet.</td></tr>`,`<tr><td></td><td><b>Total</b></td><td class="num"><b>${mm0(t.dr)}</b></td><td class="num"><b>${mm0(t.cr)}</b></td></tr>`)}
  if(acTab==="pl"){const p=REPORTS.profitLoss(RX,from,to);const r=x=>x.map(y=>`<tr data-acct="${esc(y.a)}"><td class="mono">${esc(y.a)}</td><td>${esc(y.name)}</td><td class="num">${mm0(y.amt)}</td></tr>`).join("");
    h=`<p class="sub">${from?fmtDate(from):"Start"} to ${to?fmtDate(to):"today"}.</p>`+tbl([["Account"],["Income"],["Amount",1]],r(p.inc),`<tr><td></td><td><b>Total income</b></td><td class="num"><b>${mm0(p.ti)}</b></td></tr>`)+
      tbl([["Account"],["Expenses"],["Amount",1]],r(p.exp),`<tr><td></td><td><b>Total expenses</b></td><td class="num"><b>${mm0(p.te)}</b></td></tr>`)+`<p style="margin-top:10px">Gross profit (sales − cost of sales and stock losses) <b>${mm(p.gross)}</b> · Net ${p.net>=0?"profit":"loss"} <b class="${p.net>=0?"pos":"neg"}">${mm(Math.abs(p.net))}</b></p>`}
  if(acTab==="bs"){const b=REPORTS.balanceSheet(RX,to);const r=x=>x.map(y=>`<tr data-acct="${esc(y.a)}"><td class="mono">${esc(y.a)}</td><td>${esc(y.name)}</td><td class="num">${mm0(y.amt)}</td></tr>`).join("");
    h=`<p class="sub">As at ${to?fmtDate(to):"today"}. ${b.ok?"Assets = liabilities + equity.":`<b class="neg">Out of balance by ${mm(b.assets-b.liabilities-b.equity)}.</b>`}</p>`+tbl([["Account"],["Assets"],["Amount",1]],r(b.asset),`<tr><td></td><td><b>Total assets</b></td><td class="num"><b>${mm0(b.assets)}</b></td></tr>`)+
      tbl([["Account"],["Liabilities"],["Amount",1]],r(b.liability),`<tr><td></td><td><b>Total liabilities</b></td><td class="num"><b>${mm0(b.liabilities)}</b></td></tr>`)+
      tbl([["Account"],["Equity"],["Amount",1]],r(b.equityLines)+`<tr><td></td><td>Profit to date (not yet closed to capital)</td><td class="num">${mm0(b.earnings)}</td></tr>`,`<tr><td></td><td><b>Total equity</b></td><td class="num"><b>${mm0(b.equity)}</b></td></tr>`)}
  if(acTab==="vat"){const v=REPORTS.vatReturn(RX,from,to);h=`<p class="sub">${from?fmtDate(from):"Start"} to ${to?fmtDate(to):"today"}. Figures come from the VAT accounts; check them against your EFRIS records before filing.</p>`+
    tbl([["Item"],["Amount",1]],`<tr><td>Sales (net of VAT, after credit and debit notes)</td><td class="num">${mm0(v.sales)}</td></tr><tr><td>Output VAT charged</td><td class="num">${mm0(v.outputVat)}</td></tr><tr><td>Purchases (net of VAT, after supplier debit notes)</td><td class="num">${mm0(v.purchases)}</td></tr><tr><td>Input VAT claimable</td><td class="num">${mm0(v.inputVat)}</td></tr><tr><td><b>${v.netVat>=0?"VAT payable to URA":"VAT refundable / carried forward"}</b></td><td class="num"><b>${mm0(Math.abs(v.netVat))}</b></td></tr><tr><td>VAT paid to URA in this period</td><td class="num">${mm0(v.paidToURA)}</td></tr>`)}
  if(acTab==="gl"){const a=$("#acAcct").value||"1000";const key=a+"|"+from+"|"+to;if(acGl.key!==key)acGl={key,page:0};const n=REPORTS.glCount(RX,a,from,to);const pages=Math.max(1,Math.ceil(n/GL_PAGE));if(acGl.page>=pages)acGl.page=pages-1;
    const off=acGl.page*GL_PAGE;const rows=REPORTS.generalLedgerPage(RX,a,from,to,off,GL_PAGE);const bf=REPORTS.glOpening(RX,a,from,off);
    h=`<p class="sub" id="glInfo">${n?`Rows ${(off+1).toLocaleString("en-US")}–${(off+rows.length).toLocaleString("en-US")} of ${n.toLocaleString("en-US")}`:"No entries"} in this period. Balance brought forward <b>${mm0(bf)}</b>.${pages>1?` <button class="btn ghost small" id="glPrev" ${acGl.page?"":"disabled"}>‹ Earlier</button> Page ${acGl.page+1} of ${pages} <button class="btn ghost small" id="glNext" ${acGl.page<pages-1?"":"disabled"}>Later ›</button>`:""}</p>`+tbl([["Date"],["Posting"],["Detail"],["Debit",1],["Credit",1],["Balance",1]],rows.map(x=>{const [c,rid]=x.pid.replace(/:R$/,"").split("/");const d=byId(c,rid);
    return`<tr data-c="${esc(c)}" data-id="${esc(rid)}"><td>${fmtDate(x.date)}</td><td class="mono">${esc(d?d.number:x.pid)}${/:R$/.test(x.pid)?" (void)":""}</td><td>${x.p?esc(nameOf(byId("clients",x.p)?"clients":"suppliers",x.p)):""}${x.i?esc(itemName(x.i)):""}</td><td class="num">${x.d?mm0(x.d):""}</td><td class="num">${x.c?mm0(x.c):""}</td><td class="num">${mm0(x.bal)}</td></tr>`}).join("")||`<tr><td colspan="6" class="empty">No postings to this account in this period.</td></tr>`)}
  if(acTab==="ar"||acTab==="ap"){const a=acTab==="ar"?"1100":"2000";const g=REPORTS.ageing(RX,a,to);const coll=a==="1100"?"clients":"suppliers";
    h=`<p class="sub">As at ${fmtDate(g.asAt)}. Amounts are aged from the date of each ${a==="1100"?"invoice or debit note":"purchase or debit note"}; ${a==="1100"?"receipts and credit notes":"payments and debit notes"} are applied to the oldest amount first. Over-payments are shown as unapplied, never netted away silently.</p>`+
    `<p id="agRecon">${g.ok?`Total <b>${mm(g.total)}</b> agrees with account ${a} (${esc(accName(a))}).`:`<b class="neg">Ageing total ${mm(g.total)} differs from account ${a} by ${mm(g.untagged)}</b> — some ledger lines on ${a} have no ${a==="1100"?"client":"supplier"}. Investigate on the Checks tab.`}</p>`+
    tbl([[a==="1100"?"Client":"Supplier"],["Current",1],["1–30 days",1],["31–60",1],["61–90",1],["Over 90",1],["Unapplied",1],["Total",1]],g.rows.map(r=>`<tr data-pc="${coll}" data-pid="${esc(r.p)}"><td>${esc(nameOf(coll,r.p))}</td>${r.b.map(x=>`<td class="num">${x?mm0(x):""}</td>`).join("")}<td class="num">${r.credit?mm0(-r.credit):""}</td><td class="num"><b>${mm0(r.total)}</b></td></tr>`).join("")||`<tr><td colspan="8" class="empty">Nothing owed.</td></tr>`,
      `<tr><td><b>Total</b></td>${g.totals.map(x=>`<td class="num"><b>${mm0(x)}</b></td>`).join("")}<td class="num"><b>${g.unapplied?mm0(-g.unapplied):""}</b></td><td class="num"><b>${mm0(g.total)}</b></td></tr>`)}
  if(acTab==="cf"){const c=REPORTS.cashFlow(RX,from,to);const ins=c.cats.filter(x=>x.inflow),outs=c.cats.filter(x=>x.outflow);
    h=`<p class="sub">${from?fmtDate(from):"Start"} to ${to?fmtDate(to):"today"}. Direct method: every entry that moved cash (accounts ${LEDGER.CASH_ACCTS.join(", ")}), grouped by what it was for.</p>`+
    tbl([["Cash in"],["Entries",1],["Amount",1]],ins.map(x=>`<tr><td>${esc(CF_LABEL(x.key))}</td><td class="num">${x.count}</td><td class="num">${mm0(x.inflow)}</td></tr>`).join("")||`<tr><td colspan="3" class="empty">None.</td></tr>`,`<tr><td><b>Total cash in</b></td><td></td><td class="num"><b>${mm0(ins.reduce((t,x)=>t+x.inflow,0))}</b></td></tr>`)+
    tbl([["Cash out"],["Entries",1],["Amount",1]],outs.map(x=>`<tr><td>${esc(CF_LABEL(x.key))}</td><td class="num">${x.count}</td><td class="num">${mm0(x.outflow)}</td></tr>`).join("")||`<tr><td colspan="3" class="empty">None.</td></tr>`,`<tr><td><b>Total cash out</b></td><td></td><td class="num"><b>${mm0(outs.reduce((t,x)=>t+x.outflow,0))}</b></td></tr>`)+
    `<p style="margin-top:10px" id="cfRecon">Opening cash <b>${mm(c.opening)}</b> + net cash flow <b>${mm(c.net)}</b> = closing cash <b>${mm(c.opening+c.net)}</b>. ${c.ok?"Agrees with the cash and bank accounts.":`<b class="neg">The cash and bank accounts show ${mm(c.closing)} — a difference of ${mm(c.closing-c.opening-c.net)}.</b>`}</p>`+
    (c.cats.some(x=>x.key==="mixed")?`<p class="sub">Entries that touch several other accounts at once can't be put under one heading; they are listed on their own line rather than split by guesswork.</p>`:"")}
  if(acTab==="inv"){const st=REPORTS.stockAt(RX,to);const ids=Object.keys(st).sort((x,y)=>itemName(x).localeCompare(itemName(y)));const tot=ids.reduce((t,i)=>t+st[i].v,0);const tb=REPORTS.trialBalance(RX,to).rows.find(r=>r.a==="1200");const gl=tb?tb.dr-tb.cr:0;
    h=`<p class="sub">As at ${to?fmtDate(to):"today"}. Quantity and value on hand at weighted average cost, from the stock movements in the ledger.</p>`+
    `<p id="invRecon">${tot===gl?`Total <b>${mm(tot)}</b> agrees with account 1200 (Inventory).`:`<b class="neg">Stock total ${mm(tot)} differs from account 1200 (${mm(gl)}) by ${mm(gl-tot)}.</b>`}</p>`+
    tbl([["Item"],["On hand",1],["Average cost",1],["Value",1]],ids.filter(i=>st[i].q||st[i].v).map(i=>{const x=st[i];return`<tr data-item="${esc(i)}"><td>${esc(itemName(i))}</td><td class="num">${esc(fmtQty(x.q))}</td><td class="num">${x.q>0?mm0(LEDGER.mulDiv(x.v,1e6,x.q)):"—"}</td><td class="num">${mm0(x.v)}</td></tr>`}).join("")||`<tr><td colspan="4" class="empty">No stock.</td></tr>`,`<tr><td><b>Total</b></td><td></td><td></td><td class="num"><b>${mm0(tot)}</b></td></tr>`)}
  if(acTab==="chk")h=checksHTML(L);
  $("#acAcctWrap").style.display=acTab==="gl"?"":"none";$("#acFrom").parentElement.style.display=acTab==="chk"?"none":"";
  setHTML($("#acBody"),h)}
function checksHTML(L){const iss=L.issues;let h=`<p class="sub">Every check compares two independent records. Nothing here is ever corrected automatically: a difference means something must be investigated.</p>`;
  h+=`<div class="box" style="border-color:${L.problems?"var(--out)":"var(--accent)"}"><b class="${L.problems?"neg":"pos"}">${L.problems?L.problems+" problem"+(L.problems===1?"":"s")+" found — investigate before relying on the reports.":"All checks passed."}</b> ${L.J.length} journal entries, ${S.items.length} stock items.</div>`;
  h+=`<table><thead><tr><th>Reconciliation</th><th class="num">Ledger</th><th class="num">Documents</th><th></th></tr></thead><tbody>${L.recon.map(r=>`<tr><td>${esc(r.label)}</td><td class="num">${mm0(r.gl)}</td><td class="num">${mm0(r.sub)}</td><td>${r.ok?tag("paid").replace("Paid","OK"):`<span class="tag t-overdue">Differs by ${mm0(r.gl-r.sub)}</span>`}</td></tr>`).join("")}</tbody></table>`;
  if(L.party.length)h+=`<h3 style="margin-top:14px">Accounts that don't agree with the ledger</h3><table><tbody>${L.party.map(p=>`<tr data-pc="${p.coll}" data-pid="${esc(p.id)}"><td>${p.kind}</td><td>${esc(p.name)}</td><td class="num">Ledger ${mm0(p.gl)}</td><td class="num">Account ${mm0(p.sub)}</td></tr>`).join("")}</tbody></table>`;
  const I=L.integ;if(I.errors.length)h+=`<h3 style="margin-top:14px">Broken links between records (${I.errors.length})</h3><table><tbody>${I.errors.slice(0,300).map(i=>{const [c,rid]=i.ref.split("/");const d=byId(c,rid);return`<tr data-c="${esc(c)}" data-id="${esc(rid)}"><td class="mono">${esc(d?d.number||d.name:i.ref)}</td><td>${esc(i.msg)}${isOwnerUser&&/approval record/.test(i.msg)?` <button class="btn ghost small" data-recap="${esc(c)}|${esc(rid)}|${/voided/.test(i.msg)?1:0}" type="button">Record approval</button>`:""}</td></tr>`}).join("")}</tbody></table>`;
  if(I.gaps.length)h+=`<p class="sub" style="margin-top:10px">Numbers never used (a save that didn't finish after its number was taken; nothing is missing from the books): ${I.gaps.map(g=>esc(g.miss.join(", "))).join("; ")}.</p>`;
  const un=unposted();if(un.length)h+=`<div class="box" style="margin-top:14px"><b>${un.length} document${un.length===1?"":"s"} saved before the ledger existed</b> (${esc(un.slice(0,6).map(x=>x.doc.number).join(", "))}${un.length>6?"…":""}) ${un.length===1?"has":"have"} no journal entries.${isOwnerUser?` <span class="link" id="lgPreview">Preview posting them</span>`:" The owner can post them."}</div>`;
  if(iss.length)h+=`<h3 style="margin-top:14px">Posting problems (${iss.length})</h3><table><tbody>${iss.slice(0,300).map(i=>{const [c,rid]=String(i.ref).replace(/:R$/,"").split("/");const d=byId(c,rid);return`<tr data-c="${esc(c)}" data-id="${esc(rid)}"><td class="mono">${esc(d?d.number:i.ref)}</td><td>${esc(i.msg)}</td></tr>`}).join("")}</tbody></table>${iss.length>300?`<p class="sub">Showing the first 300.</p>`:""}`;
  return h}
function accountsCSV(){const L=ledger();const {from,to}=acRange();const rows=[["Account","Name","Debit","Credit"]];const J=L.J;const RX=reportIndex(L)||REPORTS.buildIndex(J);
  if(acTab==="tb")REPORTS.trialBalance(RX,to).rows.forEach(r=>rows.push([r.a,r.name,M(r.dr),M(r.cr)]));
  else if(acTab==="gl"){rows[0]=["Date","Posting","Debit","Credit","Balance"];REPORTS.generalLedger(RX,$("#acAcct").value||"1000",from,to).forEach(x=>rows.push([x.date,x.pid,M(x.d),M(x.c),M(x.bal)]))}
  else{rows[0]=["Date","Posting","Account","Name","Debit","Credit","Party","Item","Qty"];J.filter(j=>(!from||j.date>=from)&&(!to||j.date<=to)).forEach(j=>j.lines.forEach(l=>rows.push([j.date,j.pid,l.a,accName(l.a),M(l.d),M(l.c),l.p?nameOf(byId("clients",l.p)?"clients":"suppliers",l.p):"",l.i?itemName(l.i):"",l.q?LEDGER.microQty(l.q):""])))}
  return rows}

/* ---------- posting documents saved before the ledger existed (a controlled, reversible data migration) ----------
   Never runs by itself. The owner must first download a full backup in this session, then see a dry run of every journal, then confirm.
   It only ADDS three fields to each document (je, stockItems, postedLater); every existing field is left exactly as it was.
   Undo removes those three fields again, restoring each document to its prior state, as long as nothing has been built on it since. */
let backupThisSession=false;
const unposted=()=>{const out=[];for(const c of LEDGER.DOC_COLLS)for(const r of S[c])if(!r.je)out.push({coll:c,id:r.id,doc:r});return out.sort((a,b)=>(a.doc.date+a.doc.number).localeCompare(b.doc.date+b.doc.number))};
function legacyPlan(){const dp=DP();const st={};const plan=[];
  for(const u of unposted()){const d=u.doc;const r=LEDGER.post(u.coll,d,{dp,stock:st,unitCost:u.coll==="credits"?LEDGER.unitCosts((byId("invoices",d.invoiceId)||{}).je):null});
    const pm=lockMsg(d.date);plan.push({...u,lines:r.lines||[],err:r.err||(pm?"Dated inside the locked period: "+pm:"")||(d.void?"Voided before the ledger existed; it needs a reversal posted too, so it is left for review.":"")});if(r.stockAfter)Object.assign(st,r.stockAfter)}
  return plan}
function openLegacy(){if(!isOwnerUser)return;const plan=legacyPlan();const okN=plan.filter(p=>!p.err).length;
  const rows=plan.map(p=>`<tr><td class="mono">${esc(p.doc.number)}</td><td>${fmtDate(p.doc.date)}</td><td>${p.err?`<span class="neg">${esc(p.err)}</span>`:p.lines.map(l=>`${l.d?"Dr":"Cr"} ${esc(l.a)} ${esc(accName(l.a))} ${mm0(l.d||l.c)}`).join("<br>")}</td></tr>`).join("");
  openModal("Post documents saved before the ledger",[],`<p>This is a <b>dry run</b>: nothing has been written. Each document below would get the journal shown, dated its own date, computed from its own unchanged figures. No existing field is changed, and the step can be undone.</p>
   <p>${backupThisSession?`<span class="pos">A full backup was downloaded in this session.</span>`:`<b class="neg">Download a full backup first</b> (Business details → Download full backup). Posting is disabled until you do.`}</p>
   <table><thead><tr><th>Document</th><th>Date</th><th>Journal that would be posted</th></tr></thead><tbody>${rows}</tbody></table>
   <div class="actions"><button class="btn ghost" id="lgClose" type="button">Close</button><button class="btn" id="lgGo" type="button" ${backupThisSession&&okN?"":"disabled"}>Post ${okN} document${okN===1?"":"s"}</button></div>`,{kind:"edit"});
  $("#lgClose").onclick=closeModal;$("#lgGo").onclick=async()=>{const b=$("#lgGo");b.disabled=true;try{const r=await runLegacy(plan.filter(p=>!p.err));toast(`Posted ${r.ok} of ${r.total}.`+(r.fail.length?` Not posted: ${r.fail.slice(0,3).join("; ")}`:""));closeModal()}catch(e){console.error(e);toast("Stopped — nothing further was changed. "+(e&&e.message||""))}}}
async function runLegacy(plan){if(!isOwnerUser||!canWrite)throw new Error("Only the owner can post these documents.");const wb=writesBlocked();if(wb)throw new Error(wb);if(!backupThisSession)throw new Error("Download a backup first.");let ok=0;const fail=[];
  for(const p of plan){const L=await leaseAll([[p.coll,p.id],...stockRefs(p.coll,p.doc)]);if(!L.ok){fail.push(p.doc.number+": busy");continue}
    try{const d=await freshDoc(p.coll,p.id);if(!d){fail.push(p.doc.number+": gone");continue}if(d.je){fail.push(p.doc.number+": already posted");continue}
      const P=await buildPosting(p.coll,p.id,d);if(P.err){fail.push(p.doc.number+": "+P.err);continue}
      const raw=db?(await withTimeout(db.collection(p.coll).doc(p.id).get(),10000)).data()||{}:{...SRC[p.coll].get(p.id)};
      const prev={updatedAt:raw.updatedAt===undefined?null:raw.updatedAt,updatedBy:raw.updatedBy===undefined?null:raw.updatedBy};
      if(await patch(p.coll,p.id,{je:P.je,stockItems:P.stockItems,postedLater:{at:nowISO(),by:myId||"",prev}},L))ok++;else fail.push(p.doc.number+": save failed")}finally{L.release()}}
  return{ok,total:plan.length,fail}}
/* Undo: put each migrated document back exactly as it was (its stored fields minus the three added ones). Refused where later documents depend on its stock posting. */
async function undoLegacy(){if(!isOwnerUser||!canWrite)throw new Error("Only the owner can undo postings.");const wb=writesBlocked();if(wb)throw new Error(wb);let ok=0;const fail=[];
  for(const c of LEDGER.DOC_COLLS)for(const r of S[c].filter(x=>x.postedLater&&x.je&&!x.jr)){
    const L=await leaseAll([[c,r.id],...stockRefs(c,r)]);if(!L.ok){fail.push(r.number+": busy");continue}
    try{if(stockIdsOf(c,r).length){const fs=await freshStock(stockIdsOf(c,r),[]);const later=Object.keys(fs.counts).some(i=>{const mine=r.je.lines.filter(l=>l.a==="1200"&&l.i===i).map(l=>l.n);return fs.counts[i]>Math.max(-1,...mine)+1});if(later){fail.push(r.number+": later stock movements depend on it");continue}}
      const raw=db?(await withTimeout(db.collection(c).doc(r.id).get(),10000)).data():{...SRC[c].get(r.id)};if(!raw||!raw.postedLater){fail.push(r.number+": changed");continue}
      const back={...raw};const prev=(raw.postedLater&&raw.postedLater.prev)||{};delete back.je;delete back.stockItems;delete back.postedLater;
      for(const k of ["updatedAt","updatedBy"]){if(prev[k]===null||prev[k]===undefined)delete back[k];else back[k]=prev[k]}
      if(await put(c,r.id,back,L))ok++;else fail.push(r.number+": save failed")}finally{L.release()}}
  return{ok,fail}}
document.addEventListener("click",e=>{if(e.target.id==="lgPreview")openLegacy()});
