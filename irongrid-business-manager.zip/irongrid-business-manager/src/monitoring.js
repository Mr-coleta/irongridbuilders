/* ====================== monitoring: metrics, traces, alerts, safe logs ======================
   What can be measured here. The app has no server of its own: it runs in each person's browser and talks to the
   hosted record store. So "server CPU, disk and database connections" are not visible to it. What it measures instead:
     - every store call: kind, how long it took, whether it failed (the API response times and error rates);
     - availability: the 30-second health check against the store;
     - the page: long tasks (the browser's CPU being busy), memory, how long each screen takes to draw;
     - storage: records used against the platform's 25,000-record limit (its "disk");
     - background jobs: audit and error-log writes, the books check, the report index;
     - financial postings refused or not saved, and books-check problems.
   Correlation: every user action (a click or a form submit) starts a trace with its own id (cid). Every log line,
   every store call (a span with its own id, timing and outcome) and every audit-trail entry made during that action
   carries the cid, so one action can be followed from the button press through each store round trip to the audit
   record. The store is a hosted service that cannot carry trace headers, so traces end at the store call.
   Safety: everything logged goes through redact(): only a fixed list of technical fields is kept; text is stripped of
   numbers (amounts, phone and account numbers), e-mail addresses and anything after "password", "token" or "key".
   Names, amounts, bank details and passphrases are never put in operational logs, metrics or alerts.
   Alerts only read. No alert, rule or health check changes a financial record, a posting or an accounting rule. */
const MON={t0:Date.now(),calls:[],hb:[],lt:[],errs:[],renders:[],post:[],jobs:{auditFail:0,errFail:0,metricsFail:0,checkFail:0,indexFail:0},
  alerts:new Map(),history:[],traces:[],gave:[],cur:null,day:null,agg:null,lastFlush:0,flushT:0,heapMax:0,loadMs:null,lastBackupHere:null};
const MON_LIMIT=25000;
/* Operational logs must never take the last records that a posting or a restore needs: once the store has said it is
   full, storage is at 99%, or a restore is running, error-log and metrics writes only update records that already
   exist; new ones wait in memory and are written later. */
const monFull=()=>(MON.hold&&Date.now()-MON.hold<30*60000)||!!MON.fullAt||((monRecords()||0)>=0.99*MON_LIMIT);
/* ---------- redaction ---------- */
const SAFE_KEYS=new Set(["ts","level","event","user","view","cid","sid","op","path","code","attempt","attempts","fails","ms","after_s","rule","severity","coll","count","where","state","n","p95","limit","kind","failed","message","msg","detail","pct","records","encrypted","restored","ok","no"]);
const ID_KEYS=new Set(["ts","level","event","user","view","cid","sid","op","path","code","rule","severity","coll","kind","state","where","no"]);
/* names of clients, suppliers, payees and the business itself: any of their words (4+ letters, not a legal suffix)
   found in log text is replaced, because error messages can quote them */
const MON_STOP=new Set(["limited","company","group","uganda","with","from","this","that","have","your","the","and"]);let MON_NAMES={key:"",re:null};
function monNameRe(){try{if(typeof S==="undefined"||!S)return null;const parts=[];const add=v=>{if(typeof v==="string")for(const w of v.split(/[^\p{L}\p{N}']+/u))if(w.length>=4&&!MON_STOP.has(w.toLowerCase()))parts.push(w)};
  const key=(S.clients||[]).length+"/"+(S.suppliers||[]).length+"/"+(S.payments||[]).length;if(MON_NAMES.key===key&&MON_NAMES.re!==undefined)return MON_NAMES.re;
  for(const c of ["clients","suppliers"])for(const r of S[c]||[])add(r.name),add(r.contact);for(const r of S.payments||[])add(r.payee);const b=(typeof settings!=="undefined"&&settings)||{};add(b.name);add(b.payDetails);add(b.address);
  const u=[...new Set(parts.map(w=>w.replace(/[.*+?^${}()|[\]\\]/g,"\\$&")))].sort((x,y)=>y.length-x.length).slice(0,3000);
  MON_NAMES={key,re:u.length?new RegExp("("+u.join("|")+")","giu"):null};return MON_NAMES.re}catch(e){return null}}
function redactStr(s){s=String(s==null?"":s).slice(0,300);const nr=monNameRe();if(nr)s=s.replace(nr,"[name]");
  return s.replace(/[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}/gi,"[email]")
    .replace(/(pass(word|phrase)?|pwd|token|secret|api[_-]?key|key|authorization|bearer)(\s*[:=]\s*|\s+)\S+/gi,"$1=[redacted]")
    .replace(/\d[\d,.'  ]*\d|\d/g,"#")}
function redactVal(k,v){if(v==null)return v;if(typeof v==="number"||typeof v==="boolean")return ID_KEYS.has(k)&&typeof v!=="boolean"?String(v):v;
  if(typeof v==="string")return ID_KEYS.has(k)?String(v).replace(/[^\w\-./:#@ ]/g,"").slice(0,120):redactStr(v);
  if(Array.isArray(v))return v.slice(0,8).map(x=>typeof x==="string"?redactStr(x):typeof x==="number"?x:"[object]");return"[object]"}
function redact(e){const o={};for(const [k,v] of Object.entries(e||{})){if(v===undefined)continue;o[k]=SAFE_KEYS.has(k)?redactVal(k,v):"[redacted]"}return o}
/* ---------- traces (correlation ids) ---------- */
const monId=()=>Math.random().toString(36).slice(2,10)+Date.now().toString(36).slice(-4);
function monTrace(kind){const t={cid:monId(),kind:String(kind||"action").replace(/[^\w\-]/g,"").slice(0,40),at:Date.now(),spans:[],errors:0};MON.cur=t;MON.traces.push(t);if(MON.traces.length>100)MON.traces.shift();return t}
document.addEventListener("submit",e=>monTrace("submit-"+((e.target&&e.target.id)||"form")),true);
document.addEventListener("click",e=>{const b=e.target&&e.target.closest&&e.target.closest("button,a[href],[data-t],[data-c]");if(b)monTrace((b.id||b.dataset.t||b.dataset.c||(b.getAttribute("href")||"").replace("#","")||"click"))},true);
const monCid=()=>MON.cur&&Date.now()-MON.cur.at<120000?MON.cur.cid:null;
/* ---------- recording ---------- */
const FIN_COLLS=/^(invoices|receipts|credits|debits|refunds|purchases|payments|sdebits|adjustments)\//;
function monCall(op,path,ms,ok,code){const t=Date.now();const c={t,op,path:String(path||""),ms:Math.round(ms),ok,code:code||""};MON.calls.push(c);if(MON.calls.length>5000)MON.calls.splice(0,1000);
  const tr=MON.cur&&t-MON.cur.at<120000?MON.cur:null;if(tr){tr.spans.push({sid:monId(),op,path:c.path.split("/")[0],ms:c.ms,ok,code:c.code});if(!ok)tr.errors++;if(tr.spans.length>60)tr.spans.shift()}
  monAgg().calls[op]=bucketAdd(monAgg().calls[op],ms,ok)}
function monGaveUp(ctx,code){MON.gave.push({t:Date.now(),path:String(ctx.path||""),code});if(MON.gave.length>500)MON.gave.shift();
  if(FIN_COLLS.test(String(ctx.path||""))&&/^(set|update)$/.test(ctx.op||""))monPosting(String(ctx.path).split("/")[0],"not-saved",code)}
function monHeartbeat(ok,ms){MON.hb.push({t:Date.now(),ok,ms:ms==null?null:Math.round(ms)});monCall("health-read","settings",ms||0,!!ok,ok?"":"unreachable");if(MON.hb.length>3000)MON.hb.splice(0,500);const a=monAgg();a.hb.n++;if(!ok)a.hb.fail++;if(ms!=null)a.hb.lat=bucketAdd(a.hb.lat,ms,true)}
function monRender(v,ms){if(ms<1)return;MON.renders.push({t:Date.now(),view:v,ms:Math.round(ms)});if(MON.renders.length>500)MON.renders.shift();const a=monAgg();a.render[v]=bucketAdd(a.render[v],ms,true)}
function monPosting(coll,stage,reason){MON.post.push({t:Date.now(),coll,stage});if(MON.post.length>500)MON.post.shift();monAgg().posting++;
  logEvent("warn","posting-not-made",{coll,state:stage,message:reason})}
function monJob(name,ok){if(!ok){MON.jobs[name]=(MON.jobs[name]||0)+1;monAgg().jobsFailed++}else MON.jobs[name]=0}
if(typeof PerformanceObserver!=="undefined")try{new PerformanceObserver(l=>{for(const e of l.getEntries()){MON.lt.push({t:Date.now(),ms:Math.round(e.duration)});monAgg().lt=bucketAdd(monAgg().lt,e.duration,true)}if(MON.lt.length>2000)MON.lt.splice(0,500)}).observe({type:"longtask",buffered:true})}catch(e){}
window.addEventListener("error",()=>{MON.errs.push(Date.now());monAgg().crashes++});
window.addEventListener("unhandledrejection",()=>{MON.errs.push(Date.now());monAgg().crashes++});
const monHeap=()=>{try{const m=performance.memory;if(m){const mb=Math.round(m.usedJSHeapSize/1048576);if(mb>MON.heapMax)MON.heapMax=mb;const a=monAgg();if(mb>a.heapMax)a.heapMax=mb}}catch(e){}};monHeap();setInterval(monHeap,10000);
/* histograms with fixed buckets, so days and sessions can be added together exactly */
const BKT=[100,250,500,1000,2500,5000,10000,Infinity];
function bucketAdd(h,ms,ok){h=h||{n:0,fail:0,b:BKT.map(()=>0),max:0};h.n++;if(!ok)h.fail++;const i=BKT.findIndex(x=>ms<x);h.b[i]++;if(ms>h.max)h.max=Math.round(ms);return h}
function bucketQ(h,q){if(!h||!h.n)return null;let k=Math.ceil(h.n*q),s=0;for(let i=0;i<BKT.length;i++){s+=h.b[i];if(s>=k)return i<BKT.length-1?BKT[i]:h.max}return h.max}
function monAgg(){const d=new Date().toISOString().slice(0,10);if(MON.day!==d){MON.day=d;MON.agg={day:d,sessions:1,calls:{},hb:{n:0,fail:0,lat:null},lt:null,render:{},crashes:0,posting:0,jobsFailed:0,alerts:{},heapMax:0,loadMs:MON.loadMs}}return MON.agg}
/* ---------- windows over recent data ---------- */
const since=(arr,ms)=>{const c=Date.now()-ms;return arr.filter(x=>(x.t||x)>=c)};
function pct(xs,q){if(!xs.length)return null;const s=xs.slice().sort((a,b)=>a-b);return s[Math.min(s.length-1,Math.ceil(s.length*q)-1)]}
function monStats(ms){const c=since(MON.calls,ms);const fail=c.filter(x=>!x.ok);const lat=c.filter(x=>x.ok).map(x=>x.ms);const hb=since(MON.hb,ms);
  return{n:c.length,fail:fail.length,rate:c.length?fail.length/c.length:0,p50:pct(lat,.5),p95:pct(lat,.95),hbN:hb.length,hbOk:hb.filter(x=>x.ok).length,
    lt:since(MON.lt,ms),errs:since(MON.errs,ms).length,post:since(MON.post,ms)}}
/* baseline = 95th percentile of the first 20 successful store calls of the session, fixed from then on, so "unusual"
   means slower than this device and connection usually are, and a slowdown can't become its own baseline */
function monBaseline(){if(MON.base!=null)return MON.base;const ok=MON.calls.filter(x=>x.ok).slice(0,20).map(x=>x.ms);if(ok.length<20)return null;MON.base=pct(ok,.95);return MON.base}
/* records the app has loaded (documents, approvals, settings and counters); people's own audit and metrics logs are not loaded, so this is a lower bound — the hourly monitor reads the exact count from the platform */
function monRecords(){if(typeof S==="undefined"||!S)return null;let n=0;for(const k of COLLS)if(Array.isArray(S[k]))n+=S[k].length;if(typeof SEC!=="undefined"&&SEC.approvals)n+=SEC.approvals.size;return n+1+LEDGER.DOC_COLLS.filter(c=>S[c]&&S[c].length).length}
/* ---------- alert rules: each one only reads ---------- */
const MON_RULES=[
  {id:"availability",title:"Records unreachable",run:()=>{if(HEALTH.offline&&HEALTH.downSince){const m=(Date.now()-HEALTH.downSince)/60000;if(m>=2)return{sev:"critical",detail:"The store has not answered for "+Math.round(m)+" min. Saving is paused."}}return null}},
  {id:"latency",title:"Responses much slower than usual",run:()=>{const s=monStats(5*60000);const b=monBaseline();if(s.n-s.fail<10||s.p95==null)return null;const lim=Math.max(1500,b!=null?3*b:1500);
    return s.p95>lim?{sev:s.p95>3*lim?"critical":"warn",detail:"95% of store calls in the last 5 min took up to "+s.p95+" ms (usual: "+(b==null?"not yet known":b+" ms")+"; alert above "+lim+" ms)."}:null}},
  {id:"error-rate",title:"Store calls failing",run:()=>{const s=monStats(10*60000);const gave=since(MON.gave,10*60000).filter(x=>x.code==="gave-up").length;
    if((s.n>=20&&s.rate>0.05)||gave>=3)return{sev:"critical",detail:s.fail+" of "+s.n+" store calls failed in the last 10 min ("+Math.round(s.rate*100)+"%), "+gave+" saves gave up after retries."};return null}},
  {id:"crashes",title:"Repeated errors in the app",run:()=>{const n=since(MON.errs,10*60000).length;return n>=3?{sev:"critical",detail:n+" unexpected errors in the last 10 min. See the event log for where."}:null}},
  {id:"integrity",title:"Books check found problems",run:()=>{if(typeof loaded==="undefined"||!loaded)return null;let L;try{L=ledger()}catch(e){monJob("checkFail",false);return{sev:"critical",detail:"The books check could not run."}}
    return L.problems?{sev:"critical",detail:L.problems+" problem"+(L.problems===1?"":"s")+" in the books (double entry, fingerprints, numbering, approvals or reconciliations). Open Accounts → Checks. Nothing has been changed."}:null}},
  {id:"posting",title:"Financial postings not made",run:()=>{const p=since(MON.post,30*60000);if(!p.length)return null;const by={};for(const x of p)by[x.coll]=(by[x.coll]||0)+1;
    return{sev:p.length>=3?"critical":"warn",detail:p.length+" posting"+(p.length===1?"":"s")+" refused or not saved in the last 30 min ("+Object.entries(by).map(([k,v])=>k+" "+v).join(", ")+"). Nothing was posted for these."}}},
  {id:"jobs",title:"Background jobs failing",run:()=>{const j=MON.jobs;const q=(typeof AUDITQ!=="undefined"?AUDITQ.length:0)+ERRQ.length;const bad=[];
    if(j.auditFail>=3)bad.push("audit-trail writes ("+j.auditFail+" in a row)");if(j.errFail>=3)bad.push("error-log writes ("+j.errFail+")");if(j.metricsFail>=3)bad.push("metrics writes ("+j.metricsFail+")");
    if(j.indexFail)bad.push("report index");if(j.checkFail)bad.push("books check");if(q>200)bad.push(q+" log entries waiting to be written");
    return bad.length?{sev:"warn",detail:"Failing: "+bad.join("; ")+"."}:null}},
  {id:"capacity",title:"Storage nearly full",run:()=>{const n=monRecords();if(n==null)return null;const p=n/MON_LIMIT;
    return p>=0.8?{sev:p>=0.95?"critical":"warn",detail:n.toLocaleString("en-US")+" of "+MON_LIMIT.toLocaleString("en-US")+" records used ("+Math.round(p*100)+"%). Start the archive plan."}:null}},
  {id:"slow-page",title:"The page is struggling",run:()=>{const lt=since(MON.lt,10*60000).filter(x=>x.ms>=1000);const r=since(MON.renders,10*60000).filter(x=>x.ms>=3000);
    return lt.length>=3||r.length>=2?{sev:"warn",detail:(lt.length?lt.length+" freezes over 1 s":"")+(lt.length&&r.length?"; ":"")+(r.length?r.length+" screens took over 3 s ("+[...new Set(r.map(x=>x.view))].join(", ")+")":"")+" in the last 10 min."}:null}}];
function monEvaluate(){const now=Date.now();for(const r of MON_RULES){let res=null;try{res=r.run()}catch(e){res=null}const cur=MON.alerts.get(r.id);
    if(res&&!cur){const a={rule:r.id,title:r.title,sev:res.sev,detail:res.detail,since:now,cid:monId()};MON.alerts.set(r.id,a);MON.history.unshift({...a,state:"raised",at:now});monAgg().alerts[r.id]=(monAgg().alerts[r.id]||0)+1;
      logEvent(res.sev==="critical"?"error":"warn","alert-raised",{rule:r.id,severity:res.sev,detail:res.detail})}
    else if(res&&cur){cur.detail=res.detail;if(res.sev==="critical"&&cur.sev!=="critical"){cur.sev="critical";logEvent("error","alert-raised",{rule:r.id,severity:"critical",detail:res.detail})}}
    else if(!res&&cur){MON.alerts.delete(r.id);MON.history.unshift({...cur,state:"cleared",at:now});logEvent("info","alert-cleared",{rule:r.id,after_s:Math.round((now-cur.since)/1000)})}}
  if(MON.history.length>100)MON.history.length=100;monBadge()}
function monBadge(){const a=document.querySelector('a[data-v="health"]');if(!a)return;let b=a.querySelector(".monb");const n=MON.alerts.size,crit=[...MON.alerts.values()].some(x=>x.sev==="critical");
  if(!n){if(b)b.remove();return}if(!b){b=document.createElement("span");b.className="monb";a.appendChild(b)}b.textContent=" "+n;b.style.cssText="margin-left:6px;padding:0 6px;border-radius:9px;color:#fff;font-size:12px;background:"+(crit?"#b42318":"#b54708")}
setInterval(()=>{try{monEvaluate()}catch(e){}},30000);
/* ---------- persisted daily metrics (the person's own log space; one record per person per month) ---------- */
function mergeH(a,b){if(!a)return b;if(!b)return a;return{n:a.n+b.n,fail:a.fail+b.fail,b:a.b.map((x,i)=>x+b.b[i]),max:Math.max(a.max,b.max)}}
function mergeAgg(a,b){if(!a)return b;const o={...a,sessions:(a.sessions||0)+(b.sessions||0),crashes:a.crashes+b.crashes,posting:a.posting+b.posting,jobsFailed:a.jobsFailed+b.jobsFailed,heapMax:Math.max(a.heapMax||0,b.heapMax||0),
  hb:{n:a.hb.n+b.hb.n,fail:a.hb.fail+b.hb.fail,lat:mergeH(a.hb.lat,b.hb.lat)},lt:mergeH(a.lt,b.lt),calls:{...a.calls},render:{...a.render},alerts:{...a.alerts},loadMs:a.loadMs??b.loadMs};
  for(const k in b.calls)o.calls[k]=mergeH(a.calls[k],b.calls[k]);for(const k in b.render)o.render[k]=mergeH(a.render[k],b.render[k]);for(const k in b.alerts)o.alerts[k]=(a.alerts[k]||0)+b.alerts[k];return o}
async function flushMetrics(){if(!db||!myId||HEALTH.offline)return;const agg=MON.agg;if(!agg)return;const snap=JSON.parse(JSON.stringify(agg));
  /* reset the running totals before the write, and add them back if it fails, so nothing is counted twice */
  MON.agg={...snap,sessions:0,calls:{},hb:{n:0,fail:0,lat:null},lt:null,render:{},crashes:0,posting:0,jobsFailed:0,alerts:{},heapMax:0};
  const mo=snap.day.slice(0,7);const path="audit/"+myId+"/metrics/"+mo;const ref=db.doc(path);
  try{const res=await withTimeout(ref.acquire({holder:HOLDER,ttlMs:10000}),8000);if(!res||!res.acquired)throw{code:"busy"};
    const s=await withTimeout(ref.get(),8000);if(!s.exists&&monFull()){releaseLater(path,ref);MON.agg=mergeAgg(MON.agg,snap);return}const d=s.exists?s.data():{month:mo,days:{}};const days={...(d.days||{})};days[snap.day]=mergeAgg(days[snap.day],snap);
    await withTimeout(ref.set({month:mo,days,v:1}),10000);releaseLater(path,ref);MON.lastFlush=Date.now();monJob("metricsFail",true)}
  catch(e){MON.agg=mergeAgg(MON.agg,snap);monJob("metricsFail",false)}}
setInterval(()=>{flushMetrics()},5*60000);
window.addEventListener("pagehide",()=>{try{flushMetrics()}catch(e){}});
/* ---------- deep health check: reads only ---------- */
async function deepCheck(){const out=[];const t=async(label,fn)=>{const t0=performance.now();try{const d=await fn();out.push({label,ok:true,ms:Math.round(performance.now()-t0),detail:d||""})}catch(e){out.push({label,ok:false,ms:Math.round(performance.now()-t0),detail:(e&&e.code)||String(e&&e.message||e).slice(0,80)})}};
  await t("Store answers a read (business details)",async()=>{if(!db)throw{code:"no store"};await withTimeout(db.doc("settings/business").get(),8000)});
  await t("A collection can be listed (counters)",async()=>{if(!db)throw{code:"no store"};const q=await withTimeout(db.collection("counters").get(),8000);return q.docs.length+" records"});
  await t("Books check runs",async()=>{const L=ledger();if(L.problems)throw{code:L.problems+" problems"};return L.J.length+" journal entries, 0 problems"});
  await t("Reports can be prepared",async()=>{const L=ledger();const ix=REPORTS.buildIndex(L.J);const tb=REPORTS.trialBalance(ix);if(!tb.ok)throw{code:"trial balance out of balance"};return"trial balance balances"});
  await t("Saving is allowed",async()=>{const w=writesBlocked();if(w)throw{code:w.slice(0,80)};if(!canWrite)throw{code:"view-only access"};return"yes"});
  logEvent(out.every(x=>x.ok)?"info":"warn","deep-check",{failed:out.filter(x=>!x.ok).map(x=>x.label),count:out.length});return out}
/* ---------- dashboard ---------- */
function fmtMs(x){return x==null?"—":x>=1000?(x/1000).toFixed(1)+" s":x+" ms"}
function sparkSVG(){const now=Date.now(),W=560,H=90,mins=60;const pts=[],fails=[];
  for(let i=mins-1;i>=0;i--){const a=now-(i+1)*60000,b=now-i*60000;const c=MON.calls.filter(x=>x.t>=a&&x.t<b);const ok=c.filter(x=>x.ok).map(x=>x.ms);pts.push(pct(ok,.95));fails.push(c.length-ok.length)}
  const mx=Math.max(500,...pts.filter(x=>x!=null));const x=i=>20+i*(W-30)/(mins-1),y=v=>H-14-(v/mx)*(H-24);let d="";pts.forEach((v,i)=>{if(v==null)return;d+=(d&&pts[i-1]!=null?"L":"M")+x(i).toFixed(1)+","+y(v).toFixed(1)});
  return`<svg viewBox="0 0 ${W} ${H}" width="100%" style="max-width:${W}px" role="img" aria-label="95th percentile store response time per minute, last 60 minutes"><line x1="20" y1="${H-14}" x2="${W-10}" y2="${H-14}" stroke="#ccc"/>
   <text x="20" y="10" font-size="10" fill="#667">${fmtMs(Math.round(mx))}</text><text x="20" y="${H-2}" font-size="10" fill="#667">60 min ago</text><text x="${W-10}" y="${H-2}" font-size="10" fill="#667" text-anchor="end">now</text>
   ${fails.map((f,i)=>f?`<rect x="${(x(i)-2).toFixed(1)}" y="${H-24}" width="4" height="10" fill="#b42318"><title>${f} failed</title></rect>`:"").join("")}<path d="${d}" fill="none" stroke="#1f6feb" stroke-width="1.8"/></svg>`}
function renderMonitoring(){const el=$("#monBody");if(!el)return;monEvaluate();const h1=monStats(3600000),m5=monStats(5*60000);const b=monBaseline();
  const avail=h1.hbN?Math.round(1000*h1.hbOk/h1.hbN)/10:null;const lt=h1.lt;const busy=Math.min(100,Math.round(1000*lt.reduce((t,x)=>t+x.ms,0)/3600000)/10);const rec=monRecords();
  const al=[...MON.alerts.values()].sort((a,c)=>(a.sev==="critical"?0:1)-(c.sev==="critical"?0:1));
  let h=`<h3 style="margin-top:0">Alerts</h3>`+(al.length?`<table id="monAlerts"><tbody>${al.map(a=>`<tr data-rule="${esc(a.rule)}"><td><b class="${a.sev==="critical"?"neg":"wrn"}">${a.sev==="critical"?"Critical":"Warning"}</b></td><td><b>${esc(a.title)}</b><div class="muted" style="font-size:12px">${esc(a.detail)}</div></td><td class="muted" style="white-space:nowrap">since ${esc(new Date(a.since).toTimeString().slice(0,5))}</td></tr>`).join("")}</tbody></table><p class="sub">What to do for each alert is in the monitoring runbook. Alerts never change your records.</p>`:`<p id="monAlerts" class="pos">No active alerts.</p>`);
  h+=`<h3>Service level (last hour)</h3><table><tbody>
   <tr><td>Availability (health checks answered)</td><td class="num">${avail==null?"—":avail+"%"} <span class="muted">(${h1.hbOk} of ${h1.hbN})</span></td></tr>
   <tr><td>Store response time, typical / 95% of calls</td><td class="num">${fmtMs(h1.p50)} / ${fmtMs(h1.p95)} <span class="muted">(last 5 min: ${fmtMs(m5.p95)}; usual: ${fmtMs(b)})</span></td></tr>
   <tr><td>Store calls that failed</td><td class="num">${h1.fail} of ${h1.n}${h1.n?" ("+(Math.round(h1.rate*1000)/10)+"%)":""}</td></tr>
   <tr><td>Postings refused or not saved</td><td class="num">${h1.post.length}</td></tr>
   <tr><td>Unexpected errors in the page</td><td class="num">${h1.errs}</td></tr></tbody></table>
   <div style="margin:8px 0 2px" class="muted">Store response time (95% of calls) per minute; red marks = failed calls</div>${sparkSVG()}`;
  const ops={};for(const c of since(MON.calls,3600000)){const o=ops[c.op]||(ops[c.op]={n:0,f:0,ms:[]});o.n++;if(!c.ok)o.f++;else o.ms.push(c.ms)}
  h+=`<h3>Store calls by kind (last hour)</h3><table><thead><tr><th>Kind</th><th class="num">Calls</th><th class="num">Failed</th><th class="num">Typical</th><th class="num">95%</th><th class="num">Slowest</th></tr></thead><tbody>${Object.entries(ops).map(([k,o])=>`<tr><td>${esc(k)}</td><td class="num">${o.n}</td><td class="num">${o.f}</td><td class="num">${fmtMs(pct(o.ms,.5))}</td><td class="num">${fmtMs(pct(o.ms,.95))}</td><td class="num">${fmtMs(o.ms.length?Math.max(...o.ms):null)}</td></tr>`).join("")||`<tr><td colspan="6" class="empty">No store calls yet.</td></tr>`}</tbody></table>`;
  const rv={};for(const r of since(MON.renders,3600000)){const o=rv[r.view]||(rv[r.view]=[]);o.push(r.ms)}
  let heap=null;try{heap=performance.memory?Math.round(performance.memory.usedJSHeapSize/1048576):null}catch(e){}
  h+=`<h3>This device</h3><table><tbody>
   <tr><td>Browser busy (long tasks), last hour</td><td class="num">${busy}% <span class="muted">(${lt.length} long tasks, longest ${fmtMs(lt.length?Math.max(...lt.map(x=>x.ms)):null)})</span></td></tr>
   <tr><td>Memory used by the app</td><td class="num">${heap==null?"not reported by this browser":heap+" MB (peak "+MON.heapMax+" MB)"}</td></tr>
   <tr><td>Time to load records</td><td class="num">${fmtMs(MON.loadMs)}</td></tr>
   <tr><td>Slowest screens (95%)</td><td class="num">${Object.entries(rv).map(([v,xs])=>[v,pct(xs,.95)]).sort((a,c)=>c[1]-a[1]).slice(0,4).map(([v,x])=>esc(v)+" "+fmtMs(x)).join(" · ")||"—"}</td></tr></tbody></table>
   <p class="sub">Server CPU, disk and database connections belong to the hosting platform and are not visible to the app. Storage is shown against the platform's record limit instead.</p>`;
  h+=`<h3>Storage and background jobs</h3><table><tbody>
   <tr><td>Records used (at least: people's own logs are not counted here)</td><td class="num">${rec==null?"—":rec.toLocaleString("en-US")+" of "+MON_LIMIT.toLocaleString("en-US")+" ("+(Math.round(1000*rec/MON_LIMIT)/10)+"%)"}</td></tr>
   <tr><td>Audit-trail and error-log entries waiting to be written</td><td class="num">${(typeof AUDITQ!=="undefined"?AUDITQ.length:0)+ERRQ.length}</td></tr>
   <tr><td>Failures in a row: audit trail / error log / metrics</td><td class="num">${MON.jobs.auditFail} / ${MON.jobs.errFail} / ${MON.jobs.metricsFail}</td></tr>
   <tr><td>Metrics last saved</td><td class="num">${MON.lastFlush?esc(new Date(MON.lastFlush).toTimeString().slice(0,8)):"not yet (every 5 min)"}</td></tr></tbody></table>`;
  h+=`<h3>Recent actions (traces)</h3><table id="monTraces"><thead><tr><th>Time</th><th>Action</th><th>Trace id</th><th class="num">Store calls</th><th class="num">Time in store</th><th>Result</th></tr></thead><tbody>${MON.traces.filter(t=>t.spans.length).slice(-15).reverse().map(t=>`<tr><td class="mono">${esc(new Date(t.at).toTimeString().slice(0,8))}</td><td>${esc(t.kind)}</td><td class="mono">${esc(t.cid)}</td><td class="num">${t.spans.length}</td><td class="num">${fmtMs(t.spans.reduce((s,x)=>s+x.ms,0))}</td><td>${t.errors?`<span class="neg">${t.errors} failed</span>`:"ok"}</td></tr>`).join("")||`<tr><td colspan="6" class="empty">No actions yet.</td></tr>`}</tbody></table>`;
  if(MON.history.length)h+=`<h3>Alert history (this session)</h3><table><tbody>${MON.history.slice(0,20).map(a=>`<tr><td class="mono">${esc(new Date(a.at).toTimeString().slice(0,8))}</td><td>${a.state==="raised"?`<span class="${a.sev==="critical"?"neg":"wrn"}">raised</span>`:"cleared"}</td><td>${esc(a.title)}</td></tr>`).join("")}</tbody></table>`;
  if(isOwnerUser)h+=`<h3>Team (last 7 days)</h3><div id="monTeam"><button class="btn ghost small" id="monTeamLoad" type="button">Load everyone's daily figures</button></div>`;
  el.innerHTML=h}
function knownUsers(){const u=new Set();if(myId)u.add(myId);for(const k of Object.keys(S||{}))if(Array.isArray(S[k]))for(const r of S[k])for(const f of ["createdBy","updatedBy","by","requestedBy"])if(typeof r[f]==="string"&&/^u_[A-Za-z0-9]+$/.test(r[f]))u.add(r[f]);return[...u]}
async function loadTeam(){const el=$("#monTeam");if(!el||!db)return;el.innerHTML="Loading…";const days=[...Array(7)].map((_,i)=>new Date(Date.now()-i*864e5).toISOString().slice(0,10));const rows=[];
  for(const u of knownUsers()){const mos=[...new Set(days.map(d=>d.slice(0,7)))];let agg=null;
    for(const mo of mos){try{const s=await withTimeout(db.doc("audit/"+u+"/metrics/"+mo).get(),8000);if(s.exists)for(const d of days)if(s.data().days&&s.data().days[d])agg=mergeAgg(agg,s.data().days[d])}catch(e){}}
    if(agg){let n=0,f=0,all=null;for(const k in agg.calls){n+=agg.calls[k].n;f+=agg.calls[k].fail;all=mergeH(all,agg.calls[k])}const al=Object.values(agg.alerts||{}).reduce((t,x)=>t+x,0);
      rows.push(`<tr><td class="mono">${esc(u===myId?"you":u.slice(0,8)+"…")}</td><td class="num">${agg.sessions}</td><td class="num">${agg.hb.n?Math.round(1000*(agg.hb.n-agg.hb.fail)/agg.hb.n)/10+"%":"—"}</td><td class="num">${n?f+" of "+n:"—"}</td><td class="num">${fmtMs(bucketQ(all,.95))}</td><td class="num">${agg.crashes}</td><td class="num">${agg.posting}</td><td class="num">${al}</td></tr>`)}}
  el.innerHTML=rows.length?`<table><thead><tr><th>Person</th><th class="num">Sessions</th><th class="num">Available</th><th class="num">Failed calls</th><th class="num">95% response (≤)</th><th class="num">Errors</th><th class="num">Postings not made</th><th class="num">Alerts</th></tr></thead><tbody>${rows.join("")}</tbody></table>`:`<p class="empty">No saved figures yet.</p>`}
document.addEventListener("click",e=>{const t=e.target;if(!t||!t.id)return;
  if(t.id==="monTeamLoad")loadTeam();
  if(t.id==="hlDeep"){t.disabled=true;deepCheck().then(r=>{const el=$("#hlDeepOut");if(el)el.innerHTML=`<table><tbody>${r.map(x=>`<tr><td>${x.ok?'<span class="pos">✓</span>':'<span class="neg">✗</span>'}</td><td>${esc(x.label)}${x.detail?` <span class="muted">— ${esc(x.detail)}</span>`:""}</td><td class="num">${fmtMs(x.ms)}</td></tr>`).join("")}</tbody></table>`;t.disabled=false;renderAll()})}});
