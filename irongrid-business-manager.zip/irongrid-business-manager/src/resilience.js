/* ====================== resilience: health checks, fail-safe writes, structured error log ======================
   - HEALTH is the app's own view of the connection: a heartbeat reads one small record every 30 s; two failures
     in a row (or the browser saying it is offline, or a live data feed reconnecting) mark the store unreachable.
   - While the store is unreachable or any live data feed is reconnecting, writesBlocked() refuses every save. A
     financial save is only made when the balances it is checked against are known to be current, so a
     dropped connection can delay work but never post against stale figures.
   - logEvent() writes one structured line per event (time, level, event, user, record, error code, attempt) to the
     console and keeps the last 500 in memory; warnings and errors are also appended to the person's own error log
     audit/<id>/errors/<day>, which only they can write and only the owner can read. */
const RECONNECTING=new Set();
const HEALTH={offline:false,lastOk:0,lastLatency:null,fails:0,checks:0,failedWrites:0,retries:0,landedAfterTimeout:0,since:Date.now(),started:false};
const EVLOG=[],ERRQ=[];let errT=0;
function logEvent(level,event,f){const e=redact({ts:new Date().toISOString(),level,event,user:myId||null,view,cid:monCid()||undefined,...(f||{})});
  if(event==="store-call-retry")HEALTH.retries++;if(event==="unconfirmed-write-had-landed")HEALTH.landedAfterTimeout++;
  EVLOG.push(e);if(EVLOG.length>500)EVLOG.shift();
  try{(level==="error"?console.error:level==="warn"?console.warn:console.info)("[irongrid] "+JSON.stringify(e))}catch(x){}
  if(level!=="info"&&db&&myId){ERRQ.push(e);if(ERRQ.length>500)ERRQ.shift();if(!errT)errT=setTimeout(flushErrors,5000)}
  if(view==="health")renderAll()}
async function flushErrors(){errT=0;if(!ERRQ.length||!db||!myId)return;if(HEALTH.offline){errT=setTimeout(flushErrors,15000);return}
  const batch=ERRQ.splice(0,ERRQ.length);const day=today();const ref=db.doc("audit/"+myId+"/errors/"+day);
  try{const res=await withTimeout(ref.acquire({holder:HOLDER,ttlMs:10000}),8000);if(!res||!res.acquired)throw{code:"busy"};
    const s=await withTimeout(ref.get(),8000);if(!s.exists&&monFull()){releaseLater("audit/"+myId+"/errors/"+day,ref);ERRQ.unshift(...batch);errT=setTimeout(flushErrors,60000);return}const ev=s.exists&&Array.isArray(s.data().events)?s.data().events.slice():[];ev.push(...batch);
    await withTimeout(ref.set({events:ev.slice(-1000),day}),10000);releaseLater("audit/"+myId+"/errors/"+day,ref);monJob("errFail",true)}
  catch(e){ERRQ.unshift(...batch);if(ERRQ.length>2000)ERRQ.splice(0,ERRQ.length-2000);monJob("errFail",false);errT=setTimeout(flushErrors,15000)}}
window.addEventListener("error",e=>logEvent("error","uncaught-error",{message:String(e.message||"").slice(0,300),where:(e.filename||"").split("/").pop()+":"+e.lineno}));
window.addEventListener("unhandledrejection",e=>{const r=e.reason;logEvent("error","unhandled-rejection",{code:r&&r.code,message:String(r&&r.message||r||"").slice(0,300)})});

/* ---- heartbeat ---- */
async function heartbeat(){if(!db)return;HEALTH.checks++;const t0=performance.now();
  try{if(navigator.onLine===false)throw{code:"offline"};await withTimeout(db.doc("settings/business").get(),8000);
    HEALTH.lastLatency=Math.round(performance.now()-t0);HEALTH.lastOk=Date.now();monHeartbeat(true,HEALTH.lastLatency);
    if(HEALTH.offline){HEALTH.offline=false;logEvent("info","store-reachable-again",{after_s:Math.round((Date.now()-HEALTH.downSince)/1000)});if(!RECONNECTING.size&&!loadFailed&&canWrite)banner("");renderAll()}HEALTH.fails=0}
  catch(e){HEALTH.fails++;monHeartbeat(false,null);logEvent("warn","heartbeat-failed",{code:e&&e.code,fails:HEALTH.fails});
    if(HEALTH.fails>=2&&!HEALTH.offline){HEALTH.offline=true;HEALTH.downSince=Date.now();banner("Can't reach your records right now. Saving is paused until the connection is back — nothing has been lost.");renderAll()}}}
function startHeartbeat(){if(HEALTH.started)return;HEALTH.started=true;heartbeat();setInterval(heartbeat,30000);
  window.addEventListener("offline",()=>{HEALTH.fails=2;HEALTH.offline=true;HEALTH.downSince=Date.now();logEvent("warn","browser-offline",{});banner("You're offline. Saving is paused until the connection is back — nothing has been lost.");renderAll()});
  window.addEventListener("online",()=>{logEvent("info","browser-online",{});heartbeat()})}
function staleMsg(){if(HEALTH.offline)return"Can't reach your records right now, so nothing can be saved. Your work isn't lost — try again when the connection is back.";
  if(RECONNECTING.size)return"The live connection to your records dropped and is reconnecting. Saving is paused until it's back, so nothing is saved against out-of-date balances.";return""}

/* ---- the verify step for a write whose result is unknown (timed out or dropped): read the record back ---- */
const canonical=x=>JSON.stringify(x,(k,v)=>v&&typeof v==="object"&&!Array.isArray(v)?Object.fromEntries(Object.keys(v).sort().map(j=>[j,v[j]])):v);
const landedSet=(ref,data)=>async()=>{const s=await ref.get();return s.exists&&canonical(s.data())===canonical(data)};
const landedUpdate=(ref,fields)=>async()=>{const s=await ref.get();if(!s.exists)return false;const d=s.data();return Object.keys(fields).every(k=>canonical(d[k])===canonical(fields[k]))};
const landedDelete=ref=>async()=>{const s=await ref.get();return!s.exists};

/* ---- book control totals: stored in every backup's manifest and compared after a restore ---- */
function bookControls(){const L=ledger();const bal=LEDGER.balances(L.J);const b={};for(const a of Object.keys(bal).sort())b[a]=bal[a].d-bal[a].c;
  const st={};for(const i of Object.keys(L.stock||{}).sort())st[i]={q:L.stock[i].q,v:L.stock[i].v};
  return{journals:L.J.length,problems:L.problems,balances:b,stock:st,dp:DP(),currency:cur()}}

/* ---- after a restore: read everything back from the store and prove it; success is claimed only if every check passes ---- */
async function verifyRestore(b,RC){const out={checks:[],ok:false};const add=(label,ok,detail)=>out.checks.push({label,ok,detail:detail||""});
  try{let missing=0,changed=0,extra=0,ex=[];for(const c of RC){const q=await withTimeout(db.collection(c).get(),30000);const got=new Map(q.docs.map(x=>[x.id,x.data()]));
      const want=new Map((Array.isArray(b.data[c])?b.data[c]:[]).map(r=>{const d={...r};delete d.id;return[r.id,d]}));
      for(const [id,d] of want){if(!got.has(id)){missing++;if(ex.length<5)ex.push(c+"/"+id+" missing")}else if(canonical(got.get(id))!==canonical(d)){changed++;if(ex.length<5)ex.push(c+"/"+id+" differs")}}
      for(const id of got.keys())if(!want.has(id))extra++}
    add("Every record in the backup is in the store, read back from the server",missing===0,missing?missing+" missing ("+ex.join("; ")+")":"");
    add("Every restored record is identical to its backup copy",changed===0,changed?changed+" differ — the store already had a different version of these records":"");
    add("No records outside the backup",extra===0,extra?extra+" records in the store aren't in the backup (entered after it was made)":"");
    await sleep(1500);invalidate();const L=ledger();
    add("Books check: double entry, fingerprints, numbering and references",L.problems===0,L.problems?L.problems+" problems — see Accounts → Checks":"");
    for(const r of L.recon)add(r.label,r.ok,r.ok?"":"ledger "+r.gl+" vs subledger "+r.sub);
    const C=b.manifest&&b.manifest.controls;
    if(C){const now=bookControls();const keys=new Set([...Object.keys(C.balances||{}),...Object.keys(now.balances)]);const diffs=[...keys].filter(k=>(C.balances[k]||0)!==(now.balances[k]||0));
      add("Journal count matches the backup ("+C.journals+")",now.journals===C.journals,now.journals!==C.journals?"now "+now.journals:"");
      add("Every account balance matches the backup",!diffs.length,diffs.length?diffs.slice(0,6).map(k=>k+": "+(C.balances[k]||0)+" → "+(now.balances[k]||0)).join("; "):"");
      add("Stock quantities and values match the backup",canonical(C.stock)===canonical(now.stock),"")}
    else add("Control totals",true,"This older backup has no control totals; records and books were checked instead.");
    out.ok=out.checks.every(x=>x.ok)}
  catch(e){add("Reading the store back",false,"couldn't read the store ("+(e&&e.code||"error")+") — the restore is NOT verified")}
  logEvent(out.ok?"info":"error",out.ok?"restore-verified":"restore-not-verified",{failed:out.checks.filter(x=>!x.ok).map(x=>x.label).slice(0,6)});
  audit("restore-verify","backup",{ok:out.ok,failed:out.checks.filter(x=>!x.ok).length});return out}
function showRestoreResult(v,ok,bad,stop){
  openModal(v.ok?"Restore verified":"Restore NOT verified",[],`<p>${v.ok?`<b class="pos">The restore is complete and verified.</b> ${ok} records were restored; everything below passed.`:`<b class="neg">Don't rely on these books yet.</b> ${ok} records were written${bad?`, ${bad} failed`:""}${stop?` — ${esc(stop)}`:""}, but the checks below did not all pass.`}</p>
    <table><tbody>${v.checks.map(c=>`<tr><td>${c.ok?'<span class="pos">✓</span>':'<span class="neg">✗</span>'}</td><td>${esc(c.label)}${c.detail?`<div class="muted" style="font-size:12px">${esc(c.detail)}</div>`:""}</td></tr>`).join("")}</tbody></table>`,{kind:"restore"});
  $("#mBtns").innerHTML="";const b=document.createElement("button");b.className="btn";b.textContent="Close";b.onclick=closeModal;$("#mBtns").appendChild(b)}

/* ---- Health screen ---- */
function renderHealth(){const el=$("#hlBody");if(!el)return;try{renderMonitoring()}catch(e){console.error(e)}const ago=t=>t?Math.round((Date.now()-t)/1000)+" s ago":"never";
  const L=loaded?ledger():null;const stale=staleMsg();
  const rows=[["Connection to your records",!db?"Preview (no store)":HEALTH.offline?`<b class="neg">Unreachable</b> since ${esc(localStamp(new Date(HEALTH.downSince).toISOString()))}`:RECONNECTING.size?`<b class="neg">Reconnecting</b> (${esc([...RECONNECTING].join(", "))})`:`<b class="pos">Live</b>`],
    ["Last server check",HEALTH.lastOk?ago(HEALTH.lastOk)+(HEALTH.lastLatency!=null?` · ${HEALTH.lastLatency} ms`:""):"not yet"],
    ["Saving",stale?`<b class="neg">Paused</b> — ${esc(stale)}`:writesBlocked()?`<b class="neg">Paused</b> — ${esc(writesBlocked())}`:`<b class="pos">Allowed</b>`],
    ["Books check",L?(L.problems?`<b class="neg">${L.problems} problem${L.problems===1?"":"s"}</b> — see Accounts → Checks`:`<b class="pos">All checks pass</b> (${L.J.length} journal entries)`):"loading"],
    ["Store calls retried this session",String(HEALTH.retries)],["Saves confirmed by reading back after a timeout",String(HEALTH.landedAfterTimeout)],["Saves that gave up after retries",String(HEALTH.failedWrites)],
    ["Audit and error entries waiting to be written",String(AUDITQ.length+ERRQ.length)]];
  el.innerHTML=rows.map(r=>`<tr><td>${esc(r[0])}</td><td>${r[1]}</td></tr>`).join("");
  const ev=EVLOG.slice(-200).reverse();$("#hlLog").innerHTML=ev.length?ev.map(e=>`<tr><td class="mono" style="white-space:nowrap">${esc(e.ts.slice(11,19))}</td><td>${e.level==="error"?'<span class="neg">error</span>':e.level==="warn"?'<span class="wrn">warning</span>':"info"}</td><td>${esc(e.event)}</td><td class="muted">${esc(Object.entries(e).filter(([k])=>!["ts","level","event","user","view"].includes(k)).map(([k,v])=>k+"="+(typeof v==="object"?JSON.stringify(v):v)).join(" ").slice(0,220))}</td></tr>`).join(""):`<tr><td colspan="4" class="empty">No events in this session.</td></tr>`}
document.addEventListener("click",e=>{const t=e.target;if(!t||!t.id)return;
  if(t.id==="hlCheck"){heartbeat().then(()=>renderAll())}
  if(t.id==="hlDown"){save("irongrid-events-"+today()+".json",JSON.stringify({exportedAt:nowISO(),health:HEALTH,events:EVLOG},null,1))}});
