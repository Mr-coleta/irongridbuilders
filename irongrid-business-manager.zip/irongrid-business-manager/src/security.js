/* ====================== security: roles, approvals, audit log, encrypted backups ======================
   Who may do what is decided by the storage platform's own rules (security/rules.json, declared with the app),
   not by this page. The platform refuses, for everyone except the owner, any write to payments, refunds,
   credit notes, stock adjustments, business details (banking details, month-end lock) and approval records.
   This page only mirrors those rules so people see "Submit for approval" instead of a refusal.
   - Anyone else who can write raises a REQUEST, kept under their own requests/<their id> record, which the platform
     lets only them (and the owner) change, so the requester is the platform's own identity, not a claim.
   - The owner reviews the request in the normal form, with every usual check, and posts it. An approval record
     approvals/<coll>-<id> (or -<id>-void) is written beside every approved posting and void. Only the owner can
     write approval records, so the Checks screen can show any posting or void that went round the approval.
   - Every save, change, delete, request and decision is appended to the person's own audit log
     audit/<their id>/days/<date>; nobody else can change it, and only the owner can read everyone's. */
const OWNER_ONLY=new Set(["payments","refunds","credits","adjustments"]);
let isOwnerUser=true,APPROVING=null,APPROVE_NEXT=null;
const SEC={approvals:new Map(),requests:new Map(),myRequests:[],auditUsers:[],audit:new Map(),loaded:false};
const needsApproval=coll=>OWNER_ONLY.has(coll)&&!isOwnerUser;
const REQ_LABEL={payments:"Payment",refunds:"Refund",credits:"Credit note",adjustments:"Stock adjustment",void:"Void",settings:"Business details change"};
const reqDecision=rid=>SEC.approvals.get("rq-"+rid)||null;
function reqAmount(q){const d=q.data||{};if(q.type==="void"){const r=byId(q.coll,q.docId);return r?(r.amount!=null?r.amount:calc(r).total):null}
  if(d.amount!=null)return d.amount;if(d.items){const c=calc(d);return c.err?null:c.total}if(d.value!=null)return d.value;return null}
function reqSummary(q){const d=q.data||{};
  if(q.type==="void"){const r=byId(q.coll,q.docId);return"Void "+NAMES[q.coll].toLowerCase()+" "+(r?r.number:"(deleted)")+(d.reason?" — "+d.reason:"")}
  if(q.type==="settings"){return"Change "+Object.keys(d).map(k=>({payDetails:"banking / payment details",lockDate:"month-end lock date",name:"business name",tin:"TIN",address:"address",phone:"phone",email:"email"}[k]||k)).join(", ")}
  if(q.coll==="payments")return"Pay "+(d.supplierId?nameOf("suppliers",d.supplierId):(d.payee||"—"))+" · "+(d.category||"")+" · "+(d.method||"");
  if(q.coll==="refunds")return"Refund "+(d.clientId?"to "+nameOf("clients",d.clientId):"from "+nameOf("suppliers",d.supplierId))+" · "+(d.method||"");
  if(q.coll==="credits"){const i=byId("invoices",d.invoiceId);return"Credit note against "+(i?i.number:"invoice")+(d.reason?" — "+d.reason:"")}
  if(q.coll==="adjustments")return"Stock "+(d.qty>0?"+":"")+d.qty+" "+itemName(d.itemId)+(d.reason?" — "+d.reason:"");return REQ_LABEL[q.coll]||q.coll}

/* ---- raising a request (anyone but the owner) ---- */
async function raiseRequest(type,coll,data,ctx){if(!db||!myId){toast("Requests need a signed-in account. Reload the page.");return false}
  const clean=JSON.parse(JSON.stringify(data||{}));delete clean.je;delete clean.jr;delete clean.number;delete clean.stockItems;
  const q={rid:newId(),type,coll,data:clean,...(ctx||{}),by:myId,at:nowISO()};
  const ref=db.doc("requests/"+myId);let ok=false;
  for(let i=0;i<8&&!ok;i++){let res;try{res=await withTimeout(ref.acquire({holder:HOLDER,ttlMs:15000}),8000)}catch(e){await sleep(300);continue}
    if(!res||!res.acquired){await sleep(400+Math.random()*400);continue}
    try{const s=await withTimeout(ref.get(),8000);const cur=s.exists?(s.data()||{}):{};const list=Array.isArray(cur.list)?cur.list.filter(x=>x&&x.rid):[];
      /* keep the record small: drop decided requests older than 60 days */
      const cutoff=new Date(Date.now()-60*864e5).toISOString();const keep=list.filter(x=>!reqDecision(x.rid)||str(x.at)>cutoff);
      keep.push(q);await withRetry(()=>ref.set({list:keep,by:myId,updatedAt:nowISO()}),{ctx:{op:"set",path:"requests/"+myId}});ok=true;SEC.myRequests=keep}
    catch(e){handleWriteErr(e);return false}finally{releaseLater("requests/"+myId,ref)}}
  if(!ok){toast("Couldn't submit the request — please try again.");return false}
  audit("request",coll+(ctx&&ctx.docId?"/"+ctx.docId:""),{type,amount:reqAmount(q),summary:reqSummary(q)});
  toast((REQ_LABEL[type==="void"?"void":type==="settings"?"settings":coll]||"Request")+" sent to the owner for approval. Nothing is posted until it's approved.");renderAll();return true}
async function withdrawRequest(rid){if(!db||!myId)return;const ref=db.doc("requests/"+myId);
  const res=await withTimeout(ref.acquire({holder:HOLDER,ttlMs:15000}),8000).catch(()=>null);if(!res||!res.acquired){toast("Busy — try again in a moment.");return}
  try{const s=await withTimeout(ref.get(),8000);const list=((s.exists&&s.data().list)||[]).filter(x=>x&&x.rid!==rid);await withRetry(()=>ref.set({list,by:myId,updatedAt:nowISO()}),{ctx:{op:"set",path:"requests/"+myId}});SEC.myRequests=list;audit("withdraw","requests/"+rid,{});toast("Request withdrawn")}
  catch(e){handleWriteErr(e)}finally{releaseLater("requests/"+myId,ref)}renderAll()}

/* ---- the owner's decisions ---- */
function approveRequest(q){if(!isOwnerUser)return;if(reqDecision(q.rid)){toast("This request was already decided.");return}
  const d=q.data||{};APPROVE_NEXT={rid:q.rid,by:q.by,type:q.type,coll:q.coll,docId:q.docId||null};
  if(q.type==="void"){if(!byId(q.coll,q.docId)){APPROVE_NEXT=null;toast("That document no longer exists.");return}startVoid(q.coll,q.docId,d);return}
  if(q.type==="settings"){APPROVE_NEXT=null;APPROVING={rid:q.rid,by:q.by,type:"settings",coll:"settings",docId:"business"};location.hash="settings";
    setTimeout(()=>{const f=$("#fSettings");Object.entries(d).forEach(([k,v])=>{if(f[k])f[k].value=v??""});settingsDirty=true;settingsBase=str(settings.updatedAt);
      toast("The requested changes are filled in. Check them, then press Save to approve.")},250);return}
  if(q.coll==="payments"){openEditor("payments",null,{...d});return}
  if(q.coll==="refunds"){openRefund(d.clientId?"clients":"suppliers",d.clientId||d.supplierId,d);return}
  if(q.coll==="credits"){openCreditNote(d.invoiceId,d);return}
  if(q.coll==="adjustments"){openAdjust(d.itemId,d);return}APPROVE_NEXT=null}
function rejectRequest(q){if(!isOwnerUser)return;
  openModal("Reject request",[],`<form id="rj" autocomplete="off"><p>${esc(reqSummary(q))}${reqAmount(q)!=null?" · <b>"+money(reqAmount(q))+"</b>":""}</p><label>Reason *</label><input name="reason" required maxlength="300"><div class="actions"><button type="button" class="btn ghost" id="rjNo">Cancel</button><button class="btn red" type="submit">Reject</button></div></form>`,{kind:"edit"});
  $("#mBtns").innerHTML="";const f=$("#rj");f.reason.focus();$("#rjNo").onclick=closeModal;
  f.addEventListener("submit",async e=>{e.preventDefault();if(!f.reportValidity())return;const rec={rid:q.rid,decision:"rejected",reason:f.reason.value.trim(),requestedBy:q.by,type:q.type,coll:q.coll,docId:q.docId||null,summary:reqSummary(q),amount:reqAmount(q),by:myId||"",at:nowISO()};
    try{await withRetry(()=>db.doc("approvals/rq-"+q.rid).set(rec),{ctx:{op:"set",path:"approvals/rq-"+q.rid}});SEC.approvals.set("rq-"+q.rid,rec);audit("reject","requests/"+q.rid,{summary:rec.summary,reason:rec.reason});closeModal();toast("Request rejected");renderAll()}catch(err){handleWriteErr(err)}})}

/* ---- called by put/patch after every successful write: approval records + audit trail ---- */
async function secAfterWrite(op,coll,id,data,isNew){
  const isVoid=op==="patch"&&data&&data.void===true;const sensitive=(op==="put"&&isNew&&OWNER_ONLY.has(coll)&&data&&data.je)||isVoid;
  let rid=null;
  if(sensitive&&db&&isOwnerUser){const A=APPROVING&&APPROVING.coll===coll&&(!isVoid||APPROVING.docId===id)?APPROVING:null;APPROVING=null;
    const key=coll+"-"+id+(isVoid?"-void":"");const r=byId(coll,id)||data||{};
    const rec={kind:isVoid?"void":"post",coll,docId:id,number:str(r.number),amount:r.amount!=null?r.amount:(r.items?calc(r).total:r.value??null),requestId:A?A.rid:null,requestedBy:A?A.by:(myId||""),by:myId||"",at:nowISO(),...(isVoid?{reason:str(data.voidReason)}:{})};
    try{await withRetry(()=>db.doc("approvals/"+key).set(rec),{ctx:{op:"set",path:"approvals/"+key}});SEC.approvals.set(key,rec);
      if(A){rid=A.rid;const dec={rid:A.rid,decision:"approved",requestedBy:A.by,type:A.type,coll,docId:id,posted:coll+"/"+id,number:rec.number,amount:rec.amount,by:myId||"",at:rec.at};
        await withRetry(()=>db.doc("approvals/rq-"+A.rid).set(dec),{ctx:{op:"set",path:"approvals/rq-"+A.rid}});SEC.approvals.set("rq-"+A.rid,dec)}}
    catch(e){console.error(e);toast("Posted, but the approval record couldn't be saved. Open Accounts → Checks and use 'Record approval'.")}}
  const r=byId(coll,id)||{};audit(op==="put"?(isNew?"create":"save"):op==="remove"?"delete":isVoid?"void":"update",coll+"/"+id,{no:str(r.number||(data&&data.number)||""),amount:r.amount!=null?r.amount:(r.items&&!r.err?calc(r).total:undefined),fields:op==="patch"&&data?Object.keys(data).filter(k=>k!=="updatedAt"&&k!=="updatedBy").slice(0,8):undefined,approved:rid||undefined})}
async function recordMissingApproval(coll,id,isVoid){if(!isOwnerUser||!db)return;const r=byId(coll,id);if(!r)return;
  askConfirm("Record that you approve "+(isVoid?"the void of ":"")+NAMES[coll].toLowerCase()+" "+r.number+"? Only do this if you have checked it.",async()=>{
    const key=coll+"-"+id+(isVoid?"-void":"");const rec={kind:isVoid?"void":"post",coll,docId:id,number:str(r.number),amount:r.amount!=null?r.amount:calc(r).total,requestId:null,requestedBy:str(isVoid?r.voidedBy:r.createdBy),by:myId||"",at:nowISO(),late:true};
    try{await withRetry(()=>db.doc("approvals/"+key).set(rec),{ctx:{op:"set",path:"approvals/"+key}});SEC.approvals.set(key,rec);audit("approve-late",coll+"/"+id,{no:rec.number});invalidate();renderAll();toast("Approval recorded")}catch(e){handleWriteErr(e)}},"Record approval")}
/* integrity: every owner-only posting and every void must have an owner-written approval record */
function approvalIssues(E){if(!SEC.loaded)return;
  for(const c of OWNER_ONLY)for(const r of S[c])if(r.je&&!SEC.approvals.has(c+"-"+r.id))E(c,r,"was posted without an approval record — it did not go through approval.");
  for(const c of LEDGER.DOC_COLLS)for(const r of S[c])if(r.void&&!SEC.approvals.has(c+"-"+r.id+"-void"))E(c,r,"was voided without an approval record — the void did not go through approval.")}

/* ---- audit log: each person appends to their own day record; batched every few seconds ---- */
const AUDITQ=[];let auditT=0,auditMarked=false;
function audit(act,ref,info){if(!db||!myId)return;const e={at:nowISO(),act,ref};const cid=monCid();if(cid)e.cid=cid;if(info)for(const [k,v] of Object.entries(info))if(v!==undefined&&v!==null&&v!=="")e[k]=v;AUDITQ.push(e);if(!auditT)auditT=setTimeout(flushAudit,1500)}
async function flushAudit(){auditT=0;if(!AUDITQ.length||!db||!myId)return;const batch=AUDITQ.splice(0,AUDITQ.length);const day=today();const ref=db.doc("audit/"+myId+"/days/"+day);
  try{const res=await withTimeout(ref.acquire({holder:HOLDER,ttlMs:10000}),8000);if(!res||!res.acquired)throw{code:"busy"};
    const s=await withTimeout(ref.get(),8000);const ev=s.exists&&Array.isArray(s.data().events)?s.data().events.slice():[];ev.push(...batch);
    await withRetry(()=>ref.set({events:ev.slice(-1500),day}),{ctx:{op:"set",path:"audit/"+myId+"/days/"+day}});releaseLater("audit/"+myId+"/days/"+day,ref);monJob("auditFail",true);
    if(!auditMarked){auditMarked=true;await withRetry(()=>db.doc("audit/"+myId).set({last:nowISO()})).catch(()=>{auditMarked=false})}}
  catch(e){monJob("auditFail",false);AUDITQ.unshift(...batch);if(AUDITQ.length>2000)AUDITQ.splice(0,AUDITQ.length-2000);auditT=setTimeout(flushAudit,5000)}}
window.addEventListener("pagehide",()=>{if(AUDITQ.length)flushAudit()});

/* ---- live data for approvals and requests ---- */
function secBoot(){if(!db)return;
  db.collection("approvals").onSnapshot(snap=>{const m=new Map();for(const x of snap.docs){const d=x.data();if(d)m.set(x.id,d)}SEC.approvals=m;SEC.loaded=!snap.metadata.fromCache||SEC.loaded;invalidate();renderAll()},err=>console.error(err));
  if(isOwnerUser){db.collection("requests").onSnapshot(snap=>{const m=new Map();for(const x of snap.docs){const d=x.data();if(d&&Array.isArray(d.list))m.set(x.id,d.list.filter(q=>q&&q.rid&&q.by===x.id))}SEC.requests=m;renderAll()},err=>console.error(err))}
  else if(myId){db.doc("requests/"+myId).onSnapshot(s=>{SEC.myRequests=s.exists&&Array.isArray(s.data().list)?s.data().list:[];renderAll()},err=>console.error(err))}}
function pendingRequests(){const out=[];if(isOwnerUser){for(const [uid,list] of SEC.requests)for(const q of list)if(!reqDecision(q.rid))out.push({...q,by:uid})}else for(const q of SEC.myRequests)if(!reqDecision(q.rid))out.push(q);return out.sort((a,b)=>str(a.at)<str(b.at)?-1:1)}

/* ---- screens ---- */
let PROFILES={};async function names(ids){try{const u=await claude.use("user");if(u&&u.profiles){const p=await u.profiles([...new Set(ids)].filter(Boolean));PROFILES={...PROFILES,...p}}}catch(e){}}
const who=uid=>uid===myId?"You":(PROFILES[uid]&&PROFILES[uid].name)||"Staff member "+String(uid||"?").slice(-4);
function renderApprovals(){const pend=pendingRequests();const el=$("#apList");
  const c=$("#c-approvals");if(c)c.textContent=pend.length||"";
  if(!el)return;const ids=pend.map(q=>q.by);if(ids.some(i=>!PROFILES[i]))names(ids).then(()=>{if(view==="approvals")renderAll()});
  $("#apIntro").textContent=isOwnerUser?"Requests from your staff. Approving opens the normal form, filled in, so every usual check runs before anything is posted.":"Your requests. Payments, refunds, credit notes, stock adjustments, voids and business-detail changes are posted only after the owner approves them.";
  el.innerHTML=pend.length?pend.map(q=>`<tr data-rid="${esc(q.rid)}"><td>${esc(localStamp(q.at))}</td><td>${esc(who(q.by))}</td><td>${esc(reqSummary(q))}</td><td class="num">${reqAmount(q)!=null?money(reqAmount(q)):""}</td><td style="white-space:nowrap">${isOwnerUser?`<button class="btn small" data-ap="ok">Review &amp; approve</button> <button class="btn ghost small" data-ap="no">Reject</button>`:`<button class="btn ghost small" data-ap="wd">Withdraw</button>`}</td></tr>`).join(""):`<tr><td colspan="5" class="empty">${SEC.loaded||!db?"No requests waiting.":"Loading…"}</td></tr>`;
  const dec=[...SEC.approvals.entries()].filter(([k,v])=>k.startsWith("rq-")&&(isOwnerUser||v.requestedBy===myId)).map(([k,v])=>v).sort((a,b)=>str(b.at)<str(a.at)?-1:1).slice(0,50);
  $("#apDone").innerHTML=dec.length?dec.map(v=>`<tr><td>${esc(localStamp(v.at))}</td><td>${esc(who(v.requestedBy))}</td><td>${esc(v.summary||(REQ_LABEL[v.type==="void"?"void":v.coll]||"")+(v.number?" "+v.number:""))}</td><td class="num">${v.amount!=null?money(v.amount):""}</td><td>${v.decision==="approved"?`<span class="pos">Approved</span>${v.posted?` · <span class="link" data-c="${esc(String(v.posted).split("/")[0])}" data-id="${esc(String(v.posted).split("/")[1])}">${esc(v.number||"open")}</span>`:""}`:`<span class="neg">Rejected</span>${v.reason?" — "+esc(v.reason):""}`}</td></tr>`).join(""):`<tr><td colspan="5" class="empty">Nothing decided yet.</td></tr>`}
async function renderAudit(){const el=$("#auList");if(!el)return;if(!isOwnerUser){el.innerHTML=`<tr><td colspan="5" class="empty">Only the owner can read the audit log.</td></tr>`;return}
  if(!db){el.innerHTML=`<tr><td colspan="5" class="empty">Not available in preview.</td></tr>`;return}
  const days=+($("#auDays").value||7);const since=ymd(new Date(Date.now()-(days-1)*864e5));
  try{const us=await withTimeout(db.collection("audit").get(),10000);const rows=[];
    await Promise.all(us.docs.map(async u=>{const q=await withTimeout(db.collection("audit/"+u.id+"/days").where("day",">=",since).get(),10000);for(const d of q.docs)for(const e of (d.data().events||[]))rows.push({...e,uid:u.id})}));
    await names(rows.map(r=>r.uid));rows.sort((a,b)=>str(b.at)<str(a.at)?-1:1);
    el.innerHTML=rows.length?rows.slice(0,1000).map(r=>`<tr><td>${esc(localStamp(r.at))}</td><td>${esc(who(r.uid))}</td><td>${esc(r.act)}</td><td>${esc(r.no?r.no+" ":"")}<span class="muted">${esc(r.ref)}</span>${r.summary?" — "+esc(r.summary):""}${r.reason?" — "+esc(r.reason):""}${r.fields?" <span class='muted'>("+esc([].concat(r.fields).join(", "))+")</span>":""}</td><td class="num">${typeof r.amount==="number"?money(r.amount):""}</td></tr>`).join(""):`<tr><td colspan="5" class="empty">No activity in this period.</td></tr>`}
  catch(e){console.error(e);el.innerHTML=`<tr><td colspan="5" class="empty">The audit log couldn't be loaded. Try again.</td></tr>`}}

/* ---- passphrase-protected backups (AES-256-GCM, key from PBKDF2-SHA-256, 600,000 rounds); the passphrase is never stored ---- */
const B64=b=>{let s="";const a=new Uint8Array(b);for(let i=0;i<a.length;i+=32768)s+=String.fromCharCode.apply(null,a.subarray(i,i+32768));return btoa(s)};
const UB64=s=>Uint8Array.from(atob(s),c=>c.charCodeAt(0));
async function bkKey(pass,salt){const k=await crypto.subtle.importKey("raw",new TextEncoder().encode(pass),"PBKDF2",false,["deriveKey"]);
  return crypto.subtle.deriveKey({name:"PBKDF2",salt,iterations:600000,hash:"SHA-256"},k,{name:"AES-GCM",length:256},false,["encrypt","decrypt"])}
async function encryptBackup(text,pass){const salt=crypto.getRandomValues(new Uint8Array(16)),iv=crypto.getRandomValues(new Uint8Array(12));const key=await bkKey(pass,salt);
  const ct=await crypto.subtle.encrypt({name:"AES-GCM",iv},key,new TextEncoder().encode(text));
  return JSON.stringify({app:"business-manager",encrypted:"AES-256-GCM",kdf:"PBKDF2-SHA-256",iterations:600000,salt:B64(salt),iv:B64(iv),data:B64(ct)})}
async function decryptBackup(o,pass){if(o.encrypted!=="AES-256-GCM"||o.kdf!=="PBKDF2-SHA-256"||o.iterations!==600000)throw new Error("unsupported");
  const key=await bkKey(pass,UB64(o.salt));const pt=await crypto.subtle.decrypt({name:"AES-GCM",iv:UB64(o.iv)},key,UB64(o.data));return new TextDecoder().decode(pt)}
function askPassphrase(title,msg){return new Promise(res=>{openModal(title,[],`<form id="pp" autocomplete="off"><p>${esc(msg)}</p><label>Passphrase</label><input name="p" type="password" required autocomplete="off"><div class="actions"><button type="button" class="btn ghost" id="ppNo">Cancel</button><button class="btn" type="submit">Continue</button></div></form>`,{kind:"edit"});
  $("#mBtns").innerHTML="";const f=$("#pp");f.p.focus();$("#ppNo").onclick=()=>{closeModal();res(null)};f.addEventListener("submit",e=>{e.preventDefault();const v=f.p.value;closeModal();res(v)})})}

/* fills the opened form with the request being approved and says so at the top */
function prefillApproval(){const A=APPROVING;if(!A)return;const f=$("#mBody form");if(!f)return;let q=null;for(const [uid,list] of SEC.requests)for(const x of list)if(x.rid===A.rid)q=x;if(!q)return;const d=q.data||{};
  for(const k of ["date","amount","method","reference","reason","notes","payee","category","qty","value"])if(d[k]!=null&&f[k]&&f[k].type!=="file"){f[k].value=d[k]}
  const p=document.createElement("p");p.className="box";p.textContent="Approving a request from "+who(q.by)+" sent "+localStamp(q.at)+". Check it, change anything that's wrong, then save to approve and post it.";f.prepend(p);
  const b=f.querySelector("[type=submit]");if(b)b.textContent="Approve and post"}
const pendingVoid=(coll,id)=>pendingRequests().some(q=>q.type==="void"&&q.coll===coll&&q.docId===id);
let auditView=0;
document.addEventListener("click",e=>{const t=e.target;
  const ap=t.closest&&t.closest("[data-ap]");if(ap){const rid=ap.closest("tr").dataset.rid;const q=pendingRequests().find(x=>x.rid===rid);if(!q)return;
    if(ap.dataset.ap==="ok")approveRequest(q);else if(ap.dataset.ap==="no")rejectRequest(q);else if(ap.dataset.ap==="wd")askConfirm("Withdraw this request?",()=>withdrawRequest(rid),"Withdraw");return}
  const rc=t.closest&&t.closest("[data-recap]");if(rc){e.stopPropagation();const [c,id,v]=rc.dataset.recap.split("|");recordMissingApproval(c,id,v==="1");return}
  const lk=t.closest&&t.closest("#apDone .link[data-c]");if(lk){showDoc(lk.dataset.c,lk.dataset.id)}},true);
$("#auRefresh").onclick=()=>renderAudit();$("#auDays").onchange=()=>renderAudit();
