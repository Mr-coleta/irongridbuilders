/* ====================== report index: fast, exact reports from the journals ======================
   The original report functions (LEDGER.trialBalance, profitLoss, ...) scan every journal line on every call.
   This module builds, once per change of the books, an index over the same journals:
     - for every account: the journal lines sorted by (date, posting time, original order) with a running balance,
       and per-day cumulative debit, credit and line counts (prefix sums);
     - the same per (account, journal kind) for the VAT return, per (account, party) for client and supplier balances,
       per (inventory item) for stock quantity and value, and per (cash-flow category) for the cash flow statement.
   A report for any period is then a handful of binary searches: total(from..to) = total(..to) − total(..before from).
   Exactness: amounts are whole minor units (shillings or cents). Every running total is checked to stay a safe
   integer; if one ever would not, the build stops with an error instead of rounding. Nothing is filtered out:
   every line of every journal goes into the index, and its line count is checked against the journals.
   Period cutoffs are inclusive dates (YYYY-MM-DD) exactly as in the original functions; a void's reversal counts
   on its own date. Every function returns the same shape and the same figures as the original it replaces. */
const REPORTS=(()=>{
"use strict";
const LG=typeof LEDGER!=="undefined"?LEDGER:require("./ledger.js");
const ACC=LG.ACC,CASH_ACCTS=LG.CASH_ACCTS;
const ORDER=Object.keys(ACC);
function chk(x){if(!Number.isSafeInteger(x))throw new Error("A report total is too large to add up exactly; the report was not produced.");return x}
/* a running sum keyed by date: dates[] ascending, D[] C[] N[] cumulative debit, credit and line count up to and including dates[k] */
function series(){return{dates:[],D:[],C:[],N:[]}}
function addTo(s,date,d,c){const k=s.dates.length-1;if(k>=0&&s.dates[k]===date){s.D[k]=chk(s.D[k]+d);s.C[k]=chk(s.C[k]+c);s.N[k]++;return}
  const pd=k>=0?s.D[k]:0,pc=k>=0?s.C[k]:0,pn=k>=0?s.N[k]:0;s.dates.push(date);s.D.push(chk(pd+d));s.C.push(chk(pc+c));s.N.push(pn+1)}
/* index of the last date <= x (or < x when strict); -1 if none */
function upto(dates,x,strict){let lo=0,hi=dates.length-1,r=-1;while(lo<=hi){const m=(lo+hi)>>1;if(strict?dates[m]<x:dates[m]<=x){r=m;lo=m+1}else hi=m-1}return r}
function sumTo(s,to){if(!s)return{d:0,c:0,n:0};const k=to?upto(s.dates,to,false):s.dates.length-1;return k<0?{d:0,c:0,n:0}:{d:s.D[k],c:s.C[k],n:s.N[k]}}
function sumBefore(s,from){if(!s||!from)return{d:0,c:0,n:0};const k=upto(s.dates,from,true);return k<0?{d:0,c:0,n:0}:{d:s.D[k],c:s.C[k],n:s.N[k]}}
function range(s,from,to){const a=sumTo(s,to),b=sumBefore(s,from);return{d:a.d-b.d,c:a.c-b.c,n:a.n-b.n}}
const kindOf=pid=>pid.startsWith("payments/")?"pay":/^(purchases|sdebits)\//.test(pid)?"pur":"oth";
const NORMAL_DR=a=>{const t=ACC[a]&&ACC[a][1];return t==="asset"||t==="expense"};
/* cash-flow category of one journal, from the non-cash lines it pairs with */
function cfCategory(lines){const other=new Set();for(const l of lines)if(!CASH_ACCTS.includes(l.a))other.add(l.a);
  if(!other.size)return"transfer";if(other.size>1)return"mixed";const a=[...other][0];
  if(a==="1100")return"customers";if(a==="2000")return"suppliers";if(a==="2100")return"vat";if(a==="2300")return"loans";if(a==="3000")return"capital";if(a==="3200")return"drawings";
  if(ACC[a]&&ACC[a][1]==="expense")return"exp:"+a;if(ACC[a]&&ACC[a][1]==="income")return"inc:"+a;return"other:"+a}

/* ---------- building the index (all at once, or in slices so a page never freezes) ---------- */
function newIndex(J){return{J,acct:new Map(),kind:new Map(),party:new Map(),item:new Map(),cf:new Map(),gl:new Map(),lines:0,journals:0,built:false}}
function addJournal(ix,j,order){ix.journals++;const kind=kindOf(j.pid);let hasCash=false,cash=0;
  for(let li=0;li<j.lines.length;li++){const l=j.lines[li];ix.lines++;
    let e=ix.gl.get(l.a);if(!e){e=[];ix.gl.set(l.a,e)}e.push({date:j.date,at:j.at,o:order,li,pid:j.pid,d:l.d,c:l.c,p:l.p||"",i:l.i||""});
    if(CASH_ACCTS.includes(l.a)){hasCash=true;cash=chk(cash+l.d-l.c)}
    if(l.a==="1200"&&l.i){let s=ix.item.get(l.i);if(!s){s={rows:[]};ix.item.set(l.i,s)}s.rows.push([j.date,l.q||0,l.d-l.c])}}
  if(hasCash){const cat=cfCategory(j.lines);let s=ix.cf.get(cat);if(!s){s={rows:[]};ix.cf.set(cat,s)}s.rows.push([j.date,cash])}}
function finish(ix){
  for(const [a,rows] of ix.gl){rows.sort((x,y)=>x.date<y.date?-1:x.date>y.date?1:x.at<y.at?-1:x.at>y.at?1:x.o-y.o||x.li-y.li);
    const s=series(),bal=new Array(rows.length);let b=0;const nd=NORMAL_DR(a);const ks=new Map(),ps=new Map();
    for(let k=0;k<rows.length;k++){const r=rows[k];addTo(s,r.date,r.d,r.c);b=chk(b+(nd?r.d-r.c:r.c-r.d));bal[k]=b;
      const kk=kindOf(r.pid);let x=ks.get(kk);if(!x){x=series();ks.set(kk,x)}addTo(x,r.date,r.d,r.c);
      if(r.p){let y=ps.get(r.p);if(!y){y=series();ps.set(r.p,y)}addTo(y,r.date,r.d,r.c)}}
    ix.acct.set(a,s);ix.kind.set(a,ks);ix.party.set(a,ps);ix.gl.set(a,{rows,bal})}
  for(const [i,o] of ix.item){o.rows.sort((x,y)=>x[0]<y[0]?-1:x[0]>y[0]?1:0);const s={dates:[],Q:[],V:[]};let q=0,v=0;
    for(const [d,dq,dv] of o.rows){q=chk(q+dq);v=chk(v+dv);const k=s.dates.length-1;if(k>=0&&s.dates[k]===d){s.Q[k]=q;s.V[k]=v}else{s.dates.push(d);s.Q.push(q);s.V.push(v)}}ix.item.set(i,s)}
  for(const [c,o] of ix.cf){o.rows.sort((x,y)=>x[0]<y[0]?-1:x[0]>y[0]?1:0);const s=series();for(const [d,amt] of o.rows)addTo(s,d,amt>0?amt:0,amt<0?-amt:0);ix.cf.set(c,s)}
  /* completeness: every journal line is in the account index exactly once */
  let n=0;for(const s of ix.acct.values())n+=s.N.length?s.N[s.N.length-1]:0;
  const want=ix.J.reduce((t,j)=>t+j.lines.length,0);if(n!==want||ix.lines!==want)throw new Error("Report index is incomplete ("+n+" of "+want+" lines); the report was not produced.");
  ix.built=true;return ix}
function buildIndex(J){const ix=newIndex(J);for(let k=0;k<J.length;k++)addJournal(ix,J[k],k);return finish(ix)}
/* same result, built in slices of `step` journals with a pause between, so the page stays responsive */
async function buildIndexAsync(J,step,pause){const ix=newIndex(J);step=step||5000;for(let k=0;k<J.length;k+=step){const e=Math.min(J.length,k+step);for(let i=k;i<e;i++)addJournal(ix,J[i],i);await pause()}return finish(ix)}

/* ---------- reports (same shapes and figures as LEDGER.trialBalance, profitLoss, balanceSheet, vatReturn, partyBalances, generalLedger) ---------- */
function balances(ix,from,to){const b={};for(const [a,s] of ix.acct){const r=from?range(s,from,to):sumTo(s,to);if(r.n>0)b[a]={d:r.d,c:r.c}}return b}
function trialBalance(ix,to){const b=balances(ix,null,to);const rows=ORDER.filter(a=>b[a]).map(a=>{const n=b[a].d-b[a].c;return{a,name:ACC[a][0],type:ACC[a][1],dr:n>0?n:0,cr:n<0?-n:0}});
  const dr=chk(rows.reduce((t,r)=>t+r.dr,0)),cr=chk(rows.reduce((t,r)=>t+r.cr,0));return{rows,dr,cr,ok:dr===cr}}
function profitLoss(ix,from,to){const b=balances(ix,from,to);const inc=[],exp=[];
  for(const a of ORDER){if(!b[a])continue;const t=ACC[a][1];if(t==="income")inc.push({a,name:ACC[a][0],amt:b[a].c-b[a].d});if(t==="expense")exp.push({a,name:ACC[a][0],amt:b[a].d-b[a].c})}
  const ti=inc.reduce((t,r)=>t+r.amt,0),te=exp.reduce((t,r)=>t+r.amt,0);
  const cos=exp.filter(r=>r.a==="5000"||r.a==="5100").reduce((t,r)=>t+r.amt,0);const sales=(inc.find(r=>r.a==="4000")||{amt:0}).amt;
  return{inc,exp,ti,te,gross:sales-cos,net:ti-te}}
function balanceSheet(ix,to){const b=balances(ix,null,to);const sec={asset:[],liability:[],equity:[]};let earn=0;
  for(const a of ORDER){if(!b[a])continue;const t=ACC[a][1];const n=b[a].d-b[a].c;
    if(t==="asset")sec.asset.push({a,name:ACC[a][0],amt:n});else if(t==="liability")sec.liability.push({a,name:ACC[a][0],amt:-n});else if(t==="equity")sec.equity.push({a,name:ACC[a][0],amt:-n});else earn+=-n}
  const A=sec.asset.reduce((t,r)=>t+r.amt,0),Li=sec.liability.reduce((t,r)=>t+r.amt,0),E=sec.equity.reduce((t,r)=>t+r.amt,0)+earn;
  return{asset:sec.asset,liability:sec.liability,equityLines:sec.equity,earnings:earn,assets:A,liabilities:Li,equity:E,ok:A===Li+E}}
function kr(ix,a,k,from,to){const m=ix.kind.get(a);const s=m&&m.get(k);return s?range(s,from,to):{d:0,c:0,n:0}}
function vatReturn(ix,from,to){const sum=(a,ks)=>ks.reduce((t,k)=>{const r=kr(ix,a,k,from,to);return{d:t.d+r.d,c:t.c+r.c}},{d:0,c:0});
  const v2=sum("2100",["pur","oth"]),vp=sum("2100",["pay"]),i13=sum("1300",["pay","pur","oth"]),s40=sum("4000",["pay","pur","oth"]),p20=sum("2000",["pur"]),p13=sum("1300",["pur"]);
  const out=v2.c-v2.d,inp=i13.d-i13.c;return{outputVat:out,inputVat:inp,netVat:out-inp,sales:s40.c-s40.d,purchases:(p20.c-p20.d)-(p13.d-p13.c),paidToURA:vp.d-vp.c}}
function partyBalances(ix,acct,to){const m=new Map();const ps=ix.party.get(acct);if(!ps)return m;for(const [p,s] of ps){const r=sumTo(s,to);if(r.n>0)m.set(p,acct==="1100"?r.d-r.c:r.c-r.d)}return m}
/* general ledger, a page at a time: rows in [from,to] in posting order, each with the account's running balance */
function glSpan(ix,acct,from,to){const g=ix.gl.get(acct);if(!g)return{g:null,lo:0,hi:-1};const ds=g.rows;
  let lo=0,hi=ds.length-1;if(from){let a=0,b=ds.length;while(a<b){const m=(a+b)>>1;if(ds[m].date<from)a=m+1;else b=m}lo=a}
  if(to){let a=-1,b=ds.length-1;while(a<b){const m=(a+b+1)>>1;if(ds[m].date<=to)a=m;else b=m-1}hi=a}return{g,lo,hi}}
function glCount(ix,acct,from,to){const {lo,hi}=glSpan(ix,acct,from,to);return Math.max(0,hi-lo+1)}
function generalLedgerPage(ix,acct,from,to,offset,limit){const {g,lo,hi}=glSpan(ix,acct,from,to);if(!g)return[];const a=lo+Math.max(0,offset||0),b=Math.min(hi,a+(limit||500)-1);const out=[];
  for(let k=a;k<=b;k++){const r=g.rows[k];out.push({date:r.date,pid:r.pid,d:r.d,c:r.c,bal:g.bal[k],p:r.p,i:r.i})}return out}
/* balance brought forward into a period (or a page): the running balance just before its first row */
function glOpening(ix,acct,from,offset){const {g,lo}=glSpan(ix,acct,from,null);if(!g)return 0;const k=lo+(offset||0)-1;return k>=0?g.bal[k]:0}
function generalLedger(ix,acct,from,to){return generalLedgerPage(ix,acct,from,to,0,1e15)}
/* ---------- receivables / payables ageing at a date ----------
   Per party, from the control-account lines up to the date in posting order: amounts that increase what is owed
   (debits on 1100, credits on 2000) are open items dated on their journal date; amounts that reduce it are applied
   to the oldest open items first. What is left is aged by days from its date to the as-at date. A party whose
   reductions exceed what it owed shows the excess as an unapplied credit (a negative amount), never dropped.
   Each party's total equals its ledger balance, and the grand total equals the control account. */
const DAY=86400000;const dnum=d=>Date.UTC(+d.slice(0,4),+d.slice(5,7)-1,+d.slice(8,10))/DAY;
const BUCKETS=["current","1-30","31-60","61-90","90+"];
function bucketOf(days){return days<=0?0:days<=30?1:days<=60?2:days<=90?3:4}
function ageing(ix,acct,to){const g=ix.gl.get(acct);const asAt=to||(g&&g.rows.length?g.rows[g.rows.length-1].date:"1970-01-01");
  const {hi}=glSpan(ix,acct,null,to);const per=new Map();const sign=acct==="1100"?1:-1;
  for(let k=0;k<=hi;k++){const r=g.rows[k];if(!r.p)continue;let o=per.get(r.p);if(!o){o={open:[],credit:0};per.set(r.p,o)}
    let amt=sign*(r.d-r.c);if(amt>0){/* first use any unapplied credit */if(o.credit>0){const u=Math.min(o.credit,amt);o.credit-=u;amt-=u}if(amt>0)o.open.push({date:r.date,amt})}
    else if(amt<0){let left=-amt;while(left>0&&o.open.length){const it=o.open[0];const u=Math.min(it.amt,left);it.amt-=u;left-=u;if(!it.amt)o.open.shift()}o.credit=chk(o.credit+left)}}
  const rows=[];const tot=[0,0,0,0,0];let unapplied=0;const A=dnum(asAt);
  for(const [p,o] of per){const b=[0,0,0,0,0];for(const it of o.open)b[bucketOf(A-dnum(it.date))]+=it.amt;const total=b.reduce((t,x)=>t+x,0)-o.credit;
    if(!total&&!o.credit&&!o.open.length)continue;for(let i=0;i<5;i++)tot[i]+=b[i];unapplied+=o.credit;rows.push({p,b,credit:o.credit,total})}
  rows.sort((x,y)=>y.total-x.total||(x.p<y.p?-1:1));const total=tot.reduce((t,x)=>t+x,0)-unapplied;
  const ctl=sumTo(ix.acct.get(acct),to);const control=acct==="1100"?ctl.d-ctl.c:ctl.c-ctl.d;
  const untagged=control-total;return{asAt,buckets:BUCKETS,rows,totals:tot,unapplied,total,control,untagged,ok:untagged===0}}
/* ---------- inventory valuation at a date: quantity and value per item from the inventory lines ---------- */
function stockAt(ix,to){const out={};for(const [i,s] of ix.item){const k=to?upto(s.dates,to,false):s.dates.length-1;if(k>=0)out[i]={q:s.Q[k],v:s.V[k]}}return out}
/* ---------- cash flow statement (direct method) from the cash accounts ---------- */
function cashFlow(ix,from,to){const cash=a=>{const s=ix.acct.get(a);return s};let open=0,close=0;
  for(const a of CASH_ACCTS){const s=cash(a);if(!s)continue;const b=sumBefore(s,from),e=sumTo(s,to);open+=b.d-b.c;close+=e.d-e.c}
  const cats=[];for(const [k,s] of ix.cf){const r=from?range(s,from,to):sumTo(s,to);if(r.n>0)cats.push({key:k,inflow:r.d,outflow:r.c,net:r.d-r.c,count:r.n})}
  cats.sort((x,y)=>x.key<y.key?-1:1);const net=cats.reduce((t,c)=>t+c.net,0);return{opening:open,closing:close,net,cats,ok:open+net===close}}
return{ageing,BUCKETS,buildIndex,buildIndexAsync,trialBalance,profitLoss,balanceSheet,vatReturn,partyBalances,generalLedger,generalLedgerPage,glCount,glOpening,stockAt,cashFlow,balances,cfCategory}})();
if(typeof module!=="undefined")module.exports=REPORTS;
